# SHA256-LEARN-R : Pure-R ASIC Machine-Learning Optimization & Digital Twin Engine

`SHA256-LEARN-R` is a pure-R machine-learning research, telemetry, and autonomous optimization platform for SHA-256 Application-Specific Integrated Circuit (ASIC) architectures.

The purpose of the system is to investigate whether statistical machine learning and reinforcement learning algorithms can continuously learn how to configure and operate a massive parallel SHA-256 ASIC mining architecture more efficiently—increasing successful SHA-256 hash throughput per second while minimizing power dissipation, junction temperatures, latency, and wasted compute cycles.

> **CRITICAL SCIENTIFIC & SAFETY PRINCIPLE**:
> This is an abstract semiconductor design-space exploration and digital twin simulator. It does **NOT** weaken SHA-256, predict Bitcoin blocks, modify cryptocurrency consensus, or bypass cryptographic security. The ML system learns how to schedule and physically operate silicon hardware (DVFS, core gating, pipeline occupancy), not break mathematical hashing.

---

## 📁 Project Structure

```
SHA256-LEARN-R/
├── R/
│   ├── sha256_core.R           # 100% Pure-R FIPS 180-4 SHA-256 cryptographic ground truth
│   ├── sha256_pipeline.R       # Deep hardware pipeline simulation (64 stages, stalls, bubbles)
│   ├── asic_model.R            # Abstract multi-core ASIC architecture & constraint checker
│   ├── mining_workload.R       # Stratum job generation, header packing & nonce partitioning
│   ├── hardware_state.R        # Normalized state vector & discrete action space (DVFS, gating)
│   ├── power_model.R           # Dynamic switching, leakage (FinFET temperature model), clock power
│   ├── thermal_model.R         # RC thermodynamic junction temperature & cooling model
│   ├── scheduler.R             # Multi-core dispatch & core gating policies
│   ├── telemetry.R             # Sub-millisecond sensor telemetry capture & data.frame buffer
│   ├── feature_engineering.R   # Rolling windows (5/10/50/100 cycles), gradients, volatility
│   ├── ml_model.R              # Linear Regression, Random Forest, Gradient Boosting, MLP Neural Net
│   ├── reinforcement_learning.R# Q-Learning agent, epsilon-greedy exploration, multi-objective reward
│   ├── optimisation_engine.R   # Surrogate search, Pareto optimality & non-dominated frontiers
│   ├── anomaly_detection.R     # Over-temp, power spike, and pipeline stall anomaly flagging
│   ├── model_selection.R       # Cross-validation, RMSE, MAE, R^2, and inference speed comparison
│   ├── experiment_engine.R     # End-to-end digital twin trajectory runner & online learning
│   ├── benchmark_engine.R      # Tri-state comparison: Baseline vs Overclock vs ML-Optimized
│   └── main.R                  # Master executable script
├── tests/
│   └── test_sha256.R           # NIST test vectors and unit test suites
├── results/                    # Exported telemetry CSVs, Pareto frontiers, and benchmarks
└── README.md
```

---

## 🚀 Quick Start (Running in R)

Execute the complete end-to-end machine learning and ASIC simulation experiment directly with:

```bash
Rscript R/main.R
```

Or within an interactive R session:

```r
source("R/main.R")
```

---

## 🧪 Core Research Capabilities

1. **SHA-256 Cryptographic Reference Core (`R/sha256_core.R`)**:
   - Bitwise 32-bit unsigned arithmetic (`add32`, `rotr32`, `sha256_ch`, `sha256_maj`, $\Sigma_0$, $\Sigma_1$, $\sigma_0$, $\sigma_1$).
   - 64 compression rounds and standard round constants $K$.
   - Midstate caching for first 64-byte block chunks.
   - Verified against NIST FIPS 180-4 test vectors.

2. **Silicon Physics & Thermal Model (`R/power_model.R`, `R/thermal_model.R`)**:
   - Dynamic switching power: $P_{dyn} = C_{eff} \cdot V^2 \cdot f \cdot N_{active} \cdot U_{pipe}$
   - Temperature-dependent sub-threshold leakage power ($I_{leak}(T_j)$).
   - Dynamic RC thermal junction heating and heatsink dissipation: $\frac{dT_j}{dt} = \frac{P_{total} - (T_j - T_{ambient})/R_{\theta}}{C_{th}}$.

3. **Multi-Model Machine Learning Engine (`R/ml_model.R`, `R/model_selection.R`)**:
   - **Model A (Linear Regression)**: Fast multi-target OLS with analytic standard error intervals.
   - **Model B (Random Forest)**: Ensemble tree regressor with bagging and split-reduction feature importance.
   - **Model C (Gradient Boosting)**: Sequential residual fitting for non-linear saturation curves.
   - **Model D (Neural Network)**: Multi-layer perceptron with He initialization, LeakyReLU, and backpropagation.
   - **Model E (Reinforcement Learning)**: Deep/Tabular Q-learning with multi-objective reward formulation and $\epsilon$-greedy exploration decay.

4. **Multi-Objective Pareto Optimisation (`R/optimisation_engine.R`)**:
   - Non-dominated Pareto frontier extraction over hashrate vs. power vs. thermal junction temperatures.
   - Autonomous parameter discovery beyond conventional manual overclock limits.

5. **Hardware Safety Envelopes**:
   - Strict validation preventing unphysical, destructive, or over-volt configurations from entering valid candidate sets.
