import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import {
  DEFAULT_ASIC_CONFIG,
  runSimulationTrajectory,
  runParetoOptimization,
  runComparativeBenchmark,
  evaluateMLModels,
  detectAnomalies
} from './src/simulator/asicEngine.js';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API 1: Health
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      engine: 'SHA256-LEARN-R',
      version: '1.0.0-research',
      timestamp: Date.now()
    });
  });

  // API 2: Run Simulation
  app.post('/api/simulate', (req, res) => {
    try {
      const config = { ...DEFAULT_ASIC_CONFIG, ...(req.body.asic || {}) };
      const iterations = req.body.iterations || 80;
      const objective = req.body.objective || 'BALANCED_PERFORMANCE';

      const telemetry = runSimulationTrajectory(config, iterations, objective);
      const latest = telemetry[telemetry.length - 1];
      const anomaly = latest ? detectAnomalies(latest, config) : null;

      res.json({
        success: true,
        config,
        telemetry,
        anomaly
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // API 3: Optimize ASIC
  app.post('/api/optimize', (req, res) => {
    try {
      const config = { ...DEFAULT_ASIC_CONFIG, ...(req.body.asic || {}) };
      const objective = req.body.objective || 'MAXIMUM_EFFICIENCY';

      const result = runParetoOptimization(config, objective);
      res.json({
        success: true,
        result
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // API 4: Comparative Benchmark
  app.post('/api/benchmark', (req, res) => {
    try {
      const config = { ...DEFAULT_ASIC_CONFIG, ...(req.body.asic || {}) };
      const solution = req.body.solution;
      const benchmark = runComparativeBenchmark(config, solution);

      res.json({
        success: true,
        benchmark
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // API 5: ML Models & Feature Importance
  app.get('/api/ml-models', (req, res) => {
    try {
      const data = evaluateMLModels();
      res.json({
        success: true,
        ...data
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // API 6: Inspect R Source Code Files
  app.get('/api/r-files', (req, res) => {
    try {
      const rDir = path.join(process.cwd(), 'R');
      const files: any[] = [];

      if (fs.existsSync(rDir)) {
        const filenames = fs.readdirSync(rDir);
        for (const fname of filenames) {
          if (fname.endsWith('.R')) {
            const fpath = path.join(rDir, fname);
            const content = fs.readFileSync(fpath, 'utf8');
            files.push({
              filename: fname,
              path: `R/${fname}`,
              category: fname.startsWith('sha256') ? 'Cryptographic Core' : (fname.includes('model') ? 'ML & Physics' : 'Execution & Engine'),
              description: content.split('\n').slice(0, 5).join(' ').replace(/#/g, '').trim(),
              content
            });
          }
        }
      }

      // Add README and Test file
      if (fs.existsSync(path.join(process.cwd(), 'README.md'))) {
        files.push({
          filename: 'README.md',
          path: 'README.md',
          category: 'Documentation',
          description: 'Project scientific overview, quick-start, and architecture documentation.',
          content: fs.readFileSync(path.join(process.cwd(), 'README.md'), 'utf8')
        });
      }

      if (fs.existsSync(path.join(process.cwd(), 'tests', 'test_sha256.R'))) {
        files.push({
          filename: 'test_sha256.R',
          path: 'tests/test_sha256.R',
          category: 'Unit Tests',
          description: 'FIPS PUB 180-4 reference test vectors and midstate assertions.',
          content: fs.readFileSync(path.join(process.cwd(), 'tests', 'test_sha256.R'), 'utf8')
        });
      }

      res.json({
        success: true,
        files
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SHA256-LEARN-R server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
