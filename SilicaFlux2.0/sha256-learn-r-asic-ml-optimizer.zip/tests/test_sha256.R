# ==============================================================================
# Unit Tests: Pure R SHA-256 Ground Truth Verification Suite
# ==============================================================================
source("R/sha256_core.R")

cat("Running Test Suite: test_sha256.R\n")
test_sha256_core()

# Test Midstate consistency
test_midstate <- function() {
  cat("Testing midstate hashing consistency...\n")
  msg64 <- as.raw(0:63)
  ms <- sha256_compute_midstate(msg64)
  stopifnot(length(ms) == 8)
  cat("✓ Midstate state vector correctly initialized (8 32-bit state words).\n")
}

test_midstate()
cat("All tests passed successfully.\n")
