import React, { useState } from 'react';
import { FileCode, Copy, Check, Download, Search, ExternalLink, Terminal } from 'lucide-react';
import { RFileContent } from '../types';

interface RCodeViewerProps {
  files: RFileContent[];
  onExportZip: () => void;
}

export const RCodeViewer: React.FC<RCodeViewerProps> = ({ files, onExportZip }) => {
  const [selectedFile, setSelectedFile] = useState<RFileContent | null>(files[0] || null);
  const [searchTerm, setSearchTerm] = useState('');
  const [copied, setCopied] = useState(false);

  // Update selected if files load asynchronously
  React.useEffect(() => {
    if (!selectedFile && files.length > 0) {
      setSelectedFile(files[0]);
    }
  }, [files, selectedFile]);

  const filteredFiles = files.filter(
    (f) =>
      f.filename.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCopy = () => {
    if (selectedFile) {
      navigator.clipboard.writeText(selectedFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadSingle = () => {
    if (!selectedFile) return;
    const blob = new Blob([selectedFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = selectedFile.filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 text-white rounded-xl p-5 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-mono font-bold text-emerald-400">100% PURE R ENGINE SOURCE</span>
          </div>
          <h2 className="text-base font-bold">SHA256-LEARN-R Modular R Codebase</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            17 pure-R research modules. Zero Python/Rust/CUDA dependencies. Run via <code className="text-slate-200 bg-slate-800 px-1.5 py-0.5 rounded font-mono">Rscript R/main.R</code>
          </p>
        </div>

        <button
          onClick={onExportZip}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Download All Files (.zip)</span>
        </button>
      </div>

      {/* Main Code Explorer Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left Sidebar: File List */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs flex flex-col h-[650px]">
          <div className="relative mb-3">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Filter R modules..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="overflow-y-auto space-y-1 flex-1 pr-1">
            {filteredFiles.map((file) => {
              const isSelected = selectedFile?.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-colors flex items-start gap-2 cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-50 text-indigo-900 border border-indigo-200 font-semibold'
                      : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <FileCode className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${isSelected ? 'text-indigo-600' : 'text-slate-400'}`} />
                  <div className="overflow-hidden">
                    <div className="truncate font-mono text-[11px]">{file.filename}</div>
                    <div className="text-[10px] text-slate-400 truncate">{file.category}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Pane: Code Viewer */}
        <div className="lg:col-span-3 bg-slate-950 rounded-xl border border-slate-800 shadow-md flex flex-col h-[650px] overflow-hidden">
          {/* Code Viewer Header */}
          <div className="bg-slate-900 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileCode className="w-4 h-4 text-indigo-400" />
              <span className="font-mono text-xs font-semibold text-slate-200">
                {selectedFile ? selectedFile.path : 'Select an R file'}
              </span>
              {selectedFile && (
                <span className="px-2 py-0.5 bg-slate-800 text-slate-400 rounded text-[10px]">
                  {selectedFile.category}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs transition-colors cursor-pointer"
                title="Copy code to clipboard"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>

              <button
                onClick={handleDownloadSingle}
                className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs transition-colors cursor-pointer"
                title="Download this file"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Save</span>
              </button>
            </div>
          </div>

          {/* Code Content with Line Numbers */}
          <div className="flex-1 overflow-auto p-4 font-mono text-[11px] text-slate-300 leading-relaxed bg-slate-950">
            {selectedFile ? (
              <table className="w-full border-collapse">
                <tbody>
                  {selectedFile.content.split('\n').map((line, idx) => (
                    <tr key={idx} className="hover:bg-slate-900/60">
                      <td className="text-slate-600 select-none pr-4 text-right align-top w-10 font-mono text-[10px]">
                        {idx + 1}
                      </td>
                      <td className="text-slate-300 whitespace-pre font-mono">
                        {line || ' '}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="text-slate-500 text-center mt-20">Select a file from the explorer to view source.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
