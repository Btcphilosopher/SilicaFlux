import React from 'react';
import { Cpu, Layers, Activity, AlertTriangle, ArrowRight } from 'lucide-react';
import { ASICConfig, TelemetryPoint } from '../types';

interface PipelineInspectorProps {
  asic: ASICConfig;
  latestTelemetry: TelemetryPoint | null;
}

export const PipelineInspector: React.FC<PipelineInspectorProps> = ({
  asic,
  latestTelemetry
}) => {
  const stages = asic.stagesPerPipeline; // 64 stages
  const occupancy = latestTelemetry ? latestTelemetry.pipelineUtilisation : 0.85;

  // Generate visual representations for sample pipeline blocks
  const sampleRounds = [
    { label: 'W[0..15]', desc: 'Direct Message Words', stage: 'Stage 1-16', active: true },
    { label: 'W[16..63]', desc: 'Message Schedule Expansion', stage: 'Stage 17-64', active: true },
    { label: 'Ch / Maj / Σ', desc: 'Non-linear Compression Logic', stage: 'Rounds 0-63', active: true },
    { label: 'Digest Adder', desc: 'Modulo 2^32 State Accumulation', stage: 'Final Stage', active: true }
  ];

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-purple-600" />
          <h3 className="text-sm font-semibold text-slate-900">SHA-256 Deep Silicon Hardware Pipeline</h3>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-500 font-medium">Pipeline Depth:</span>
          <span className="font-mono font-bold text-slate-800">{stages} Stages (Unrolled)</span>
        </div>
      </div>

      {/* Stage Flow Visualizer */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-5">
        {sampleRounds.map((round, idx) => (
          <div key={idx} className="bg-slate-50 border border-slate-200 rounded-lg p-3 relative">
            <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono mb-1">
              <span>{round.stage}</span>
              <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse"></span>
            </div>
            <div className="text-xs font-bold text-slate-900">{round.label}</div>
            <div className="text-[10px] text-slate-500 mt-0.5">{round.desc}</div>
          </div>
        ))}
      </div>

      {/* Pipeline 64-Cell Micro Grid */}
      <div className="mb-4">
        <div className="flex justify-between text-xs text-slate-600 mb-1.5">
          <span className="font-medium">64-Stage Pipeline Compression Occupancy</span>
          <span className="font-mono text-purple-600 font-semibold">
            {latestTelemetry ? `${(latestTelemetry.pipelineUtilisation * 100).toFixed(1)}% Active` : '85.0% Active'}
          </span>
        </div>
        <div className="grid grid-cols-16 gap-1 p-2 bg-slate-900 rounded-lg">
          {Array.from({ length: 64 }).map((_, i) => {
            const isActive = (i / 64) < occupancy;
            return (
              <div
                key={i}
                title={`Stage ${i}: ${isActive ? 'Active Compute' : 'Idle / Bubble'}`}
                className={`h-4 rounded-xs transition-colors ${
                  isActive ? 'bg-indigo-500 shadow-2xs' : 'bg-slate-800'
                }`}
              />
            );
          })}
        </div>
        <div className="flex justify-between text-[10px] text-slate-400 mt-1">
          <span>Stage 0 (Input Midstate)</span>
          <span>Stage 31 (Halfway Round)</span>
          <span>Stage 63 (Digest Out)</span>
        </div>
      </div>

      {/* Pipeline Metrics Footer */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-100 text-xs">
        <div>
          <span className="text-slate-400 text-[10px] block">Pipeline Latency</span>
          <span className="font-mono font-semibold text-slate-800">
            {latestTelemetry ? `${latestTelemetry.latencyNs.toFixed(1)} ns` : '64.0 ns'}
          </span>
        </div>
        <div>
          <span className="text-slate-400 text-[10px] block">Accepted Nonce Rate</span>
          <span className="font-mono font-semibold text-emerald-600">99.2%</span>
        </div>
        <div>
          <span className="text-slate-400 text-[10px] block">Bubble Stall Overhead</span>
          <span className="font-mono font-semibold text-slate-800">1.2%</span>
        </div>
        <div>
          <span className="text-slate-400 text-[10px] block">Midstate Cache</span>
          <span className="font-mono font-semibold text-purple-600">Active (Block 1 Precomputed)</span>
        </div>
      </div>
    </div>
  );
};
