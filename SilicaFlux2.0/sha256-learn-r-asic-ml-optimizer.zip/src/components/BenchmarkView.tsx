import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend
} from 'recharts';
import { Zap, TrendingUp, Award, ShieldAlert, Cpu, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { BenchmarkOutput } from '../types';

interface BenchmarkViewProps {
  benchmark: BenchmarkOutput | null;
  onRunBenchmark: () => void;
  isRunning: boolean;
}

export const BenchmarkView: React.FC<BenchmarkViewProps> = ({
  benchmark,
  onRunBenchmark,
  isRunning
}) => {
  if (!benchmark) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-10 text-center shadow-2xs">
        <Zap className="w-8 h-8 text-amber-500 mx-auto mb-3" />
        <h3 className="text-base font-semibold text-slate-900 mb-1">Tri-State ASIC Benchmark</h3>
        <p className="text-xs text-slate-500 max-w-md mx-auto mb-4">
          Compare Factory Baseline against Heuristic Manual Overclocking and Autonomous ML-Optimized configurations.
        </p>
        <button
          onClick={onRunBenchmark}
          disabled={isRunning}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
        >
          {isRunning ? 'Running Benchmark...' : 'Run Comparative Benchmark'}
        </button>
      </div>
    );
  }

  const { table, summary } = benchmark;

  const chartData = table.map((row) => ({
    name: row.configuration.replace(/^\d+\.\s*/, ''),
    hashrate: parseFloat(row.hashrateGhs.toFixed(1)),
    power: parseFloat(row.powerWatts.toFixed(1)),
    temp: parseFloat(row.temperatureC.toFixed(1)),
    eff: parseFloat(row.efficiencyMhPerJ.toFixed(2))
  }));

  return (
    <div className="space-y-6">
      {/* Top Cards: Summary of ML Gains over Baseline */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Hashrate Improvement */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs flex items-center justify-between">
          <div>
            <div className="text-xs font-medium text-slate-500">Hashrate Throughput</div>
            <div className="text-xl font-bold font-mono text-indigo-600 mt-0.5 flex items-center gap-1">
              <span>{summary.hashrateImprovementPct >= 0 ? `+${summary.hashrateImprovementPct.toFixed(1)}%` : `${summary.hashrateImprovementPct.toFixed(1)}%`}</span>
              <ArrowUpRight className="w-4 h-4 text-emerald-500" />
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">vs. Factory Baseline</div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 2: Energy Efficiency */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs flex items-center justify-between">
          <div>
            <div className="text-xs font-medium text-slate-500">Energy Efficiency (H/J)</div>
            <div className="text-xl font-bold font-mono text-emerald-600 mt-0.5 flex items-center gap-1">
              <span>{summary.efficiencyImprovementPct >= 0 ? `+${summary.efficiencyImprovementPct.toFixed(1)}%` : `${summary.efficiencyImprovementPct.toFixed(1)}%`}</span>
              <ArrowUpRight className="w-4 h-4 text-emerald-500" />
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">More hashes per Joule</div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600">
            <Award className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 3: Power Delta */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs flex items-center justify-between">
          <div>
            <div className="text-xs font-medium text-slate-500">Power Consumption</div>
            <div className="text-xl font-bold font-mono text-slate-800 mt-0.5 flex items-center gap-1">
              <span>{summary.powerDeltaPct >= 0 ? `+${summary.powerDeltaPct.toFixed(1)}%` : `${summary.powerDeltaPct.toFixed(1)}%`}</span>
              <Zap className="w-4 h-4 text-amber-500" />
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">Under power cap</div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center text-amber-600">
            <Zap className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 4: Junction Temp Delta */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs flex items-center justify-between">
          <div>
            <div className="text-xs font-medium text-slate-500">Thermal Junction Δ</div>
            <div className="text-xl font-bold font-mono text-slate-800 mt-0.5 flex items-center gap-1">
              <span>{summary.temperatureDeltaC >= 0 ? `+${summary.temperatureDeltaC.toFixed(1)} °C` : `${summary.temperatureDeltaC.toFixed(1)} °C`}</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">Safe thermal envelope</div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center text-slate-700">
            <Cpu className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Main Table: Side-by-Side Comparison */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">Tri-Configuration Silicon Performance Matrix</h2>
            <p className="text-xs text-slate-500">Benchmark results sampled under steady-state thermal equilibrium</p>
          </div>
          <button
            onClick={onRunBenchmark}
            disabled={isRunning}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md text-xs font-semibold transition-colors cursor-pointer"
          >
            Re-run Benchmark
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-semibold bg-slate-50/70">
                <th className="py-2.5 px-3">Configuration</th>
                <th className="py-2.5 px-3">Clock (MHz)</th>
                <th className="py-2.5 px-3">Voltage (V)</th>
                <th className="py-2.5 px-3">Hashrate (GH/s)</th>
                <th className="py-2.5 px-3">Power (W)</th>
                <th className="py-2.5 px-3">Junction Temp (°C)</th>
                <th className="py-2.5 px-3">Efficiency (MH/J)</th>
                <th className="py-2.5 px-3">Energy (nJ/hash)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {table.map((row, idx) => (
                <tr key={idx} className={idx === 2 ? 'bg-indigo-50/40 font-semibold' : ''}>
                  <td className="py-3 px-3 font-sans font-medium text-slate-900 flex items-center gap-1.5">
                    {idx === 2 && <Award className="w-3.5 h-3.5 text-indigo-600" />}
                    <span>{row.configuration}</span>
                  </td>
                  <td className="py-3 px-3 text-slate-700">{row.frequencyMhz.toFixed(0)}</td>
                  <td className="py-3 px-3 text-slate-700">{row.voltageV.toFixed(3)}</td>
                  <td className="py-3 px-3 text-indigo-600 font-bold">{row.hashrateGhs.toFixed(2)}</td>
                  <td className="py-3 px-3 text-slate-700">{row.powerWatts.toFixed(1)}</td>
                  <td className="py-3 px-3 text-slate-700">{row.temperatureC.toFixed(1)}</td>
                  <td className="py-3 px-3 text-emerald-600 font-bold">{row.efficiencyMhPerJ.toFixed(2)}</td>
                  <td className="py-3 px-3 text-slate-600">{row.energyNjPerHash.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bar Chart Comparison */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
        <h3 className="text-sm font-semibold text-slate-900 mb-4">Hashrate vs. Power vs. Efficiency Comparison</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="name" stroke="#64748b" fontSize={11} />
              <YAxis stroke="#64748b" fontSize={11} />
              <Tooltip />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
              <Bar dataKey="hashrate" name="Hashrate (GH/s)" fill="#4f46e5" radius={[4, 4, 0, 0]} />
              <Bar dataKey="power" name="Power Dissipation (W)" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              <Bar dataKey="eff" name="Efficiency (MH/J)" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
