import React from 'react';
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  Cell
} from 'recharts';
import { Gauge, Sparkles, CheckCircle2, ArrowRight, ShieldCheck, Zap } from 'lucide-react';
import { OptimizationResult, ASICConfig } from '../types';

interface ParetoOptimizerViewProps {
  optimizationResult: OptimizationResult | null;
  onApplyOptimal: (solution: OptimizationResult) => void;
  onReoptimize: () => void;
  asic: ASICConfig;
}

export const ParetoOptimizerView: React.FC<ParetoOptimizerViewProps> = ({
  optimizationResult,
  onApplyOptimal,
  onReoptimize,
  asic
}) => {
  if (!optimizationResult) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-10 text-center shadow-2xs">
        <Sparkles className="w-8 h-8 text-indigo-600 mx-auto mb-3" />
        <h3 className="text-base font-semibold text-slate-900 mb-1">Autonomous Pareto Search Ready</h3>
        <p className="text-xs text-slate-500 max-w-md mx-auto mb-4">
          Explore the multi-dimensional design space to discover non-dominated trade-offs between SHA-256 hashrate, power dissipation, and thermal headroom.
        </p>
        <button
          onClick={onReoptimize}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
        >
          Launch Pareto Optimization
        </button>
      </div>
    );
  }

  const paretoPoints = optimizationResult.paretoFrontier.map((p) => ({
    power: parseFloat(p.powerWatts.toFixed(1)),
    hashrate: parseFloat(p.hashrateGhs.toFixed(1)),
    temp: parseFloat(p.temperatureC.toFixed(1)),
    eff: parseFloat((p.hashesPerJoule / 1e6).toFixed(2)),
    freq: p.frequencyMhz,
    volt: p.voltageV,
    isPareto: p.isPareto
  }));

  const nonDominatedCount = paretoPoints.filter((p) => p.isPareto).length;

  return (
    <div className="space-y-6">
      {/* Top Banner: Discovered Optimal Operating Point */}
      <div className="bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-xl p-6 shadow-md border border-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2 py-0.5 text-[10px] font-mono font-semibold bg-emerald-500/20 text-emerald-300 rounded border border-emerald-500/30">
                OPTIMAL PARETO SOLUTION FOUND
              </span>
              <span className="text-xs text-slate-400">Objective: {optimizationResult.objective}</span>
            </div>
            <h2 className="text-lg font-bold tracking-tight">Autonomous ASIC Configuration Recommendation</h2>
            <p className="text-xs text-slate-300 mt-0.5">
              Discovered non-dominated balance between hashing throughput, sub-threshold leakage, and dynamic power.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onReoptimize}
              className="px-3.5 py-2 bg-white/10 hover:bg-white/15 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
            >
              Re-scan Space
            </button>
            <button
              onClick={() => onApplyOptimal(optimizationResult)}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 rounded-lg text-xs font-bold transition-colors shadow-xs cursor-pointer"
            >
              <span>Apply to Digital Twin</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-5 pt-4 border-t border-slate-800">
          <div className="bg-white/5 rounded-lg p-3 border border-white/10">
            <div className="text-[11px] text-slate-400">Optimal Frequency</div>
            <div className="text-base font-bold font-mono text-white mt-0.5">
              {(optimizationResult.optimalFrequency / 1e6).toFixed(0)} MHz
            </div>
          </div>
          <div className="bg-white/5 rounded-lg p-3 border border-white/10">
            <div className="text-[11px] text-slate-400">Optimal Voltage</div>
            <div className="text-base font-bold font-mono text-white mt-0.5">
              {optimizationResult.optimalVoltage.toFixed(3)} V
            </div>
          </div>
          <div className="bg-white/5 rounded-lg p-3 border border-white/10">
            <div className="text-[11px] text-slate-400">Predicted Hashrate</div>
            <div className="text-base font-bold font-mono text-emerald-400 mt-0.5">
              {optimizationResult.predictedHashrateGhs.toFixed(1)} GH/s
            </div>
          </div>
          <div className="bg-white/5 rounded-lg p-3 border border-white/10">
            <div className="text-[11px] text-slate-400">Predicted Power</div>
            <div className="text-base font-bold font-mono text-amber-300 mt-0.5">
              {optimizationResult.predictedPowerWatts.toFixed(1)} W
            </div>
          </div>
          <div className="bg-white/5 rounded-lg p-3 border border-white/10">
            <div className="text-[11px] text-slate-400">Junction Temperature</div>
            <div className="text-base font-bold font-mono text-white mt-0.5">
              {optimizationResult.predictedTemperatureC.toFixed(1)} °C
            </div>
          </div>
          <div className="bg-white/5 rounded-lg p-3 border border-white/10">
            <div className="text-[11px] text-slate-400">Efficiency</div>
            <div className="text-base font-bold font-mono text-indigo-300 mt-0.5">
              {(optimizationResult.hashesPerJoule / 1e6).toFixed(2)} MH/J
            </div>
          </div>
        </div>
      </div>

      {/* Pareto Frontier Multi-Dimensional Chart */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Pareto Frontier: Hashrate (GH/s) vs. Power (W)
            </h3>
            <p className="text-xs text-slate-500">
              Green markers indicate non-dominated Pareto-optimal configurations ({nonDominatedCount} solutions discovered)
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
              <span className="text-slate-600">Pareto Frontier</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-300 inline-block"></span>
              <span className="text-slate-400">Dominated Points</span>
            </span>
          </div>
        </div>

        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                type="number"
                dataKey="power"
                name="Power"
                unit=" W"
                stroke="#94a3b8"
                fontSize={11}
                label={{ value: 'Power Dissipation (Watts)', position: 'insideBottom', offset: -10, fontSize: 11 }}
              />
              <YAxis
                type="number"
                dataKey="hashrate"
                name="Hashrate"
                unit=" GH/s"
                stroke="#94a3b8"
                fontSize={11}
                label={{ value: 'Hashrate (GH/s)', angle: -90, position: 'insideLeft', fontSize: 11 }}
              />
              <Tooltip
                cursor={{ strokeDasharray: '3 3' }}
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2.5 rounded-lg text-xs shadow-lg border border-slate-700">
                        <div className="font-semibold text-indigo-300 mb-1">
                          {data.freq} MHz @ {data.volt} V
                        </div>
                        <div>Hashrate: {data.hashrate} GH/s</div>
                        <div>Power: {data.power} W</div>
                        <div>Junction Temp: {data.temp} °C</div>
                        <div>Efficiency: {data.eff} MH/J</div>
                        <div className="mt-1 pt-1 border-t border-slate-700 font-bold">
                          {data.isPareto ? (
                            <span className="text-emerald-400">✓ Pareto Optimal</span>
                          ) : (
                            <span className="text-slate-400">Dominated</span>
                          )}
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Scatter name="ASIC Configurations" data={paretoPoints}>
                {paretoPoints.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.isPareto ? '#10b981' : '#cbd5e1'}
                    r={entry.isPareto ? 6 : 3.5}
                  />
                ))}
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
