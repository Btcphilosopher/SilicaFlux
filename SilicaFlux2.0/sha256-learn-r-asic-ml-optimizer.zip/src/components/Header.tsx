import React from 'react';
import { Cpu, Zap, Thermometer, Gauge, Activity, ShieldCheck, ShieldAlert, Sparkles, Download, Play, RefreshCw } from 'lucide-react';
import { ASICConfig, OptimizationObjective, AnomalyStatus } from '../types';

interface HeaderProps {
  asic: ASICConfig;
  setAsic: React.Dispatch<React.SetStateAction<ASICConfig>>;
  objective: OptimizationObjective;
  setObjective: (obj: OptimizationObjective) => void;
  anomaly: AnomalyStatus | null;
  isRunning: boolean;
  onRunSimulation: () => void;
  onExportZip: () => void;
  onOptimize: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  asic,
  setAsic,
  objective,
  setObjective,
  anomaly,
  isRunning,
  onRunSimulation,
  onExportZip,
  onOptimize,
  activeTab,
  setActiveTab
}) => {
  const tabs = [
    { id: 'twin', label: 'Digital Twin & Telemetry', icon: Activity },
    { id: 'ml', label: 'ML Models & Importance', icon: Sparkles },
    { id: 'pareto', label: 'Pareto Optimization', icon: Gauge },
    { id: 'benchmark', label: 'Tri-State Benchmark', icon: Zap },
    { id: 'r_code', label: 'Pure-R Source & Core', icon: Cpu }
  ];

  const getStatusBadge = () => {
    if (!anomaly || anomaly.status === 'NORMAL') {
      return (
        <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full text-xs font-semibold">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Silicon Healthy (Normal)</span>
        </div>
      );
    }
    if (anomaly.status === 'WARNING') {
      return (
        <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-700 border border-amber-200 rounded-full text-xs font-semibold">
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>Headroom Warning</span>
        </div>
      );
    }
    return (
      <div className="flex items-center gap-1.5 px-3 py-1 bg-rose-50 text-rose-700 border border-rose-200 rounded-full text-xs font-semibold">
        <ShieldAlert className="w-3.5 h-3.5" />
        <span>Hardware Anomaly ({anomaly.status})</span>
      </div>
    );
  };

  return (
    <header className="border-b border-slate-200 bg-white/95 backdrop-blur-md sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-900 to-indigo-950 flex items-center justify-center text-white shadow-md">
              <Cpu className="w-6 h-6 text-indigo-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-slate-900">SHA256-LEARN-R</h1>
                <span className="px-2 py-0.5 text-[11px] font-mono font-medium tracking-wide bg-indigo-100 text-indigo-800 rounded">
                  ASIC ML OPTIMIZER
                </span>
                {getStatusBadge()}
              </div>
              <p className="text-xs text-slate-500">
                Pure-R Machine Learning Simulation & Hardware Optimization Engine
              </p>
            </div>
          </div>

          {/* Quick Action Controls */}
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg p-1 text-xs">
              <span className="text-slate-500 px-2 font-medium">Objective:</span>
              <select
                value={objective}
                onChange={(e) => setObjective(e.target.value as OptimizationObjective)}
                className="bg-white border border-slate-200 rounded px-2.5 py-1 text-slate-800 font-medium focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              >
                <option value="BALANCED_PERFORMANCE">Balanced Performance</option>
                <option value="MAXIMUM_EFFICIENCY">Max Efficiency (MH/J)</option>
                <option value="MAXIMUM_HASHRATE">Maximum Hashrate</option>
                <option value="THERMAL_CONSTRAINED">Thermal-Constrained</option>
                <option value="POWER_CONSTRAINED">Power-Constrained</option>
              </select>
            </div>

            <button
              onClick={onRunSimulation}
              disabled={isRunning}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            >
              {isRunning ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              <span>{isRunning ? 'Simulating...' : 'Run Simulation'}</span>
            </button>

            <button
              onClick={onOptimize}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Auto-Optimize</span>
            </button>

            <button
              onClick={onExportZip}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              title="Download full R project bundle (.zip)"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export R Bundle</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 mt-3 border-t border-slate-100 pt-2 overflow-x-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-indigo-50 text-indigo-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
