import React from 'react';
import { Cpu, Zap, Thermometer, Gauge, Clock, Shield } from 'lucide-react';
import { TelemetryPoint, ASICConfig } from '../types';

interface TelemetryCardsProps {
  telemetry: TelemetryPoint | null;
  asic: ASICConfig;
}

export const TelemetryCards: React.FC<TelemetryCardsProps> = ({ telemetry, asic }) => {
  if (!telemetry) return null;

  const cards = [
    {
      label: 'Effective Hashrate',
      value: `${telemetry.hashrateGhs.toFixed(2)} GH/s`,
      sub: `${(telemetry.hashrateGhs / 1000).toFixed(3)} TH/s throughput`,
      icon: Gauge,
      color: 'text-indigo-600',
      bg: 'bg-indigo-50/50',
      border: 'border-indigo-100'
    },
    {
      label: 'Power Dissipation',
      value: `${telemetry.powerWatts.toFixed(1)} W`,
      sub: `Headroom: ${telemetry.powerHeadroomW.toFixed(1)} W (Limit ${asic.powerLimit}W)`,
      icon: Zap,
      color: telemetry.powerWatts > asic.powerLimit * 0.9 ? 'text-amber-600' : 'text-emerald-600',
      bg: 'bg-slate-50',
      border: 'border-slate-200'
    },
    {
      label: 'Junction Temperature',
      value: `${telemetry.temperatureC.toFixed(1)} °C`,
      sub: `Thermal headroom: ${telemetry.thermalHeadroomC.toFixed(1)} °C (Max ${asic.temperatureLimit}°C)`,
      icon: Thermometer,
      color: telemetry.temperatureC > asic.temperatureLimit - 5 ? 'text-rose-600' : 'text-slate-800',
      bg: 'bg-slate-50',
      border: 'border-slate-200'
    },
    {
      label: 'Energy Efficiency',
      value: `${(telemetry.hashesPerJoule / 1e6).toFixed(2)} MH/J`,
      sub: `${telemetry.energyPerHashNj.toFixed(2)} nJ / SHA-256 hash`,
      icon: Shield,
      color: 'text-blue-600',
      bg: 'bg-blue-50/40',
      border: 'border-blue-100'
    },
    {
      label: 'Pipeline Utilisation',
      value: `${(telemetry.pipelineUtilisation * 100).toFixed(1)}%`,
      sub: `Core occupancy: ${(telemetry.coreUtilisation * 100).toFixed(0)}%`,
      icon: Cpu,
      color: 'text-purple-600',
      bg: 'bg-slate-50',
      border: 'border-slate-200'
    },
    {
      label: 'Operating Point',
      value: `${telemetry.frequencyMhz.toFixed(0)} MHz`,
      sub: `Rail voltage: ${telemetry.voltageV.toFixed(3)} V`,
      icon: Clock,
      color: 'text-slate-800',
      bg: 'bg-slate-50',
      border: 'border-slate-200'
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
      {cards.map((card, idx) => {
        const Icon = card.icon;
        return (
          <div
            key={idx}
            className={`p-3.5 rounded-xl border ${card.border} ${card.bg} flex flex-col justify-between shadow-2xs transition-all`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-medium text-slate-500 tracking-tight">{card.label}</span>
              <Icon className={`w-4 h-4 ${card.color}`} />
            </div>
            <div>
              <div className="text-lg font-bold tracking-tight text-slate-900 font-mono">{card.value}</div>
              <div className="text-[10px] text-slate-500 font-medium truncate mt-0.5">{card.sub}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
