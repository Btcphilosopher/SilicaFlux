import React from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  AreaChart,
  Area
} from 'recharts';
import { Sliders, Cpu, Zap, Thermometer, ShieldAlert, CheckCircle2, RefreshCw } from 'lucide-react';
import { ASICConfig, TelemetryPoint, HardwareLimitsCheck, AnomalyStatus } from '../types';
import { checkHardwareLimits } from '../simulator/asicEngine';

interface DigitalTwinViewProps {
  asic: ASICConfig;
  setAsic: React.Dispatch<React.SetStateAction<ASICConfig>>;
  telemetryHistory: TelemetryPoint[];
  anomaly: AnomalyStatus | null;
  onRunStep: () => void;
  isRunning: boolean;
}

export const DigitalTwinView: React.FC<DigitalTwinViewProps> = ({
  asic,
  setAsic,
  telemetryHistory,
  anomaly,
  onRunStep,
  isRunning
}) => {
  const limitsCheck = checkHardwareLimits(asic);

  const handleSliderChange = (field: keyof ASICConfig, value: number) => {
    setAsic((prev) => ({
      ...prev,
      [field]: value
    }));
  };

  const chartData = telemetryHistory.map((pt) => ({
    cycle: pt.cycle,
    hashrate: parseFloat(pt.hashrateGhs.toFixed(2)),
    power: parseFloat(pt.powerWatts.toFixed(1)),
    temp: parseFloat(pt.temperatureC.toFixed(1)),
    eff: parseFloat((pt.hashesPerJoule / 1e6).toFixed(2)),
    reward: pt.reward !== undefined ? parseFloat(pt.reward.toFixed(2)) : 0,
    voltage: parseFloat(pt.voltageV.toFixed(3)),
    frequency: parseFloat(pt.frequencyMhz.toFixed(0))
  }));

  return (
    <div className="space-y-6">
      {/* Top Grid: Hardware Parameter Controls & Constraint Envelope */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Controls Card */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-indigo-600" />
              <h2 className="text-sm font-semibold text-slate-900">ASIC Dynamic Voltage & Frequency (DVFS) Controls</h2>
            </div>
            <button
              onClick={onRunStep}
              disabled={isRunning}
              className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md text-xs font-semibold transition-colors cursor-pointer"
            >
              {isRunning ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
              <span>Step Telemetry</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Clock Frequency */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700">Clock Frequency</span>
                <span className="font-mono font-semibold text-indigo-600">{(asic.clockFrequency / 1e6).toFixed(0)} MHz</span>
              </div>
              <input
                type="range"
                min="400"
                max="1400"
                step="25"
                value={asic.clockFrequency / 1e6}
                onChange={(e) => handleSliderChange('clockFrequency', parseFloat(e.target.value) * 1e6)}
                className="w-full accent-indigo-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                <span>400 MHz (Safe min)</span>
                <span>1400 MHz (Silicon max)</span>
              </div>
            </div>

            {/* Core Voltage */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700">Core Rail Voltage</span>
                <span className="font-mono font-semibold text-indigo-600">{asic.voltage.toFixed(3)} V</span>
              </div>
              <input
                type="range"
                min="0.55"
                max="0.95"
                step="0.005"
                value={asic.voltage}
                onChange={(e) => handleSliderChange('voltage', parseFloat(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                <span>0.55 V (Low power)</span>
                <span>0.95 V (Max saturation)</span>
              </div>
            </div>

            {/* Core Count Scaling */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700">Physical Hashing Cores</span>
                <span className="font-mono font-semibold text-indigo-600">{asic.cores.toLocaleString()} cores</span>
              </div>
              <input
                type="range"
                min="10"
                max="5000"
                step="10"
                value={asic.cores}
                onChange={(e) => handleSliderChange('cores', parseInt(e.target.value, 10))}
                className="w-full accent-indigo-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                <span>10 cores (Micro test)</span>
                <span>5,000 cores (Macro ASIC)</span>
              </div>
            </div>

            {/* Active Parallelism */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700">Core Active Gating Factor</span>
                <span className="font-mono font-semibold text-indigo-600">{(asic.parallelism * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={asic.parallelism}
                onChange={(e) => handleSliderChange('parallelism', parseFloat(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                <span>10% Gated</span>
                <span>100% Fully Powered</span>
              </div>
            </div>
          </div>
        </div>

        {/* Safety & Constraint Status */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-100">
              <ShieldAlert className="w-4 h-4 text-slate-700" />
              <h2 className="text-sm font-semibold text-slate-900">Silicon Physical Constraints</h2>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                <span className="text-slate-600">Voltage Stability (V-f curve):</span>
                {limitsCheck.stabilityValid ? (
                  <span className="flex items-center gap-1 text-emerald-700 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Stable
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-rose-600 font-medium">
                    <ShieldAlert className="w-3.5 h-3.5" /> Under-volt Risk
                  </span>
                )}
              </div>

              <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                <span className="text-slate-600">Power Budget ({asic.powerLimit}W):</span>
                {limitsCheck.powerValid ? (
                  <span className="flex items-center gap-1 text-emerald-700 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Within Cap
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-rose-600 font-medium">
                    <ShieldAlert className="w-3.5 h-3.5" /> Exceeded
                  </span>
                )}
              </div>

              <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                <span className="text-slate-600">Junction Temp ({asic.temperatureLimit}°C):</span>
                {limitsCheck.temperatureValid ? (
                  <span className="flex items-center gap-1 text-emerald-700 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Normal
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-rose-600 font-medium">
                    <ShieldAlert className="w-3.5 h-3.5" /> Over-temp Throttling
                  </span>
                )}
              </div>
            </div>
          </div>

          {anomaly && anomaly.reasons.length > 0 && (
            <div className="mt-3 p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-800">
              <span className="font-semibold block mb-0.5">Telemetry Diagnostic:</span>
              <ul className="list-disc list-inside space-y-0.5">
                {anomaly.reasons.map((r, i) => (
                  <li key={i}>{r}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Telemetry Charts Bento */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Hashrate vs Power */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">Hashrate (GH/s) vs. Power Dissipation (W)</h3>
              <p className="text-xs text-slate-500">Live multi-cycle performance trajectory</p>
            </div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="cycle" stroke="#94a3b8" fontSize={11} />
                <YAxis yAxisId="left" stroke="#6366f1" fontSize={11} label={{ value: 'GH/s', angle: -90, position: 'insideLeft', fontSize: 10 }} />
                <YAxis yAxisId="right" orientation="right" stroke="#f59e0b" fontSize={11} label={{ value: 'Watts', angle: 90, position: 'insideRight', fontSize: 10 }} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Line yAxisId="left" type="monotone" dataKey="hashrate" name="Hashrate (GH/s)" stroke="#4f46e5" strokeWidth={2} dot={false} />
                <Line yAxisId="right" type="monotone" dataKey="power" name="Power (W)" stroke="#f59e0b" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Temperature & Efficiency Learning Curve */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">Thermodynamics (°C) & Energy Efficiency (MH/J)</h3>
              <p className="text-xs text-slate-500">Silicon junction heat vs. hashes per joule</p>
            </div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="cycle" stroke="#94a3b8" fontSize={11} />
                <YAxis yAxisId="left" stroke="#ef4444" fontSize={11} domain={['auto', 'auto']} label={{ value: '°C', angle: -90, position: 'insideLeft', fontSize: 10 }} />
                <YAxis yAxisId="right" orientation="right" stroke="#10b981" fontSize={11} label={{ value: 'MH/J', angle: 90, position: 'insideRight', fontSize: 10 }} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Area yAxisId="left" type="monotone" dataKey="temp" name="Junction Temp (°C)" stroke="#ef4444" fill="#fee2e2" strokeWidth={2} />
                <Line yAxisId="right" type="monotone" dataKey="eff" name="Efficiency (MH/J)" stroke="#10b981" strokeWidth={2} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
