/**
 * SHA256-LEARN-R : Shared TypeScript Interfaces & Types
 */

export interface ASICConfig {
  cores: number;
  pipelinesPerCore: number;
  stagesPerPipeline: number;
  clockFrequency: number; // Hz
  voltage: number; // V
  powerLimit: number; // W
  temperatureLimit: number; // °C
  thermalResistance: number; // °C/W
  ambientTemperature: number; // °C
  processNodeNm: number;
  parallelism: number; // 0.0 - 1.0
  minVoltage: number;
  maxVoltage: number;
  minFrequency: number; // Hz
  maxFrequency: number; // Hz
}

export interface HardwareLimitsCheck {
  isValid: boolean;
  violations: string[];
  voltageValid: boolean;
  frequencyValid: boolean;
  stabilityValid: boolean;
  powerValid: boolean;
  temperatureValid: boolean;
}

export interface TelemetryPoint {
  cycle: number;
  timestamp: number;
  hashrateGhs: number;
  powerWatts: number;
  voltageV: number;
  frequencyMhz: number;
  temperatureC: number;
  coreUtilisation: number;
  pipelineUtilisation: number;
  nonceThroughput: number;
  acceptedWork: number;
  rejectedWork: number;
  latencyNs: number;
  energyPerHashNj: number;
  hashesPerJoule: number;
  thermalHeadroomC: number;
  powerHeadroomW: number;
  reward?: number;
  action?: string;
}

export type OptimizationObjective =
  | 'BALANCED_PERFORMANCE'
  | 'MAXIMUM_HASHRATE'
  | 'MAXIMUM_EFFICIENCY'
  | 'MAXIMUM_HASHES_JOULE'
  | 'THERMAL_CONSTRAINED'
  | 'POWER_CONSTRAINED';

export interface MLModelMetric {
  name: string;
  rmse: number;
  mae: number;
  rSquared: number;
  mapePercent: number;
  trainTimeMs: number;
  inferenceUsPerSample: number;
}

export interface FeatureImportance {
  feature: string;
  importancePct: number;
}

export interface ParetoCandidate {
  frequencyMhz: number;
  voltageV: number;
  activeCores: number;
  hashrateGhs: number;
  powerWatts: number;
  temperatureC: number;
  hashesPerJoule: number;
  energyPerHashNj: number;
  isPareto: boolean;
}

export interface OptimizationResult {
  optimalFrequency: number;
  optimalVoltage: number;
  optimalCoreCount: number;
  optimalParallelism: number;
  predictedHashrateGhs: number;
  predictedPowerWatts: number;
  predictedTemperatureC: number;
  hashesPerJoule: number;
  energyPerHashNj: number;
  confidence: number;
  objective: OptimizationObjective;
  paretoFrontier: ParetoCandidate[];
}

export interface BenchmarkRow {
  configuration: string;
  frequencyMhz: number;
  voltageV: number;
  hashrateGhs: number;
  powerWatts: number;
  temperatureC: number;
  efficiencyMhPerJ: number;
  energyNjPerHash: number;
}

export interface BenchmarkSummary {
  hashrateImprovementPct: number;
  powerDeltaPct: number;
  efficiencyImprovementPct: number;
  temperatureDeltaC: number;
}

export interface BenchmarkOutput {
  table: BenchmarkRow[];
  summary: BenchmarkSummary;
}

export interface AnomalyStatus {
  status: 'NORMAL' | 'WARNING' | 'ANOMALY' | 'CRITICAL';
  reasons: string[];
  isSafe: boolean;
  timestamp: number;
}

export interface RFileContent {
  filename: string;
  path: string;
  category: string;
  description: string;
  content: string;
}
