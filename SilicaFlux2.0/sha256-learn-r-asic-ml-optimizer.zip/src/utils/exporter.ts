import JSZip from 'jszip';
import { RFileContent } from '../types';

export async function exportProjectZip(files: RFileContent[]) {
  const zip = new JSZip();

  for (const file of files) {
    zip.file(file.path, file.content);
  }

  const content = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(content);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'SHA256-LEARN-R-Pure-R-Project.zip';
  link.click();
  URL.revokeObjectURL(url);
}
