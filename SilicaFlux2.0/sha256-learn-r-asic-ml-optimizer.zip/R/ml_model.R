# ==============================================================================
# SHA256-LEARN-R : Multi-Model Machine Learning Engine (Pure R)
# ==============================================================================
# Implements Linear Regression, Random Forest, Gradient Boosting, and
# Feed-Forward Neural Network with zero external runtime dependencies.
# ==============================================================================

# ------------------------------------------------------------------------------
# Model A: Multi-Target Linear Regression (Matrix OLS)
# ------------------------------------------------------------------------------
train_linear_regression <- function(X, y) {
  # Add bias column
  X_mat <- as.matrix(cbind(Intercept = 1, X))
  y_mat <- as.matrix(y)
  
  # OLS via QR decomposition or Moore-Penrose pseudo-inverse
  XtX <- t(X_mat) %*% X_mat
  # Add slight ridge regularizer for singular protection
  XtX_reg <- XtX + diag(1e-6, ncol(X_mat))
  beta <- solve(XtX_reg) %*% t(X_mat) %*% y_mat
  
  # Residual standard error
  preds <- X_mat %*% beta
  residuals <- y_mat - preds
  df_resid <- max(1, nrow(X_mat) - ncol(X_mat))
  sigma_sq <- colSums(residuals^2) / df_resid
  
  model <- list(
    type = "LinearRegression",
    beta = beta,
    feature_names = colnames(X),
    sigma = sqrt(sigma_sq),
    XtX_inv = solve(XtX_reg)
  )
  class(model) <- "ML_LinearRegression"
  return(model)
}

predict_linear_regression <- function(model, X_new) {
  X_mat <- as.matrix(cbind(Intercept = 1, X_new))
  preds <- X_mat %*% model$beta
  
  # Statistical confidence interval (95%)
  # Var(y_hat) = x * (X'X)^-1 * x' * sigma^2
  se <- sqrt(rowSums((X_mat %*% model$XtX_inv) * X_mat) * (model$sigma[1]^2))
  ci_lower <- preds[, 1] - 1.96 * se
  ci_upper <- preds[, 1] + 1.96 * se
  
  list(
    predictions = preds,
    ci_lower = ci_lower,
    ci_upper = ci_upper,
    standard_error = se
  )
}

# ------------------------------------------------------------------------------
# Simple Decision Tree Regression Stump / Tree
# ------------------------------------------------------------------------------
build_decision_tree <- function(X, y, max_depth = 4, min_samples = 5, current_depth = 1) {
  n <- nrow(X)
  if (n <= min_samples || current_depth >= max_depth || var(y) < 1e-7) {
    return(list(is_leaf = TRUE, value = mean(y), n_samples = n))
  }
  
  best_feat <- NULL
  best_thresh <- NULL
  best_sse <- Inf
  p <- ncol(X)
  
  # Subsample sqrt(p) or all features
  feat_indices <- sample(1:p, max(1, round(sqrt(p))))
  
  for (f in feat_indices) {
    vals <- unique(X[, f])
    if (length(vals) < 2) next
    # Test quantiles
    thresholds <- quantile(vals, probs = seq(0.1, 0.9, length.out = min(10, length(vals))))
    for (th in thresholds) {
      left_mask <- X[, f] <= th
      right_mask <- !left_mask
      if (sum(left_mask) < 2 || sum(right_mask) < 2) next
      
      sse <- sum((y[left_mask] - mean(y[left_mask]))^2) + sum((y[right_mask] - mean(y[right_mask]))^2)
      if (sse < best_sse) {
        best_sse <- sse
        best_feat <- f
        best_thresh <- th
      }
    }
  }
  
  if (is.null(best_feat)) {
    return(list(is_leaf = TRUE, value = mean(y), n_samples = n))
  }
  
  left_mask <- X[, best_feat] <= best_thresh
  left_tree <- build_decision_tree(X[left_mask, , drop = FALSE], y[left_mask], max_depth, min_samples, current_depth + 1)
  right_tree <- build_decision_tree(X[!left_mask, , drop = FALSE], y[!left_mask], max_depth, min_samples, current_depth + 1)
  
  list(
    is_leaf = FALSE,
    feature_idx = best_feat,
    feature_name = colnames(X)[best_feat],
    threshold = best_thresh,
    left = left_tree,
    right = right_tree,
    sse_reduction = var(y) * n - best_sse
  )
}

predict_tree_single <- function(tree, row) {
  if (tree$is_leaf) return(tree$value)
  if (row[tree$feature_idx] <= tree$threshold) {
    predict_tree_single(tree$left, row)
  } else {
    predict_tree_single(tree$right, row)
  }
}

predict_tree <- function(tree, X) {
  apply(as.matrix(X), 1, function(row) predict_tree_single(tree, row))
}

# ------------------------------------------------------------------------------
# Model B: Random Forest Regressor
# ------------------------------------------------------------------------------
train_random_forest <- function(X, y, n_trees = 25, max_depth = 5, min_samples = 4) {
  n <- nrow(X)
  trees <- vector("list", n_trees)
  feat_importance <- setNames(rep(0, ncol(X)), colnames(X))
  
  for (t in 1:n_trees) {
    # Bootstrap sample
    boot_idx <- sample(1:n, n, replace = TRUE)
    X_boot <- X[boot_idx, , drop = FALSE]
    y_boot <- y[boot_idx]
    
    tree <- build_decision_tree(X_boot, y_boot, max_depth = max_depth, min_samples = min_samples)
    trees[[t]] <- tree
  }
  
  # Calculate empirical feature importance
  for (tree in trees) {
    accumulate_importance <- function(node) {
      if (node$is_leaf) return()
      if (!is.null(node$feature_name) && !is.null(node$sse_reduction)) {
        feat_importance[node$feature_name] <<- feat_importance[node$feature_name] + max(0, node$sse_reduction)
      }
      accumulate_importance(node$left)
      accumulate_importance(node$right)
    }
    accumulate_importance(tree)
  }
  
  total_imp <- sum(feat_importance)
  if (total_imp > 0) feat_importance <- feat_importance / total_imp
  
  model <- list(
    type = "RandomForest",
    trees = trees,
    n_trees = n_trees,
    feature_names = colnames(X),
    feature_importance = feat_importance
  )
  class(model) <- "ML_RandomForest"
  return(model)
}

predict_random_forest <- function(model, X_new) {
  preds_matrix <- matrix(0, nrow = nrow(X_new), ncol = model$n_trees)
  for (t in 1:model$n_trees) {
    preds_matrix[, t] <- predict_tree(model$trees[[t]], X_new)
  }
  mean_preds <- rowMeans(preds_matrix)
  sd_preds <- apply(preds_matrix, 1, sd)
  
  list(
    predictions = mean_preds,
    uncertainty = sd_preds,
    ci_lower = mean_preds - 1.96 * sd_preds,
    ci_upper = mean_preds + 1.96 * sd_preds
  )
}

# ------------------------------------------------------------------------------
# Model C: Gradient Boosting Regressor
# ------------------------------------------------------------------------------
train_gradient_boosting <- function(X, y, n_estimators = 20, learning_rate = 0.1, max_depth = 3) {
  n <- nrow(X)
  base_pred <- mean(y)
  residuals <- y - base_pred
  trees <- vector("list", n_estimators)
  feat_importance <- setNames(rep(0, ncol(X)), colnames(X))
  
  for (i in 1:n_estimators) {
    tree <- build_decision_tree(X, residuals, max_depth = max_depth, min_samples = 4)
    tree_preds <- predict_tree(tree, X)
    residuals <- residuals - learning_rate * tree_preds
    trees[[i]] <- tree
  }
  
  model <- list(
    type = "GradientBoosting",
    base_pred = base_pred,
    trees = trees,
    learning_rate = learning_rate,
    n_estimators = n_estimators,
    feature_names = colnames(X)
  )
  class(model) <- "ML_GradientBoosting"
  return(model)
}

predict_gradient_boosting <- function(model, X_new) {
  preds <- rep(model$base_pred, nrow(X_new))
  for (i in 1:model$n_estimators) {
    preds <- preds + model$learning_rate * predict_tree(model$trees[[i]], X_new)
  }
  list(predictions = preds)
}

# ------------------------------------------------------------------------------
# Model D: Feed-Forward Neural Network (MLP with Backpropagation)
# ------------------------------------------------------------------------------
train_neural_network <- function(X, y, hidden_units = 16, epochs = 200, lr = 0.01) {
  X_mat <- as.matrix(X)
  n_samples <- nrow(X_mat)
  n_features <- ncol(X_mat)
  
  # Normalise targets
  y_mean <- mean(y)
  y_sd <- if (sd(y) > 0) sd(y) else 1
  y_norm <- (y - y_mean) / y_sd
  
  # He initialization
  W1 <- matrix(rnorm(n_features * hidden_units, 0, sqrt(2 / n_features)), nrow = n_features, ncol = hidden_units)
  b1 <- matrix(0, nrow = 1, ncol = hidden_units)
  W2 <- matrix(rnorm(hidden_units * 1, 0, sqrt(2 / hidden_units)), nrow = hidden_units, ncol = 1)
  b2 <- 0
  
  # Activation: LeakyReLU
  leaky_relu <- function(z) ifelse(z > 0, z, 0.01 * z)
  leaky_relu_deriv <- function(z) ifelse(z > 0, 1, 0.01)
  
  loss_history <- numeric(epochs)
  
  for (ep in 1:epochs) {
    # Forward Pass
    Z1 <- X_mat %*% W1 + matrix(rep(b1, n_samples), nrow = n_samples, byrow = TRUE)
    A1 <- leaky_relu(Z1)
    y_pred <- A1 %*% W2 + b2
    
    # Loss: MSE
    error <- y_pred - y_norm
    loss <- mean(error^2)
    loss_history[ep] <- loss
    
    # Backward Pass
    dW2 <- (t(A1) %*% error) / n_samples
    db2 <- mean(error)
    
    dZ1 <- (error %*% t(W2)) * leaky_relu_deriv(Z1)
    dW1 <- (t(X_mat) %*% dZ1) / n_samples
    db1 <- colMeans(dZ1)
    
    # Gradient Descent update
    W1 <- W1 - lr * dW1
    b1 <- b1 - lr * db1
    W2 <- W2 - lr * dW2
    b2 <- b2 - lr * db2
  }
  
  model <- list(
    type = "NeuralNetwork",
    W1 = W1, b1 = b1,
    W2 = W2, b2 = b2,
    y_mean = y_mean, y_sd = y_sd,
    feature_names = colnames(X),
    loss_history = loss_history
  )
  class(model) <- "ML_NeuralNetwork"
  return(model)
}

predict_neural_network <- function(model, X_new) {
  X_mat <- as.matrix(X_new)
  n <- nrow(X_mat)
  Z1 <- X_mat %*% model$W1 + matrix(rep(model$b1, n), nrow = n, byrow = TRUE)
  A1 <- ifelse(Z1 > 0, Z1, 0.01 * Z1)
  y_pred_norm <- A1 %*% model$W2 + model$b2
  preds <- as.numeric(y_pred_norm * model$y_sd + model$y_mean)
  list(predictions = preds)
}
