# ==============================================================================
# SHA256-LEARN-R : High-Throughput ASIC Hardware Telemetry Engine (Pure R)
# ==============================================================================
# Captures per-cycle semiconductor sensor readings, power rails, clock domains,
# and cryptographic workload performance counters.
# ==============================================================================

# Initialize an in-memory telemetry buffer
init_telemetry_buffer <- function(capacity = 50000) {
  df <- data.frame(
    cycle = integer(capacity),
    timestamp = numeric(capacity),
    hashrate_ghs = numeric(capacity),
    power_watts = numeric(capacity),
    voltage_v = numeric(capacity),
    frequency_mhz = numeric(capacity),
    temperature_c = numeric(capacity),
    core_utilisation = numeric(capacity),
    pipeline_utilisation = numeric(capacity),
    nonce_throughput = numeric(capacity),
    accepted_work = numeric(capacity),
    rejected_work = numeric(capacity),
    latency_ns = numeric(capacity),
    energy_per_hash_nj = numeric(capacity),
    hashes_per_joule = numeric(capacity),
    thermal_headroom_c = numeric(capacity),
    power_headroom_w = numeric(capacity),
    stringsAsFactors = FALSE
  )
  list(data = df, count = 0, capacity = capacity)
}

# Append a record to telemetry buffer
record_telemetry <- function(buffer, record) {
  idx <- buffer$count + 1
  if (idx > buffer$capacity) {
    # Double buffer capacity if exceeded
    new_cap <- buffer$capacity * 2
    ext_df <- data.frame(
      cycle = integer(new_cap),
      timestamp = numeric(new_cap),
      hashrate_ghs = numeric(new_cap),
      power_watts = numeric(new_cap),
      voltage_v = numeric(new_cap),
      frequency_mhz = numeric(new_cap),
      temperature_c = numeric(new_cap),
      core_utilisation = numeric(new_cap),
      pipeline_utilisation = numeric(new_cap),
      nonce_throughput = numeric(new_cap),
      accepted_work = numeric(new_cap),
      rejected_work = numeric(new_cap),
      latency_ns = numeric(new_cap),
      energy_per_hash_nj = numeric(new_cap),
      hashes_per_joule = numeric(new_cap),
      thermal_headroom_c = numeric(new_cap),
      power_headroom_w = numeric(new_cap),
      stringsAsFactors = FALSE
    )
    ext_df[1:buffer$capacity, ] <- buffer$data
    buffer$data <- ext_df
    buffer$capacity <- new_cap
  }
  
  for (col in names(record)) {
    if (col %in% names(buffer$data)) {
      buffer$data[idx, col] <- record[[col]]
    }
  }
  buffer$count <- idx
  return(buffer)
}

# Trim telemetry buffer to active rows
get_telemetry_df <- function(buffer) {
  if (buffer$count == 0) return(data.frame())
  buffer$data[1:buffer$count, ]
}

# Generate a single cycle telemetry snapshot from ASIC physical state
generate_telemetry_snapshot <- function(
  cycle_id,
  asic,
  active_cores,
  pipe_res,
  power_res,
  thermal_res,
  scheduler_res,
  workload_job
) {
  effective_hashes <- pipe_res$simulated_hashes
  dt_sec <- 0.001
  hashrate_ghs <- pipe_res$effective_hashrate_ghs
  power_w <- power_res$total_power_watts
  
  # Hashes per Joule = (hashes / sec) / (Joules / sec) = Hashes / Watt
  hashes_per_joule <- if (power_w > 0) (hashrate_ghs * 1e9) / power_w else 0
  energy_per_hash_nj <- if (hashrate_ghs > 0) (power_w / (hashrate_ghs * 1e9)) * 1e9 else 0
  
  # Nonce throughput and share verification
  nonce_throughput <- effective_hashes
  difficulty_factor <- 2^(16 - workload_job$difficulty_bits)
  accepted_rate <- 0.992
  rejected_rate <- 0.008
  if (thermal_res$temperature_c > asic$temperature_limit) {
    rejected_rate <- 0.08 # Thermal bit errors
    accepted_rate <- 0.92
  }
  
  list(
    cycle = as.integer(cycle_id),
    timestamp = as.numeric(Sys.time()),
    hashrate_ghs = as.numeric(hashrate_ghs),
    power_watts = as.numeric(power_w),
    voltage_v = as.numeric(asic$voltage),
    frequency_mhz = as.numeric(asic$clock_frequency / 1e6),
    temperature_c = as.numeric(thermal_res$temperature_c),
    core_utilisation = as.numeric(active_cores / asic$cores),
    pipeline_utilisation = as.numeric(pipe_res$pipeline_utilisation),
    nonce_throughput = as.numeric(nonce_throughput),
    accepted_work = as.numeric(nonce_throughput * accepted_rate),
    rejected_work = as.numeric(nonce_throughput * rejected_rate),
    latency_ns = as.numeric(pipe_res$pipeline_latency_ns),
    energy_per_hash_nj = as.numeric(energy_per_hash_nj),
    hashes_per_joule = as.numeric(hashes_per_joule),
    thermal_headroom_c = as.numeric(thermal_res$thermal_headroom_c),
    power_headroom_w = as.numeric(power_res$power_headroom_watts)
  )
}
