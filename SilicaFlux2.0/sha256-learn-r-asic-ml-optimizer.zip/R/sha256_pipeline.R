# ==============================================================================
# SHA256-LEARN-R : Deeply Pipelined SHA-256 Hardware Pipeline Simulator
# ==============================================================================
# Models the micro-architectural execution of SHA-256 compression loops inside
# custom silicon cells (standard cell / custom gate-level ASICs).
# ==============================================================================

create_pipeline_config <- function(
  stages = 64,               # Deeply unrolled 64-stage or folded 16/32 stages
  buffer_depth = 32,         # Input/Output FIFO buffer depth
  clock_mhz = 1000,          # Operating clock in MHz
  bubble_penalty_cycles = 2, # Bubble cycles on midstate/job reload
  stall_threshold = 0.95     # Workload pressure at which bus back-pressure stalls occur
) {
  list(
    stages = stages,
    buffer_depth = buffer_depth,
    clock_mhz = clock_mhz,
    bubble_penalty_cycles = bubble_penalty_cycles,
    stall_threshold = stall_threshold
  )
}

# Simulates a pipeline batch over time delta t (seconds)
simulate_pipeline_execution <- function(
  pipeline_cfg,
  workload_items_available,
  active_pipelines = 1,
  clock_freq_hz = 1000e6,
  duration_sec = 0.001
) {
  clock_cycles <- clock_freq_hz * duration_sec
  stages <- pipeline_cfg$stages
  
  # Latency to fill empty pipeline = stages * clock_period
  pipeline_latency_cycles <- stages
  pipeline_latency_ns <- (stages / clock_freq_hz) * 1e9
  
  # Capacity in hashes if 100% full without stalls
  # Fully unrolled pipeline outputs 1 hash per clock cycle once filled
  throughput_per_pipe_cycles <- max(0, clock_cycles - pipeline_latency_cycles)
  theoretical_hashes <- active_pipelines * throughput_per_pipe_cycles
  
  # Workload saturation and starvation model
  workload_ratio <- if (theoretical_hashes > 0) workload_items_available / theoretical_hashes else 0
  workload_saturation <- min(1.0, workload_ratio)
  
  # Stall generation: buffer overrun when workload > 1.2x capacity, or underflow when < 0.5x
  stall_rate <- if (workload_ratio > 1.3) {
    min(0.25, (workload_ratio - 1.3) * 0.15)
  } else if (workload_ratio < 0.3) {
    min(0.40, (0.3 - workload_ratio) * 0.8)
  } else {
    0.01 # Baseline 1% routing/jitter stall
  }
  
  # Bubble generation on context switch or nonce partition exhaustion
  bubble_rate <- if (workload_items_available < 100) 0.08 else 0.015
  
  # Actual pipeline occupancy and utilisation
  pipeline_occupancy <- max(0.05, min(1.0, workload_saturation * (1.0 - stall_rate)))
  pipeline_utilisation <- max(0.05, min(1.0, pipeline_occupancy * (1.0 - bubble_rate)))
  
  simulated_hashes <- theoretical_hashes * pipeline_utilisation
  effective_hashrate_ghs <- (simulated_hashes / duration_sec) / 1e9
  theoretical_hashrate_ghs <- (theoretical_hashes / duration_sec) / 1e9
  
  list(
    clock_cycles = clock_cycles,
    stages = stages,
    pipeline_latency_ns = pipeline_latency_ns,
    theoretical_hashes = theoretical_hashes,
    simulated_hashes = simulated_hashes,
    theoretical_hashrate_ghs = theoretical_hashrate_ghs,
    effective_hashrate_ghs = effective_hashrate_ghs,
    pipeline_occupancy = pipeline_occupancy,
    pipeline_utilisation = pipeline_utilisation,
    stall_rate = stall_rate,
    bubble_rate = bubble_rate,
    workload_saturation = workload_saturation
  )
}
