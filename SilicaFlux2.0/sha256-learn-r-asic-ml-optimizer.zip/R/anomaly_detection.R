# ==============================================================================
# SHA256-LEARN-R : Silicon Anomaly & Fault Detection Subsystem (Pure R)
# ==============================================================================
# Detects abnormal power spikes, runaway junction temperatures, pipeline stalls,
# clock degradation, and unexpected sub-threshold leakage surges.
# ==============================================================================

ANOMALY_LEVELS <- c("NORMAL", "WARNING", "ANOMALY", "CRITICAL")

detect_anomaly <- function(telemetry, asic = NULL, history_df = NULL) {
  reasons <- character(0)
  level <- "NORMAL"
  
  # 1. Thermal Criticality & Runaway Check
  if (!is.null(asic) && telemetry$temperature_c >= asic$temperature_limit) {
    level <- "CRITICAL"
    reasons <- c(reasons, sprintf("Thermal Junction Over-temperature: %.1f°C >= limit %.1f°C", 
                                 telemetry$temperature_c, asic$temperature_limit))
  } else if (!is.null(asic) && telemetry$temperature_c >= (asic$temperature_limit - 4.0)) {
    if (level != "CRITICAL") level <- "WARNING"
    reasons <- c(reasons, sprintf("Thermal Headroom Depleted: %.1f°C", telemetry$temperature_c))
  }
  
  # 2. Power Rail Surge
  if (!is.null(asic) && telemetry$power_watts >= asic$power_limit) {
    level <- "CRITICAL"
    reasons <- c(reasons, sprintf("Power Rail Exceeded: %.1fW >= budget %.1fW",
                                 telemetry$power_watts, asic$power_limit))
  }
  
  # 3. Pipeline Instability & Stalls
  if (telemetry$pipeline_utilisation < 0.35 && telemetry$core_utilisation > 0.8) {
    if (level == "NORMAL") level <- "ANOMALY"
    reasons <- c(reasons, sprintf("Severe Pipeline Starvation: utilisation %.1f%% with active cores",
                                 telemetry$pipeline_utilisation * 100))
  }
  
  # 4. Hashrate Collapse / Clock Glitch
  if (telemetry$hashrate_ghs < 50 && telemetry$frequency_mhz > 600) {
    if (level == "NORMAL") level <- "ANOMALY"
    reasons <- c(reasons, "Hashrate collapse detected under active clock domain")
  }
  
  # 5. Statistical Outlier Detection against History
  if (!is.null(history_df) && nrow(history_df) >= 15) {
    hist_pwr_mean <- mean(history_df$power_watts, na.rm = TRUE)
    hist_pwr_sd <- sd(history_df$power_watts, na.rm = TRUE)
    
    if (!is.na(hist_pwr_sd) && hist_pwr_sd > 0) {
      z_score <- (telemetry$power_watts - hist_pwr_mean) / hist_pwr_sd
      if (z_score > 3.5) {
        if (level == "NORMAL") level <- "WARNING"
        reasons <- c(reasons, sprintf("Statistical Power Surge (Z=%.2f)", z_score))
      }
    }
  }
  
  list(
    status = level,
    reasons = reasons,
    is_safe = (level %in% c("NORMAL", "WARNING")),
    timestamp = telemetry$timestamp
  )
}
