# ==============================================================================
# SHA256-LEARN-R : Comparative Hardware Benchmark Engine (Pure R)
# ==============================================================================
# Benchmarks Baseline Factory ASIC vs. Overclocked ASIC vs. ML-Optimized ASIC
# across Hashrate, Power, Energy Efficiency, and Thermal Headroom.
# ==============================================================================

benchmark_asic <- function(
  base_asic,
  ml_solution = NULL,
  simulation_duration = 50
) {
  cat("[Benchmark Engine] Starting Tri-Configuration ASIC Benchmark Comparison...\n")
  
  # 1. Baseline Factory ASIC (Default conservative settings: 800 MHz, 0.75V)
  asic_base <- base_asic
  asic_base$clock_frequency <- 800e6
  asic_base$voltage <- 0.75
  asic_base$parallelism <- 1.0
  res_base <- run_experiment(
    cores = asic_base$cores,
    frequency = asic_base$clock_frequency,
    voltage = asic_base$voltage,
    iterations = simulation_duration,
    enable_rl_learning = FALSE,
    verbose = FALSE
  )
  
  # 2. Heuristic Manual Overclock ASIC (Aggressive 1100 MHz, 0.88V)
  asic_manual <- base_asic
  asic_manual$clock_frequency <- 1100e6
  asic_manual$voltage <- 0.88
  asic_manual$parallelism <- 1.0
  res_manual <- run_experiment(
    cores = asic_manual$cores,
    frequency = asic_manual$clock_frequency,
    voltage = asic_manual$voltage,
    iterations = simulation_duration,
    enable_rl_learning = FALSE,
    verbose = FALSE
  )
  
  # 3. ML-Optimized ASIC
  opt_freq <- if (!is.null(ml_solution)) ml_solution$optimal_frequency else 950e6
  opt_volt <- if (!is.null(ml_solution)) ml_solution$optimal_voltage else 0.70
  res_opt <- run_experiment(
    cores = base_asic$cores,
    frequency = opt_freq,
    voltage = opt_volt,
    iterations = simulation_duration,
    enable_rl_learning = FALSE,
    verbose = FALSE
  )
  
  # Extract steady-state tail averages (last 15 cycles)
  calc_steady_means <- function(telemetry_df) {
    tail_df <- tail(telemetry_df, 15)
    list(
      hashrate_ghs = mean(tail_df$hashrate_ghs),
      power_watts = mean(tail_df$power_watts),
      temperature_c = mean(tail_df$temperature_c),
      hashes_per_joule = mean(tail_df$hashes_per_joule),
      energy_per_hash_nj = mean(tail_df$energy_per_hash_nj),
      pipeline_utilisation = mean(tail_df$pipeline_utilisation)
    )
  }
  
  s_base <- calc_steady_means(res_base$telemetry)
  s_manual <- calc_steady_means(res_manual$telemetry)
  s_opt <- calc_steady_means(res_opt$telemetry)
  
  # Percentage Improvements Relative to Baseline
  delta_hashrate_pct <- ((s_opt$hashrate_ghs - s_base$hashrate_ghs) / s_base$hashrate_ghs) * 100
  delta_power_pct    <- ((s_opt$power_watts - s_base$power_watts) / s_base$power_watts) * 100
  delta_eff_pct      <- ((s_opt$hashes_per_joule - s_base$hashes_per_joule) / s_base$hashes_per_joule) * 100
  delta_temp_c       <- s_opt$temperature_c - s_base$temperature_c
  
  benchmark_table <- data.frame(
    Configuration = c("1. Factory Baseline", "2. Manual Overclock", "3. ML-Optimized ASIC"),
    Frequency_MHz = c(asic_base$clock_frequency / 1e6, asic_manual$clock_frequency / 1e6, opt_freq / 1e6),
    Voltage_V = c(asic_base$voltage, asic_manual$voltage, opt_volt),
    Hashrate_GHs = c(s_base$hashrate_ghs, s_manual$hashrate_ghs, s_opt$hashrate_ghs),
    Power_Watts = c(s_base$power_watts, s_manual$power_watts, s_opt$power_watts),
    Temperature_C = c(s_base$temperature_c, s_manual$temperature_c, s_opt$temperature_c),
    Efficiency_MH_per_J = c(s_base$hashes_per_joule / 1e6, s_manual$hashes_per_joule / 1e6, s_opt$hashes_per_joule / 1e6),
    Energy_nJ_per_Hash = c(s_base$energy_per_hash_nj, s_manual$energy_per_hash_nj, s_opt$energy_per_hash_nj),
    stringsAsFactors = FALSE
  )
  
  list(
    benchmark_table = benchmark_table,
    improvement_summary = list(
      hashrate_improvement_pct = delta_hashrate_pct,
      power_delta_pct = delta_power_pct,
      efficiency_improvement_pct = delta_eff_pct,
      temperature_delta_c = delta_temp_c
    ),
    raw_results = list(
      baseline = res_base,
      manual = res_manual,
      ml_optimized = res_opt
    )
  )
}
