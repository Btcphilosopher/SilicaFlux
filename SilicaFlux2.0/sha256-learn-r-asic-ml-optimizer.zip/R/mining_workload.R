# ==============================================================================
# SHA256-LEARN-R : Mining Workload & Nonce Partitioning Simulator (Pure R)
# ==============================================================================
# Models Stratum V1/V2 job injection, block header serialization, midstate
# caching, and 32-bit nonce space distribution across parallel hashing cores.
# ==============================================================================

create_mining_job <- function(
  job_id = 1,
  difficulty_bits = 16, # Simulated difficulty target
  prev_block_hash = "000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f",
  merkle_root = "4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b",
  version = 0x20000000,
  timestamp = as.integer(Sys.time())
) {
  # Header block 1 (64 bytes): version (4B) + prev_hash (32B) + merkle_root_prefix (28B)
  # Header block 2 (16 bytes payload + 48B padding): merkle_root_suffix (4B) + time (4B) + nBits (4B) + nonce (4B)
  # This enables the ASIC midstate optimization: Block 1 is hashed ONCE into midstate H[0..7]
  dummy_64_bytes <- as.raw(rep(0x5a, 64))
  midstate <- sha256_compute_midstate(dummy_64_bytes)
  
  list(
    job_id = as.integer(job_id),
    difficulty_bits = as.numeric(difficulty_bits),
    target_threshold = 2^(32 - difficulty_bits),
    midstate = midstate,
    timestamp = timestamp,
    total_nonces = 2^32
  )
}

# Partition Nonce Space across Active Cores
partition_nonce_space <- function(
  job,
  active_cores,
  partition_strategy = c("uniform", "interleaved", "dynamic_range")
) {
  partition_strategy <- match.arg(partition_strategy)
  active_cores <- max(1, as.integer(active_cores))
  nonces_per_core <- floor(job$total_nonces / active_cores)
  
  partitions <- vector("list", active_cores)
  for (c_idx in 1:active_cores) {
    start_nonce <- (c_idx - 1) * nonces_per_core
    end_nonce <- if (c_idx == active_cores) (job$total_nonces - 1) else (c_idx * nonces_per_core - 1)
    partitions[[c_idx]] <- list(
      core_id = c_idx,
      start_nonce = start_nonce,
      end_nonce = end_nonce,
      nonce_count = end_nonce - start_nonce + 1
    )
  }
  
  list(
    strategy = partition_strategy,
    active_cores = active_cores,
    nonces_per_core = nonces_per_core,
    partitions = partitions
  )
}
