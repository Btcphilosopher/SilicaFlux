# ==============================================================================
# SHA256-LEARN-R : Abstract ASIC Architecture Model & Hardware Constraints
# ==============================================================================
# Defines the multi-core ASIC specification, parameter envelope, and strict
# silicon reliability boundary checking routines.
# ==============================================================================

# Create an ASIC Model instance
create_asic <- function(
  cores = 1000,
  pipelines_per_core = 1,
  stages_per_pipeline = 64,
  clock_frequency = 850e6,     # 850 MHz baseline
  voltage = 0.72,              # 0.72 V nominal
  power_limit = 2500,          # 2500 Watts chassis budget
  temperature_limit = 85.0,    # 85.0 °C junction max safe operating temperature
  thermal_resistance = 0.022,  # 0.022 °C/W heatsink + forced air package
  ambient_temperature = 25.0,  # 25.0 °C datacenter ambient
  process_node_nm = 5,         # 5nm FinFET / GAAFET technology node
  nonce_width = 32,
  min_voltage = 0.55,
  max_voltage = 0.95,
  min_frequency = 400e6,
  max_frequency = 1400e6
) {
  asic <- list(
    cores = as.integer(cores),
    pipelines_per_core = as.integer(pipelines_per_core),
    stages_per_pipeline = as.integer(stages_per_pipeline),
    clock_frequency = as.numeric(clock_frequency),
    voltage = as.numeric(voltage),
    power_limit = as.numeric(power_limit),
    temperature_limit = as.numeric(temperature_limit),
    thermal_resistance = as.numeric(thermal_resistance),
    ambient_temperature = as.numeric(ambient_temperature),
    process_node_nm = as.integer(process_node_nm),
    nonce_width = as.integer(nonce_width),
    active_units = as.integer(cores * pipelines_per_core),
    parallelism = 1.0, # Active core fraction [0.0 - 1.0]
    pipeline_utilisation = 0.85,
    min_voltage = as.numeric(min_voltage),
    max_voltage = as.numeric(max_voltage),
    min_frequency = as.numeric(min_frequency),
    max_frequency = as.numeric(max_frequency)
  )
  class(asic) <- c("ASIC_Model", "list")
  return(asic)
}

# Constraint checking functions
check_power_constraint <- function(asic, power_watts) {
  power_watts <= asic$power_limit
}

check_temperature_constraint <- function(asic, temp_c) {
  temp_c <= asic$temperature_limit
}

check_voltage_constraint <- function(asic, voltage_v) {
  voltage_v >= asic$min_voltage && voltage_v <= asic$max_voltage
}

check_clock_constraint <- function(asic, freq_hz) {
  freq_hz >= asic$min_frequency && freq_hz <= asic$max_frequency
}

# Physical Fmax(V) curve check: Frequency requires minimum stable voltage
check_voltage_frequency_stability <- function(voltage_v, freq_hz) {
  # Minimum voltage required for given frequency in modern FinFET cell library
  # V_min = 0.50 + (f_ghz - 0.4) * 0.45
  f_ghz <- freq_hz / 1e9
  v_req <- 0.50 + max(0, f_ghz - 0.4) * 0.45
  voltage_v >= (v_req - 0.02) # Allows small 20mV tolerance margin
}

# Holistic Hardware Limit Check
check_hardware_limits <- function(asic, voltage = NULL, frequency = NULL, power = NULL, temp = NULL) {
  v <- if (!is.null(voltage)) voltage else asic$voltage
  f <- if (!is.null(frequency)) frequency else asic$clock_frequency
  p <- if (!is.null(power)) power else 0
  t <- if (!is.null(temp)) temp else asic$ambient_temperature
  
  v_ok <- check_voltage_constraint(asic, v)
  f_ok <- check_clock_constraint(asic, f)
  vf_ok <- check_voltage_frequency_stability(v, f)
  p_ok <- if (p > 0) check_power_constraint(asic, p) else TRUE
  t_ok <- if (t > 0) check_temperature_constraint(asic, t) else TRUE
  
  is_valid <- v_ok && f_ok && vf_ok && p_ok && t_ok
  
  violations <- character(0)
  if (!v_ok) violations <- c(violations, sprintf("Voltage %.3fV outside [%.2f, %.2f]V", v, asic$min_voltage, asic$max_voltage))
  if (!f_ok) violations <- c(violations, sprintf("Frequency %.0fMHz outside [%.0f, %.0f]MHz", f/1e6, asic$min_frequency/1e6, asic$max_frequency/1e6))
  if (!vf_ok) violations <- c(violations, sprintf("Voltage %.3fV insufficient to sustain clock %.0fMHz (under-volt instability)", v, f/1e6))
  if (!p_ok) violations <- c(violations, sprintf("Power %.1fW exceeds limit %.1fW", p, asic$power_limit))
  if (!t_ok) violations <- c(violations, sprintf("Temperature %.1f°C exceeds max junction limit %.1f°C", t, asic$temperature_limit))
  
  list(
    is_valid = is_valid,
    violations = violations,
    voltage_valid = v_ok,
    frequency_valid = f_ok,
    stability_valid = vf_ok,
    power_valid = p_ok,
    temperature_valid = t_ok
  )
}
