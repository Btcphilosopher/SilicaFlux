# ==============================================================================
# SHA256-LEARN-R : Telemetry Feature Engineering & Rolling Window Layer (Pure R)
# ==============================================================================
# Transforms raw silicon telemetry streams into rich lag, rolling window, delta,
# and efficiency features for predictive machine learning models.
# ==============================================================================

# Helper for rolling mean
rolling_mean <- function(x, window) {
  n <- length(x)
  if (n == 0) return(numeric(0))
  if (window <= 1) return(x)
  res <- numeric(n)
  for (i in 1:n) {
    start_idx <- max(1, i - window + 1)
    res[i] <- mean(x[start_idx:i], na.rm = TRUE)
  }
  res
}

# Helper for rolling standard deviation
rolling_sd <- function(x, window) {
  n <- length(x)
  if (n == 0) return(numeric(0))
  res <- numeric(n)
  for (i in 1:n) {
    start_idx <- max(1, i - window + 1)
    sub <- x[start_idx:i]
    res[i] <- if (length(sub) > 1) sd(sub, na.rm = TRUE) else 0
  }
  # Replace any NA with 0
  res[is.na(res)] <- 0
  res
}

# Calculate rolling gradient / slope over window
rolling_gradient <- function(x, window = 5) {
  n <- length(x)
  if (n <= 1) return(rep(0, n))
  res <- numeric(n)
  for (i in 1:n) {
    start_idx <- max(1, i - window + 1)
    sub <- x[start_idx:i]
    len_sub <- length(sub)
    if (len_sub >= 2) {
      # Simple linear regression slope
      t <- 1:len_sub
      cov_tx <- cov(t, sub)
      var_t <- var(t)
      res[i] <- if (!is.na(var_t) && var_t > 0) cov_tx / var_t else 0
    } else {
      res[i] <- 0
    }
  }
  res
}

# Engineer Full Feature Matrix from Telemetry DataFrame
engineer_telemetry_features <- function(telemetry_df) {
  if (nrow(telemetry_df) == 0) return(data.frame())
  
  df <- telemetry_df
  n <- nrow(df)
  
  # 1. Delta Features (Cycle-over-cycle change)
  df$temperature_delta <- c(0, diff(df$temperature_c))
  df$power_delta       <- c(0, diff(df$power_watts))
  df$frequency_delta   <- c(0, diff(df$frequency_mhz))
  df$hashrate_delta    <- c(0, diff(df$hashrate_ghs))
  df$utilisation_delta <- c(0, diff(df$pipeline_utilisation))
  
  # 2. Efficiency Metrics
  df$pipeline_efficiency <- df$pipeline_utilisation * (1.0 - (df$rejected_work / pmax(1, df$nonce_throughput)))
  df$core_efficiency     <- df$hashrate_ghs / pmax(0.1, df$power_watts)
  df$nonce_efficiency    <- df$accepted_work / pmax(1, df$nonce_throughput)
  
  # 3. Rolling Window Aggregations (5, 10, 50, 100 cycles)
  for (win in c(5, 10, 50, 100)) {
    if (n >= win) {
      df[[paste0("hashrate_mean_", win)]]    <- rolling_mean(df$hashrate_ghs, win)
      df[[paste0("power_mean_", win)]]       <- rolling_mean(df$power_watts, win)
      df[[paste0("temp_mean_", win)]]        <- rolling_mean(df$temperature_c, win)
      df[[paste0("hash_joule_mean_", win)]]  <- rolling_mean(df$hashes_per_joule, win)
    } else {
      df[[paste0("hashrate_mean_", win)]]    <- rolling_mean(df$hashrate_ghs, min(n, 5))
      df[[paste0("power_mean_", win)]]       <- rolling_mean(df$power_watts, min(n, 5))
      df[[paste0("temp_mean_", win)]]        <- rolling_mean(df$temperature_c, min(n, 5))
      df[[paste0("hash_joule_mean_", win)]]  <- rolling_mean(df$hashes_per_joule, min(n, 5))
    }
  }
  
  # 4. Volatility and Trend Features
  df$temp_volatility_10 <- rolling_sd(df$temperature_c, 10)
  df$power_volatility_10 <- rolling_sd(df$power_watts, 10)
  df$temp_gradient_5 <- rolling_gradient(df$temperature_c, 5)
  df$power_gradient_5 <- rolling_gradient(df$power_watts, 5)
  df$hashrate_gradient_5 <- rolling_gradient(df$hashrate_ghs, 5)
  
  return(df)
}
