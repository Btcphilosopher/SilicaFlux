# ==============================================================================
# SHA256-LEARN-R : Hardware State Vector & Action Space Definition (Pure R)
# ==============================================================================
# Implements normalisation, hardware state representation, and discrete/continuous
# action transformations for Reinforcement Learning and ML optimization agents.
# ==============================================================================

# Hardware bounds dictionary for min-max feature normalisation
STATE_BOUNDS <- list(
  clock_frequency     = c(min = 400e6, max = 1400e6), # 400 MHz to 1400 MHz
  voltage             = c(min = 0.55,  max = 0.95),   # 0.55 V to 0.95 V
  active_cores        = c(min = 1,     max = 10000),  # 1 to 10k cores
  pipeline_utilisation= c(min = 0.0,   max = 1.0),
  core_utilisation    = c(min = 0.0,   max = 1.0),
  temperature         = c(min = 25.0,  max = 95.0),   # °C
  power               = c(min = 10.0,  max = 5000.0), # Watts
  thermal_headroom    = c(min = 0.0,   max = 60.0),   # °C
  hashes_per_second   = c(min = 1e9,   max = 15e12),  # 1 GH/s to 15 TH/s
  hashes_per_joule    = c(min = 1e6,   max = 10e9),   # H/J
  workload_pressure   = c(min = 0.0,   max = 2.0)
)

# Construct State Vector
create_hardware_state <- function(
  clock_frequency,
  voltage,
  active_cores,
  pipeline_utilisation,
  core_utilisation,
  temperature,
  power,
  thermal_headroom,
  hashes_per_second,
  hashes_per_joule,
  workload_pressure = 1.0
) {
  state <- c(
    clock_frequency      = as.numeric(clock_frequency),
    voltage              = as.numeric(voltage),
    active_cores         = as.numeric(active_cores),
    pipeline_utilisation = as.numeric(pipeline_utilisation),
    core_utilisation     = as.numeric(core_utilisation),
    temperature          = as.numeric(temperature),
    power                = as.numeric(power),
    thermal_headroom     = as.numeric(thermal_headroom),
    hashes_per_second    = as.numeric(hashes_per_second),
    hashes_per_joule     = as.numeric(hashes_per_joule),
    workload_pressure    = as.numeric(workload_pressure)
  )
  return(state)
}

# Min-Max Normalisation into [0, 1] range
normalize_state_vector <- function(state, bounds = STATE_BOUNDS) {
  norm_vec <- numeric(length(state))
  names(norm_vec) <- names(state)
  
  for (nm in names(state)) {
    if (nm %in% names(bounds)) {
      b <- bounds[[nm]]
      val <- state[[nm]]
      norm_val <- (val - b["min"]) / (b["max"] - b["min"])
      norm_vec[nm] <- max(0.0, min(1.0, norm_val))
    } else {
      norm_vec[nm] <- state[[nm]]
    }
  }
  return(norm_vec)
}

# Denormalise back to physical hardware units
denormalize_state_vector <- function(norm_state, bounds = STATE_BOUNDS) {
  raw_vec <- numeric(length(norm_state))
  names(raw_vec) <- names(norm_state)
  
  for (nm in names(norm_state)) {
    if (nm %in% names(bounds)) {
      b <- bounds[[nm]]
      val <- norm_state[[nm]]
      raw_vec[nm] <- b["min"] + val * (b["max"] - b["min"])
    } else {
      raw_vec[nm] <- norm_state[[nm]]
    }
  }
  return(raw_vec)
}

# Action Space (12 Discrete Actions)
ACTION_NAMES <- c(
  "INCREASE_CLOCK",       # +25 MHz
  "DECREASE_CLOCK",       # -25 MHz
  "INCREASE_VOLTAGE",     # +0.01 V
  "DECREASE_VOLTAGE",     # -0.01 V
  "ACTIVATE_CORES",       # +5% active cores
  "DEACTIVATE_CORES",     # -5% active cores
  "INCREASE_PARALLELISM", # Increase pipeline parallelism factor
  "DECREASE_PARALLELISM", # Decrease pipeline parallelism factor
  "INCREASE_BATCH_SIZE",  # +20% batch
  "DECREASE_BATCH_SIZE",  # -20% batch
  "SWITCH_SCHEDULER",     # Cycle scheduler policy
  "NOOP"                  # Maintain current operating point
)

# Apply an action to an ASIC hardware configuration with safety boundaries
apply_action_to_asic <- function(asic, action_id, batch_size = 100000) {
  act_name <- if (is.numeric(action_id)) ACTION_NAMES[action_id] else as.character(action_id)
  
  new_asic <- asic
  new_batch_size <- batch_size
  
  delta_freq <- 25e6 # 25 MHz
  delta_volt <- 0.01 # 10 mV
  delta_cores <- max(1, round(asic$cores * 0.05))
  
  if (act_name == "INCREASE_CLOCK") {
    new_asic$clock_frequency <- min(asic$max_frequency, asic$clock_frequency + delta_freq)
  } else if (act_name == "DECREASE_CLOCK") {
    new_asic$clock_frequency <- max(asic$min_frequency, asic$clock_frequency - delta_freq)
  } else if (act_name == "INCREASE_VOLTAGE") {
    new_asic$voltage <- min(asic$max_voltage, asic$voltage + delta_volt)
  } else if (act_name == "DECREASE_VOLTAGE") {
    new_asic$voltage <- max(asic$min_voltage, asic$voltage - delta_volt)
  } else if (act_name == "ACTIVATE_CORES") {
    new_active <- min(asic$cores, asic$cores * asic$parallelism + delta_cores)
    new_asic$parallelism <- new_active / asic$cores
  } else if (act_name == "DEACTIVATE_CORES") {
    new_active <- max(1, asic$cores * asic$parallelism - delta_cores)
    new_asic$parallelism <- new_active / asic$cores
  } else if (act_name == "INCREASE_PARALLELISM") {
    new_asic$parallelism <- min(1.0, asic$parallelism + 0.05)
  } else if (act_name == "DECREASE_PARALLELISM") {
    new_asic$parallelism <- max(0.1, asic$parallelism - 0.05)
  } else if (act_name == "INCREASE_BATCH_SIZE") {
    new_batch_size <- min(1000000, round(batch_size * 1.2))
  } else if (act_name == "DECREASE_BATCH_SIZE") {
    new_batch_size <- max(10000, round(batch_size * 0.8))
  }
  
  list(
    asic = new_asic,
    action = act_name,
    batch_size = new_batch_size
  )
}
