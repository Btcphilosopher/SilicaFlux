# ==============================================================================
# SHA256-LEARN-R : SHA-256 Cryptographic Core Reference Implementation (Pure R)
# ==============================================================================
# This module provides a 100% pure-R reference implementation of FIPS PUB 180-4
# Secure Hash Standard (SHA-256). It serves as the mathematical ground truth
# for pipeline stage verification, midstate generation, and ASIC compute units.
#
# NOTE: The ML optimizer learns hardware operating configurations (DVFS,
# core scheduling, pipeline occupancy) and NEVER modifies cryptographic math.
# ==============================================================================

# 32-bit unsigned arithmetic helper: addition modulo 2^32
add32 <- function(...) {
  vals <- list(...)
  total <- 0
  for (v in vals) {
    total <- (total + as.numeric(v)) %% 4294967296
  }
  return(as.numeric(total))
}

# Bitwise Right Rotate for 32-bit unsigned integers
rotr32 <- function(x, n) {
  n <- n %% 32
  if (n == 0) return(x)
  bitwOr(bitwShiftR(x, n), bitwShiftL(x, 32 - n))
}

# SHA-256 Non-linear logical functions
# Ch(x, y, z) = (x AND y) XOR (NOT x AND z)
sha256_ch <- function(x, y, z) {
  bitwXor(bitwAnd(x, y), bitwAnd(bitwNot(x), z))
}

# Maj(x, y, z) = (x AND y) XOR (x AND z) XOR (y AND z)
sha256_maj <- function(x, y, z) {
  bitwXor(bitwXor(bitwAnd(x, y), bitwAnd(x, z)), bitwAnd(y, z))
}

# Sigma0(x) = ROTR(x, 2) XOR ROTR(x, 13) XOR ROTR(x, 22)
sha256_sigma0 <- function(x) {
  bitwXor(bitwXor(rotr32(x, 2), rotr32(x, 13)), rotr32(x, 22))
}

# Sigma1(x) = ROTR(x, 6) XOR ROTR(x, 11) XOR ROTR(x, 25)
sha256_sigma1 <- function(x) {
  bitwXor(bitwXor(rotr32(x, 6), rotr32(x, 11)), rotr32(x, 25))
}

# sigma0(x) = ROTR(x, 7) XOR ROTR(x, 18) XOR SHR(x, 3)
sha256_gamma0 <- function(x) {
  bitwXor(bitwXor(rotr32(x, 7), rotr32(x, 18)), bitwShiftR(x, 3))
}

# sigma1(x) = ROTR(x, 17) XOR ROTR(x, 19) XOR SHR(x, 10)
sha256_gamma1 <- function(x) {
  bitwXor(bitwXor(rotr32(x, 17), rotr32(x, 19)), bitwShiftR(x, 10))
}

# Initial SHA-256 Hash Values (first 32 bits of fractional parts of square roots of first 8 primes)
SHA256_H_INIT <- as.numeric(c(
  0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
  0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
))

# 64 Round Constants K (first 32 bits of fractional parts of cube roots of first 64 primes)
SHA256_K <- as.numeric(c(
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
))

# Preprocess and Pad Message according to SHA-256 standard
sha256_pad_message <- function(raw_bytes) {
  len_bytes <- length(raw_bytes)
  bit_len <- len_bytes * 8
  
  # Append 0x80 (10000000 in binary)
  padded <- c(raw_bytes, as.raw(0x80))
  
  # Pad with zeros until length == 56 mod 64 (which leaves 8 bytes for bit length)
  pad_len <- (56 - (length(padded) %% 64)) %% 64
  if (pad_len > 0) {
    padded <- c(padded, as.raw(rep(0, pad_len)))
  }
  
  # Append 64-bit big-endian message length in bits
  len_hi <- floor(bit_len / (2^32))
  len_lo <- bit_len %% (2^32)
  
  len_bytes_8 <- as.raw(c(
    bitwShiftR(len_hi, 24) %% 256,
    bitwShiftR(len_hi, 16) %% 256,
    bitwShiftR(len_hi, 8) %% 256,
    len_hi %% 256,
    bitwShiftR(len_lo, 24) %% 256,
    bitwShiftR(len_lo, 16) %% 256,
    bitwShiftR(len_lo, 8) %% 256,
    len_lo %% 256
  ))
  
  c(padded, len_bytes_8)
}

# Convert raw bytes chunk into 16 32-bit words (big-endian)
bytes_to_words32 <- function(block_bytes) {
  words <- numeric(16)
  for (i in 1:16) {
    idx <- (i - 1) * 4 + 1
    b <- as.integer(block_bytes[idx:(idx + 3)])
    words[i] <- (b[1] * 16777216) + (b[2] * 65536) + (b[3] * 256) + b[4]
  }
  words
}

# Process a single 512-bit (64-byte) block and return new state
sha256_transform_block <- function(state, block_bytes) {
  W <- numeric(64)
  W[1:16] <- bytes_to_words32(block_bytes)
  
  # Message Schedule expansion (Rounds 16 to 63)
  for (t in 17:64) {
    s0 <- sha256_gamma0(W[t - 15])
    s1 <- sha256_gamma1(W[t - 2])
    W[t] <- add32(W[t - 16], s0, W[t - 7], s1)
  }
  
  # Initialize working variables
  a <- state[1]
  b <- state[2]
  c <- state[3]
  d <- state[4]
  e <- state[5]
  f <- state[6]
  g <- state[7]
  h <- state[8]
  
  # 64 Compression Rounds
  for (t in 1:64) {
    S1 <- sha256_sigma1(e)
    ch <- sha256_ch(e, f, g)
    temp1 <- add32(h, S1, ch, SHA256_K[t], W[t])
    S0 <- sha256_sigma0(a)
    maj <- sha256_maj(a, b, c)
    temp2 <- add32(S0, maj)
    
    h <- g
    g <- f
    f <- e
    e <- add32(d, temp1)
    d <- c
    c <- b
    b <- a
    a <- add32(temp1, temp2)
  }
  
  # Add compressed chunk to current hash value
  new_state <- c(
    add32(state[1], a),
    add32(state[2], b),
    add32(state[3], c),
    add32(state[4], d),
    add32(state[5], e),
    add32(state[6], f),
    add32(state[7], g),
    add32(state[8], h)
  )
  
  return(new_state)
}

# Compute Midstate from First 64-byte Header Chunk (ASIC Mining Optimization)
sha256_compute_midstate <- function(first_64_bytes) {
  if (length(first_64_bytes) != 64) {
    stop("Midstate computation requires exactly 64 bytes (block chunk 1).")
  }
  sha256_transform_block(SHA256_H_INIT, first_64_bytes)
}

# Complete SHA-256 Digest calculation
sha256_digest <- function(message) {
  if (is.character(message)) {
    raw_bytes <- charToRaw(message)
  } else if (is.raw(message)) {
    raw_bytes <- message
  } else {
    stop("Message must be a character string or raw vector.")
  }
  
  padded <- sha256_pad_message(raw_bytes)
  num_blocks <- length(padded) / 64
  
  state <- SHA256_H_INIT
  for (b in 1:num_blocks) {
    block_start <- (b - 1) * 64 + 1
    block_end <- b * 64
    state <- sha256_transform_block(state, padded[block_start:block_end])
  }
  
  # Format as hex string
  hex_str <- paste0(sprintf("%08x", state), collapse = "")
  return(hex_str)
}

# Double SHA-256 (SHA-256d) used in proof-of-work
sha256d <- function(raw_bytes) {
  first_hex <- sha256_digest(raw_bytes)
  # Convert hex to raw
  first_raw <- as.raw(as.hexmode(substring(first_hex, seq(1, nchar(first_hex), 2), seq(2, nchar(first_hex), 2))))
  second_hex <- sha256_digest(first_raw)
  return(second_hex)
}

# Unit Test Runner for SHA-256 Reference Core
test_sha256_core <- function() {
  cat("[SHA-256 Core] Running FIPS PUB 180-4 Test Vectors...\n")
  
  # Vector 1: Empty string
  v1 <- sha256_digest("")
  expected_1 <- "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  stopifnot(v1 == expected_1)
  cat("  ✓ Test 1 Passed (Empty string)\n")
  
  # Vector 2: "abc"
  v2 <- sha256_digest("abc")
  expected_2 <- "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
  stopifnot(v2 == expected_2)
  cat("  ✓ Test 2 Passed ('abc')\n")
  
  # Vector 3: 56-byte string "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"
  v3 <- sha256_digest("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq")
  expected_3 <- "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1"
  stopifnot(v3 == expected_3)
  cat("  ✓ Test 3 Passed (Multi-chunk NIST standard vector)\n")
  
  cat("[SHA-256 Core] All NIST cryptographic reference tests verified successfully.\n")
  return(TRUE)
}
