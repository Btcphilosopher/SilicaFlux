# ==============================================================================
# SHA256-LEARN-R : Model Evaluation, Cross-Validation & Selection (Pure R)
# ==============================================================================
# Evaluates competing ML models on hold-out ASIC telemetry datasets across RMSE,
# MAE, R^2, and runtime inference efficiency.
# ==============================================================================

calculate_metrics <- function(y_true, y_pred) {
  residuals <- y_true - y_pred
  n <- length(y_true)
  
  mse <- mean(residuals^2)
  rmse <- sqrt(mse)
  mae <- mean(abs(residuals))
  
  ss_tot <- sum((y_true - mean(y_true))^2)
  ss_res <- sum(residuals^2)
  r_squared <- if (ss_tot > 0) max(0, 1 - (ss_res / ss_tot)) else 1.0
  mape <- mean(abs(residuals / pmax(1e-5, abs(y_true)))) * 100
  
  list(
    rmse = rmse,
    mae = mae,
    r_squared = r_squared,
    mape = mape
  )
}

compare_and_select_models <- function(
  train_X, train_y,
  test_X, test_y
) {
  cat("[Model Selection] Training & Benchmarking Competing ML Architectures...\n")
  
  results <- list()
  
  # 1. Linear Regression
  t0 <- Sys.time()
  model_lr <- train_linear_regression(train_X, train_y)
  t_train_lr <- as.numeric(difftime(Sys.time(), t0, units = "secs")) * 1000
  
  t0 <- Sys.time()
  pred_lr <- predict_linear_regression(model_lr, test_X)$predictions[, 1]
  t_inf_lr <- (as.numeric(difftime(Sys.time(), t0, units = "secs")) * 1e6) / nrow(test_X)
  m_lr <- calculate_metrics(test_y, pred_lr)
  
  # 2. Random Forest
  t0 <- Sys.time()
  model_rf <- train_random_forest(train_X, train_y, n_trees = 15, max_depth = 4)
  t_train_rf <- as.numeric(difftime(Sys.time(), t0, units = "secs")) * 1000
  
  t0 <- Sys.time()
  pred_rf <- predict_random_forest(model_rf, test_X)$predictions
  t_inf_rf <- (as.numeric(difftime(Sys.time(), t0, units = "secs")) * 1e6) / nrow(test_X)
  m_rf <- calculate_metrics(test_y, pred_rf)
  
  # 3. Gradient Boosting
  t0 <- Sys.time()
  model_gb <- train_gradient_boosting(train_X, train_y, n_estimators = 15, learning_rate = 0.1)
  t_train_gb <- as.numeric(difftime(Sys.time(), t0, units = "secs")) * 1000
  
  t0 <- Sys.time()
  pred_gb <- predict_gradient_boosting(model_gb, test_X)$predictions
  t_inf_gb <- (as.numeric(difftime(Sys.time(), t0, units = "secs")) * 1e6) / nrow(test_X)
  m_gb <- calculate_metrics(test_y, pred_gb)
  
  # 4. Neural Network (MLP)
  t0 <- Sys.time()
  model_nn <- train_neural_network(train_X, train_y, hidden_units = 16, epochs = 100, lr = 0.02)
  t_train_nn <- as.numeric(difftime(Sys.time(), t0, units = "secs")) * 1000
  
  t0 <- Sys.time()
  pred_nn <- predict_neural_network(model_nn, test_X)$predictions
  t_inf_nn <- (as.numeric(difftime(Sys.time(), t0, units = "secs")) * 1e6) / nrow(test_X)
  m_nn <- calculate_metrics(test_y, pred_nn)
  
  comparison_df <- data.frame(
    Model = c("Linear Regression", "Random Forest", "Gradient Boosting", "Neural Network (MLP)"),
    RMSE = c(m_lr$rmse, m_rf$rmse, m_gb$rmse, m_nn$rmse),
    MAE = c(m_lr$mae, m_rf$mae, m_gb$mae, m_nn$mae),
    R_Squared = c(m_lr$r_squared, m_rf$r_squared, m_gb$r_squared, m_nn$r_squared),
    MAPE_Percent = c(m_lr$mape, m_rf$mape, m_gb$mape, m_nn$mape),
    Train_Time_ms = c(t_train_lr, t_train_rf, t_train_gb, t_train_nn),
    Inference_us_per_sample = c(t_inf_lr, t_inf_rf, t_inf_gb, t_inf_nn),
    stringsAsFactors = FALSE
  )
  
  # Rank by best R_Squared / lowest RMSE
  comparison_df <- comparison_df[order(-comparison_df$R_Squared, comparison_df$RMSE), ]
  rownames(comparison_df) <- NULL
  
  best_model_name <- comparison_df$Model[1]
  best_model_obj <- switch(
    best_model_name,
    "Linear Regression" = model_lr,
    "Random Forest" = model_rf,
    "Gradient Boosting" = model_gb,
    "Neural Network (MLP)" = model_nn
  )
  
  list(
    comparison_table = comparison_df,
    best_model_name = best_model_name,
    best_model_obj = best_model_obj,
    models = list(lr = model_lr, rf = model_rf, gb = model_gb, nn = model_nn)
  )
}
