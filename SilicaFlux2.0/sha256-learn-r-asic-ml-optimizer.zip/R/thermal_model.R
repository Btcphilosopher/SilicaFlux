# ==============================================================================
# SHA256-LEARN-R : Thermodynamic Package & Heat Dissipation Model
# ==============================================================================
# Simulates Silicon Junction Temperature (T_j) dynamics using RC Thermal Network
# (Thermal Resistance R_th, Thermal Capacitance C_th, Newton's law of cooling).
# ==============================================================================

# Calculate steady-state junction temperature
calculate_steady_state_temp <- function(asic, power_watts) {
  asic$ambient_temperature + (power_watts * asic$thermal_resistance)
}

# Step thermal state over dt seconds
step_thermal_state <- function(
  asic,
  current_temp_c,
  power_watts,
  dt_seconds = 0.1,
  fan_speed_ratio = 1.0 # 0.5 to 1.5 cooling speed multiplier
) {
  effective_r_th <- asic$thermal_resistance / (0.6 + 0.4 * fan_speed_ratio)
  c_thermal <- 180.0 # Heat capacity of package + copper cold plate in J/°C
  
  # Heat generated vs Heat dissipated through sink
  q_in <- power_watts
  q_out <- (current_temp_c - asic$ambient_temperature) / effective_r_th
  
  # dT/dt = (Q_in - Q_out) / C_th
  delta_t <- ((q_in - q_out) / c_thermal) * dt_seconds
  new_temp_c <- current_temp_c + delta_t
  
  # Safety floor at ambient
  new_temp_c <- max(asic$ambient_temperature, new_temp_c)
  
  thermal_headroom <- max(0, asic$temperature_limit - new_temp_c)
  
  # Thermal throttling ratio if temp approaches limit
  throttling_factor <- if (new_temp_c >= asic$temperature_limit) {
    max(0.1, 1.0 - (new_temp_c - asic$temperature_limit) * 0.1)
  } else if (new_temp_c > asic$temperature_limit - 5.0) {
    1.0 - ((new_temp_c - (asic$temperature_limit - 5.0)) / 5.0) * 0.15
  } else {
    1.0
  }
  
  list(
    temperature_c = new_temp_c,
    thermal_headroom_c = thermal_headroom,
    steady_state_target_c = calculate_steady_state_temp(asic, power_watts),
    throttling_factor = throttling_factor,
    heat_dissipated_watts = q_out
  )
}
