# ==============================================================================
# SHA256-LEARN-R : MASTER RESEARCH EXPERIMENT & MACHINE-LEARNING RUNNER (Pure R)
# ==============================================================================
# Execution Entry Point: Rscript R/main.R
#
# Investigates whether statistical learning & reinforcement algorithms can
# autonomously learn optimal voltage, frequency, core gating, and scheduling
# configurations for a multi-engine SHA-256 ASIC mining system under strict
# semiconductor physics constraints (DVFS, junction thermal limits, power cap).
# ==============================================================================

cat("\n==============================================================================\n")
cat("          SHA256-LEARN-R : ASIC MACHINE-LEARNING OPTIMISATION ENGINE           \n")
cat("==============================================================================\n\n")

# 1. Source all modular R subsystems
source_files <- c(
  "R/sha256_core.R",
  "R/sha256_pipeline.R",
  "R/asic_model.R",
  "R/mining_workload.R",
  "R/hardware_state.R",
  "R/power_model.R",
  "R/thermal_model.R",
  "R/scheduler.R",
  "R/telemetry.R",
  "R/feature_engineering.R",
  "R/ml_model.R",
  "R/reinforcement_learning.R",
  "R/optimisation_engine.R",
  "R/anomaly_detection.R",
  "R/model_selection.R",
  "R/experiment_engine.R",
  "R/benchmark_engine.R"
)

# Robust source loader (works whether running from project root or R/ folder)
for (f in source_files) {
  target <- if (file.exists(f)) f else file.path("..", f)
  if (file.exists(target)) {
    source(target)
  } else {
    cat(sprintf("Warning: Could not locate source file %s\n", f))
  }
}

# ------------------------------------------------------------------------------
# STEP 1: Cryptographic Core Ground Truth Verification
# ------------------------------------------------------------------------------
cat("\n[STEP 1/6] Verifying Pure-R FIPS 180-4 SHA-256 Ground Truth Core...\n")
test_sha256_core()

# ------------------------------------------------------------------------------
# STEP 2: Initialize ASIC Digital Twin & Simulation Experiment
# ------------------------------------------------------------------------------
cat("\n[STEP 2/6] Spawning ASIC Digital Twin & Running Telemetry Trajectory...\n")
asic <- create_asic(
  cores = 1000,
  pipelines_per_core = 1,
  stages_per_pipeline = 64,
  clock_frequency = 850e6,
  voltage = 0.72,
  power_limit = 2500,
  temperature_limit = 85.0
)

experiment_result <- run_experiment(
  cores = asic$cores,
  frequency = asic$clock_frequency,
  voltage = asic$voltage,
  iterations = 120,
  objective = "BALANCED_PERFORMANCE",
  enable_rl_learning = TRUE,
  verbose = TRUE
)

telemetry_data <- experiment_result$telemetry
features_data <- experiment_result$features

# ------------------------------------------------------------------------------
# STEP 3: Machine Learning Model Training & Comparative Benchmark
# ------------------------------------------------------------------------------
cat("\n[STEP 3/6] Training & Comparing Competing ML Models on Hold-Out Data...\n")
# Prepare Feature Matrix & Target
feature_cols <- c("frequency_mhz", "voltage_v", "core_utilisation", "pipeline_utilisation", "temperature_c")
X <- features_data[, feature_cols, drop = FALSE]
y <- features_data$hashrate_ghs

# 80/20 Train-Test Split
set.seed(42)
n_obs <- nrow(X)
train_idx <- sample(1:n_obs, round(0.8 * n_obs))
train_X <- X[train_idx, , drop = FALSE]
train_y <- y[train_idx]
test_X  <- X[-train_idx, , drop = FALSE]
test_y  <- y[-train_idx]

model_comparison <- compare_and_select_models(train_X, train_y, test_X, test_y)
print(model_comparison$comparison_table)

# ------------------------------------------------------------------------------
# STEP 4: Feature Importance Analysis (Tree Models)
# ------------------------------------------------------------------------------
cat("\n[STEP 4/6] Computing Silicon Performance Feature Importance...\n")
rf_model <- model_comparison$models$rf
feat_imp <- rf_model$feature_importance
imp_df <- data.frame(
  Feature = names(feat_imp),
  Importance_Pct = round(feat_imp * 100, 2),
  stringsAsFactors = FALSE
)
imp_df <- imp_df[order(-imp_df$Importance_Pct), ]
print(imp_df)

# ------------------------------------------------------------------------------
# STEP 5: Autonomous ASIC Search & Pareto Frontier Extraction
# ------------------------------------------------------------------------------
cat("\n[STEP 5/6] Executing Autonomous Multi-Objective Pareto Optimisation...\n")
optimal_solution <- optimise_asic(
  asic,
  ml_model = model_comparison$best_model_obj,
  objective = "MAXIMUM_EFFICIENCY",
  n_samples = 200
)

cat(sprintf("  Optimal Clock:   %.0f MHz\n", optimal_solution$optimal_frequency / 1e6))
cat(sprintf("  Optimal Voltage: %.3f V\n", optimal_solution$optimal_voltage))
cat(sprintf("  Active Cores:    %d / %d\n", optimal_solution$optimal_core_count, asic$cores))
cat(sprintf("  Predicted Hash:  %.2f GH/s\n", optimal_solution$predicted_hashrate_ghs))
cat(sprintf("  Predicted Power: %.1f W\n", optimal_solution$predicted_power_watts))
cat(sprintf("  Predicted Temp:  %.1f °C\n", optimal_solution$predicted_temperature_c))
cat(sprintf("  Energy/Hash:     %.2f nJ/hash (%.2f MH/J)\n", 
            optimal_solution$energy_per_hash_nj, optimal_solution$hashes_per_joule / 1e6))

# Extract Pareto Frontier
pareto_df <- extract_pareto_frontier(optimal_solution$evaluated_population)
cat(sprintf("  Identified %d non-dominated Pareto frontier operating points.\n", sum(pareto_df$is_pareto)))

# ------------------------------------------------------------------------------
# STEP 6: Tri-State Comparative Benchmark & Report
# ------------------------------------------------------------------------------
cat("\n[STEP 6/6] Generating Tri-State ASIC Comparative Benchmark...\n")
benchmark_results <- benchmark_asic(asic, optimal_solution, simulation_duration = 30)
print(benchmark_results$benchmark_table)

cat("\n==============================================================================\n")
cat("                            OPTIMISATION SUMMARY                              \n")
cat("==============================================================================\n")
cat(sprintf("  Hashrate Improvement:   %+6.2f%%\n", benchmark_results$improvement_summary$hashrate_improvement_pct))
cat(sprintf("  Power Consumption:      %+6.2f%%\n", benchmark_results$improvement_summary$power_delta_pct))
cat(sprintf("  Energy Efficiency:      %+6.2f%% (Hashes/Joule)\n", benchmark_results$improvement_summary$efficiency_improvement_pct))
cat(sprintf("  Thermal Junction Delta: %+6.2f °C\n", benchmark_results$improvement_summary$temperature_delta_c))
cat("==============================================================================\n\n")

# Save outputs to results directory if exists
if (!dir.exists("results")) dir.create("results", showWarnings = FALSE)
write.csv(telemetry_data, "results/telemetry_output.csv", row.names = FALSE)
write.csv(benchmark_results$benchmark_table, "results/benchmark_summary.csv", row.names = FALSE)
write.csv(pareto_df, "results/pareto_frontier.csv", row.names = FALSE)
cat("[Output] Telemetry, benchmark summary, and Pareto frontier exported to results/ directory.\n\n")
