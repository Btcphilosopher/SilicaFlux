# ==============================================================================
# SHA256-LEARN-R : Multi-Core ASIC Task Scheduler & Core Gating Policy (Pure R)
# ==============================================================================
# Distributes cryptographic jobs across physical hashing engines while handling
# power-gating, core thermal mitigation, and load-balancing.
# ==============================================================================

SCHEDULER_POLICIES <- c(
  "UNIFORM_ROUND_ROBIN",
  "THERMAL_AWARE_BALANCING",
  "WORK_STEALING",
  "DYNAMIC_VOLTAGE_CORE_GATING",
  "THROUGHPUT_MAXIMIZING"
)

create_scheduler <- function(policy = "DYNAMIC_VOLTAGE_CORE_GATING") {
  if (!policy %in% SCHEDULER_POLICIES) {
    stop(paste("Invalid policy. Must be one of:", paste(SCHEDULER_POLICIES, collapse = ", ")))
  }
  list(
    policy = policy,
    dispatched_batches = 0,
    scheduling_efficiency = 0.95
  )
}

schedule_workload <- function(
  scheduler,
  asic,
  workload_job,
  active_cores,
  current_temp_c,
  batch_size = 100000
) {
  policy <- scheduler$policy
  
  # Scheduling efficiency and core distribution factor
  eff <- switch(
    policy,
    "UNIFORM_ROUND_ROBIN" = 0.92,
    "THERMAL_AWARE_BALANCING" = if (current_temp_c > 75) 0.96 else 0.90,
    "WORK_STEALING" = 0.94,
    "DYNAMIC_VOLTAGE_CORE_GATING" = 0.98,
    "THROUGHPUT_MAXIMIZING" = 0.95,
    0.90
  )
  
  # Thermal throttling reduction on scheduling
  thermal_penalty <- if (current_temp_c > asic$temperature_limit - 3) {
    (current_temp_c - (asic$temperature_limit - 3)) * 0.08
  } else 0
  
  final_efficiency <- max(0.40, min(1.0, eff - thermal_penalty))
  
  list(
    policy = policy,
    active_cores_scheduled = active_cores,
    effective_batch_size = batch_size * active_cores,
    scheduling_efficiency = final_efficiency,
    core_gating_savings_ratio = (asic$cores - active_cores) / asic$cores
  )
}
