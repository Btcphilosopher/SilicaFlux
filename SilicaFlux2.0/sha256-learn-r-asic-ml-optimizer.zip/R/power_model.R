# ==============================================================================
# SHA256-LEARN-R : Semiconductor Power Dissipation Model (Pure R)
# ==============================================================================
# Calculates dynamic switching power, sub-threshold leakage, and clock network
# power across voltage, frequency, active core count, and thermal states.
# ==============================================================================

calculate_asic_power <- function(
  asic,
  active_cores = NULL,
  voltage = NULL,
  frequency = NULL,
  temperature = NULL,
  pipeline_utilisation = 0.85
) {
  cores_act <- if (!is.null(active_cores)) active_cores else asic$cores * asic$parallelism
  v <- if (!is.null(voltage)) voltage else asic$voltage
  f <- if (!is.null(frequency)) frequency else asic$clock_frequency
  t_j <- if (!is.null(temperature)) temperature else asic$ambient_temperature
  
  # Effective switching capacitance per active 64-stage SHA-256 core (Farads)
  # 5nm cell library: ~1.8e-12 F per core pipeline
  c_eff_core <- 1.85e-12 * (asic$process_node_nm / 5.0)
  
  # Dynamic Power: P_dyn = alpha * C_eff * V^2 * f * N_active * Utilisation
  p_dynamic <- c_eff_core * (v^2) * f * cores_act * pipeline_utilisation
  
  # Clock Tree Distribution Power (scales with total cores and clock)
  c_clock_tree <- 0.35e-12 * asic$cores
  p_clock <- c_clock_tree * (v^2) * f
  
  # Static Sub-threshold Leakage Power (Exponentially temperature dependent)
  # I_leak(T) = I_0 * (T / T_ref)^2 * exp( -q * V_th / (k * T) )
  # Simplified standard empirical fit:
  t_kelvin <- t_j + 273.15
  t_ref_kelvin <- 25.0 + 273.15
  leakage_temp_factor <- ((t_kelvin / t_ref_kelvin)^2) * exp((t_j - 25.0) / 48.0)
  base_leakage_per_core <- 0.00035 * (v / 0.72) # ~0.35mW at 25C 0.72V
  p_leakage <- asic$cores * base_leakage_per_core * v * leakage_temp_factor
  
  # I/O and PLL Controller base power
  p_io <- 12.5 * (v / 0.72)
  
  p_total <- p_dynamic + p_clock + p_leakage + p_io
  
  list(
    total_power_watts = p_total,
    dynamic_power_watts = p_dynamic,
    leakage_power_watts = p_leakage,
    clock_power_watts = p_clock,
    io_power_watts = p_io,
    power_headroom_watts = max(0, asic$power_limit - p_total)
  )
}
