# ==============================================================================
# SHA256-LEARN-R : ASIC Digital Twin & Simulation Experiment Engine (Pure R)
# ==============================================================================
# Orchestrates end-to-end hardware simulation loops, online telemetry capture,
# and reinforcement learning optimization trajectories.
# ==============================================================================

run_experiment <- function(
  cores = 1000,
  frequency = 850e6,
  voltage = 0.72,
  iterations = 150,
  objective = "BALANCED_PERFORMANCE",
  enable_rl_learning = TRUE,
  verbose = TRUE
) {
  if (verbose) {
    cat(sprintf("[Experiment Engine] Initializing ASIC Digital Twin (%d cores, %.0f MHz, %.2f V)...\n",
                cores, frequency / 1e6, voltage))
  }
  
  # 1. Initialize Silicon Digital Twin
  asic <- create_asic(
    cores = cores,
    clock_frequency = frequency,
    voltage = voltage
  )
  
  pipeline_cfg <- create_pipeline_config(stages = asic$stages_per_pipeline, clock_mhz = frequency / 1e6)
  scheduler <- create_scheduler("DYNAMIC_VOLTAGE_CORE_GATING")
  job <- create_mining_job(job_id = 101, difficulty_bits = 16)
  telemetry_buf <- init_telemetry_buffer(capacity = iterations + 50)
  reward_cfg <- create_reward_config(objective)
  rl_agent <- create_rl_agent(epsilon_start = 0.8, epsilon_decay = 0.98)
  
  current_temp <- asic$ambient_temperature
  history_records <- list()
  reward_history <- numeric(iterations)
  action_history <- character(iterations)
  
  # Baseline Hashrate for relative scaling
  base_power_res <- calculate_asic_power(asic, active_cores = cores, voltage = voltage, frequency = frequency, temperature = 25)
  base_pipe_res <- simulate_pipeline_execution(pipeline_cfg, 100000 * cores, cores, frequency, 0.001)
  baseline_hashrate <- base_pipe_res$effective_hashrate_ghs
  
  # 2. Execute Simulation Loop
  for (iter in 1:iterations) {
    active_cores <- max(1, round(asic$cores * asic$parallelism))
    
    # Task Scheduling
    sched_res <- schedule_workload(scheduler, asic, job, active_cores, current_temp)
    
    # SHA-256 Deep Hardware Pipeline
    pipe_res <- simulate_pipeline_execution(
      pipeline_cfg,
      workload_items_available = sched_res$effective_batch_size,
      active_pipelines = active_cores * asic$pipelines_per_core,
      clock_freq_hz = asic$clock_frequency,
      duration_sec = 0.001
    )
    
    # Semiconductor Power Dissipation
    pwr_res <- calculate_asic_power(
      asic,
      active_cores = active_cores,
      voltage = asic$voltage,
      frequency = asic$clock_frequency,
      temperature = current_temp,
      pipeline_utilisation = pipe_res$pipeline_utilisation
    )
    
    # Thermodynamic Heat Dissipation
    thermal_res <- step_thermal_state(
      asic,
      current_temp_c = current_temp,
      power_watts = pwr_res$total_power_watts,
      dt_seconds = 0.1
    )
    current_temp <- thermal_res$temperature_c
    
    # Telemetry Snapshot
    telemetry_snap <- generate_telemetry_snapshot(
      cycle_id = iter,
      asic = asic,
      active_cores = active_cores,
      pipe_res = pipe_res,
      power_res = pwr_res,
      thermal_res = thermal_res,
      scheduler_res = sched_res,
      workload_job = job
    )
    
    telemetry_buf <- record_telemetry(telemetry_buf, telemetry_snap)
    history_records[[iter]] <- telemetry_snap
    
    # Constraints check & Reward
    limits <- check_hardware_limits(
      asic,
      voltage = asic$voltage,
      frequency = asic$clock_frequency,
      power = pwr_res$total_power_watts,
      temp = current_temp
    )
    
    step_reward <- calculate_reward(reward_cfg, telemetry_snap, limits, hashrate_baseline = baseline_hashrate)
    reward_history[iter] <- step_reward
    
    # State Vector and RL Action Step
    if (enable_rl_learning) {
      state_vec <- create_hardware_state(
        clock_frequency = asic$clock_frequency,
        voltage = asic$voltage,
        active_cores = active_cores,
        pipeline_utilisation = pipe_res$pipeline_utilisation,
        core_utilisation = active_cores / asic$cores,
        temperature = current_temp,
        power = pwr_res$total_power_watts,
        thermal_headroom = thermal_res$thermal_headroom_c,
        hashes_per_second = pipe_res$effective_hashrate_ghs * 1e9,
        hashes_per_joule = telemetry_snap$hashes_per_joule
      )
      
      state_key <- discretize_state(state_vec)
      action_idx <- select_rl_action(rl_agent, state_key)
      action_name <- ACTION_NAMES[action_idx]
      action_history[iter] <- action_name
      
      # Apply action to mutate hardware parameters
      action_result <- apply_action_to_asic(asic, action_idx)
      new_asic <- action_result$asic
      
      # Compute next state and update Q-table
      next_state_vec <- state_vec
      next_state_vec["clock_frequency"] <- new_asic$clock_frequency
      next_state_vec["voltage"] <- new_asic$voltage
      next_state_key <- discretize_state(next_state_vec)
      
      rl_agent <- update_rl_agent(rl_agent, state_key, action_idx, step_reward, next_state_key)
      
      # Update ASIC if action was physically valid
      limits_next <- check_hardware_limits(new_asic)
      if (limits_next$is_valid) {
        asic <- new_asic
      }
    }
  }
  
  telemetry_df <- get_telemetry_df(telemetry_buf)
  
  # Engineer features
  feature_df <- engineer_telemetry_features(telemetry_df)
  feature_df$reward <- reward_history
  feature_df$action <- action_history
  
  if (verbose) {
    cat(sprintf("[Experiment Engine] Completed %d simulation cycles. Final Hashrate: %.2f GH/s, Power: %.1f W, Temp: %.1f °C, Eff: %.2f MH/J\n",
                iterations,
                tail(telemetry_df$hashrate_ghs, 1),
                tail(telemetry_df$power_watts, 1),
                tail(telemetry_df$temperature_c, 1),
                tail(telemetry_df$hashes_per_joule, 1) / 1e6))
  }
  
  list(
    final_asic = asic,
    telemetry = telemetry_df,
    features = feature_df,
    reward_history = reward_history,
    action_history = action_history,
    rl_agent = rl_agent,
    iterations = iterations,
    objective = objective
  )
}
