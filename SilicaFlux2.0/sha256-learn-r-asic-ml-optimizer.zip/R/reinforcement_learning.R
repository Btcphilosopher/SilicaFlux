# ==============================================================================
# SHA256-LEARN-R : ASIC Reinforcement Learning Agent & Environment (Pure R)
# ==============================================================================
# Implements autonomous Q-learning and policy iteration for dynamic hardware
# voltage, frequency, core gating, and scheduling control under strict constraints.
# ==============================================================================

# Reward Weights Profile Configuration
create_reward_config <- function(
  objective = c("BALANCED_PERFORMANCE", "MAXIMUM_HASHRATE", "MAXIMUM_EFFICIENCY", 
                "MAXIMUM_HASHES_JOULE", "THERMAL_CONSTRAINED", "POWER_CONSTRAINED")
) {
  objective <- match.arg(objective)
  
  weights <- switch(
    objective,
    "MAXIMUM_HASHRATE" = list(
      alpha = 1.0,  # Hashrate priority
      beta  = 0.1,  # Efficiency
      gamma = 0.3,  # Pipeline utilisation
      delta = 0.4,  # Power penalty
      epsilon = 0.6,# Thermal penalty
      zeta = 0.5    # Instability penalty
    ),
    "MAXIMUM_EFFICIENCY" = list(
      alpha = 0.2,
      beta  = 1.0,  # Maximize H/J
      gamma = 0.4,
      delta = 0.6,
      epsilon = 0.5,
      zeta = 0.5
    ),
    "MAXIMUM_HASHES_JOULE" = list(
      alpha = 0.1,
      beta  = 1.2,
      gamma = 0.3,
      delta = 0.7,
      epsilon = 0.5,
      zeta = 0.5
    ),
    "THERMAL_CONSTRAINED" = list(
      alpha = 0.4,
      beta  = 0.4,
      gamma = 0.3,
      delta = 0.4,
      epsilon = 1.5, # Heavy thermal penalty
      zeta = 0.8
    ),
    "POWER_CONSTRAINED" = list(
      alpha = 0.4,
      beta  = 0.5,
      gamma = 0.3,
      delta = 1.5, # Heavy power penalty
      epsilon = 0.6,
      zeta = 0.6
    ),
    # Default BALANCED_PERFORMANCE
    list(
      alpha = 0.5,
      beta  = 0.5,
      gamma = 0.3,
      delta = 0.5,
      epsilon = 0.6,
      zeta = 0.5
    )
  )
  
  list(
    objective = objective,
    weights = weights
  )
}

# Multi-Objective Reward Calculation
calculate_reward <- function(
  reward_cfg,
  telemetry,
  constraint_check,
  hashrate_baseline = 1000
) {
  w <- reward_cfg$weights
  
  # Normalised Hashrate
  norm_hashrate <- telemetry$hashrate_ghs / max(1, hashrate_baseline)
  
  # Normalised Hashes per Joule (scaled to [0, 1])
  norm_eff <- min(1.0, telemetry$hashes_per_joule / 2.5e9)
  
  # Pipeline Utilisation
  pipe_util <- telemetry$pipeline_utilisation
  
  # Power Penalty (exponential as it approaches limit)
  power_ratio <- telemetry$power_watts / (telemetry$power_watts + telemetry$power_headroom_w)
  power_penalty <- if (power_ratio > 0.95) (power_ratio - 0.95) * 20.0 else 0
  
  # Temperature Penalty
  temp_penalty <- if (telemetry$temperature_c > 80.0) {
    ((telemetry$temperature_c - 80.0) / 5.0)^2
  } else 0
  
  # Instability / Violation Penalty
  instability_penalty <- if (!constraint_check$is_valid) 50.0 else 0
  
  # Multi-objective synthesis
  reward <- (w$alpha * norm_hashrate) +
            (w$beta  * norm_eff) +
            (w$gamma * pipe_util) -
            (w$delta * power_penalty) -
            (w$epsilon * temp_penalty) -
            (w$zeta  * instability_penalty)
            
  return(reward)
}

# Create Reinforcement Learning Agent
create_rl_agent <- function(
  n_actions = 12,
  n_states_bins = 5,
  learning_rate = 0.1,
  discount_factor = 0.95,
  epsilon_start = 1.0,
  epsilon_min = 0.05,
  epsilon_decay = 0.995
) {
  # State discretization grid (Frequency, Voltage, Temp, Power)
  q_table <- list()
  
  list(
    n_actions = n_actions,
    lr = learning_rate,
    gamma = discount_factor,
    epsilon = epsilon_start,
    epsilon_min = epsilon_min,
    epsilon_decay = epsilon_decay,
    q_table = q_table,
    experience_buffer = list(),
    total_steps = 0
  )
}

# Discretize continuous state into discrete key
discretize_state <- function(state_vector) {
  f_bin <- floor(state_vector["clock_frequency"] / 100e6)
  v_bin <- floor(state_vector["voltage"] * 50)
  t_bin <- floor(state_vector["temperature"] / 10)
  p_bin <- floor(state_vector["power"] / 250)
  paste(f_bin, v_bin, t_bin, p_bin, sep = "_")
}

# Select Action using Epsilon-Greedy Exploration
select_rl_action <- function(agent, state_key) {
  if (runif(1) < agent$epsilon) {
    # Explore
    action_idx <- sample(1:agent$n_actions, 1)
  } else {
    # Exploit
    if (is.null(agent$q_table[[state_key]])) {
      action_idx <- sample(1:agent$n_actions, 1)
    } else {
      q_vals <- agent$q_table[[state_key]]
      max_q <- max(q_vals)
      best_actions <- which(q_vals == max_q)
      action_idx <- if (length(best_actions) > 1) sample(best_actions, 1) else best_actions[1]
    }
  }
  return(action_idx)
}

# Update Q-Value via Bellman Equation
update_rl_agent <- function(agent, state_key, action_idx, reward, next_state_key) {
  if (is.null(agent$q_table[[state_key]])) {
    agent$q_table[[state_key]] <- rep(0.0, agent$n_actions)
  }
  if (is.null(agent$q_table[[next_state_key]])) {
    agent$q_table[[next_state_key]] <- rep(0.0, agent$n_actions)
  }
  
  current_q <- agent$q_table[[state_key]][action_idx]
  max_next_q <- max(agent$q_table[[next_state_key]])
  
  # Bellman update
  new_q <- current_q + agent$lr * (reward + agent$gamma * max_next_q - current_q)
  agent$q_table[[state_key]][action_idx] <- new_q
  
  # Decay exploration epsilon
  agent$epsilon <- max(agent$epsilon_min, agent$epsilon * agent$epsilon_decay)
  agent$total_steps <- agent$total_steps + 1
  
  return(agent)
}
