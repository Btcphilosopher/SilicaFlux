# rtl/vector — not yet implemented

Planned: `sfx_vector_lane`, `sfx_vector_engine`, `sfx_vector_scheduler`
(PHASE 11). See `docs/PHASE_STATUS.md`.
