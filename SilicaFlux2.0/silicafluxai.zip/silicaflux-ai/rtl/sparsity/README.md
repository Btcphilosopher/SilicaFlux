# rtl/sparsity — not yet implemented

Planned: `sfx_sparse_decoder`, `sfx_sparse_scheduler`, `sfx_zero_skipper`,
`sfx_metadata_engine` (PHASE 9). `architectures/sparse.yaml` documents the
intended schema shape for this (all fields marked schema-DESCRIPTIVE). See
`docs/PHASE_STATUS.md`.
