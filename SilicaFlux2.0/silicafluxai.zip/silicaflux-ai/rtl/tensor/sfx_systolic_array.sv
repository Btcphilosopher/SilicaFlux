// =============================================================================
// sfx_systolic_array.sv
// SilicaFlux-AI :: rtl/tensor
//
// A ROWS x COLS weight-stationary systolic array built from sfx_pe (see that
// file for the per-PE contract). This module is pure structural wiring plus
// the mesh of registers inside each PE -- it adds no combinational logic of
// its own beyond the boundary array indexing.
//
//   Weight loading (load_mode=1): each of the COLS columns has an
//   independent weight_in lane at its top (row 0) boundary. Column c's ROWS
//   values must be fed in *reverse row order* (row ROWS-1's weight first,
//   row 0's last) over exactly ROWS consecutive load_mode=1 cycles -- see
//   sfx_pe.sv's header for why. All COLS columns load in parallel, so a full
//   ROWS x COLS weight tile loads in ROWS cycles regardless of COLS.
//
//   Compute (load_mode=0, compute_en=1): activations enter at each row's
//   west boundary and are consumed left-to-right as they cross the row;
//   partial sums enter at each column's north boundary (the caller ties
//   psum_in to 0 for a fresh tile, or to a prior partial result to continue
//   accumulating a K dimension larger than ROWS across multiple passes) and
//   exit, fully accumulated across all ROWS of this pass, at psum_out.
//
//   Systolic skew requirement: for PE(r,c)'s product act*weight to combine
//   the correct (matching-index) activation and psum term, activation row r
//   must be injected with a start delay of r cycles relative to row 0 (and
//   correspondingly, output row m's result at column c drains r cycles later
//   than it would in a non-skewed design). This module does NOT skew its
//   own boundary ports -- it is a fixed-latency structural mesh, exactly
//   like a real ASIC systolic array's wiring. Skewing the activation feed
//   (and de-skewing the result capture) is sfx_tensor_loader / the GEMM
//   controller's job, matching the "make pipeline stages explicit" /
//   "make memory movement explicit" engineering rules -- see
//   docs/ARCHITECTURE.md's systolic timing diagram for a worked ROWS=4
//   example and tb/unit/tb_sfx_systolic_array.sv for the reference
//   skewed-injection testbench sequence.
//
//   Port shape: every multi-lane boundary (weight/act/psum in and out) is a
//   single flattened packed vector -- lane i occupies bits
//   [ (i+1)*WIDTH-1 : i*WIDTH ] -- rather than a SystemVerilog unpacked
//   array port. This is a deliberate, portable choice, not just a style
//   preference: unpacked array ports have inconsistent support across
//   simulators and synthesis front-ends (this repo's own open-source
//   regression flow, Icarus Verilog, silently fails to propagate values
//   through an unpacked array port at all -- confirmed while bringing this
//   module up, see docs/TOOLING.md), whereas a flattened packed vector with
//   `+:` part-selects is universally supported. Callers reconstruct/take
//   apart individual signed lanes with `lane_i = $signed(flat[i*WIDTH +:
//   WIDTH])` (see tb/unit/tb_sfx_systolic_array.sv for the pattern this
//   module itself uses internally, and which the GEMM controller reuses at
//   its own instantiation of this array).
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sfx_systolic_array #(
    parameter int ROWS       = 16,
    parameter int COLS       = 16,
    parameter int DATA_WIDTH = 8,
    parameter int ACC_WIDTH  = 32
)(
    input  wire logic clk,
    input  wire logic rst_n,

    input  wire logic load_mode,
    input  wire logic compute_en,

    // Flattened multi-lane boundary buses -- see header for the layout and
    // rationale. Bit widths are unsigned bus containers; each lane's
    // signedness is reconstructed with $signed() where it is unpacked.
    input  wire logic [COLS*DATA_WIDTH-1:0] weight_in_flat, // top boundary, per column
    input  wire logic [ROWS*DATA_WIDTH-1:0] act_in_flat,    // west boundary, per row
    input  wire logic [COLS*ACC_WIDTH-1:0]  psum_in_flat,   // north boundary, per column

    output      logic [COLS*ACC_WIDTH-1:0]  psum_out_flat,   // bottom boundary -- the tile result
    output      logic [ROWS*DATA_WIDTH-1:0] act_out_flat,    // east boundary (observability)
    output      logic [COLS*DATA_WIDTH-1:0] weight_out_flat  // bottom boundary weight shift-out (observability)
);

    // Mesh wiring (module-internal only -- unpacked arrays are fine here,
    // the propagation issue described above is specific to *ports*).
    // act_mesh[r][0..COLS] spans one extra column (the west boundary
    // input); weight_mesh/psum_mesh[0..ROWS][c] span one extra row (the
    // north/top boundary input).
    logic signed [DATA_WIDTH-1:0] act_mesh     [ROWS][COLS+1];
    logic signed [DATA_WIDTH-1:0] weight_mesh   [ROWS+1][COLS];
    logic signed [ACC_WIDTH-1:0]  psum_mesh     [ROWS+1][COLS];

    genvar r, c;
    generate
        for (r = 0; r < ROWS; r++) begin : g_row
            assign act_mesh[r][0] = $signed(act_in_flat[r*DATA_WIDTH +: DATA_WIDTH]);
            assign act_out_flat[r*DATA_WIDTH +: DATA_WIDTH] = act_mesh[r][COLS];
        end
        for (c = 0; c < COLS; c++) begin : g_col
            assign weight_mesh[0][c] = $signed(weight_in_flat[c*DATA_WIDTH +: DATA_WIDTH]);
            assign psum_mesh[0][c]   = $signed(psum_in_flat[c*ACC_WIDTH +: ACC_WIDTH]);
            assign weight_out_flat[c*DATA_WIDTH +: DATA_WIDTH] = weight_mesh[ROWS][c];
            assign psum_out_flat[c*ACC_WIDTH +: ACC_WIDTH]     = psum_mesh[ROWS][c];
        end

        for (r = 0; r < ROWS; r++) begin : g_pe_row
            for (c = 0; c < COLS; c++) begin : g_pe_col
                sfx_pe #(
                    .DATA_WIDTH(DATA_WIDTH),
                    .ACC_WIDTH(ACC_WIDTH)
                ) u_pe (
                    .clk(clk),
                    .rst_n(rst_n),
                    .load_mode(load_mode),
                    .compute_en(compute_en),
                    .weight_in(weight_mesh[r][c]),
                    .weight_out(weight_mesh[r+1][c]),
                    .act_in(act_mesh[r][c]),
                    .act_out(act_mesh[r][c+1]),
                    .psum_in(psum_mesh[r][c]),
                    .psum_out(psum_mesh[r+1][c])
                );
            end
        end
    endgenerate

endmodule

`default_nettype wire
