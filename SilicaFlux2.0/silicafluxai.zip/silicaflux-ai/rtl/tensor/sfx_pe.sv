// =============================================================================
// sfx_pe.sv
// SilicaFlux-AI :: rtl/tensor
//
// A single weight-stationary systolic processing element. This is the atomic
// compute cell of rtl/tensor/sfx_systolic_array.sv (see that file's header
// for the array-level dataflow and required input skew).
//
// Two structural modes, selected by `load_mode` (broadcast identically to
// every PE in the array by the controller -- never set per-PE):
//
//   load_mode = 1 (weight load):
//     Every cycle, this PE captures `weight_in` (from the previous PE
//     north) into its single weight register, and combinationally exposes
//     that *same* (just-captured) register on `weight_out` towards the
//     next PE south. Chaining PEs this way makes each column a standard
//     one-register-per-stage shift register with exactly 1 cycle of delay
//     per row hop. To end up with PE(row=r) holding weight W[r], the
//     controller must feed the column's weights in *reverse* row order
//     over exactly ROWS cycles (row ROWS-1's weight first, row 0's weight
//     last) -- after ROWS cycles every row has shifted the value meant for
//     it exactly r positions and holds it stationary. See
//     tb/unit/tb_sfx_pe.sv and docs/ARCHITECTURE.md for a worked trace.
//     (An earlier version of this module registered weight_out separately
//     from weight_reg, which doubled the per-hop delay to 2 cycles and
//     silently broke loading for every row below row 0 -- caught by
//     tb/unit/tb_sfx_systolic_array.sv, not by this file's own unit test,
//     which is exactly why the array-level test exists in addition to the
//     PE-level one.)
//
//   load_mode = 0 (compute):
//     Every cycle that `compute_en` is high: act_out <= act_in (activation
//     continues flowing east, 1-cycle delay) and
//     psum_out <= psum_in + act_in * weight_reg (partial sum accumulates
//     the local product and continues flowing south, 1-cycle delay). The
//     weight register itself does not change in this mode -- it is
//     "stationary" for the whole tile's compute pass.
//
// No internal valid/backpressure signalling: like classic systolic-array
// designs, this PE is a pure fixed-latency structural pipeline stage. It is
// the *caller's* responsibility (sfx_tensor_loader / sfx_tensor_controller)
// to inject well-defined zero activations and zero psum_in at the array
// boundary during skew/ramp-up and ramp-down cycles so "no real data yet"
// cycles contribute an honest zero rather than garbage -- see
// docs/ARCHITECTURE.md's systolic timing diagram.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sfx_pe #(
    parameter int DATA_WIDTH = 8,
    parameter int ACC_WIDTH  = 32
)(
    input  wire logic                          clk,
    input  wire logic                          rst_n,

    input  wire logic                          load_mode,
    input  wire logic                          compute_en,

    input  wire logic signed [DATA_WIDTH-1:0]  weight_in,
    output      logic signed [DATA_WIDTH-1:0]  weight_out,

    input  wire logic signed [DATA_WIDTH-1:0]  act_in,
    output      logic signed [DATA_WIDTH-1:0]  act_out,

    input  wire logic signed [ACC_WIDTH-1:0]   psum_in,
    output      logic signed [ACC_WIDTH-1:0]   psum_out
);

    generate
        if (ACC_WIDTH < 2*DATA_WIDTH) begin : g_width_check
            $error("sfx_pe: ACC_WIDTH (%0d) must be >= 2*DATA_WIDTH (%0d)",
                    ACC_WIDTH, 2*DATA_WIDTH);
        end
    endgenerate

    // ---------------------------------------------------------------------
    // Stationary weight register / column shift chain
    // ---------------------------------------------------------------------
    logic signed [DATA_WIDTH-1:0] weight_reg;

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            weight_reg <= '0;
        end else if (load_mode) begin
            weight_reg <= weight_in;
        end
    end

    assign weight_out = weight_reg;

    // ---------------------------------------------------------------------
    // Compute datapath: multiply-accumulate-and-forward
    // ---------------------------------------------------------------------
    wire logic signed [2*DATA_WIDTH-1:0] product     = act_in * weight_reg;
    wire logic signed [ACC_WIDTH-1:0]    product_ext = ACC_WIDTH'(product); // sign-extend

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            act_out  <= '0;
            psum_out <= '0;
        end else if (compute_en) begin
            act_out  <= act_in;
            psum_out <= psum_in + product_ext;
        end
    end

endmodule

`default_nettype wire
