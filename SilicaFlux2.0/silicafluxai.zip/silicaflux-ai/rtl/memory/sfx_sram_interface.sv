// =============================================================================
// sfx_sram_interface.sv
// SilicaFlux-AI :: rtl/memory
//
// Single-port synchronous SRAM wrapper: one address bus shared between read
// and write, byte-strobed writes, and a registered (1-cycle-latency) read
// path -- the standard shape that FPGA/ASIC single-port BRAM/SRAM macros
// actually have, so this module's `mem` array is intended to map directly
// onto one at synthesis, not to be read as behavioural convenience.
//
// Protocol (see docs/MEMORY_PROTOCOL.md):
//   - `en` qualifies the whole request; `we` selects write (1) vs read (0).
//   - Write: on a clock edge with en&&we, for each byte i where wstrb[i] is
//     set, mem[addr][8*i +: 8] <= wdata[8*i +: 8]. Bytes with wstrb[i]=0
//     are left untouched (a true read-modify-write is NOT performed -- this
//     is a masked write, not a merge of new and old data through the read
//     port).
//   - Read: on a clock edge with en&&!we, rdata <= mem[addr] (visible the
//     *following* cycle) and rvalid pulses one cycle later to mark it.
//     There is no combinational (0-latency) read mode: real SRAM macros
//     don't have one, and pretending otherwise would make the timing this
//     module teaches downstream logic to expect actively wrong.
//   - Single port: a write and a read cannot both be issued on the same
//     cycle (there is one `addr`/`en`/`we` per cycle) -- a caller needing
//     concurrent read+write bandwidth must arbitrate (see
//     rtl/common/sfx_arbiter.sv, roadmap) or instantiate two of these as a
//     true dual-bank design.
//
// Reset: only `rvalid` (a control flop) is reset. `mem` itself is
// deliberately NOT reset -- real SRAM/BRAM macros power up with whatever
// content the process/technology leaves them in, not a defined value, and
// this module should not teach simulation-only habits (relying on a
// power-on-zero memory) that silently break on real silicon or a real
// synthesis flow. A caller that needs known content must explicitly write
// it first. For simulation convenience only, `mem` is exposed for direct
// hierarchical preload from a testbench (`dut.mem[i] = ...`); that is a
// simulation-only backdoor, not part of this module's synthesizable
// interface.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sfx_sram_interface #(
    parameter int DATA_WIDTH = 32,  // must be a multiple of 8 (byte-strobed)
    parameter int DEPTH      = 1024
)(
    input  wire logic                          clk,
    input  wire logic                          rst_n,

    input  wire logic                          en,
    input  wire logic                          we,
    input  wire logic [$clog2(DEPTH)-1:0]      addr,
    input  wire logic [DATA_WIDTH-1:0]         wdata,
    input  wire logic [(DATA_WIDTH/8)-1:0]     wstrb,

    output      logic [DATA_WIDTH-1:0]         rdata,
    output      logic                          rvalid
);

    generate
        if (DATA_WIDTH % 8 != 0) begin : g_width_check
            $error("sfx_sram_interface: DATA_WIDTH (%0d) must be a multiple of 8", DATA_WIDTH);
        end
    endgenerate

    logic [DATA_WIDTH-1:0] mem [DEPTH]; // intentionally not reset -- see header

    always_ff @(posedge clk) begin
        if (en && we) begin
            for (int b = 0; b < DATA_WIDTH/8; b++) begin
                if (wstrb[b]) begin
                    mem[addr][8*b +: 8] <= wdata[8*b +: 8];
                end
            end
        end
    end

    always_ff @(posedge clk) begin
        if (en && !we) begin
            rdata <= mem[addr];
        end
    end

    always_ff @(posedge clk) begin
        if (!rst_n) rvalid <= 1'b0;
        else        rvalid <= en && !we;
    end

endmodule

`default_nettype wire
