// =============================================================================
// sfx_mac.sv
// SilicaFlux-AI :: rtl/arithmetic
//
// Signed multiply-accumulate primitive: acc <= acc + (a * b), with a
// synchronous `clear` to start a fresh accumulation (loading just the new
// product rather than adding to stale state) and an `en` clock-enable so it
// can be held idle in a stalled pipeline. This is the numerical core shared
// by rtl/tensor/sfx_pe.sv and, later, the vector engine's dot-product paths.
//
// Numerical semantics (see docs/DATATYPES_AND_PRECISION.md):
//   - a, b are signed integers, A_WIDTH/B_WIDTH bits (INT4/INT8/INT16
//     operands map directly onto these; sub-byte types like INT4 are simply
//     narrower A_WIDTH/B_WIDTH -- no separate "INT4 mode").
//   - The product a*b is exact at A_WIDTH+B_WIDTH bits (no truncation).
//   - Accumulation is exact two's-complement addition at ACC_WIDTH bits.
//     ACC_WIDTH must be `>= A_WIDTH+B_WIDTH` (checked below) so a single
//     multiply-accumulate cannot itself overflow; *repeated* accumulation
//     over many cycles still can, and this module does NOT saturate --
//     wraparound on sustained overflow is the caller's responsibility to
//     avoid (by sizing ACC_WIDTH for the known reduction length, e.g.
//     INT8 x INT8 accumulated over up to 2^24 terms fits safely in
//     ACC_WIDTH=32) or to handle explicitly (see sfx_saturate.sv, used at
//     the accumulator's final readout in sfx_pe.sv and the GEMM
//     controller's writeback stage, not on every partial-sum add).
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sfx_mac #(
    parameter int A_WIDTH   = 8,
    parameter int B_WIDTH   = 8,
    parameter int ACC_WIDTH = 32
)(
    input  wire logic                        clk,
    input  wire logic                        rst_n,
    input  wire logic                        en,     // clock-enable: perform this cycle's MAC
    input  wire logic                        clear,  // synchronous: acc <= (en ? new product : 0)
    input  wire logic signed [A_WIDTH-1:0]   a,
    input  wire logic signed [B_WIDTH-1:0]   b,
    output      logic signed [ACC_WIDTH-1:0] acc
);

    generate
        if (ACC_WIDTH < A_WIDTH + B_WIDTH) begin : g_width_check
            $error("sfx_mac: ACC_WIDTH (%0d) must be >= A_WIDTH+B_WIDTH (%0d+%0d=%0d)",
                    ACC_WIDTH, A_WIDTH, B_WIDTH, A_WIDTH + B_WIDTH);
        end
    endgenerate

    wire logic signed [A_WIDTH+B_WIDTH-1:0] product = a * b;
    wire logic signed [ACC_WIDTH-1:0] product_ext = ACC_WIDTH'(product); // sign-extends: product is signed

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            acc <= '0;
        end else if (en) begin
            acc <= clear ? product_ext : (acc + product_ext);
        end
        // clear with !en is intentionally a no-op (see `en` semantics above):
        // clear only takes effect on a cycle where the MAC is also enabled.
    end

endmodule

`default_nettype wire
