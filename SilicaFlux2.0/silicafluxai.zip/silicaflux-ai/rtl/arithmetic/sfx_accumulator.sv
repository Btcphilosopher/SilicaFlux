// =============================================================================
// sfx_accumulator.sv
// SilicaFlux-AI :: rtl/arithmetic
//
// Small addressable accumulator register file: DEPTH independent signed
// accumulators, each updatable by a read-modify-write ("add" or "clear-and-
// load") in a single cycle. This is the primitive rtl/gemm/sfx_gemm_controller
// uses (one instance per systolic-array column) to reduce partial sums
// across K-tiles when K exceeds the array's row count, without needing to
// pipe partial sums back into the systolic array itself (see
// sfx_gemm_controller.sv's header for why that split was chosen).
//
// This is a small register-file array (`mem`), not an SRAM macro: the same-
// cycle read-modify-write it performs (read mem[addr], add, write mem[addr])
// is normal for a flip-flop-based register file at DEPTH small enough to
// stay off-BRAM (tens to low hundreds of entries in the reference
// configurations here), but would not synthesize onto a real single-port
// BRAM the way rtl/memory/sfx_sram_interface.sv is written to. Keep DEPTH
// small for the same reason a real design would.
//
// Two independent ports:
//   - write port: `en` qualifies a request; when `clear` is also set, this
//     is a fresh load (mem[addr] <= data) rather than an accumulate
//     (mem[addr] <= mem[addr] + data). Exactly one address may be written
//     per cycle.
//   - read port: purely combinational, `rd_data` always reflects
//     `mem[rd_addr]`. If rd_addr equals this cycle's write addr, rd_data
//     shows the *pre*-write value (standard read-before-write register
//     file behaviour), matching what an `assign` off the storage array
//     naturally gives -- there is no read/write ordering hazard to
//     document beyond that.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sfx_accumulator #(
    parameter int WIDTH = 32,
    parameter int DEPTH = 32
)(
    input  wire logic                     clk,
    input  wire logic                     rst_n,

    input  wire logic                     en,
    input  wire logic                     clear,
    input  wire logic [$clog2(DEPTH)-1:0] addr,
    input  wire logic signed [WIDTH-1:0]  data,

    input  wire logic [$clog2(DEPTH)-1:0] rd_addr,
    output      logic signed [WIDTH-1:0]  rd_data
);

    logic signed [WIDTH-1:0] mem [DEPTH]; // deliberately not reset -- see sfx_sram_interface.sv's
                                           // header for the same reasoning; every address here is
                                           // always written with clear=1 before it is ever accumulated
                                           // into (the caller's kt==0 pass), so a defined reset value
                                           // is never actually relied upon.

    always_ff @(posedge clk) begin
        if (en) begin
            if (clear) mem[addr] <= data;
            else       mem[addr] <= mem[addr] + data;
        end
    end

    assign rd_data = mem[rd_addr];

endmodule

`default_nettype wire
