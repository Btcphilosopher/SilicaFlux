// =============================================================================
// sfx_saturate.sv
// SilicaFlux-AI :: rtl/arithmetic
//
// Combinational signed saturation: clamps a wide signed value into a
// narrower signed range instead of silently wrapping (see
// docs/DATATYPES_AND_PRECISION.md for the numerical semantics this
// implements and why AI accumulate/requantize paths need it explicitly --
// two's-complement wraparound on int32 accumulator overflow is *not* the
// same value as a saturated result, and this repo always uses the latter
// unless a module explicitly documents otherwise).
//
// Purely combinational (no clock): it is meant to be instantiated directly
// in front of / behind a register elsewhere in the datapath (e.g.
// sfx_mac's accumulator, or a requantization stage), not to carry its own
// pipeline stage.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sfx_saturate #(
    parameter int IN_WIDTH  = 32,
    parameter int OUT_WIDTH = 8
)(
    input  wire  logic signed [IN_WIDTH-1:0]  in_data,
    output       logic signed [OUT_WIDTH-1:0] out_data,
    output       logic                        saturated
);

    generate
        if (OUT_WIDTH > IN_WIDTH) begin : g_width_check
            $error("sfx_saturate: OUT_WIDTH (%0d) must not exceed IN_WIDTH (%0d)",
                    OUT_WIDTH, IN_WIDTH);
        end
    endgenerate

    // Representable range of the OUT_WIDTH-bit signed output, computed in
    // IN_WIDTH-bit precision so the comparison against in_data is exact.
    localparam logic signed [IN_WIDTH-1:0] MAX_OUT =
        (IN_WIDTH)'($signed({1'b0, {(OUT_WIDTH-1){1'b1}}}));
    localparam logic signed [IN_WIDTH-1:0] MIN_OUT =
        (IN_WIDTH)'($signed({1'b1, {(OUT_WIDTH-1){1'b0}}}));

    always_comb begin
        if (in_data > MAX_OUT) begin
            out_data  = MAX_OUT; // implicit truncation to OUT_WIDTH bits: same low bits as an explicit slice
            saturated = 1'b1;
        end else if (in_data < MIN_OUT) begin
            out_data  = MIN_OUT; // implicit truncation to OUT_WIDTH bits
            saturated = 1'b1;
        end else begin
            out_data  = in_data; // in range: implicit truncation is lossless here
            saturated = 1'b0;
        end
    end

endmodule

`default_nettype wire
