# rtl/scheduler — not yet implemented

Planned: `sfx_scheduler`, `sfx_tile_controller`, `sfx_operand_router`,
`sfx_reduction_controller` (PHASE 7), and the multi-cluster global
scheduler (PHASE 13). `rtl/gemm/sfx_gemm_controller.sv`'s own FSM covers a
real (if single-tensor-core, non-overlapping-tiles) subset of PHASE 7's
scope today. See `docs/PHASE_STATUS.md`.
