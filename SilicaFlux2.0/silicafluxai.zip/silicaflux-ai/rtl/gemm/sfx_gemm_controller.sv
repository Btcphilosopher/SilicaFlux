// =============================================================================
// sfx_gemm_controller.sv
// SilicaFlux-AI :: rtl/gemm
//
// Reference tiled GEMM engine: C[M,N] = A[M,K] x B[K,N], M/N/K runtime-
// configurable up to compile-time bounds MAX_M/MAX_N/MAX_K, built around one
// rtl/tensor/sfx_systolic_array instance (ROWS x COLS PEs). Handles M, N, K
// that are not multiples of the array dimensions (Phase 5's requirement) via
// explicit zero-padding of partial tiles -- see "Partial-tile padding" below.
//
// -----------------------------------------------------------------------
// Dataflow
// -----------------------------------------------------------------------
//                 DMA (external, not instantiated here)
//                        |
//        preloaded  A_sram   B_sram
//              \       |        |
//               \  tile loop: for nt, for kt
//                \      |        |
//                 v     v        v
//              [skew] [weight load]  <-- ROWS x COLS systolic array -->
//                 \                          |
//                  \-----------------> psum_out[COLS], tagged with wave m
//                                             |
//                                     COLS x sfx_accumulator
//                                     (reduces across kt passes)
//                                             |
//                                          C_sram  ---> DMA (external)
//
// This module intentionally stops at an int32 accumulator writeback -- no
// requantization/activation is applied (that is rtl/arithmetic/
// sfx_saturate.sv + a future sfx_activation_engine's job, PHASE 3/12,
// downstream of this controller, not inside it). C_sram's element width is
// therefore ACC_WIDTH, not DATA_WIDTH.
//
// -----------------------------------------------------------------------
// Why partial sums are reduced by an external accumulator, not psum_in
// -----------------------------------------------------------------------
// rtl/tensor/sfx_systolic_array.sv exposes a psum_in boundary specifically
// so a caller *could* chain multiple K-tile passes by feeding the previous
// pass's result back in -- but that requires re-injecting each output
// element's prior partial sum at the exact skewed cycle its matching wave
// re-arrives at the array's north boundary, which means either an
// SRAM structured for per-cycle-aligned readback or a second skew network
// as complex as the activation one. Accumulating externally, once per
// (wave, column) pair as psum_out is produced, needs none of that: each
// column's sfx_accumulator instance is simply told "add this" or "start
// fresh" as results arrive, addressed by wave index. This is a deliberate
// scope decision for this reference controller, not a limitation of
// sfx_systolic_array itself -- documented in docs/ARCHITECTURE.md as a
// roadmap item (in-array psum accumulation) rather than silently omitted.
//
// -----------------------------------------------------------------------
// Timing: counters, not a shadow valid-network
// -----------------------------------------------------------------------
// sfx_systolic_array is a fixed-latency structural pipeline with no internal
// valid signalling (see that module's header). This controller derives
// exactly when each result is valid from the *same* closed-form latency
// tb/unit/tb_sfx_systolic_array.sv already validates empirically
// (result for wave m, column c is valid T = ROWS + c + m edges after wave
// 0 first reaches the array's row-0 boundary) -- but instead of computing
// that formula against a raw cycle counter (error-prone, see docs/TOOLING.md
// for how easy this class of bug is to get subtly wrong), each column's
// tag is threaded through its own rtl/common/sfx_pipeline_reg instance with
// STAGES = ROWS+c, injected at the exact cycle wave m's data is presented
// at the array's row-0 boundary. The tag pipeline is then latency-matched
// to the real datapath *by construction*, not by arithmetic that has to be
// independently re-verified for every ROWS/COLS/M combination.
//
// -----------------------------------------------------------------------
// SRAM layout convention (host/DMA responsibility, not this module's)
// -----------------------------------------------------------------------
//   A_sram: DATA_WIDTH = ROWS*DATA_WIDTH (one word = a full systolic row's
//     worth of K-tile activations). addr = m*KTILES_MAX + kt.
//   B_sram: DATA_WIDTH = COLS*DATA_WIDTH (one word = a full systolic row's
//     worth of an N-tile's weights). addr = (nt*KTILES_MAX + kt)*ROWS + rr,
//     where rr in [0,ROWS) is which array row that word loads.
//   C_sram: DATA_WIDTH = ACC_WIDTH, natural row-major addr = m*N + n (using
//     the command's actual runtime N, so a host reads back a normal M x N
//     matrix with no tile padding in it).
// A_sram/B_sram must be pre-tiled into this layout before this controller
// runs (a real system does this DMA-side, or the workload compiler does it
// off-chip -- out of scope here; see docs/ARCHITECTURE.md). Padding
// elements within a partial tile (M/N/K not multiples of the array size)
// may hold anything in A_sram/B_sram: this controller explicitly zeroes
// out-of-range rows/columns itself rather than trusting SRAM content, see
// "Partial-tile padding" below.
//
// -----------------------------------------------------------------------
// Partial-tile padding
// -----------------------------------------------------------------------
// For the last K-tile when K is not a multiple of ROWS, or the last N-tile
// when N is not a multiple of COLS: rows/columns beyond the valid range are
// explicitly forced to zero (both the weight fed into the array during
// load, and the activation fed during streaming) rather than relying on
// whatever A_sram/B_sram happen to contain there, so a partial tile
// contributes exactly zero from its padding positions -- never garbage.
// Columns beyond n_count still get a well-defined (junk-free, just unused)
// accumulator value; the writeback stage simply never reads or writes them
// to C_sram.
//
// -----------------------------------------------------------------------
// What this module deliberately does NOT do (see docs/PHASE_STATUS.md)
// -----------------------------------------------------------------------
// No overlap between tiles (weight load for tile i+1 does not begin while
// tile i is still draining) -- correctness over throughput for this first
// reference implementation; pipelining tile boundaries is Phase 7
// (dataflow engine) territory. M is processed as a single pass up to
// MAX_M (no separate M-tile loop) -- documented, not silently assumed.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sfx_gemm_controller #(
    parameter int ROWS        = 4,
    parameter int COLS        = 4,
    parameter int DATA_WIDTH  = 8,
    parameter int ACC_WIDTH   = 32,
    parameter int MAX_M       = 32,
    parameter int MAX_N       = 32,
    parameter int MAX_K       = 32
)(
    input  wire logic clk,
    input  wire logic rst_n,

    // --- command in / done out (single command in flight at a time) ---
    input  wire logic                          cmd_valid,
    output      logic                          cmd_ready,
    input  wire logic [$clog2(MAX_M+1)-1:0]     cmd_m,
    input  wire logic [$clog2(MAX_N+1)-1:0]     cmd_n,
    input  wire logic [$clog2(MAX_K+1)-1:0]     cmd_k,

    output      logic                          done_valid,
    input  wire logic                          done_ready
);

    // ------------------------------------------------------------------
    // Derived, elaboration-time-only constants
    // ------------------------------------------------------------------
    localparam int KTILES_MAX = (MAX_K + ROWS - 1) / ROWS;
    localparam int NTILES_MAX = (MAX_N + COLS - 1) / COLS;

    // M_IDX_W holds *indices* 0..MAX_M-1 (m_r stores cmd_m-1, the maximum
    // wave index, which is exactly that range) so $clog2(MAX_M) is
    // correct. N_IDX_W/K_IDX_W, by contrast, size n_r/k_r, which hold the
    // *value* N/K itself (1..MAX_N / 1..MAX_K, not an index) -- these need
    // $clog2(MAX_N+1)/$clog2(MAX_K+1) bits, one more than the index width,
    // exactly matching cmd_n/cmd_k's own port width. Using the narrower
    // (index-sized) width here silently truncated N=MAX_N (or K=MAX_K)
    // to 0 whenever MAX_N/MAX_K is an exact power of two, since
    // $clog2(2^j) == j gives only j bits -- not enough to hold the value
    // 2^j itself. Caught by python/verification/bridge.py's randomized
    // sweep hitting N=MAX_N=16 and K=MAX_K=16 (see docs/TOOLING.md);
    // tb_sfx_gemm_controller.sv's own directed cases never happened to
    // use M/N/K exactly at the compile-time maximum.
    localparam int M_IDX_W  = $clog2(MAX_M);
    localparam int N_IDX_W  = $clog2(MAX_N + 1);
    localparam int K_IDX_W  = $clog2(MAX_K + 1);
    localparam int NT_IDX_W = (NTILES_MAX > 1) ? $clog2(NTILES_MAX) : 1;
    localparam int KT_IDX_W = (KTILES_MAX > 1) ? $clog2(KTILES_MAX) : 1;
    localparam int RR_W     = (ROWS > 1) ? $clog2(ROWS) : 1;

    localparam int A_DEPTH = MAX_M * KTILES_MAX;
    localparam int B_DEPTH = NTILES_MAX * KTILES_MAX * ROWS;
    localparam int C_DEPTH = MAX_M * MAX_N;

    // ------------------------------------------------------------------
    // Internal memories
    // ------------------------------------------------------------------
    logic a_en, a_we; logic [$clog2(A_DEPTH)-1:0] a_addr;
    logic [ROWS*DATA_WIDTH-1:0] a_rdata; logic a_rvalid;

    logic b_en, b_we; logic [$clog2(B_DEPTH)-1:0] b_addr;
    logic [COLS*DATA_WIDTH-1:0] b_rdata; logic b_rvalid;

    logic c_en, c_we; logic [$clog2(C_DEPTH)-1:0] c_addr;
    logic [ACC_WIDTH-1:0] c_wdata;

    sfx_sram_interface #(.DATA_WIDTH(ROWS*DATA_WIDTH), .DEPTH(A_DEPTH)) u_a_sram (
        .clk(clk), .rst_n(rst_n), .en(a_en), .we(a_we), .addr(a_addr),
        .wdata('0), .wstrb('0), .rdata(a_rdata), .rvalid(a_rvalid)
    );
    sfx_sram_interface #(.DATA_WIDTH(COLS*DATA_WIDTH), .DEPTH(B_DEPTH)) u_b_sram (
        .clk(clk), .rst_n(rst_n), .en(b_en), .we(b_we), .addr(b_addr),
        .wdata('0), .wstrb('0), .rdata(b_rdata), .rvalid(b_rvalid)
    );
    sfx_sram_interface #(.DATA_WIDTH(ACC_WIDTH), .DEPTH(C_DEPTH)) u_c_sram (
        .clk(clk), .rst_n(rst_n), .en(c_en), .we(c_we), .addr(c_addr),
        .wdata(c_wdata), .wstrb({(ACC_WIDTH/8){1'b1}}), .rdata(), .rvalid()
    );
    assign a_we = 1'b0;
    assign b_we = 1'b0;

    // ------------------------------------------------------------------
    // Systolic array
    // ------------------------------------------------------------------
    logic array_load_mode, array_compute_en;
    logic [COLS*DATA_WIDTH-1:0] weight_in_flat;
    logic [ROWS*DATA_WIDTH-1:0] act_in_flat;
    logic [COLS*ACC_WIDTH-1:0]  psum_in_flat;
    logic [COLS*ACC_WIDTH-1:0]  psum_out_flat;
    logic [ROWS*DATA_WIDTH-1:0] act_out_flat_unused;
    logic [COLS*DATA_WIDTH-1:0] weight_out_flat_unused;

    assign psum_in_flat = '0; // this controller always starts each K-tile pass fresh (see header)

    sfx_systolic_array #(.ROWS(ROWS), .COLS(COLS), .DATA_WIDTH(DATA_WIDTH), .ACC_WIDTH(ACC_WIDTH)) u_array (
        .clk(clk), .rst_n(rst_n),
        .load_mode(array_load_mode), .compute_en(array_compute_en),
        .weight_in_flat(weight_in_flat), .act_in_flat(act_in_flat), .psum_in_flat(psum_in_flat),
        .psum_out_flat(psum_out_flat), .act_out_flat(act_out_flat_unused), .weight_out_flat(weight_out_flat_unused)
    );

    // ------------------------------------------------------------------
    // Per-column accumulators + latency-matched wave-index tag pipelines
    // ------------------------------------------------------------------
    logic acc_en   [COLS];
    logic acc_clear[COLS];
    logic [M_IDX_W-1:0] acc_wr_addr [COLS];
    logic signed [ACC_WIDTH-1:0] acc_wr_data [COLS];
    logic [M_IDX_W-1:0] acc_rd_addr [COLS];
    logic signed [ACC_WIDTH-1:0] acc_rd_data [COLS];

    logic tag_valid_in;
    logic [M_IDX_W-1:0] tag_m_in;
    logic tag_valid_out [COLS];
    logic [M_IDX_W-1:0] tag_m_out [COLS];

    logic kt_is_first; // latched for the duration of the current kt pass: clear vs accumulate

    genvar gc;
    generate
        for (gc = 0; gc < COLS; gc++) begin : g_col_acc
            sfx_accumulator #(.WIDTH(ACC_WIDTH), .DEPTH(MAX_M)) u_acc (
                .clk(clk), .rst_n(rst_n),
                .en(acc_en[gc]), .clear(acc_clear[gc]), .addr(acc_wr_addr[gc]), .data(acc_wr_data[gc]),
                .rd_addr(acc_rd_addr[gc]), .rd_data(acc_rd_data[gc])
            );

            sfx_pipeline_reg #(.WIDTH(M_IDX_W), .STAGES(ROWS + gc)) u_tag (
                .clk(clk), .rst_n(rst_n),
                .valid_in(tag_valid_in), .data_in(tag_m_in),
                .valid_out(tag_valid_out[gc]), .data_out(tag_m_out[gc])
            );

            assign acc_en[gc]      = tag_valid_out[gc];
            assign acc_clear[gc]   = kt_is_first;
            assign acc_wr_addr[gc] = tag_m_out[gc];
            assign acc_wr_data[gc] = $signed(psum_out_flat[gc*ACC_WIDTH +: ACC_WIDTH]);
        end
    endgenerate

    // ------------------------------------------------------------------
    // Activation skew network (per-row fixed delay r, mirrors the array's
    // own required skew -- see rtl/tensor/sfx_systolic_array.sv header)
    // ------------------------------------------------------------------
    logic a_lane_valid_in;
    logic signed [DATA_WIDTH-1:0] a_lane_data_in [ROWS];
    logic a_lane_valid_out [ROWS];
    logic signed [DATA_WIDTH-1:0] a_lane_data_out [ROWS];

    genvar gr;
    generate
        for (gr = 0; gr < ROWS; gr++) begin : g_row_skew
            sfx_pipeline_reg #(.WIDTH(DATA_WIDTH), .STAGES(gr)) u_skew (
                .clk(clk), .rst_n(rst_n),
                .valid_in(a_lane_valid_in), .data_in(a_lane_data_in[gr]),
                .valid_out(a_lane_valid_out[gr]), .data_out(a_lane_data_out[gr])
            );
            // Feed zero (never X/garbage) whenever this row has no real
            // data yet/anymore -- required by sfx_pe's contract.
            assign act_in_flat[gr*DATA_WIDTH +: DATA_WIDTH] =
                a_lane_valid_out[gr] ? a_lane_data_out[gr] : {DATA_WIDTH{1'b0}};
        end
    endgenerate

    // ------------------------------------------------------------------
    // Main FSM
    // ------------------------------------------------------------------
    typedef enum logic [3:0] {
        ST_IDLE, ST_NT_INIT, ST_KT_INIT, ST_LOAD_W, ST_STREAM,
        ST_KT_NEXT, ST_WRITEBACK, ST_NT_NEXT, ST_DONE
    } state_e;
    state_e state, state_n;

    logic [M_IDX_W-1:0] m_r;               // latched cmd_m - 1 (max wave index)
    logic [N_IDX_W-1:0] n_r;               // latched cmd_n
    logic [K_IDX_W-1:0] k_r;               // latched cmd_k

    logic [NT_IDX_W-1:0] nt_r;
    logic [KT_IDX_W-1:0] kt_r;
    logic [N_IDX_W-1:0]  n_start_r;
    logic [$clog2(COLS+1)-1:0] n_count_r;
    logic [K_IDX_W-1:0]  k_start_r;
    logic [$clog2(ROWS+1)-1:0] k_count_r;

    wire logic [N_IDX_W-1:0] n_start_c = N_IDX_W'(nt_r) * COLS;
    wire logic [K_IDX_W-1:0] k_start_c = K_IDX_W'(kt_r) * ROWS;

    // --- weight-load sub-counter ---
    logic [RR_W:0] load_cycle_r; // 0..ROWS (ROWS+1 distinct values)
    wire logic loading_active = (load_cycle_r < ROWS);
    wire logic [RR_W-1:0] load_rr = RR_W'(ROWS - 1 - load_cycle_r);
    wire logic load_row_is_padding = (K_IDX_W'(k_start_r) + K_IDX_W'(load_rr)) >= k_r;

    assign b_en   = (state == ST_LOAD_W) && loading_active;
    assign b_addr = (($clog2(B_DEPTH))'(nt_r) * KTILES_MAX + $clog2(B_DEPTH)'(kt_r)) * ROWS
                     + $clog2(B_DEPTH)'(load_rr);
    assign array_load_mode = (state == ST_LOAD_W) && b_rvalid;

    // sfx_sram_interface has 1 cycle of read latency: b_rdata/b_rvalid seen
    // on a given cycle correspond to the request issued the *previous*
    // cycle, whose `load_rr` (and therefore padding status) has since
    // moved on. load_row_is_padding above is combinational off the
    // *current* load_rr and is only valid to gate a request being issued
    // *this* cycle -- it must not be read again once the cycle has passed
    // (load_rr itself would even underflow one cycle after the last
    // request, since load_cycle_r keeps counting past ROWS). Latch it at
    // request-issue time instead, so the value consumed by
    // g_weight_unpack below always matches the request that produced the
    // b_rdata arriving that same cycle -- caught by tb_sfx_gemm_controller.sv
    // failing every case with a partial K-tile until this was added; see
    // docs/TOOLING.md.
    logic load_row_is_padding_d;
    always_ff @(posedge clk) begin
        if (b_en) load_row_is_padding_d <= load_row_is_padding;
    end

    genvar gw;
    generate
        for (gw = 0; gw < COLS; gw++) begin : g_weight_unpack
            wire logic col_is_padding = (N_IDX_W'(gw) >= n_count_r);
            assign weight_in_flat[gw*DATA_WIDTH +: DATA_WIDTH] =
                (load_row_is_padding_d || col_is_padding) ? {DATA_WIDTH{1'b0}}
                                                            : b_rdata[gw*DATA_WIDTH +: DATA_WIDTH];
        end
    endgenerate

    // --- activation-stream sub-counters ---
    logic [M_IDX_W:0] a_issue_cnt_r;  // how many A_sram read requests issued this kt pass (0..m_r+1)
    logic [M_IDX_W:0] a_wave_cnt_r;   // which wave index the *next* A_sram response corresponds to
    logic [$clog2(MAX_M + ROWS + COLS + 4)-1:0] stream_cycles_left_r;

    wire logic a_issue_more = (state == ST_STREAM) && (a_issue_cnt_r <= {1'b0, m_r});
    assign a_en   = a_issue_more;
    assign a_addr = ($clog2(A_DEPTH))'(a_issue_cnt_r) * KTILES_MAX + $clog2(A_DEPTH)'(kt_r);

    assign a_lane_valid_in = a_rvalid;
    assign tag_valid_in    = a_rvalid;
    assign tag_m_in        = a_wave_cnt_r[M_IDX_W-1:0];

    genvar ga;
    generate
        for (ga = 0; ga < ROWS; ga++) begin : g_act_unpack
            wire logic row_is_padding = (K_IDX_W'(k_start_r) + K_IDX_W'(ga)) >= k_r;
            assign a_lane_data_in[ga] = row_is_padding ? {DATA_WIDTH{1'b0}}
                                                        : $signed(a_rdata[ga*DATA_WIDTH +: DATA_WIDTH]);
        end
    endgenerate

    assign array_compute_en = (state == ST_STREAM);

    // --- writeback sub-counters ---
    logic [M_IDX_W-1:0] wb_m_r;
    logic [N_IDX_W-1:0] wb_c_r; // 0..n_count_r-1, indexes within the current N-tile

    genvar gcr;
    generate
        for (gcr = 0; gcr < COLS; gcr++) begin : g_acc_rd_addr
            assign acc_rd_addr[gcr] = wb_m_r;
        end
    endgenerate

    assign c_we    = (state == ST_WRITEBACK);
    assign c_en    = c_we;
    assign c_addr  = ($clog2(C_DEPTH))'(wb_m_r) * N_IDX_W'(n_r) + $clog2(C_DEPTH)'(n_start_r) + $clog2(C_DEPTH)'(wb_c_r);
    assign c_wdata = acc_rd_data[wb_c_r]; // wb_c_r < COLS always (loop bound below)

    // ------------------------------------------------------------------
    // Command latch
    // ------------------------------------------------------------------
    assign cmd_ready = (state == ST_IDLE);

    always_ff @(posedge clk) begin
        if (cmd_valid && cmd_ready) begin
            m_r <= M_IDX_W'(cmd_m - 1'b1);
            n_r <= N_IDX_W'(cmd_n);
            k_r <= K_IDX_W'(cmd_k);
        end
    end

    // ------------------------------------------------------------------
    // Tile-index / sub-stage registers
    // ------------------------------------------------------------------
    always_ff @(posedge clk) begin
        if (!rst_n) begin
            nt_r <= '0;
        end else if (cmd_valid && cmd_ready) begin
            nt_r <= '0;
        end else if (state == ST_NT_NEXT) begin
            nt_r <= nt_r + 1'b1;
        end
    end

    always_ff @(posedge clk) begin
        if (state == ST_NT_INIT) begin
            n_start_r <= n_start_c;
            n_count_r <= (n_start_c + COLS <= {1'b0, n_r}) ? $clog2(COLS+1)'(COLS)
                                                            : $clog2(COLS+1)'({1'b0, n_r} - n_start_c);
            kt_r      <= '0;
        end else if (state == ST_KT_NEXT) begin
            kt_r <= kt_r + 1'b1;
        end
    end

    always_ff @(posedge clk) begin
        if (state == ST_KT_INIT) begin
            k_start_r   <= k_start_c;
            k_count_r   <= (k_start_c + ROWS <= {1'b0, k_r}) ? $clog2(ROWS+1)'(ROWS)
                                                              : $clog2(ROWS+1)'({1'b0, k_r} - k_start_c);
            kt_is_first <= (kt_r == '0);
        end
    end

    always_ff @(posedge clk) begin
        if (!rst_n || state == ST_KT_INIT) begin
            load_cycle_r <= '0;
        end else if (state == ST_LOAD_W) begin
            load_cycle_r <= load_cycle_r + 1'b1;
        end
    end

    always_ff @(posedge clk) begin
        if (!rst_n || state == ST_LOAD_W) begin
            a_issue_cnt_r <= '0;
            a_wave_cnt_r  <= '0;
        end else if (state == ST_STREAM) begin
            if (a_issue_more) a_issue_cnt_r <= a_issue_cnt_r + 1'b1;
            if (a_rvalid)     a_wave_cnt_r  <= a_wave_cnt_r + 1'b1;
        end
    end

    always_ff @(posedge clk) begin
        if (!rst_n || state == ST_LOAD_W) begin
            stream_cycles_left_r <= ($clog2(MAX_M+ROWS+COLS+4))'({1'b0, m_r} + ROWS + COLS + 2);
        end else if (state == ST_STREAM && stream_cycles_left_r != '0) begin
            stream_cycles_left_r <= stream_cycles_left_r - 1'b1;
        end
    end

    always_ff @(posedge clk) begin
        if (!rst_n || state == ST_KT_NEXT || state == ST_NT_NEXT) begin
            wb_m_r <= '0;
            wb_c_r <= '0;
        end else if (state == ST_WRITEBACK) begin
            if (wb_c_r + 1'b1 >= n_count_r) begin
                wb_c_r <= '0;
                wb_m_r <= wb_m_r + 1'b1;
            end else begin
                wb_c_r <= wb_c_r + 1'b1;
            end
        end
    end

    // ------------------------------------------------------------------
    // State transition logic
    // ------------------------------------------------------------------
    wire logic stream_done     = (state == ST_STREAM) && (stream_cycles_left_r == 0);
    wire logic writeback_done  = (state == ST_WRITEBACK) &&
                                  (wb_m_r == m_r) && (wb_c_r + 1'b1 >= n_count_r);
    wire logic more_kt         = (K_IDX_W'(kt_r + 1'b1) * ROWS < {1'b0, k_r});
    wire logic more_nt         = (N_IDX_W'(nt_r + 1'b1) * COLS < {1'b0, n_r});

    always_comb begin
        state_n = state;
        unique case (state)
            ST_IDLE:      if (cmd_valid && cmd_ready) state_n = ST_NT_INIT;
            ST_NT_INIT:   state_n = ST_KT_INIT;
            ST_KT_INIT:   state_n = ST_LOAD_W;
            ST_LOAD_W:    if (load_cycle_r == ROWS) state_n = ST_STREAM;
            ST_STREAM:    if (stream_done) state_n = ST_KT_NEXT;
            ST_KT_NEXT:   begin
                              if (more_kt) state_n = ST_KT_INIT;
                              else         state_n = ST_WRITEBACK;
                          end
            ST_WRITEBACK: if (writeback_done) state_n = ST_NT_NEXT;
            ST_NT_NEXT:   begin
                              if (more_nt) state_n = ST_NT_INIT;
                              else         state_n = ST_DONE;
                          end
            ST_DONE:      if (done_valid && done_ready) state_n = ST_IDLE;
            default:      state_n = ST_IDLE;
        endcase
    end

    always_ff @(posedge clk) begin
        if (!rst_n) state <= ST_IDLE;
        else        state <= state_n;
    end

    assign done_valid = (state == ST_DONE);

`ifndef SFX_SYNTHESIS
    always_ff @(posedge clk) begin
        if (rst_n) begin
            assert (wb_c_r < COLS)
                else $error("sfx_gemm_controller: writeback column index escaped COLS range");
        end
    end
`endif

endmodule

`default_nettype wire
