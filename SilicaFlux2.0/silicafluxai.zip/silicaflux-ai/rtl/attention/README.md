# rtl/attention — not yet implemented

Planned: `sfx_qkv_engine`, `sfx_attention_engine`, `sfx_softmax_engine`,
`sfx_layernorm_engine`, `sfx_elementwise_engine` (PHASE 8).
`architectures/transformer.yaml` documents the intended schema shape for
this (all fields marked schema-DESCRIPTIVE). See `docs/PHASE_STATUS.md`.
