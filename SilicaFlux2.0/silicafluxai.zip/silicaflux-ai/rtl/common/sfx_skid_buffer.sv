// =============================================================================
// sfx_skid_buffer.sv
// SilicaFlux-AI :: rtl/common
//
// Classic "skid buffer" / pipeline breaker for valid/ready streams. Registers
// both data and control so that upstream and downstream have no combinational
// path through this stage (useful for closing timing across long wires such
// as NoC hops or SRAM read latches), while still sustaining full throughput
// (a new transfer can be accepted every cycle once primed).
//
// Behaviour: when the downstream is not ready and a new upstream transfer
// arrives, it "skids" into a one-deep shadow register so upstream never has
// to see combinational backpressure from the internal state.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sfx_skid_buffer #(
    parameter int WIDTH = 32
)(
    input  wire logic             clk,
    input  wire logic             rst_n,

    input  wire logic             in_valid,
    output      logic             in_ready,
    input  wire logic [WIDTH-1:0] in_data,

    output      logic             out_valid,
    input  wire logic             out_ready,
    output      logic [WIDTH-1:0] out_data
);

    logic              main_valid_r;
    logic [WIDTH-1:0]  main_data_r;

    logic              skid_valid_r;
    logic [WIDTH-1:0]  skid_data_r;

    // Upstream is only blocked while the skid slot itself is occupied.
    assign in_ready  = !skid_valid_r;
    assign out_valid = main_valid_r;
    assign out_data  = main_data_r;

    wire logic out_fire = out_valid && out_ready;
    wire logic in_fire  = in_valid && in_ready;

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            main_valid_r <= 1'b0;
            skid_valid_r <= 1'b0;
            main_data_r  <= '0;
            skid_data_r  <= '0;
        end else begin
            unique case ({in_fire, out_fire})
                2'b00: begin
                    // nothing happens
                end
                2'b01: begin
                    // downstream drained; if something was skidded, promote it
                    if (skid_valid_r) begin
                        main_data_r  <= skid_data_r;
                        skid_valid_r <= 1'b0;
                    end else begin
                        main_valid_r <= 1'b0;
                    end
                end
                2'b10: begin
                    // new data arrives, downstream did not drain this cycle
                    if (main_valid_r) begin
                        // main is occupied and not draining -> must skid
                        skid_data_r  <= in_data;
                        skid_valid_r <= 1'b1;
                    end else begin
                        main_data_r  <= in_data;
                        main_valid_r <= 1'b1;
                    end
                end
                2'b11: begin
                    // simultaneous accept and drain: main slot refills
                    // directly from input (no need to skid).
                    main_data_r  <= in_data;
                    main_valid_r <= 1'b1;
                end
                default: ;
            endcase
        end
    end

`ifndef SFX_SYNTHESIS
    // See rtl/common/sfx_fifo.sv for why these are immediate assertions
    // rather than `assert property` (Icarus Verilog does not implement
    // concurrent assertions). The authoritative concurrent-SVA form lives
    // in assertions/sfx_skid_buffer_assertions.sva.
    logic in_stall_prev_r, out_stall_prev_r;

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            in_stall_prev_r  <= 1'b0;
            out_stall_prev_r <= 1'b0;
        end else begin
            in_stall_prev_r  <= in_valid && !in_ready;
            out_stall_prev_r <= out_valid && !out_ready;
        end
    end

    always_ff @(posedge clk) begin
        if (rst_n) begin
            assert (!in_stall_prev_r || in_valid)
                else $error("sfx_skid_buffer: in_valid retracted before handshake");
            assert (!out_stall_prev_r || out_valid)
                else $error("sfx_skid_buffer: out_valid retracted before handshake");
        end
    end
`endif

endmodule

`default_nettype wire
