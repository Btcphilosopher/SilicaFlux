// =============================================================================
// sfx_register.sv
// SilicaFlux-AI :: rtl/common
//
// Generic synchronous, synchronously-resettable register with clock enable.
// This is the base storage primitive used throughout SilicaFlux RTL instead
// of ad-hoc `always_ff` blocks, so reset/enable behaviour is uniform and
// auditable in one place.
//
// Timing / reset discipline (see docs/TIMING_AND_RESET.md):
//   - Single clock domain `clk`.
//   - `rst_n` is active-low and SYNCHRONOUS: it must already be synchronized
//     to `clk` by the caller (e.g. via a reset synchronizer at the clock
//     domain boundary). This module performs no asynchronous reset.
//   - No latches: every bit of `q` is driven on every clocked path.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sfx_register #(
    parameter int WIDTH        = 32,
    parameter logic [WIDTH-1:0] RESET_VALUE = '0
)(
    input  wire logic             clk,
    input  wire logic             rst_n,
    input  wire logic             en,      // clock enable (ignored during reset)
    input  wire logic [WIDTH-1:0] d,
    output      logic [WIDTH-1:0] q
);

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            q <= RESET_VALUE;
        end else if (en) begin
            q <= d;
        end
    end

endmodule

`default_nettype wire
