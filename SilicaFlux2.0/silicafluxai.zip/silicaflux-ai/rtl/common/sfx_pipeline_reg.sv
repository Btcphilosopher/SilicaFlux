// =============================================================================
// sfx_pipeline_reg.sv
// SilicaFlux-AI :: rtl/common
//
// N-stage shift-register pipeline for a valid-tagged payload, used to align
// side-channel signals (e.g. control/opcode tags) with a datapath that has a
// known fixed latency (e.g. behind a multi-cycle MAC or systolic array).
// Stalling is NOT supported (STAGES is a fixed-latency shift register) --
// use sfx_skid_buffer chains instead when back-pressure must be honoured.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sfx_pipeline_reg #(
    parameter int WIDTH  = 32,
    parameter int STAGES = 1
)(
    input  wire logic             clk,
    input  wire logic             rst_n,
    input  wire logic             valid_in,
    input  wire logic [WIDTH-1:0] data_in,
    output      logic             valid_out,
    output      logic [WIDTH-1:0] data_out
);

    generate
        if (STAGES <= 0) begin : g_bypass
            assign valid_out = valid_in;
            assign data_out  = data_in;
        end else begin : g_pipe
            logic             valid_sr [STAGES];
            logic [WIDTH-1:0] data_sr  [STAGES];

            always_ff @(posedge clk) begin
                if (!rst_n) begin
                    for (int i = 0; i < STAGES; i++) begin
                        valid_sr[i] <= 1'b0;
                    end
                end else begin
                    valid_sr[0] <= valid_in;
                    for (int i = 1; i < STAGES; i++) begin
                        valid_sr[i] <= valid_sr[i-1];
                    end
                end
            end

            always_ff @(posedge clk) begin
                data_sr[0] <= data_in;
                for (int i = 1; i < STAGES; i++) begin
                    data_sr[i] <= data_sr[i-1];
                end
            end

            assign valid_out = valid_sr[STAGES-1];
            assign data_out  = data_sr[STAGES-1];
        end
    endgenerate

endmodule

`default_nettype wire
