// =============================================================================
// sfx_fifo.sv
// SilicaFlux-AI :: rtl/common
//
// Synchronous, single-clock-domain FIFO with valid/ready handshaking on both
// the write and read sides. Depth must be a power of two (checked with a
// generate-time $error) so the read/write pointers can use natural wraparound
// binary counters with one extra MSB for full/empty disambiguation (the
// standard Sutherland/Cummings technique).
//
// Protocol (both sides): a transfer happens on a clock edge iff valid && ready
// on that side. Neither side may retract `valid` before a transfer completes
// (standard AXI-style stability rule) -- see assertions below.
//
// Synthesizes to a register file or a single-port/dual-port BRAM depending on
// DEPTH and the target tool's inference rules. No latches, no unsynthesizable
// constructs.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sfx_fifo #(
    parameter int WIDTH = 32,
    parameter int DEPTH = 16,   // must be a power of 2
    parameter bit REGISTERED_OUTPUT = 1 // 1: rdata is registered (extra cycle of latency, higher fmax)
) (
    input  wire logic             clk,
    input  wire logic             rst_n,

    // write side
    input  wire logic             wr_valid,
    output      logic             wr_ready,
    input  wire logic [WIDTH-1:0] wr_data,

    // read side
    output      logic             rd_valid,
    input  wire logic             rd_ready,
    output      logic [WIDTH-1:0] rd_data,

    // status
    output      logic [$clog2(DEPTH):0] count,
    output      logic             almost_full,
    output      logic             almost_empty
);

    // ---------------------------------------------------------------------
    // Elaboration-time checks
    // ---------------------------------------------------------------------
    generate
        if ((DEPTH & (DEPTH - 1)) != 0) begin : g_depth_check
            $error("sfx_fifo: DEPTH (%0d) must be a power of two", DEPTH);
        end
    endgenerate

    localparam int PTR_W = $clog2(DEPTH);

    logic [PTR_W:0] wr_ptr, rd_ptr;   // one extra MSB: wrap-detection bit
    logic [WIDTH-1:0] mem [DEPTH];

    // NOTE: these track only the DEPTH-entry backing array. With
    // REGISTERED_OUTPUT=1 there is one additional element of storage in the
    // output "peek" register (see g_registered_rd below), so the array can
    // be simultaneously mem_full and still hand off one more item into that
    // register -- effective total capacity is DEPTH+1 in that mode. `count`
    // (below) reports true end-to-end occupancy, not just this array's.
    wire logic mem_full  = (wr_ptr[PTR_W] != rd_ptr[PTR_W]) &&
                            (wr_ptr[PTR_W-1:0] == rd_ptr[PTR_W-1:0]);
    wire logic mem_empty = (wr_ptr == rd_ptr);

    assign wr_ready = !mem_full;

    wire logic wr_fire = wr_valid && wr_ready;
    wire logic rd_fire_mem; // internal read-from-memory pulse

    // ---------------------------------------------------------------------
    // Write port
    // ---------------------------------------------------------------------
    always_ff @(posedge clk) begin
        if (wr_fire) begin
            mem[wr_ptr[PTR_W-1:0]] <= wr_data;
        end
    end

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            wr_ptr <= '0;
        end else if (wr_fire) begin
            wr_ptr <= wr_ptr + 1'b1;
        end
    end

    // ---------------------------------------------------------------------
    // Read port
    // ---------------------------------------------------------------------
    generate
        if (REGISTERED_OUTPUT) begin : g_registered_rd
            // Simple valid/ready registered-output FIFO: an internal
            // "peek" flop holds mem[rd_ptr] and is refilled whenever it is
            // consumed (rd_fire) or the FIFO is currently empty of valid
            // output but has data to offer.
            logic              out_valid_r;
            logic [WIDTH-1:0]  out_data_r;

            wire logic rd_fire = rd_valid && rd_ready;
            wire logic can_advance = !mem_empty; // there is unread data behind mem[rd_ptr]

            assign rd_fire_mem = (rd_fire || !out_valid_r) && can_advance;

            always_ff @(posedge clk) begin
                if (!rst_n) begin
                    rd_ptr <= '0;
                end else if (rd_fire_mem) begin
                    rd_ptr <= rd_ptr + 1'b1;
                end
            end

            always_ff @(posedge clk) begin
                if (!rst_n) begin
                    out_valid_r <= 1'b0;
                    out_data_r  <= '0;
                end else if (rd_fire_mem) begin
                    out_valid_r <= 1'b1;
                    out_data_r  <= mem[rd_ptr[PTR_W-1:0]];
                end else if (rd_fire) begin
                    out_valid_r <= 1'b0;
                end
            end

            assign rd_valid = out_valid_r;
            assign rd_data  = out_data_r;

            // True end-to-end occupancy = items still in the array + the
            // one (optional) item parked in the output register.
            assign count        = (wr_ptr - rd_ptr) + {{PTR_W{1'b0}}, out_valid_r};
            assign almost_full  = (count >= DEPTH);     // array full and/or reg occupied near capacity
            assign almost_empty = (count <= 1);
        end else begin : g_combinational_rd
            // Combinational (first-word-fall-through) read: rd_data always
            // shows mem[rd_ptr] while !mem_empty. Lower latency, longer
            // combinational path from memory read to rd_data.
            wire logic rd_fire = rd_valid && rd_ready;
            assign rd_fire_mem = rd_fire;
            assign rd_valid = !mem_empty;
            assign rd_data  = mem[rd_ptr[PTR_W-1:0]];

            always_ff @(posedge clk) begin
                if (!rst_n) begin
                    rd_ptr <= '0;
                end else if (rd_fire) begin
                    rd_ptr <= rd_ptr + 1'b1;
                end
            end

            assign count        = wr_ptr - rd_ptr;
            assign almost_full  = (count >= DEPTH - 1);
            assign almost_empty = (count <= 1);
        end
    endgenerate

    // ---------------------------------------------------------------------
    // Assertions (see PHASE 18 -- SystemVerilog Assertions)
    //
    // The authoritative properties for this module are written as proper
    // concurrent SVA (`assert property` with `disable iff` / `|->` / `|=>`)
    // in assertions/sfx_fifo_assertions.sva, for use with a full SVA-capable
    // simulator or formal tool (Questa/VCS/JasperGold/...).
    //
    // Icarus Verilog (the open-source simulator used by this repo's default
    // regression flow, see docs/TOOLING.md) does not implement concurrent
    // assertions ("sorry: concurrent_assertion_item not supported"), so the
    // same invariants are re-expressed below as immediate assertions driven
    // off explicit shadow state, purely so they actually execute in CI.
    //   - no write accepted while full
    //   - no read observed while empty
    //   - valid must hold stable (not retract) until its handshake fires
    // ---------------------------------------------------------------------
`ifndef SFX_SYNTHESIS
    logic wr_stall_prev_r, rd_stall_prev_r;

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            wr_stall_prev_r <= 1'b0;
            rd_stall_prev_r <= 1'b0;
        end else begin
            wr_stall_prev_r <= wr_valid && !wr_ready;
            rd_stall_prev_r <= rd_valid && !rd_ready;
        end
    end

    always_ff @(posedge clk) begin
        if (rst_n) begin
            assert (!wr_valid || wr_ready || mem_full)
                else $error("sfx_fifo: write accepted while full");
            assert (count <= DEPTH + (REGISTERED_OUTPUT ? 1 : 0))
                else $error("sfx_fifo: reported occupancy exceeds capacity");
            assert (!wr_stall_prev_r || wr_valid)
                else $error("sfx_fifo: wr_valid retracted before handshake completed");
            assert (!rd_stall_prev_r || rd_valid)
                else $error("sfx_fifo: rd_valid retracted before handshake completed");
        end
    end
`endif

endmodule

`default_nettype wire
