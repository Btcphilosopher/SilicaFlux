# rtl/command — not yet implemented

Planned: `sfx_command_processor` with a general opcode/instruction stream
(PHASE 10). `rtl/gemm/sfx_gemm_controller.sv`'s `cmd_valid/cmd_m/cmd_n/cmd_k`
interface is a single fixed opcode ("do one GEMM"), not a general command
processor. See `docs/PHASE_STATUS.md`.
