// =============================================================================
// sfx_dma.sv
// SilicaFlux-AI :: rtl/dma
//
// Single-channel, descriptor-driven DMA engine that copies a run of words
// from a source memory port to a destination memory port, both shaped like
// rtl/memory/sfx_sram_interface.sv's port set (see docs/MEMORY_PROTOCOL.md)
// so this module can sit between any two SRAM-style memories (e.g. an
// external/global-buffer source and a local operand SRAM destination) --
// this reference implementation makes no distinction between "external
// memory" and "on-chip SRAM" beyond which port a given sfx_sram_interface
// instance is wired to.
//
// Architecture: read-address generation and write-address generation run as
// two decoupled counters, connected through an internal sfx_fifo (reused
// from rtl/common/, not reimplemented). This is what lets the engine keep
// multiple read requests outstanding while sfx_sram_interface's 1-cycle
// read latency is in flight, models basic burst/backpressure behaviour (the
// FIFO's fullness throttles how far the read side can run ahead of the
// write side), and keeps read/write address generation independent should
// src and dst ever run at different effective rates.
//
//                 ┌──────────┐        ┌────────┐        ┌───────────┐
//   cmd ─────────►│ read addr│──src──►│ sfx_fifo│──rd──►│ write addr │──dst──►
//                 │  counter │  port  │(FIFO_DEPTH)      │  counter  │  port
//                 └──────────┘        └────────┘        └───────────┘
//
// What this module does NOT model (see PHASE 20/21 in docs/PHASE_STATUS.md
// for what's estimate-only vs. simulated here): multiple outstanding
// *transactions* to an external memory with its own variable latency
// (sfx_sram_interface's read latency is fixed at 1 cycle), address
// alignment restrictions, or multi-bank conflict modelling. Burst length,
// backpressure, and outstanding-reads-limited-by-buffer-depth are modelled.
//
// Protocol: `cmd_*` and `done_*` are standard valid/ready single-beat
// handshakes (see docs/MEMORY_PROTOCOL.md). Only one command may be in
// flight at a time -- cmd_ready is low from the cycle a command is accepted
// until its done_valid handshake completes.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module sfx_dma #(
    parameter int DATA_WIDTH    = 32,
    parameter int ADDR_WIDTH    = 16,
    parameter int MAX_LEN       = 4096, // largest transfer this engine will accept, in words
    parameter int FIFO_DEPTH    = 16    // must be a power of 2 (see sfx_fifo)
)(
    input  wire logic clk,
    input  wire logic rst_n,

    // --- command in ---
    input  wire logic                         cmd_valid,
    output      logic                         cmd_ready,
    input  wire logic [ADDR_WIDTH-1:0]        cmd_src_addr,
    input  wire logic [ADDR_WIDTH-1:0]        cmd_dst_addr,
    input  wire logic [$clog2(MAX_LEN+1)-1:0] cmd_length,   // number of words, 0 is legal (completes immediately)

    // --- completion out ---
    output      logic                         done_valid,
    input  wire logic                         done_ready,

    // --- source memory port (sfx_sram_interface-shaped, read-only use) ---
    output      logic                         src_en,
    output      logic                         src_we,      // always driven 0
    output      logic [ADDR_WIDTH-1:0]        src_addr,
    input  wire logic [DATA_WIDTH-1:0]        src_rdata,
    input  wire logic                         src_rvalid,

    // --- destination memory port (sfx_sram_interface-shaped, write-only use) ---
    output      logic                         dst_en,
    output      logic                         dst_we,      // always driven 1 while active
    output      logic [ADDR_WIDTH-1:0]        dst_addr,
    output      logic [DATA_WIDTH-1:0]        dst_wdata,
    output      logic [(DATA_WIDTH/8)-1:0]    dst_wstrb    // always driven all-1s (full-word writes)
);

    localparam int LEN_W = $clog2(MAX_LEN + 1);

    typedef enum logic [1:0] {ST_IDLE, ST_RUN, ST_DONE} state_e;
    state_e state, state_n;

    logic [ADDR_WIDTH-1:0] src_base_r, dst_base_r;
    logic [LEN_W-1:0]      length_r;
    logic [LEN_W-1:0]      read_issued_r;   // words for which a src read request has been issued
    logic [LEN_W-1:0]      write_issued_r;  // words successfully written to dst so far

    wire logic transfer_done = (state == ST_RUN) && (write_issued_r == length_r);
    wire logic reads_outstanding_all_issued = (read_issued_r == length_r);

    // --- read-side <-> write-side decoupling FIFO ---
    logic fifo_wr_valid, fifo_wr_ready;
    logic fifo_rd_valid, fifo_rd_ready;
    logic [DATA_WIDTH-1:0] fifo_wr_data, fifo_rd_data;

    sfx_fifo #(.WIDTH(DATA_WIDTH), .DEPTH(FIFO_DEPTH), .REGISTERED_OUTPUT(1)) u_fifo (
        .clk(clk), .rst_n(rst_n),
        .wr_valid(fifo_wr_valid), .wr_ready(fifo_wr_ready), .wr_data(fifo_wr_data),
        .rd_valid(fifo_rd_valid), .rd_ready(fifo_rd_ready), .rd_data(fifo_rd_data),
        .count(), .almost_full(), .almost_empty()
    );

    // sfx_sram_interface's read response has no address/tag attached to it
    // -- it is a simple 1-cycle-fixed-latency pipe -- so the FIFO write side
    // is fed directly by src_rvalid/src_rdata whenever a read was in
    // flight; this is only correct because reads are never issued faster
    // than the FIFO can accept them (read issue below is itself gated on
    // fifo_wr_ready), so a read response can never arrive when the FIFO is
    // full.
    assign fifo_wr_valid = src_rvalid;
    assign fifo_wr_data  = src_rdata;

    // --- read-address (src) issue logic ---
    wire logic can_issue_read = (state == ST_RUN) && !reads_outstanding_all_issued && fifo_wr_ready;

    assign src_en   = can_issue_read;
    assign src_we   = 1'b0;
    assign src_addr = src_base_r + ADDR_WIDTH'(read_issued_r);

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            read_issued_r <= '0;
        end else if (state == ST_IDLE) begin
            read_issued_r <= '0;
        end else if (can_issue_read) begin
            read_issued_r <= read_issued_r + 1'b1;
        end
    end

    // --- write-address (dst) issue logic ---
    wire logic can_issue_write = (state == ST_RUN) && fifo_rd_valid && (write_issued_r != length_r);

    assign dst_en    = can_issue_write;
    assign dst_we    = can_issue_write; // driven low when not writing, matching sfx_sram_interface's en-qualified we
    assign dst_addr  = dst_base_r + ADDR_WIDTH'(write_issued_r);
    assign dst_wdata = fifo_rd_data;
    assign dst_wstrb = {(DATA_WIDTH/8){1'b1}};
    assign fifo_rd_ready = can_issue_write;

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            write_issued_r <= '0;
        end else if (state == ST_IDLE) begin
            write_issued_r <= '0;
        end else if (can_issue_write) begin
            write_issued_r <= write_issued_r + 1'b1;
        end
    end

    // --- command/completion + main FSM ---
    assign cmd_ready  = (state == ST_IDLE);
    assign done_valid = (state == ST_DONE);

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            src_base_r <= '0;
            dst_base_r <= '0;
            length_r   <= '0;
        end else if (cmd_valid && cmd_ready) begin
            src_base_r <= cmd_src_addr;
            dst_base_r <= cmd_dst_addr;
            length_r   <= cmd_length;
        end
    end

    always_comb begin
        state_n = state;
        unique case (state)
            ST_IDLE: if (cmd_valid && cmd_ready) begin
                         if (cmd_length == 0) state_n = ST_DONE;
                         else                  state_n = ST_RUN;
                     end
            ST_RUN:  if (transfer_done)          state_n = ST_DONE;
            ST_DONE: if (done_valid && done_ready) state_n = ST_IDLE;
            default: state_n = ST_IDLE;
        endcase
    end

    always_ff @(posedge clk) begin
        if (!rst_n) state <= ST_IDLE;
        else        state <= state_n;
    end

`ifndef SFX_SYNTHESIS
    // write_issued_r must never exceed read_issued_r (the write side can
    // only have consumed words the read side actually requested) and
    // neither counter may ever exceed the command's length.
    always_ff @(posedge clk) begin
        if (rst_n) begin
            assert (write_issued_r <= read_issued_r)
                else $error("sfx_dma: write counter overtook read counter");
            assert (read_issued_r <= length_r)
                else $error("sfx_dma: read counter exceeded command length");
            assert (write_issued_r <= length_r)
                else $error("sfx_dma: write counter exceeded command length");
        end
    end
`endif

endmodule

`default_nettype wire
