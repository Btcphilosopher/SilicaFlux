# rtl/noc — not yet implemented

Planned: `sfx_noc_router`, `sfx_noc_link`, `sfx_noc_mesh` (PHASE 14).
`architectures/multicluster.yaml`'s `interconnect.topology: mesh` field
documents intent only (schema-DESCRIPTIVE). See `docs/PHASE_STATUS.md`.
