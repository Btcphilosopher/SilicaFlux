// =============================================================================
// sfx_stream_if.sv
// SilicaFlux-AI :: rtl/interfaces
//
// Canonical valid/ready streaming interface used across SilicaFlux RTL for
// point-to-point data movement (SRAM <-> DMA, tensor core <-> vector engine,
// NoC hops, command streams, ...).
//
// Protocol (identical discipline to every valid/ready port in this repo, see
// docs/MEMORY_PROTOCOL.md and docs/TIMING_AND_RESET.md):
//   - A transfer occurs on a clock edge iff (valid && ready) on that edge.
//   - The producer must not retract `valid`, and must not change `data`/
//     `last`, while `valid && !ready` (a stalled transfer).
//   - The consumer's `ready` may change freely on any cycle, including
//     depending combinationally on `valid` (that is NOT true in the other
//     direction: `valid` must never combinationally depend on `ready`,
//     to avoid a combinational handshake loop across module boundaries).
//   - `last` marks the final beat of a burst/packet; interpretation (e.g.
//     "last row of a tile") is defined by the module pair using this
//     interface, not by the interface itself.
//
// This is a *simulation/elaboration convenience* (modport-checked
// connectivity, one declaration instead of N loose signals at every
// hierarchy level) -- it carries no behaviour of its own. Synthesis tools
// that don't like virtual interfaces in the design hierarchy can be pointed
// at the equivalent loose-signal module ports instead; the two are wire-
// compatible by construction (same signal names/widths).
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

interface sfx_stream_if #(
    parameter int WIDTH = 256
) (
    input logic clk
);

    logic             valid;
    logic             ready;
    logic [WIDTH-1:0] data;
    logic             last;

    modport producer (
        input  clk,
        output valid,
        input  ready,
        output data,
        output last
    );

    modport consumer (
        input  clk,
        input  valid,
        output ready,
        input  data,
        input  last
    );

    // Monitor/testbench-only view (no direction restrictions).
    modport monitor (
        input clk, valid, ready, data, last
    );

`ifndef SFX_SYNTHESIS
    // Same immediate-assertion discipline as rtl/common/sfx_fifo.sv (Icarus
    // Verilog does not implement concurrent `assert property`). Authoritative
    // concurrent-SVA form: assertions/sfx_stream_if_assertions.sva.
    logic stall_prev_r = 1'b0;
    logic [WIDTH-1:0] data_prev_r = '0;
    logic last_prev_r = 1'b0;

    always_ff @(posedge clk) begin
        stall_prev_r <= valid && !ready;
        data_prev_r  <= data;
        last_prev_r  <= last;
    end

    always_ff @(posedge clk) begin
        assert (!stall_prev_r || valid)
            else $error("sfx_stream_if: valid retracted before handshake completed");
        assert (!stall_prev_r || (data === data_prev_r))
            else $error("sfx_stream_if: data changed while stalled");
        assert (!stall_prev_r || (last === last_prev_r))
            else $error("sfx_stream_if: last changed while stalled");
    end
`endif

endinterface

`default_nettype wire
