# rtl/top — not yet implemented

Planned: SFX-AI-CORE, the full host/command-interface/NoC/multi-cluster
top-level chip (PHASE 15). `silicaflux/compiler/rtlgen.py` generates a much
smaller top-level today: a single tensor core + GEMM controller wrapper
(`<name>_top.sv`), written to the directory the CLI's `generate-rtl`
command is pointed at, not into this directory. See `docs/PHASE_STATUS.md`.
