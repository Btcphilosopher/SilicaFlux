"""
python/models/gemm.py
SilicaFlux-AI :: Python synthetic laboratory

Bit-accurate golden reference for rtl/gemm/sfx_gemm_controller.sv: computes
C[M,N] = A[M,K] @ B[K,N] with INT8 x INT8 operands accumulated into a
32-bit (by default) signed accumulator, tiled the same way the RTL controller
tiles it (ROWS x COLS systolic passes, K reduced across ceil(K/ROWS) passes),
so this model predicts the RTL's output exactly -- including its wraparound
behaviour on the rare case an accumulation actually overflows ACC_WIDTH.

Why tile in Python at all, instead of just calling numpy's matmul: the
per-K-tile partial sums in the RTL are each computed by the systolic array
(never overflowing ACC_WIDTH within one pass -- see
rtl/gemm/sfx_gemm_controller.sv's header) and then combined by
rtl/arithmetic/sfx_accumulator.sv's plain `acc + data`, which wraps at
ACC_WIDTH on overflow. A single numpy matmul over the *full* K dimension
computes the same value only when no wraparound occurs anywhere in that
reduction; `gemm_reference` reproduces the RTL's actual per-tile-then-
accumulate structure so it stays correct even in that edge case, and
`gemm_reference_fast` is the equivalent-when-no-overflow-occurs numpy
shortcut used for large/DSE-style inputs where speed matters more than
covering that edge case explicitly.
"""
from __future__ import annotations

import numpy as np

from .datatypes import wrap_signed


def gemm_reference(
    a: np.ndarray,
    b: np.ndarray,
    rows: int,
    cols: int,
    acc_width: int = 32,
) -> np.ndarray:
    """Tiled INT8 GEMM golden model, bit-accurate against
    rtl/gemm/sfx_gemm_controller.sv (see module docstring).

    a: (M, K) int8-range array. b: (K, N) int8-range array. Returns (M, N)
    int64 array holding the ACC_WIDTH-bit signed accumulator result (as a
    plain Python-range int64, not re-truncated -- callers comparing against
    RTL output should mask/compare against the same acc_width their RTL
    instance uses).
    """
    a = np.asarray(a, dtype=np.int64)
    b = np.asarray(b, dtype=np.int64)
    m, k = a.shape
    k2, n = b.shape
    if k != k2:
        raise ValueError(f"gemm_reference: inner dimensions must match (A is {a.shape}, B is {b.shape})")

    ktiles = (k + rows - 1) // rows
    out = np.zeros((m, n), dtype=np.int64)

    for kt in range(ktiles):
        k0 = kt * rows
        k1 = min(k0 + rows, k)
        # This K-tile's own dot-product contribution. Within one pass the
        # array's accumulator never overflows ACC_WIDTH for any realistic
        # configuration this project targets (see sfx_gemm_controller.sv's
        # header), so a plain numpy matmul over just this slice is exact.
        partial = a[:, k0:k1].astype(np.int64) @ b[k0:k1, :].astype(np.int64)
        # Reduce into the running accumulator exactly like
        # rtl/arithmetic/sfx_accumulator.sv: out <= out + partial, wrapped
        # to acc_width bits, per element.
        for i in range(m):
            for j in range(n):
                out[i, j] = wrap_signed(int(out[i, j]) + int(partial[i, j]), acc_width)

    return out


def gemm_reference_fast(a: np.ndarray, b: np.ndarray, acc_width: int = 32) -> np.ndarray:
    """Untiled numpy matmul, wrapped once to acc_width bits at the end.

    Equivalent to gemm_reference() whenever no single element's *full*
    K-length dot product would itself overflow acc_width before the final
    wrap (true for every configuration exercised in this repo's tests and
    reference architectures/*.yaml -- INT8 products capped at 16384
    magnitude, K bounded by MAX_K, ACC_WIDTH=32). Prefer gemm_reference()
    for RTL cross-checks; use this for design-space-exploration-scale
    problems where python/verification's tiled loop would be too slow and
    the overflow edge case is not in play.
    """
    a = np.asarray(a, dtype=np.int64)
    b = np.asarray(b, dtype=np.int64)
    raw = a @ b
    return np.vectorize(lambda v: wrap_signed(int(v), acc_width))(raw)
