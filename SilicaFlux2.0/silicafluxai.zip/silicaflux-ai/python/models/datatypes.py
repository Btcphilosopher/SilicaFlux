"""
python/models/datatypes.py
SilicaFlux-AI :: Python synthetic laboratory

Bit-accurate numerical primitives shared by every golden reference model in
this package: signed wraparound and saturation at an arbitrary integer
width, and affine (scale/zero-point) quantize/dequantize.

These functions are written to match the *hardware's* semantics exactly,
not "a reasonable numpy equivalent" -- see each docstring for which RTL
module it mirrors. Where this repo's RTL does not (yet) implement an
operation (BF16/FP16 conversion, per-tensor requantization), the model here
is still bit-accurate against a documented convention, but is explicitly
labelled PYTHON-MODEL-ONLY so nothing downstream mistakes it for a verified
match to hardware -- see docs/PHASE_STATUS.md.
"""
from __future__ import annotations

import numpy as np


def wrap_signed(value: int, width: int) -> int:
    """Two's-complement wraparound of `value` to `width` bits.

    Mirrors rtl/arithmetic/sfx_mac.sv's accumulator and
    rtl/arithmetic/sfx_accumulator.sv: plain `<= acc + product`/`<= acc +
    data` on a fixed-width signed register in SystemVerilog silently wraps
    on overflow rather than saturating. This function reproduces that
    wraparound exactly so a golden model can predict what the RTL will
    actually output even in a (deliberately constructed, in a directed
    overflow test) overflow case.
    """
    mask = (1 << width) - 1
    value &= mask
    sign_bit = 1 << (width - 1)
    if value & sign_bit:
        value -= (1 << width)
    return value


def saturate_signed(value: int, out_width: int) -> tuple[int, bool]:
    """Signed saturation into `out_width` bits.

    Mirrors rtl/arithmetic/sfx_saturate.sv exactly: clamps to
    [-2^(out_width-1), 2^(out_width-1)-1] rather than wrapping. Returns
    (clamped_value, was_saturated) -- the RTL module's `saturated` output
    is likewise exposed for exactly this kind of directed-test bookkeeping.
    """
    lo = -(1 << (out_width - 1))
    hi = (1 << (out_width - 1)) - 1
    if value > hi:
        return hi, True
    if value < lo:
        return lo, True
    return value, False


def mac_int(a: int, b: int, acc: int, acc_width: int, clear: bool = False) -> int:
    """One signed multiply-accumulate step, matching rtl/arithmetic/sfx_mac.sv.

    `acc <= clear ? (a*b) : (acc + a*b)`, wrapped to `acc_width` bits. The
    product itself is never truncated (SystemVerilog computes it exactly at
    A_WIDTH+B_WIDTH bits before extending) -- only the running accumulator
    wraps.
    """
    product = a * b
    new_acc = product if clear else (acc + product)
    return wrap_signed(new_acc, acc_width)


def quantize_affine(x: np.ndarray, scale: float, zero_point: int, out_width: int) -> np.ndarray:
    """Affine (scale/zero-point) quantization: q = round(x/scale) + zero_point,
    saturated into a signed out_width-bit integer.

    PYTHON-MODEL-ONLY: no RTL module in this repository implements
    requantization yet (see docs/PHASE_STATUS.md, Phase 3's
    dequantization/requantization units are not built in this milestone).
    This function documents the intended numerical convention so future RTL
    has a fixed target to match, and is exercised by tests/test_models.py
    for its own internal consistency (quantize -> dequantize round-trips
    within one quantization step), not against any RTL simulation.
    """
    q = np.round(x / scale).astype(np.int64) + zero_point
    lo = -(1 << (out_width - 1))
    hi = (1 << (out_width - 1)) - 1
    return np.clip(q, lo, hi).astype(np.int64)


def dequantize_affine(q: np.ndarray, scale: float, zero_point: int) -> np.ndarray:
    """Inverse of quantize_affine: x = (q - zero_point) * scale. PYTHON-MODEL-ONLY,
    see quantize_affine's docstring.
    """
    return (q.astype(np.float64) - zero_point) * scale


def int8_range() -> tuple[int, int]:
    return -128, 127


def to_unsigned_bits(value: int, width: int) -> int:
    """Two's-complement bit pattern of a signed `value` in `width` bits, as
    a non-negative Python int -- the form $readmemh/$writememh exchange
    with hex files (see python/verification/vectors.py)."""
    return value & ((1 << width) - 1)


def from_unsigned_bits(bits: int, width: int) -> int:
    """Inverse of to_unsigned_bits: interpret an unsigned bit pattern as a
    signed two's-complement value."""
    return wrap_signed(bits, width)
