"""
python/verification/vectors.py
SilicaFlux-AI :: RTL<->Python verification bridge

Writes A_sram/B_sram content for tb/integration/tb_sfx_gemm_vectors.sv in
the exact pre-tiled layout rtl/gemm/sfx_gemm_controller.sv's header
documents, as $readmemh-compatible hex files, and reads its C_sram dump
back out. The address/packing math here is deliberately a second,
independent implementation of the same layout convention the RTL
testbenches (tb/integration/tb_sfx_gemm_controller.sv's `preload` task)
also implement in SystemVerilog -- both must agree with
sfx_gemm_controller.sv's header comment, which is the actual source of
truth for the convention.

Compile-time array configuration matches tb_sfx_gemm_vectors.sv exactly:
ROWS=COLS=4, MAX_M=MAX_N=MAX_K=16. If those ever change, both this file's
constants and the testbench's localparams must change together.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from python.models.datatypes import to_unsigned_bits


@dataclass(frozen=True)
class ArrayConfig:
    rows: int = 4
    cols: int = 4
    data_width: int = 8
    acc_width: int = 32
    max_m: int = 16
    max_n: int = 16
    max_k: int = 16

    @property
    def ktiles_max(self) -> int:
        return (self.max_k + self.rows - 1) // self.rows

    @property
    def ntiles_max(self) -> int:
        return (self.max_n + self.cols - 1) // self.cols

    @property
    def a_depth(self) -> int:
        return self.max_m * self.ktiles_max

    @property
    def b_depth(self) -> int:
        return self.ntiles_max * self.ktiles_max * self.rows

    @property
    def c_depth(self) -> int:
        return self.max_m * self.max_n

    @classmethod
    def from_spec(cls, spec) -> "ArrayConfig":  # spec: silicaflux.schema.architecture.ArchitectureSpec
        """Builds an ArrayConfig from a validated ArchitectureSpec, for
        per-architecture simulation (silicaflux/compiler/simulate.py) as
        opposed to the fixed-size config the bridge regression
        (bridge.py's DEFAULT_CONFIG) uses."""
        return cls(
            rows=spec.compute.tensor.rows,
            cols=spec.compute.tensor.cols,
            data_width=spec.data_width_bits(),
            acc_width=spec.acc_width_bits(),
            max_m=spec.memory.max_m,
            max_n=spec.memory.max_n,
            max_k=spec.memory.max_k,
        )


# The default bridge config -- must match tb/integration/tb_sfx_gemm_vectors.sv.
DEFAULT_CONFIG = ArrayConfig()


def pack_a_word(a_row: np.ndarray, cfg: ArrayConfig) -> int:
    """One A_sram word: `cfg.rows` INT(data_width) lanes packed
    little-lane-first (lane r occupies bits [(r+1)*W-1 : r*W]), matching
    the RTL's `a_rdata[r*DATA_WIDTH +: DATA_WIDTH]` unpacking."""
    word = 0
    for r in range(cfg.rows):
        val = int(a_row[r]) if r < len(a_row) else 0
        word |= to_unsigned_bits(val, cfg.data_width) << (r * cfg.data_width)
    return word


def pack_b_word(b_row: np.ndarray, cfg: ArrayConfig) -> int:
    """One B_sram word: `cfg.cols` lanes, same packing convention as
    pack_a_word (matching `b_rdata[c*DATA_WIDTH +: DATA_WIDTH]`)."""
    word = 0
    for c in range(cfg.cols):
        val = int(b_row[c]) if c < len(b_row) else 0
        word |= to_unsigned_bits(val, cfg.data_width) << (c * cfg.data_width)
    return word


def write_a_sram(path: Path, a: np.ndarray, cfg: ArrayConfig = DEFAULT_CONFIG) -> None:
    """a: (M, K) int8-range array, M<=cfg.max_m, K<=cfg.max_k."""
    m, k = a.shape
    hex_digits = cfg.rows * cfg.data_width // 4
    lines = []
    for row in range(cfg.max_m):
        for kt in range(cfg.ktiles_max):
            if row < m:
                k0, k1 = kt * cfg.rows, min(kt * cfg.rows + cfg.rows, k)
                lane_vals = np.zeros(cfg.rows, dtype=np.int64)
                if k0 < k1:
                    lane_vals[: k1 - k0] = a[row, k0:k1]
            else:
                lane_vals = np.zeros(cfg.rows, dtype=np.int64)
            lines.append(f"{pack_a_word(lane_vals, cfg):0{hex_digits}x}")
    path.write_text("\n".join(lines) + "\n")


def write_b_sram(path: Path, b: np.ndarray, cfg: ArrayConfig = DEFAULT_CONFIG) -> None:
    """b: (K, N) int8-range array, K<=cfg.max_k, N<=cfg.max_n."""
    k, n = b.shape
    hex_digits = cfg.cols * cfg.data_width // 4
    lines = []
    for nt in range(cfg.ntiles_max):
        for kt in range(cfg.ktiles_max):
            for rr in range(cfg.rows):
                kidx = kt * cfg.rows + rr
                if kidx < k:
                    n0, n1 = nt * cfg.cols, min(nt * cfg.cols + cfg.cols, n)
                    lane_vals = np.zeros(cfg.cols, dtype=np.int64)
                    if n0 < n1:
                        lane_vals[: n1 - n0] = b[kidx, n0:n1]
                else:
                    lane_vals = np.zeros(cfg.cols, dtype=np.int64)
                lines.append(f"{pack_b_word(lane_vals, cfg):0{hex_digits}x}")
    path.write_text("\n".join(lines) + "\n")


def read_c_sram(path: Path, m: int, n: int, cfg: ArrayConfig = DEFAULT_CONFIG) -> np.ndarray:
    """Reads back the first m*n words of a $writememh C_sram dump (natural
    row-major addr = row*n + col, matching sfx_gemm_controller.sv's
    C_sram addressing with the command's *actual* runtime N) as a signed
    (m, n) int64 array.

    Icarus Verilog's $writememh prefixes the dump with an address comment
    line (e.g. "// 0x00000000") rather than repeating an address per data
    line; strip comment/blank lines so this only indexes real data words.
    """
    lines = [
        line for line in path.read_text().splitlines()
        if line.strip() and not line.strip().startswith("//")
    ]
    mask = (1 << cfg.acc_width) - 1
    sign_bit = 1 << (cfg.acc_width - 1)
    out = np.zeros((m, n), dtype=np.int64)
    for row in range(m):
        for col in range(n):
            idx = row * n + col
            bits = int(lines[idx], 16) & mask
            if bits & sign_bit:
                bits -= 1 << cfg.acc_width
            out[row, col] = bits
    return out
