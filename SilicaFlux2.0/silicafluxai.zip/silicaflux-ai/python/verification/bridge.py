"""
python/verification/bridge.py
SilicaFlux-AI :: RTL<->Python verification bridge (PHASE 17)

Drives the flow:

    Python golden model -> test vector generator -> RTL simulation (Icarus
    Verilog) -> output capture -> Python comparator -> machine-readable
    result

for rtl/gemm/sfx_gemm_controller.sv via tb/integration/tb_sfx_gemm_vectors.sv.
Every result this module returns comes from an actual `iverilog`+`vvp` run
against real generated stimulus -- there is no code path here that
fabricates a PASS. If Icarus Verilog is not on PATH, run_case() raises
rather than returning a synthesized result (see docs/PHASE_STATUS.md and
the engineering rule against fabricating verification results).
"""
from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from python.models.gemm import gemm_reference
from python.verification.vectors import DEFAULT_CONFIG, ArrayConfig, read_c_sram, write_a_sram, write_b_sram

REPO_ROOT = Path(__file__).resolve().parents[2]
TB_TOP = REPO_ROOT / "tb" / "integration" / "tb_sfx_gemm_vectors.sv"
RTL_SOURCES = [
    REPO_ROOT / "rtl" / "common" / "sfx_fifo.sv",
    REPO_ROOT / "rtl" / "common" / "sfx_pipeline_reg.sv",
    REPO_ROOT / "rtl" / "arithmetic" / "sfx_accumulator.sv",
    REPO_ROOT / "rtl" / "arithmetic" / "sfx_saturate.sv",
    REPO_ROOT / "rtl" / "tensor" / "sfx_pe.sv",
    REPO_ROOT / "rtl" / "tensor" / "sfx_systolic_array.sv",
    REPO_ROOT / "rtl" / "memory" / "sfx_sram_interface.sv",
    REPO_ROOT / "rtl" / "gemm" / "sfx_gemm_controller.sv",
]


@dataclass
class BridgeResult:
    test: str
    status: str  # "PASS" or "FAIL"
    cycles: int | None
    mismatches: int
    m: int
    n: int
    k: int
    seed: int
    detail: str = ""
    mismatch_samples: list[dict] = field(default_factory=list)

    def to_json_dict(self) -> dict:
        return {
            "test": self.test,
            "status": self.status,
            "cycles": self.cycles,
            "mismatches": self.mismatches,
            "m": self.m,
            "n": self.n,
            "k": self.k,
            "seed": self.seed,
            "detail": self.detail,
            "mismatch_samples": self.mismatch_samples,
        }


def _require_iverilog() -> None:
    if shutil.which("iverilog") is None or shutil.which("vvp") is None:
        raise RuntimeError(
            "iverilog/vvp not found on PATH -- the RTL<->Python verification "
            "bridge requires a real Icarus Verilog simulation to run; it does "
            "not fabricate results when the simulator is unavailable. See "
            "docs/TOOLING.md for how this repo's regression flow installs it."
        )


def compile_bridge(build_dir: Path) -> Path:
    """Compiles tb_sfx_gemm_vectors.sv once; returns the .vvp path.

    Callers running many run_case() calls should pass the same build_dir so
    this only compiles once per process (cheap to re-check: iverilog itself
    is fast for this design size, but avoiding it entirely when nothing
    changed keeps a large randomized sweep snappy).
    """
    _require_iverilog()
    build_dir.mkdir(parents=True, exist_ok=True)
    vvp_path = build_dir / "tb_sfx_gemm_vectors.vvp"
    sources = [str(p) for p in RTL_SOURCES] + [str(TB_TOP)]
    newest_source_mtime = max(Path(s).stat().st_mtime for s in sources)
    if vvp_path.exists() and vvp_path.stat().st_mtime > newest_source_mtime:
        return vvp_path
    cmd = ["iverilog", "-g2012", "-o", str(vvp_path), *sources]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if proc.returncode != 0:
        raise RuntimeError(f"iverilog compile failed:\n{proc.stdout}\n{proc.stderr}")
    return vvp_path


def run_case(
    m: int,
    n: int,
    k: int,
    seed: int,
    cfg: ArrayConfig = DEFAULT_CONFIG,
    build_dir: Path | None = None,
    work_dir: Path | None = None,
    timeout_s: float = 60.0,
) -> BridgeResult:
    """Runs one GEMM RTL<->Python verification case and returns a
    BridgeResult built entirely from real simulation output.
    """
    if m > cfg.max_m or n > cfg.max_n or k > cfg.max_k:
        raise ValueError(f"m,n,k=({m},{n},{k}) exceed this bridge config's max_m/n/k={cfg.max_m}/{cfg.max_n}/{cfg.max_k}")

    test_name = f"gemm_int8_m{m}_n{n}_k{k}_seed{seed}"

    own_build_dir = build_dir is None
    if own_build_dir:
        build_dir = Path(tempfile.mkdtemp(prefix="sfx_bridge_build_"))
    vvp_path = compile_bridge(build_dir)

    own_work_dir = work_dir is None
    if own_work_dir:
        work_dir = Path(tempfile.mkdtemp(prefix="sfx_bridge_work_"))
    work_dir.mkdir(parents=True, exist_ok=True)

    try:
        rng = np.random.default_rng(seed)
        a = rng.integers(-128, 128, size=(m, k), dtype=np.int64)
        b = rng.integers(-128, 128, size=(k, n), dtype=np.int64)
        golden = gemm_reference(a, b, rows=cfg.rows, cols=cfg.cols, acc_width=cfg.acc_width)

        a_file = work_dir / "a_sram.hex"
        b_file = work_dir / "b_sram.hex"
        c_file = work_dir / "c_sram.hex"
        write_a_sram(a_file, a, cfg)
        write_b_sram(b_file, b, cfg)

        cmd = [
            "vvp", str(vvp_path),
            f"+A_FILE={a_file}", f"+B_FILE={b_file}", f"+C_FILE={c_file}",
            f"+M={m}", f"+N={n}", f"+K={k}",
        ]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_s)
        stdout = proc.stdout

        if "SFX_BRIDGE_DONE" not in stdout:
            return BridgeResult(
                test=test_name, status="FAIL", cycles=None, mismatches=-1,
                m=m, n=n, k=k, seed=seed,
                detail=f"simulation did not report completion (exit={proc.returncode}); stdout tail: {stdout[-2000:]}",
            )

        cycles = None
        for line in stdout.splitlines():
            if line.startswith("SFX_BRIDGE_CYCLES:"):
                cycles = int(line.split(":", 1)[1].strip())

        if not c_file.exists():
            return BridgeResult(
                test=test_name, status="FAIL", cycles=cycles, mismatches=-1,
                m=m, n=n, k=k, seed=seed, detail="C_sram dump file was not produced",
            )

        got = read_c_sram(c_file, m, n, cfg)
        mismatch_mask = got != golden
        mismatches = int(np.count_nonzero(mismatch_mask))

        samples = []
        if mismatches:
            coords = np.argwhere(mismatch_mask)[:10]
            for (i, j) in coords:
                samples.append({
                    "row": int(i), "col": int(j),
                    "got": int(got[i, j]), "expected": int(golden[i, j]),
                })

        return BridgeResult(
            test=test_name,
            status="PASS" if mismatches == 0 else "FAIL",
            cycles=cycles,
            mismatches=mismatches,
            m=m, n=n, k=k, seed=seed,
            mismatch_samples=samples,
        )
    finally:
        if own_work_dir:
            shutil.rmtree(work_dir, ignore_errors=True)
        if own_build_dir:
            shutil.rmtree(build_dir, ignore_errors=True)


def run_suite(cases: list[tuple[int, int, int, int]], out_path: Path | None = None) -> list[dict]:
    """Runs several (m, n, k, seed) cases against one compiled build,
    returns the list of result dicts, and (if out_path given) writes them
    as a JSON array -- the machine-readable Phase 17 result format."""
    build_dir = Path(tempfile.mkdtemp(prefix="sfx_bridge_build_"))
    results = []
    try:
        for (m, n, k, seed) in cases:
            r = run_case(m, n, k, seed, build_dir=build_dir)
            results.append(r.to_json_dict())
    finally:
        shutil.rmtree(build_dir, ignore_errors=True)
    if out_path is not None:
        out_path.write_text(json.dumps(results, indent=2) + "\n")
    return results


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="SilicaFlux-AI RTL<->Python GEMM verification bridge")
    parser.add_argument("--out", type=Path, default=None, help="write JSON results here")
    args = parser.parse_args()

    default_cases = [
        (4, 4, 4, 1001),
        (4, 4, 8, 1002),
        (5, 6, 7, 1003),
        (1, 1, 1, 1004),
        (8, 8, 8, 1005),
        (16, 16, 16, 1006),   # M=N=K=MAX: see docs/TOOLING.md for the width bug this once caught
        (9, 5, 3, 1007),
        (3, 9, 9, 1008),
        (13, 11, 15, 1009),
        (16, 4, 4, 2001),     # each dimension individually at its compile-time max
        (4, 16, 4, 2002),
        (4, 4, 16, 2003),
    ]
    results = run_suite(default_cases, out_path=args.out)
    n_pass = sum(1 for r in results if r["status"] == "PASS")
    for r in results:
        print(f"{r['status']:5s} {r['test']:35s} cycles={r['cycles']} mismatches={r['mismatches']}")
    print(f"\n{n_pass}/{len(results)} passed")
    raise SystemExit(0 if n_pass == len(results) else 1)
