// =============================================================================
// tb_sfx_dma.sv -- self-checking unit testbench for rtl/dma/sfx_dma.sv
//
// Wires the DMA between two sfx_sram_interface instances (src, dst). Source
// content is preloaded and destination content is verified via each
// module's documented simulation-only hierarchical backdoor
// (`<inst>.mem[addr]`, see sfx_sram_interface.sv's header) rather than
// contending with the DMA for its single read/write port.
//
// Coverage:
//   - directed copy: known data, verified word-for-word after completion
//   - zero-length command: must complete without any memory access
//   - a transfer longer than FIFO_DEPTH: forces the read side to actually
//     throttle on backpressure (fifo_wr_ready) rather than running ahead
//     unbounded -- correctness here is only possible if that backpressure
//     path works, and rtl/common/sfx_fifo.sv's own overflow assertion
//     would also fire if it didn't
//   - back-to-back commands: cmd_ready must stay low for the duration of a
//     transfer and only re-assert once done_valid/done_ready has fired
//   - done_ready backpressure: the engine must hold ST_DONE (and keep
//     cmd_ready low) until the host actually accepts the completion
// =============================================================================
`timescale 1ns/1ps

module tb_sfx_dma;

    localparam int DATA_WIDTH = 32;
    localparam int ADDR_WIDTH = 10; // 1024 words
    localparam int MEM_DEPTH  = 1 << ADDR_WIDTH;
    localparam int MAX_LEN    = 256;
    localparam int FIFO_DEPTH = 4;  // deliberately small: forces backpressure on longer transfers
    localparam int LEN_W      = $clog2(MAX_LEN + 1);

    logic clk = 0;
    logic rst_n;
    always #5 clk = ~clk;

    // --- DMA <-> src/dst port wiring ---
    logic src_en, src_we;
    logic [ADDR_WIDTH-1:0] src_addr;
    logic [DATA_WIDTH-1:0] src_rdata;
    logic src_rvalid;

    logic dst_en, dst_we;
    logic [ADDR_WIDTH-1:0] dst_addr;
    logic [DATA_WIDTH-1:0] dst_wdata;
    logic [(DATA_WIDTH/8)-1:0] dst_wstrb;
    logic [DATA_WIDTH-1:0] dst_rdata_unused;
    logic dst_rvalid_unused;

    logic cmd_valid, cmd_ready;
    logic [ADDR_WIDTH-1:0] cmd_src_addr, cmd_dst_addr;
    logic [LEN_W-1:0] cmd_length;
    logic done_valid, done_ready;

    int errors = 0;

    sfx_dma #(
        .DATA_WIDTH(DATA_WIDTH), .ADDR_WIDTH(ADDR_WIDTH),
        .MAX_LEN(MAX_LEN), .FIFO_DEPTH(FIFO_DEPTH)
    ) dut (
        .clk(clk), .rst_n(rst_n),
        .cmd_valid(cmd_valid), .cmd_ready(cmd_ready),
        .cmd_src_addr(cmd_src_addr), .cmd_dst_addr(cmd_dst_addr), .cmd_length(cmd_length),
        .done_valid(done_valid), .done_ready(done_ready),
        .src_en(src_en), .src_we(src_we), .src_addr(src_addr),
        .src_rdata(src_rdata), .src_rvalid(src_rvalid),
        .dst_en(dst_en), .dst_we(dst_we), .dst_addr(dst_addr),
        .dst_wdata(dst_wdata), .dst_wstrb(dst_wstrb)
    );

    sfx_sram_interface #(.DATA_WIDTH(DATA_WIDTH), .DEPTH(MEM_DEPTH)) src_mem (
        .clk(clk), .rst_n(rst_n),
        .en(src_en), .we(src_we), .addr(src_addr),
        .wdata('0), .wstrb('0),
        .rdata(src_rdata), .rvalid(src_rvalid)
    );

    sfx_sram_interface #(.DATA_WIDTH(DATA_WIDTH), .DEPTH(MEM_DEPTH)) dst_mem (
        .clk(clk), .rst_n(rst_n),
        .en(dst_en), .we(dst_we), .addr(dst_addr),
        .wdata(dst_wdata), .wstrb(dst_wstrb),
        .rdata(dst_rdata_unused), .rvalid(dst_rvalid_unused)
    );

    task automatic check(string what, logic cond);
        if (!cond) begin
            $display("MISMATCH %s @t=%0t", what, $time);
            errors++;
        end
    endtask

    // Issues one command and waits for done_valid, then completes the done
    // handshake (holding done_ready high throughout unless the caller has
    // already driven it differently).
    //
    // Precondition: the engine must already be idle (cmd_ready===1) when
    // this is called -- true at every call site below, since each only
    // issues a new command after the previous one's done handshake fully
    // completed (or, for the very first call, after reset). Given that,
    // a single unconditional edge-cross performs the acceptance; there is
    // deliberately no `while (!cmd_ready) @(negedge clk)` polling loop
    // here. cmd_ready is not a pulse that only means "just accepted" -- it
    // is a plain `state == IDLE` level signal, so it reads 0 for the
    // entire rest of the transfer (RUN) *and* through the whole DONE hold,
    // not just for one cycle after acceptance. A polling loop on cmd_ready
    // alone cannot tell "not yet accepted" apart from "already accepted,
    // now busy", and will not exit until the engine cycles all the way
    // back to IDLE -- at which point cmd_valid (never cleared) plus the
    // now-1 cmd_ready look like a *second* command with the same fields,
    // which gets accepted too, forever. (Caught by this exact hang while
    // bringing this testbench up -- see docs/TOOLING.md.)
    task automatic run_transfer(input logic [ADDR_WIDTH-1:0] s, input logic [ADDR_WIDTH-1:0] d,
                                 input logic [LEN_W-1:0] len);
        cmd_valid = 1; cmd_src_addr = s; cmd_dst_addr = d; cmd_length = len;
        @(negedge clk);
        cmd_valid = 0;
        while (!done_valid) @(negedge clk);
        // done_ready is expected to already be 1 here in the common path
        @(negedge clk); // handshake completes on the edge just crossed while done_valid&&done_ready
    endtask

    task automatic verify_copy(input logic [ADDR_WIDTH-1:0] s, input logic [ADDR_WIDTH-1:0] d,
                                input int len);
        for (int i = 0; i < len; i++) begin
            if (dst_mem.mem[d+i] !== src_mem.mem[s+i]) begin
                $display("MISMATCH copy[%0d]: dst[%0d]=%0h src[%0d]=%0h",
                          i, d+i, dst_mem.mem[d+i], s+i, src_mem.mem[s+i]);
                errors++;
            end
        end
    endtask

    initial begin
        int seed;
        seed = 32'hD10A_0001;

        rst_n = 0; cmd_valid = 0; cmd_src_addr = 0; cmd_dst_addr = 0; cmd_length = 0;
        done_ready = 1;
        repeat (3) @(negedge clk);
        rst_n = 1;
        @(negedge clk);

        // Preload source memory with known data via the simulation-only
        // backdoor (see sfx_sram_interface.sv's header).
        for (int i = 0; i < MEM_DEPTH; i++) src_mem.mem[i] = $urandom(seed);
        // Destination starts as a distinct known pattern so an
        // under-run (DMA writing fewer words than expected) is visible
        // as leftover 0xDEADDEAD rather than silently matching by luck.
        for (int i = 0; i < MEM_DEPTH; i++) dst_mem.mem[i] = 32'hDEAD_DEAD;

        // --- directed small copy, fits entirely within FIFO_DEPTH ---
        run_transfer(10'd5, 10'd20, LEN_W'(3));
        verify_copy(10'd5, 10'd20, 3);
        check("no_overrun_before", dst_mem.mem[19] === 32'hDEAD_DEAD);
        check("no_overrun_after",  dst_mem.mem[23] === 32'hDEAD_DEAD);

        // --- zero-length command: must complete with no memory access ---
        // A zero-length command's state_n logic goes straight from ST_IDLE
        // to ST_DONE on the very same edge that accepts it (see
        // sfx_dma.sv), so done_valid must already be visible the instant
        // cmd_ready is observed true -- no loop/race to get wrong here.
        begin
            cmd_valid = 1; cmd_src_addr = 10'd100; cmd_dst_addr = 10'd200; cmd_length = LEN_W'(0);
            @(negedge clk); // engine is idle on entry (see run_transfer's precondition note) -- accepted here
            cmd_valid = 0;
            check("zero_length_immediate_done", done_valid === 1'b1);
            check("zero_length_no_access", !src_en && !dst_en);
            @(negedge clk); // done_ready is already 1, so this edge completes the handshake
        end

        // --- long transfer, forces read-side backpressure (len >> FIFO_DEPTH) ---
        run_transfer(10'd0, 10'd300, LEN_W'(50));
        verify_copy(10'd0, 10'd300, 50);

        // --- back-to-back commands: cmd_ready must stay low mid-transfer ---
        begin
            cmd_valid = 1; cmd_src_addr = 10'd400; cmd_dst_addr = 10'd500; cmd_length = LEN_W'(20);
            @(negedge clk); // accepted here (engine idle on entry)
            cmd_valid = 0;
            @(negedge clk); // now mid-transfer
            check("cmd_ready_low_mid_transfer", cmd_ready === 1'b0);
            while (!done_valid) @(negedge clk);
            @(negedge clk);
        end
        verify_copy(10'd400, 10'd500, 20);

        // --- done_ready backpressure: engine must hold ST_DONE / cmd_ready
        // low until the host accepts the completion.
        begin
            int hold_cycles;
            done_ready = 0;
            cmd_valid = 1; cmd_src_addr = 10'd600; cmd_dst_addr = 10'd700; cmd_length = LEN_W'(4);
            @(negedge clk); // accepted here (engine idle on entry)
            cmd_valid = 0;
            while (!done_valid) @(negedge clk);
            hold_cycles = 0;
            repeat (5) begin
                check("cmd_ready_low_while_done_pending", cmd_ready === 1'b0);
                check("done_valid_holds", done_valid === 1'b1);
                @(negedge clk);
                hold_cycles++;
            end
            done_ready = 1;
            @(negedge clk);
            check("cmd_ready_after_done_accepted", cmd_ready === 1'b1);
        end
        verify_copy(10'd600, 10'd700, 4);

        if (errors == 0) $display("SFX_TB_RESULT: PASS");
        else              $display("SFX_TB_RESULT: FAIL (%0d mismatches)", errors);
        $finish;
    end

endmodule
