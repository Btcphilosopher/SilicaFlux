// =============================================================================
// tb_sfx_systolic_array.sv -- parameterized self-checking testbench for
// rtl/tensor/sfx_systolic_array.sv, instantiated at two sizes by
// tb_sfx_systolic_array_4x4.sv (ROWS=COLS=4) and
// tb_sfx_systolic_array_16x16.sv (ROWS=COLS=16), see the note at the bottom
// of this file for why they must run as separate vvp invocations.
//
// Method: pick a random weight matrix W[ROWS][COLS] and activation matrix
// A[M][ROWS] (M output rows, deliberately not equal to ROWS/COLS so this
// also exercises a non-square GEMM shape), compute the expected product
// C[M][COLS] with plain SV integer arithmetic, then:
//   1. load W into the array (reverse-row-order shift, see sfx_pe.sv)
//   2. drive A into the array with the systolic skew (row r's activation
//      stream starts r cycles after row 0 -- see sfx_systolic_array.sv's
//      header for the dataflow this implements)
//   3. capture psum_out[c] at the exact cycle each result becomes valid
//      (derived analytically as T = ROWS + c + m, see docs/ARCHITECTURE.md
//      for the derivation) and compare against C[m][c]
//
// The DUT's boundary ports are flattened packed vectors (see
// sfx_systolic_array.sv's header for why); this testbench packs/unpacks
// individual lanes with `flat[i*WIDTH +: WIDTH]` part-selects, which is
// exactly the pattern real callers (e.g. the GEMM controller) use too.
// =============================================================================
`timescale 1ns/1ps

module tb_sfx_systolic_array #(
    parameter int ROWS       = 4,
    parameter int COLS       = 4,
    parameter int DATA_WIDTH = 8,
    parameter int ACC_WIDTH  = 32,
    parameter int M          = 6,
    parameter int SEED       = 32'hD00D_1234
);

    logic clk = 0;
    logic rst_n;
    logic load_mode, compute_en;

    logic [COLS*DATA_WIDTH-1:0] weight_in_flat;
    logic [ROWS*DATA_WIDTH-1:0] act_in_flat;
    logic [COLS*ACC_WIDTH-1:0]  psum_in_flat;
    logic [COLS*ACC_WIDTH-1:0]  psum_out_flat;
    logic [ROWS*DATA_WIDTH-1:0] act_out_flat;
    logic [COLS*DATA_WIDTH-1:0] weight_out_flat;

    int errors = 0;
    int checks_performed = 0;

    always #5 clk = ~clk;

    sfx_systolic_array #(
        .ROWS(ROWS), .COLS(COLS), .DATA_WIDTH(DATA_WIDTH), .ACC_WIDTH(ACC_WIDTH)
    ) dut (
        .clk(clk), .rst_n(rst_n),
        .load_mode(load_mode), .compute_en(compute_en),
        .weight_in_flat(weight_in_flat),
        .act_in_flat(act_in_flat),
        .psum_in_flat(psum_in_flat),
        .psum_out_flat(psum_out_flat),
        .act_out_flat(act_out_flat),
        .weight_out_flat(weight_out_flat)
    );

    logic signed [DATA_WIDTH-1:0] W    [ROWS][COLS];
    logic signed [DATA_WIDTH-1:0] A    [M][ROWS];
    logic signed [ACC_WIDTH-1:0]  Cexp [M][COLS];

    initial begin
        int seed;
        seed = SEED;

        rst_n = 0; load_mode = 0; compute_en = 0;
        weight_in_flat = '0; act_in_flat = '0; psum_in_flat = '0;
        repeat (3) @(negedge clk);
        rst_n = 1;
        @(negedge clk);

        // --- golden data ---
        for (int r = 0; r < ROWS; r++)
            for (int c = 0; c < COLS; c++)
                W[r][c] = 8'($urandom(seed));
        for (int m = 0; m < M; m++)
            for (int r = 0; r < ROWS; r++)
                A[m][r] = 8'($urandom(seed));
        for (int m = 0; m < M; m++) begin
            for (int c = 0; c < COLS; c++) begin
                longint sum;
                sum = 0;
                for (int r = 0; r < ROWS; r++)
                    sum = sum + (longint'($signed(A[m][r])) * longint'($signed(W[r][c])));
                Cexp[m][c] = sum[ACC_WIDTH-1:0];
            end
        end

        // --- weight load: reverse row order, ROWS cycles ---
        load_mode = 1;
        for (int rr = ROWS - 1; rr >= 0; rr--) begin
            for (int c = 0; c < COLS; c++)
                weight_in_flat[c*DATA_WIDTH +: DATA_WIDTH] = W[rr][c];
            @(negedge clk);
        end
        load_mode = 0;
        weight_in_flat = '0;
        @(negedge clk);

        // --- skewed compute ---
        compute_en = 1;
        psum_in_flat = '0; // tied low throughout: one pass covers the full K=ROWS dimension

        begin
            int total_cycles;
            total_cycles = ROWS + COLS + M + 4;
            for (int t = 0; t < total_cycles; t++) begin
                int t_now;
                for (int r = 0; r < ROWS; r++) begin
                    int m;
                    logic signed [DATA_WIDTH-1:0] lane;
                    m = t - r;
                    lane = (m >= 0 && m < M) ? A[m][r] : 8'sd0;
                    act_in_flat[r*DATA_WIDTH +: DATA_WIDTH] = lane;
                end
                @(negedge clk);
                t_now = t + 1; // number of edges crossed so far
                for (int c = 0; c < COLS; c++) begin
                    int m;
                    logic signed [ACC_WIDTH-1:0] got;
                    m = t_now - ROWS - c;
                    if (m >= 0 && m < M) begin
                        got = $signed(psum_out_flat[c*ACC_WIDTH +: ACC_WIDTH]);
                        checks_performed++;
                        if (got !== Cexp[m][c]) begin
                            $display("MISMATCH C[m=%0d][c=%0d]: got=%0d exp=%0d @cycle=%0d",
                                      m, c, got, Cexp[m][c], t_now);
                            errors++;
                        end
                    end
                end
            end
        end

        if (checks_performed != M * COLS) begin
            $display("MISMATCH: only %0d/%0d expected results were actually checked",
                      checks_performed, M * COLS);
            errors++;
        end

        if (errors == 0) $display("SFX_TB_RESULT: PASS (%0d results checked)", checks_performed);
        else              $display("SFX_TB_RESULT: FAIL (%0d mismatches)", errors);
        $finish;
    end

endmodule

// NOTE: like tb_sfx_fifo.sv, this module is instantiated from separate
// top-level wrapper files per configuration (tb_sfx_systolic_array_4x4.sv,
// tb_sfx_systolic_array_16x16.sv) so each runs as its own vvp invocation --
// $finish is process-global in Icarus Verilog.
