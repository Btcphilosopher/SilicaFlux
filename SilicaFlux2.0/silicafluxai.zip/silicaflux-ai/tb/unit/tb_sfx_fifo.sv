// =============================================================================
// tb_sfx_fifo.sv -- self-checking unit testbench for rtl/common/sfx_fifo.sv
//
// Coverage:
//   - fill to full, drain to empty (checks full/empty flags and pointer wrap
//     by running two full loops -- exercises the wrap-around MSB logic)
//   - random valid/ready toggling (backpressure) against a SW reference queue
//   - both REGISTERED_OUTPUT=0 and REGISTERED_OUTPUT=1 configurations
// =============================================================================
`timescale 1ns/1ps

module tb_sfx_fifo #(
    parameter bit REGISTERED_OUTPUT = 1
);

    localparam int WIDTH = 16;
    localparam int DEPTH = 8;

    logic clk = 0;
    logic rst_n;
    logic wr_valid, wr_ready;
    logic [WIDTH-1:0] wr_data;
    logic rd_valid, rd_ready;
    logic [WIDTH-1:0] rd_data;
    logic [$clog2(DEPTH):0] count;
    logic almost_full, almost_empty;

    int errors = 0;

    always #5 clk = ~clk;

    sfx_fifo #(.WIDTH(WIDTH), .DEPTH(DEPTH), .REGISTERED_OUTPUT(REGISTERED_OUTPUT)) dut (
        .clk(clk), .rst_n(rst_n),
        .wr_valid(wr_valid), .wr_ready(wr_ready), .wr_data(wr_data),
        .rd_valid(rd_valid), .rd_ready(rd_ready), .rd_data(rd_data),
        .count(count), .almost_full(almost_full), .almost_empty(almost_empty)
    );

    // reference model: a simple SW queue
    logic [WIDTH-1:0] ref_q[$];

    task automatic do_reset();
        rst_n = 0; wr_valid = 0; wr_data = '0; rd_ready = 0;
        ref_q.delete();
        repeat (3) @(negedge clk);
        rst_n = 1;
        @(negedge clk);
    endtask

    // Directed: fill completely, then drain completely, twice (wrap check).
    //
    // "Completely" means filling to this configuration's true effective
    // capacity: DEPTH for the combinational (FWFT) read path, but DEPTH+1
    // for the registered read path, which adds one extra element of
    // storage in its output "peek" register beyond the DEPTH-entry backing
    // array (see rtl/common/sfx_fifo.sv header comment on `count`).
    //
    // Sampling discipline: rd_valid/rd_data (like wr_ready above) are pure
    // functions of already-registered state and are stable for an entire
    // clock period. So the correct place to check "what will this edge
    // transfer" is *before* issuing the `@(negedge clk)` that crosses the
    // consuming edge -- exactly mirroring how the fill loop above checks
    // wr_ready right after driving wr_data, before the edge that samples
    // it. Checking *after* crossing the edge would observe the *next*
    // item already having been prefetched into view.
    task automatic directed_fill_drain();
        int cap = DEPTH + (REGISTERED_OUTPUT ? 1 : 0);
        for (int loop = 0; loop < 2; loop++) begin
            for (int i = 0; i < cap; i++) begin
                @(negedge clk);
                wr_valid = 1;
                wr_data  = 16'hBEEF + i + loop*100;
                if (wr_ready) ref_q.push_back(wr_data);
            end
            @(negedge clk);
            wr_valid = 0;
            if (count !== cap) begin
                $display("MISMATCH full_count: got=%0d exp=%0d", count, cap);
                errors++;
            end
            if (wr_ready !== 1'b0) begin
                $display("MISMATCH wr_ready_when_full: got=%0d exp=0", wr_ready);
                errors++;
            end

            for (int i = 0; i < cap; i++) begin
                rd_ready = 1;
                if (rd_valid) begin
                    automatic logic [WIDTH-1:0] exp = ref_q.pop_front();
                    if (rd_data !== exp) begin
                        $display("MISMATCH rd_data: got=%0h exp=%0h", rd_data, exp);
                        errors++;
                    end
                end else begin
                    $display("MISMATCH expected rd_valid during drain");
                    errors++;
                end
                @(negedge clk);
            end
            rd_ready = 0;
            @(negedge clk);
            if (count !== 0) begin
                $display("MISMATCH empty_count: got=%0d exp=0", count);
                errors++;
            end
        end
    endtask

    // Randomised backpressure test against SW reference queue.
    //
    // Protocol discipline: VALID must never be retracted, and its payload
    // must not change, while a transfer is stalled (valid && !ready). READY
    // has no such restriction and may toggle freely every cycle. So the
    // driver only re-randomises wr_valid/wr_data when no write is currently
    // stalled; rd_ready is free-running.
    //
    // Timing note: wr_hold (the "is a write currently stalled" flag) and the
    // ref_q bookkeeping below are deliberately computed from the *same*
    // sample of wr_ready/rd_valid, taken once per iteration immediately
    // after driving this cycle's stimulus and *before* crossing the clock
    // edge that consumes it. wr_ready/rd_valid are pure functions of
    // already-registered state, so they are stable across an entire clock
    // period and only change at an edge -- sampling them again *after*
    // crossing an edge (e.g. at the top of the next iteration) would race
    // against whatever that same edge just updated (for example a
    // concurrent read draining a slot that a stalled write is waiting on),
    // making the hold decision depend on unrelated activity on the other
    // port. Recomputing it from a fresh post-edge sample was tried first
    // and is exactly that bug: seed-dependent, not consistently wrong, so
    // it can pass by chance on one random run and fail on the next.
    task automatic random_backpressure(int n_cycles);
        int seed = 32'hC0FFEE ^ REGISTERED_OUTPUT;
        bit wr_hold = 1'b0;
        for (int c = 0; c < n_cycles; c++) begin
            automatic bit do_wr = ($urandom(seed) % 3) != 0; // ~66% attempt write
            automatic bit do_rd = ($urandom(seed) % 3) != 0; // ~66% attempt read

            if (!wr_hold) begin
                wr_valid = do_wr;
                wr_data  = $urandom(seed);
            end // else: hold wr_valid/wr_data exactly as they were
            rd_ready = do_rd;

            if (wr_valid && wr_ready) ref_q.push_back(wr_data);
            wr_hold = wr_valid && !wr_ready;

            if (rd_valid && rd_ready) begin
                if (ref_q.size() == 0) begin
                    $display("MISMATCH: rd_valid asserted but reference queue empty @t=%0t", $time);
                    errors++;
                end else begin
                    automatic logic [WIDTH-1:0] exp = ref_q.pop_front();
                    if (rd_data !== exp) begin
                        $display("MISMATCH rd_data(random): got=%0h exp=%0h", rd_data, exp);
                        errors++;
                    end
                end
            end

            @(negedge clk);
        end
        wr_valid = 0; rd_ready = 0;
        @(negedge clk);
    endtask

    initial begin
        do_reset();
        directed_fill_drain();
        do_reset();
        random_backpressure(500);

        if (errors == 0) $display("SFX_TB_RESULT: PASS");
        else              $display("SFX_TB_RESULT: FAIL (%0d mismatches)", errors);
        $finish;
    end

endmodule

// NOTE: the two REGISTERED_OUTPUT configurations are instantiated from
// separate top-level wrapper files (tb_sfx_fifo_registered.sv and
// tb_sfx_fifo_combinational.sv), each compiled+run as its own vvp
// invocation. $finish is process-global in Icarus Verilog: two top
// modules sharing one simulation would have the first one to finish
// silently truncate the other's test before it can report a result, so
// they must not share a compile+run.
