// Top-level wrapper: runs tb_sfx_systolic_array at ROWS=COLS=4, M=6
// (non-square: exercises M != ROWS/COLS).
`timescale 1ns/1ps
module tb_sfx_systolic_array_4x4;
    tb_sfx_systolic_array #(
        .ROWS(4), .COLS(4), .DATA_WIDTH(8), .ACC_WIDTH(32), .M(6),
        .SEED(32'hAAAA_0001)
    ) u_tb();
endmodule
