// Top-level wrapper: runs tb_sfx_systolic_array at ROWS=COLS=16, M=20
// (the "first implementation target" 16x16 array size, non-square M).
`timescale 1ns/1ps
module tb_sfx_systolic_array_16x16;
    tb_sfx_systolic_array #(
        .ROWS(16), .COLS(16), .DATA_WIDTH(8), .ACC_WIDTH(32), .M(20),
        .SEED(32'hBBBB_0002)
    ) u_tb();
endmodule
