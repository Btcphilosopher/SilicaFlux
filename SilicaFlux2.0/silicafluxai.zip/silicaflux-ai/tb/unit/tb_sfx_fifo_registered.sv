// Top-level wrapper: runs tb_sfx_fifo with REGISTERED_OUTPUT=1 as its own
// standalone simulation (see note at the bottom of tb_sfx_fifo.sv).
`timescale 1ns/1ps
module tb_sfx_fifo_registered;
    tb_sfx_fifo #(.REGISTERED_OUTPUT(1)) u_tb();
endmodule
