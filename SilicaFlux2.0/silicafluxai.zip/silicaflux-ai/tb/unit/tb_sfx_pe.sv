// =============================================================================
// tb_sfx_pe.sv -- self-checking unit testbench for rtl/tensor/sfx_pe.sv
//
// Coverage:
//   - weight-load shift semantics: verifies weight_out mirrors weight_in
//     delayed by exactly one cycle while load_mode=1 (the property a column
//     of PEs relies on to end up correctly loaded, see sfx_pe.sv header)
//   - compute datapath: psum_out = psum_in + act_in*weight_reg, act_out =
//     delayed act_in, checked against boundary values including INT8
//     extremes (won't overflow ACC_WIDTH=32)
//   - compute_en=0 correctly holds both act_out and psum_out
// =============================================================================
`timescale 1ns/1ps

module tb_sfx_pe;

    localparam int DATA_WIDTH = 8;
    localparam int ACC_WIDTH  = 32;

    logic clk = 0;
    logic rst_n;
    logic load_mode, compute_en;
    logic signed [DATA_WIDTH-1:0] weight_in;
    logic signed [DATA_WIDTH-1:0] weight_out;
    logic signed [DATA_WIDTH-1:0] act_in;
    logic signed [DATA_WIDTH-1:0] act_out;
    logic signed [ACC_WIDTH-1:0]  psum_in;
    logic signed [ACC_WIDTH-1:0]  psum_out;
    int errors = 0;

    always #5 clk = ~clk;

    sfx_pe #(.DATA_WIDTH(DATA_WIDTH), .ACC_WIDTH(ACC_WIDTH)) dut (
        .clk(clk), .rst_n(rst_n),
        .load_mode(load_mode), .compute_en(compute_en),
        .weight_in(weight_in), .weight_out(weight_out),
        .act_in(act_in), .act_out(act_out),
        .psum_in(psum_in), .psum_out(psum_out)
    );

    task automatic check(string what, logic signed [ACC_WIDTH-1:0] got, logic signed [ACC_WIDTH-1:0] exp);
        if (got !== exp) begin
            $display("MISMATCH %s: got=%0d exp=%0d @t=%0t", what, got, exp, $time);
            errors++;
        end
    endtask

    initial begin
        rst_n = 0; load_mode = 0; compute_en = 0;
        weight_in = 0; act_in = 0; psum_in = 0;
        repeat (3) @(negedge clk);
        check("reset_weight_out", weight_out, 0);
        check("reset_act_out", act_out, 0);
        check("reset_psum_out", psum_out, 0);
        rst_n = 1;
        @(negedge clk);

        // --- Weight-load shift: feed a distinct sequence, confirm
        // weight_out mirrors weight_in exactly one cycle later (weight_out
        // is a combinational tap of the single weight register, which
        // itself is a 1-cycle-delayed capture of weight_in -- see
        // sfx_pe.sv's header for why this single-register design, not a
        // separately-registered weight_out, is what gives each row of a
        // column exactly 1 cycle of shift delay).
        load_mode = 1;
        for (int i = 0; i < 6; i++) begin
            weight_in = 8'sd10 + i;
            @(negedge clk);
            check("weight_shift", weight_out, 8'sd10 + i);
        end
        // After the loop, weight_reg holds the LAST fed value (8'sd15),
        // which becomes this PE's stationary weight for compute below.
        load_mode = 0;
        @(negedge clk);

        // --- Compute datapath ---
        // weight_reg == 15 now. Feed act_in=4, psum_in=100 ->
        // expect psum_out = 100 + 4*15 = 160, act_out = 4 (one cycle later)
        compute_en = 1;
        act_in = 8'sd4; psum_in = 32'sd100;
        @(negedge clk);
        check("compute_psum", psum_out, 100 + 4*15);
        check("compute_act", act_out, 4);

        // INT8 extremes: -128 * -128 = 16384, plus a large psum_in
        act_in = -8'sd128; psum_in = 32'sd1_000_000;
        @(negedge clk);
        check("compute_extreme", psum_out, 1_000_000 + (-128)*15);

        // compute_en=0 must hold both outputs regardless of new inputs
        compute_en = 0;
        act_in = 8'sd99; psum_in = 32'sd99;
        @(negedge clk);
        check("hold_psum", psum_out, 1_000_000 + (-128)*15);
        check("hold_act", act_out, -128);

        if (errors == 0) $display("SFX_TB_RESULT: PASS");
        else              $display("SFX_TB_RESULT: FAIL (%0d mismatches)", errors);
        $finish;
    end

endmodule
