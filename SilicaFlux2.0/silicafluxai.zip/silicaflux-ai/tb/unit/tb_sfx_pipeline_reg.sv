// =============================================================================
// tb_sfx_pipeline_reg.sv -- self-checking unit testbench for
// rtl/common/sfx_pipeline_reg.sv
//
// Coverage: fixed-latency alignment for STAGES=0 (bypass), 1, and 4. A
// distinct tag is driven for exactly one cycle at a time (with idle gaps in
// between, to catch an implementation that accidentally coalesces or drops
// bubbles) and must reappear on valid_out/data_out exactly STAGES cycles
// later, on each instance independently, for several trials.
// =============================================================================
`timescale 1ns/1ps

module tb_sfx_pipeline_reg;

    localparam int WIDTH = 8;
    logic clk = 0;
    logic rst_n;
    logic valid_in;
    logic [WIDTH-1:0] data_in;
    int errors = 0;

    always #5 clk = ~clk;

    // --- STAGES = 0 (bypass) ---
    logic v0_out; logic [WIDTH-1:0] d0_out;
    sfx_pipeline_reg #(.WIDTH(WIDTH), .STAGES(0)) u_bypass (
        .clk(clk), .rst_n(rst_n), .valid_in(valid_in), .data_in(data_in),
        .valid_out(v0_out), .data_out(d0_out)
    );

    // --- STAGES = 1 ---
    logic v1_out; logic [WIDTH-1:0] d1_out;
    sfx_pipeline_reg #(.WIDTH(WIDTH), .STAGES(1)) u_s1 (
        .clk(clk), .rst_n(rst_n), .valid_in(valid_in), .data_in(data_in),
        .valid_out(v1_out), .data_out(d1_out)
    );

    // --- STAGES = 4 ---
    logic v4_out; logic [WIDTH-1:0] d4_out;
    sfx_pipeline_reg #(.WIDTH(WIDTH), .STAGES(4)) u_s4 (
        .clk(clk), .rst_n(rst_n), .valid_in(valid_in), .data_in(data_in),
        .valid_out(v4_out), .data_out(d4_out)
    );

    task automatic check_bit(string what, logic a, logic b);
        if (a !== b) begin
            $display("MISMATCH %s: got=%0b exp=%0b @t=%0t", what, a, b, $time);
            errors++;
        end
    endtask
    task automatic check_byte(string what, logic [WIDTH-1:0] a, logic [WIDTH-1:0] b);
        if (a !== b) begin
            $display("MISMATCH %s: got=%0h exp=%0h @t=%0t", what, a, b, $time);
            errors++;
        end
    endtask

    initial begin
        rst_n = 0; valid_in = 0; data_in = '0;
        repeat (3) @(negedge clk);
        rst_n = 1;
        @(negedge clk);

        // Bypass (STAGES=0): purely combinational passthrough.
        valid_in = 1; data_in = 8'hAA;
        #1;
        check_bit("bypass_valid", v0_out, 1'b1);
        check_byte("bypass_data", d0_out, 8'hAA);
        valid_in = 0;
        #1;
        check_bit("bypass_valid_falls", v0_out, 1'b0);
        @(negedge clk);

        // Confirm both pipelines are quiescent (valid_out low) with no
        // stimulus in flight before starting the timed trials below.
        check_bit("s1_quiescent", v1_out, 1'b0);
        check_bit("s4_quiescent", v4_out, 1'b0);

        // Drive one one-cycle-wide tag at a time and confirm it surfaces on
        // each pipeline exactly STAGES cycles later, with an idle gap of
        // several cycles between trials so a trial's tag can't be confused
        // with the previous one still draining through the deeper (4-stage)
        // pipeline.
        for (int trial = 0; trial < 5; trial++) begin
            logic [WIDTH-1:0] tag;
            tag = 8'hC0 + trial;

            valid_in = 1; data_in = tag;
            @(negedge clk);
            valid_in = 0; data_in = '0;

            // One cycle has now elapsed since the tag was driven -> that is
            // exactly STAGES=1's latency.
            check_bit("s1_valid", v1_out, 1'b1);
            check_byte("s1_data", d1_out, tag);

            repeat (3) @(negedge clk); // three more cycles -> total 4 -> STAGES=4's latency
            check_bit("s4_valid", v4_out, 1'b1);
            check_byte("s4_data", d4_out, tag);

            repeat (4) @(negedge clk); // idle gap before the next trial
            check_bit("s1_idle_between_trials", v1_out, 1'b0);
            check_bit("s4_idle_between_trials", v4_out, 1'b0);
        end

        // Reset must clear valid_out on every stage, even mid-flight.
        valid_in = 1; data_in = 8'hEE;
        @(negedge clk);
        valid_in = 0;
        rst_n = 0;
        @(negedge clk);
        check_bit("reset_clears_s1_valid", v1_out, 1'b0);
        check_bit("reset_clears_s4_valid", v4_out, 1'b0);
        rst_n = 1;
        @(negedge clk);

        if (errors == 0) $display("SFX_TB_RESULT: PASS");
        else              $display("SFX_TB_RESULT: FAIL (%0d mismatches)", errors);
        $finish;
    end

endmodule
