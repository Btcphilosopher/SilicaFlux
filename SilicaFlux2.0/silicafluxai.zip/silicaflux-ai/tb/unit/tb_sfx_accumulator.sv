// =============================================================================
// tb_sfx_accumulator.sv -- self-checking unit testbench for
// rtl/arithmetic/sfx_accumulator.sv
//
// Coverage: clear-then-accumulate sequence at one address, read-during-write
// (same-cycle read/write to the same address shows the pre-write value),
// and a randomised multi-address accumulate sequence checked against a SW
// reference array.
// =============================================================================
`timescale 1ns/1ps

module tb_sfx_accumulator;

    localparam int WIDTH = 32;
    localparam int DEPTH = 16;
    localparam int ADDR_W = $clog2(DEPTH);

    logic clk = 0;
    logic rst_n;
    logic en, clear;
    logic [ADDR_W-1:0] addr;
    logic signed [WIDTH-1:0] data;
    logic [ADDR_W-1:0] rd_addr;
    logic signed [WIDTH-1:0] rd_data;
    int errors = 0;

    always #5 clk = ~clk;

    sfx_accumulator #(.WIDTH(WIDTH), .DEPTH(DEPTH)) dut (
        .clk(clk), .rst_n(rst_n), .en(en), .clear(clear), .addr(addr), .data(data),
        .rd_addr(rd_addr), .rd_data(rd_data)
    );

    task automatic check(string what, logic signed [WIDTH-1:0] got, logic signed [WIDTH-1:0] exp);
        if (got !== exp) begin
            $display("MISMATCH %s: got=%0d exp=%0d @t=%0t", what, got, exp, $time);
            errors++;
        end
    endtask

    initial begin
        rst_n = 0; en = 0; clear = 0; addr = 0; data = 0; rd_addr = 0;
        repeat (3) @(negedge clk);
        rst_n = 1;
        @(negedge clk);

        // --- directed: clear-load then two accumulates at addr=3 ---
        en = 1; clear = 1; addr = 3; data = 100;
        @(negedge clk);
        rd_addr = 3;
        #1; check("after_clear", rd_data, 100);

        clear = 0; data = 50;
        @(negedge clk);
        #1; check("after_add1", rd_data, 150);

        data = -200;
        @(negedge clk);
        #1; check("after_add2", rd_data, -50);

        en = 0;
        @(negedge clk);
        #1; check("hold_when_disabled", rd_data, -50);

        // --- read-during-write: rd_addr==write addr shows PRE-write value ---
        en = 1; clear = 0; addr = 3; data = 1000;
        rd_addr = 3;
        #1; check("read_before_write_visible", rd_data, -50); // still old value combinationally
        @(negedge clk);
        #1; check("write_landed", rd_data, 950); // -50+1000

        en = 0;

        // --- randomised multi-address accumulation vs SW reference ---
        begin
            int seed;
            logic signed [WIDTH-1:0] ref_mem [DEPTH];
            seed = 32'hACC0_1234;
            for (int i = 0; i < DEPTH; i++) ref_mem[i] = 0;

            for (int i = 0; i < 1000; i++) begin
                logic [ADDR_W-1:0] a;
                logic signed [WIDTH-1:0] d;
                bit do_clear;
                a = $urandom(seed) % DEPTH;
                d = $urandom(seed);
                do_clear = ($urandom(seed) % 5) == 0; // occasional clear
                en = 1; clear = do_clear; addr = a; data = d;
                if (do_clear) ref_mem[a] = d;
                else           ref_mem[a] = ref_mem[a] + d;
                @(negedge clk);
            end
            en = 0;
            @(negedge clk);

            for (int a = 0; a < DEPTH; a++) begin
                rd_addr = a[ADDR_W-1:0];
                #1;
                if (rd_data !== ref_mem[a]) begin
                    $display("MISMATCH random final[%0d]: got=%0d exp=%0d", a, rd_data, ref_mem[a]);
                    errors++;
                end
            end
        end

        if (errors == 0) $display("SFX_TB_RESULT: PASS");
        else              $display("SFX_TB_RESULT: FAIL (%0d mismatches)", errors);
        $finish;
    end

endmodule
