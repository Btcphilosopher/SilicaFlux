// =============================================================================
// tb_sfx_skid_buffer.sv -- self-checking unit testbench for
// rtl/common/sfx_skid_buffer.sv
//
// Coverage: back-to-back full-throughput transfer, a stalled downstream that
// forces data to "skid", and randomised backpressure on both sides checked
// against a SW reference queue (same discipline as tb_sfx_fifo.sv: VALID
// must not retract or change payload while stalled; READY is free-running).
// =============================================================================
`timescale 1ns/1ps

module tb_sfx_skid_buffer;

    localparam int WIDTH = 16;

    logic clk = 0;
    logic rst_n;
    logic in_valid, in_ready;
    logic [WIDTH-1:0] in_data;
    logic out_valid, out_ready;
    logic [WIDTH-1:0] out_data;
    int errors = 0;

    always #5 clk = ~clk;

    sfx_skid_buffer #(.WIDTH(WIDTH)) dut (
        .clk(clk), .rst_n(rst_n),
        .in_valid(in_valid), .in_ready(in_ready), .in_data(in_data),
        .out_valid(out_valid), .out_ready(out_ready), .out_data(out_data)
    );

    logic [WIDTH-1:0] ref_q[$];

    task automatic do_reset();
        rst_n = 0; in_valid = 0; in_data = '0; out_ready = 0;
        ref_q.delete();
        repeat (3) @(negedge clk);
        rst_n = 1;
        @(negedge clk);
    endtask

    // Full-throughput back-to-back transfer: out_ready always high, push a
    // new item every cycle, expect it to appear one or two cycles later in
    // strict FIFO order with nothing lost or duplicated.
    task automatic full_throughput(int n);
        out_ready = 1;
        for (int i = 0; i < n; i++) begin
            in_valid = 1;
            in_data  = 16'h1000 + i;
            if (in_ready) ref_q.push_back(in_data);
            if (out_valid && out_ready) begin
                automatic logic [WIDTH-1:0] exp = ref_q.pop_front();
                if (out_data !== exp) begin
                    $display("MISMATCH full_throughput: got=%0h exp=%0h", out_data, exp);
                    errors++;
                end
            end
            @(negedge clk);
        end
        in_valid = 0;
        // drain whatever remains
        for (int i = 0; i < 4; i++) begin
            if (out_valid && out_ready) begin
                if (ref_q.size() == 0) begin
                    $display("MISMATCH: unexpected out_valid during drain, ref_q empty");
                    errors++;
                end else begin
                    automatic logic [WIDTH-1:0] exp = ref_q.pop_front();
                    if (out_data !== exp) begin
                        $display("MISMATCH drain: got=%0h exp=%0h", out_data, exp);
                        errors++;
                    end
                end
            end
            @(negedge clk);
        end
        if (ref_q.size() != 0) begin
            $display("MISMATCH: %0d items never drained", ref_q.size());
            errors++;
        end
    endtask

    // See the equivalent comment in tb_sfx_fifo.sv::random_backpressure for
    // why in_hold and the ref_q bookkeeping must come from one sample taken
    // before crossing the edge, not a fresh sample taken after it.
    task automatic random_backpressure(int n_cycles);
        int seed = 32'hFEED5EED;
        bit in_hold = 1'b0;
        for (int c = 0; c < n_cycles; c++) begin
            automatic bit want_in  = ($urandom(seed) % 3) != 0;
            automatic bit want_out = ($urandom(seed) % 3) != 0;

            if (!in_hold) begin
                in_valid = want_in;
                in_data  = $urandom(seed);
            end
            out_ready = want_out;

            if (in_valid && in_ready) ref_q.push_back(in_data);
            in_hold = in_valid && !in_ready;

            if (out_valid && out_ready) begin
                if (ref_q.size() == 0) begin
                    $display("MISMATCH: out_valid but reference empty @t=%0t", $time);
                    errors++;
                end else begin
                    automatic logic [WIDTH-1:0] exp = ref_q.pop_front();
                    if (out_data !== exp) begin
                        $display("MISMATCH random: got=%0h exp=%0h", out_data, exp);
                        errors++;
                    end
                end
            end
            @(negedge clk);
        end
        in_valid = 0; out_ready = 0;
        @(negedge clk);
    endtask

    initial begin
        do_reset();
        full_throughput(20);
        do_reset();
        random_backpressure(500);

        if (errors == 0) $display("SFX_TB_RESULT: PASS");
        else              $display("SFX_TB_RESULT: FAIL (%0d mismatches)", errors);
        $finish;
    end

endmodule
