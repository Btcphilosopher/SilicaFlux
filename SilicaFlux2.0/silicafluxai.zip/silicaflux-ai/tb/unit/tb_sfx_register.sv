// =============================================================================
// tb_sfx_register.sv -- self-checking unit testbench for rtl/common/sfx_register.sv
// Convention: prints "SFX_TB_RESULT: PASS" or "SFX_TB_RESULT: FAIL (<n> mismatches)"
// as the last line before $finish. scripts/run_unit_tests.sh greps for this.
// =============================================================================
`timescale 1ns/1ps

module tb_sfx_register;

    localparam int WIDTH = 8;
    logic clk = 0;
    logic rst_n;
    logic en;
    logic [WIDTH-1:0] d;
    logic [WIDTH-1:0] q;
    int errors = 0;

    always #5 clk = ~clk;

    sfx_register #(.WIDTH(WIDTH), .RESET_VALUE(8'hA5)) dut (
        .clk(clk), .rst_n(rst_n), .en(en), .d(d), .q(q)
    );

    task automatic check(string what, logic [WIDTH-1:0] got, logic [WIDTH-1:0] exp);
        if (got !== exp) begin
            $display("MISMATCH %s: got=%0h exp=%0h @t=%0t", what, got, exp, $time);
            errors++;
        end
    endtask

    initial begin
        rst_n = 0; en = 0; d = '0;
        @(negedge clk);
        check("reset_value", q, 8'hA5);

        rst_n = 1;
        en = 0; d = 8'h42;
        @(negedge clk);
        check("hold_when_disabled", q, 8'hA5);

        en = 1; d = 8'h42;
        @(negedge clk);
        check("load_when_enabled", q, 8'h42);

        en = 0; d = 8'hFF;
        @(negedge clk);
        check("hold_after_load", q, 8'h42);

        en = 1; d = 8'hFF;
        @(negedge clk);
        check("load_second_value", q, 8'hFF);

        // synchronous reset reasserted mid-stream must win over enable
        rst_n = 0; en = 1; d = 8'h11;
        @(negedge clk);
        check("sync_reset_overrides_enable", q, 8'hA5);
        rst_n = 1;

        if (errors == 0) $display("SFX_TB_RESULT: PASS");
        else              $display("SFX_TB_RESULT: FAIL (%0d mismatches)", errors);
        $finish;
    end

endmodule
