// =============================================================================
// tb_sfx_saturate.sv -- self-checking unit testbench for
// rtl/arithmetic/sfx_saturate.sv
//
// Directed boundary tests (IN=32,OUT=8: range [-128,127]) plus an
// exhaustive sweep of every representable IN=8,OUT=4 value (range [-8,7])
// checked against a behavioural SW clamp -- small enough to cover fully.
// =============================================================================
`timescale 1ns/1ps

module tb_sfx_saturate;

    int errors = 0;

    // --- 32 -> 8 directed boundary cases ---
    logic signed [31:0] in32;
    logic signed [7:0]  out8;
    logic               sat8;

    sfx_saturate #(.IN_WIDTH(32), .OUT_WIDTH(8)) dut32 (
        .in_data(in32), .out_data(out8), .saturated(sat8)
    );

    task automatic check32(string what, logic signed [31:0] v,
                            logic signed [7:0] exp_out, logic exp_sat);
        in32 = v;
        #1;
        if (out8 !== exp_out || sat8 !== exp_sat) begin
            $display("MISMATCH %s: in=%0d got=(%0d,sat=%0b) exp=(%0d,sat=%0b)",
                      what, v, out8, sat8, exp_out, exp_sat);
            errors++;
        end
    endtask

    // --- exhaustive 8 -> 4 sweep ---
    logic signed [7:0] in8;
    logic signed [3:0] out4;
    logic              sat4;

    sfx_saturate #(.IN_WIDTH(8), .OUT_WIDTH(4)) dut8 (
        .in_data(in8), .out_data(out4), .saturated(sat4)
    );

    function automatic logic signed [3:0] sw_clamp4(input logic signed [7:0] v);
        if (v > 8'sd7)   return 4'sd7;
        if (v < -8'sd8)  return -4'sd8;
        return v[3:0];
    endfunction

    initial begin
        // Boundary cases for IN=32 -> OUT=8, range [-128, 127]
        check32("zero",          32'sd0,    8'sd0,    1'b0);
        check32("max_in_range",  32'sd127,  8'sd127,  1'b0);
        check32("min_in_range", -32'sd128, -8'sd128,  1'b0);
        check32("just_over",     32'sd128,  8'sd127,  1'b1);
        check32("just_under",   -32'sd129, -8'sd128,  1'b1);
        check32("large_pos",     32'sd2_000_000, 8'sd127,  1'b1);
        check32("large_neg",    -32'sd2_000_000, -8'sd128, 1'b1);

        // Exhaustive 8->4 sweep: every representable INT8 value
        for (int i = -128; i <= 127; i++) begin
            logic signed [3:0] exp;
            logic exp_sat;
            in8 = 8'(i);
            exp = sw_clamp4(8'(i));
            exp_sat = (i > 7) || (i < -8);
            #1;
            if (out4 !== exp || sat4 !== exp_sat) begin
                $display("MISMATCH sweep8to4: in=%0d got=(%0d,sat=%0b) exp=(%0d,sat=%0b)",
                          i, out4, sat4, exp, exp_sat);
                errors++;
            end
        end

        if (errors == 0) $display("SFX_TB_RESULT: PASS");
        else              $display("SFX_TB_RESULT: FAIL (%0d mismatches)", errors);
        $finish;
    end

endmodule
