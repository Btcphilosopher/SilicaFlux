// =============================================================================
// tb_sfx_sram_interface.sv -- self-checking unit testbench for
// rtl/memory/sfx_sram_interface.sv
//
// Coverage: write-then-read-back at several addresses, byte-strobed partial
// writes (confirm untouched bytes are preserved), rvalid timing (exactly 1
// cycle after a read request, and only after a read -- not a write), and a
// randomised write/read sequence checked against a SW reference array that
// itself models per-byte write masking.
// =============================================================================
`timescale 1ns/1ps

module tb_sfx_sram_interface;

    localparam int DATA_WIDTH = 32;
    localparam int DEPTH      = 256;
    localparam int ADDR_W     = $clog2(DEPTH);

    logic clk = 0;
    logic rst_n;
    logic en, we;
    logic [ADDR_W-1:0] addr;
    logic [DATA_WIDTH-1:0] wdata;
    logic [(DATA_WIDTH/8)-1:0] wstrb;
    logic [DATA_WIDTH-1:0] rdata;
    logic rvalid;
    int errors = 0;

    always #5 clk = ~clk;

    sfx_sram_interface #(.DATA_WIDTH(DATA_WIDTH), .DEPTH(DEPTH)) dut (
        .clk(clk), .rst_n(rst_n), .en(en), .we(we), .addr(addr),
        .wdata(wdata), .wstrb(wstrb), .rdata(rdata), .rvalid(rvalid)
    );

    // SW reference: full memory image + a "known" bitmask (has this word
    // ever been written) so we never compare against genuinely undefined
    // (never-written) locations.
    logic [DATA_WIDTH-1:0] ref_mem [DEPTH];
    bit                    ref_known [DEPTH];

    task automatic do_write(input logic [ADDR_W-1:0] a, input logic [DATA_WIDTH-1:0] d,
                             input logic [(DATA_WIDTH/8)-1:0] strb);
        en = 1; we = 1; addr = a; wdata = d; wstrb = strb;
        @(negedge clk);
        for (int b = 0; b < DATA_WIDTH/8; b++) begin
            if (strb[b]) begin
                ref_mem[a][8*b +: 8] = d[8*b +: 8];
            end
        end
        ref_known[a] = 1;
        en = 0; we = 0;
    endtask

    // Issues a read request; caller must wait 1 more cycle and check
    // rvalid/rdata (see check_pending_read below) -- kept separate so
    // callers can interleave other activity while a read is in flight.
    task automatic issue_read(input logic [ADDR_W-1:0] a);
        en = 1; we = 0; addr = a;
        @(negedge clk);
        en = 0;
    endtask

    task automatic check(string what, logic cond);
        if (!cond) begin
            $display("MISMATCH %s @t=%0t", what, $time);
            errors++;
        end
    endtask

    initial begin
        rst_n = 0; en = 0; we = 0; addr = 0; wdata = 0; wstrb = 0;
        for (int i = 0; i < DEPTH; i++) ref_known[i] = 0;
        repeat (3) @(negedge clk);
        check("reset_rvalid", rvalid === 1'b0);
        rst_n = 1;
        @(negedge clk);

        // --- directed: write then read back at a few addresses ---
        do_write(8'd0,   32'hDEAD_BEEF, 4'hF);
        do_write(8'd1,   32'h1234_5678, 4'hF);
        do_write(8'd255, 32'hCAFE_BABE, 4'hF);

        // issue_read() already crosses the one edge that makes rdata/rvalid
        // valid (rvalid is a plain 1-cycle-delayed copy of en&&!we, so it
        // drops back to 0 on the very next edge regardless of activity --
        // check it right here, not after a further edge).
        issue_read(8'd0);
        check("rvalid_after_read", rvalid === 1'b1);
        check("rdata_addr0", rdata === 32'hDEAD_BEEF);

        issue_read(8'd255);
        check("rdata_addr255", rdata === 32'hCAFE_BABE);

        // rvalid must NOT pulse after a write (same reasoning: check right
        // after the write's own edge, via do_write() so the reference
        // model's bookkeeping stays consistent with the DUT -- a raw
        // signal-level write here that bypassed do_write() would leave
        // ref_mem/ref_known out of sync with this address for the rest of
        // the test).
        do_write(8'd10, 32'hAAAA_AAAA, 4'hF);
        check("rvalid_not_after_write", rvalid === 1'b0);

        // --- byte-strobed partial write: only bytes 0 and 2 updated ---
        do_write(8'd20, 32'h1111_1111, 4'hF);       // baseline: all bytes = 0x11
        do_write(8'd20, 32'h9999_9999, 4'b0101);    // update byte0 and byte2 only
        issue_read(8'd20);
        // expected: byte3=0x11 (untouched), byte2=0x99 (updated),
        //           byte1=0x11 (untouched), byte0=0x99 (updated)
        check("partial_write", rdata === 32'h1199_1199);
        check("partial_write_ref_matches", rdata === ref_mem[20]);

        // --- randomised write/read vs SW reference ---
        begin
            int seed;
            seed = 32'h5EED_CAFE;
            for (int i = 0; i < 800; i++) begin
                bit do_wr;
                logic [ADDR_W-1:0] a;
                do_wr = ($urandom(seed) % 2) == 0;
                a     = $urandom(seed) % DEPTH;
                if (do_wr) begin
                    logic [DATA_WIDTH-1:0] d;
                    logic [(DATA_WIDTH/8)-1:0] strb;
                    d    = $urandom(seed);
                    strb = $urandom(seed);
                    if (strb == '0) strb = 4'hF; // avoid a no-op write every so often
                    do_write(a, d, strb);
                end else begin
                    issue_read(a);
                    @(negedge clk);
                    if (ref_known[a]) begin
                        if (rdata !== ref_mem[a]) begin
                            $display("MISMATCH random read addr=%0d: got=%0h exp=%0h", a, rdata, ref_mem[a]);
                            errors++;
                        end
                    end
                end
            end
        end

        if (errors == 0) $display("SFX_TB_RESULT: PASS");
        else              $display("SFX_TB_RESULT: FAIL (%0d mismatches)", errors);
        $finish;
    end

endmodule
