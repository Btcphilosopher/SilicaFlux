// =============================================================================
// tb_sfx_mac.sv -- self-checking unit testbench for rtl/arithmetic/sfx_mac.sv
//
// Coverage: reset behaviour, clear-restart semantics, en=0 hold, a directed
// accumulation of known INT8xINT8 products, and a randomised long-running
// accumulation (INT8 x INT8 -> INT32, well within ACC_WIDTH so no overflow
// is expected) checked cycle-by-cycle against a SW running sum.
// =============================================================================
`timescale 1ns/1ps

module tb_sfx_mac;

    localparam int A_WIDTH   = 8;
    localparam int B_WIDTH   = 8;
    localparam int ACC_WIDTH = 32;

    logic clk = 0;
    logic rst_n;
    logic en, clear;
    logic signed [A_WIDTH-1:0] a;
    logic signed [B_WIDTH-1:0] b;
    logic signed [ACC_WIDTH-1:0] acc;
    int errors = 0;

    always #5 clk = ~clk;

    sfx_mac #(.A_WIDTH(A_WIDTH), .B_WIDTH(B_WIDTH), .ACC_WIDTH(ACC_WIDTH)) dut (
        .clk(clk), .rst_n(rst_n), .en(en), .clear(clear), .a(a), .b(b), .acc(acc)
    );

    task automatic check(string what, logic signed [ACC_WIDTH-1:0] got, logic signed [ACC_WIDTH-1:0] exp);
        if (got !== exp) begin
            $display("MISMATCH %s: got=%0d exp=%0d @t=%0t", what, got, exp, $time);
            errors++;
        end
    endtask

    initial begin
        rst_n = 0; en = 0; clear = 0; a = 0; b = 0;
        repeat (3) @(negedge clk);
        check("reset_value", acc, 0);
        rst_n = 1;
        @(negedge clk);

        // Directed: clear-load with 5 * -3 = -15, then accumulate +7*7=49,
        // then -8*-8=64 -> running total -15+49+64=98
        en = 1; clear = 1; a = 8'sd5;  b = -8'sd3;
        @(negedge clk);
        check("clear_load", acc, -15);

        clear = 0; a = 8'sd7; b = 8'sd7;
        @(negedge clk);
        check("accum_1", acc, -15 + 49);

        a = -8'sd8; b = -8'sd8;
        @(negedge clk);
        check("accum_2", acc, -15 + 49 + 64);

        // en=0 must hold, regardless of a/b changing
        en = 0; a = 8'sd127; b = 8'sd127;
        @(negedge clk);
        check("hold_when_disabled", acc, -15 + 49 + 64);
        @(negedge clk);
        check("hold_when_disabled_2", acc, -15 + 49 + 64);

        // extreme products: -128 * -128 = 16384 (both operands at INT8 min)
        en = 1; clear = 1; a = -8'sd128; b = -8'sd128;
        @(negedge clk);
        check("extreme_product", acc, 16384);

        // synchronous reset mid-accumulation must clear to 0 and override en/clear
        clear = 0; en = 1; a = 8'sd1; b = 8'sd1;
        rst_n = 0;
        @(negedge clk);
        check("sync_reset_overrides", acc, 0);
        rst_n = 1;
        @(negedge clk);

        // Randomised long accumulation vs SW reference, no overflow expected
        // (INT8*INT8 magnitude <= 16384; even 100k terms stays far inside
        // signed 32-bit range).
        begin
            longint sw_acc;
            int seed;
            seed = 32'hA5A5_1234;
            en = 1; clear = 1;
            a = $urandom(seed);
            b = $urandom(seed);
            sw_acc = $signed(a) * $signed(b);
            @(negedge clk);
            check("rand_clear_load", acc, sw_acc[ACC_WIDTH-1:0]);

            clear = 0;
            for (int i = 0; i < 2000; i++) begin
                a = $urandom(seed);
                b = $urandom(seed);
                sw_acc = sw_acc + ($signed(a) * $signed(b));
                @(negedge clk);
                if (acc !== sw_acc[ACC_WIDTH-1:0]) begin
                    $display("MISMATCH rand_accum[%0d]: got=%0d exp=%0d", i, acc, sw_acc);
                    errors++;
                end
            end
        end

        if (errors == 0) $display("SFX_TB_RESULT: PASS");
        else              $display("SFX_TB_RESULT: FAIL (%0d mismatches)", errors);
        $finish;
    end

endmodule
