// =============================================================================
// tb_sfx_gemm_vectors.sv -- RTL<->Python verification bridge testbench
//
// This is the RTL side of python/verification/bridge.py's flow (PHASE 17):
//
//    Python golden model -> test vector generator -> RTL simulation
//         -> output capture -> Python comparator
//
// Unlike tb/integration/tb_sfx_gemm_controller.sv (a self-contained,
// directed regression test with vectors and golden values computed in SV),
// this testbench carries NO golden data of its own: every input comes from
// files Python writes, and every result Python reads back and judges. Its
// only jobs are: load A_sram/B_sram from hex files ($readmemh, into
// dut.u_a_sram.mem / dut.u_b_sram.mem via the same simulation-only
// hierarchical backdoor documented in sfx_sram_interface.sv), run one GEMM
// command with the runtime M/N/K given on the command line, dump C_sram
// back out ($writememh), and report the cycle count the command actually
// took. It does not know what "correct" looks like -- see
// python/verification/bridge.py for where the actual PASS/FAIL judgement
// and JSON result happen. This split is deliberate: it is the difference
// between a regression test (this repo asserting its own RTL is right) and
// a verification *bridge* (an independent Python-computed oracle checking
// the RTL from outside), and only the latter can catch a bug shared
// between the RTL and a hand-written SV testbench's own golden math.
//
// Command-line plusargs (all required):
//   +A_FILE=<path>    hex file for A_sram, one ROWS*DATA_WIDTH-bit word
//                     per line, MAX_M*KTILES_MAX lines, layout matching
//                     sfx_gemm_controller.sv's documented A_sram convention
//   +B_FILE=<path>    hex file for B_sram, COLS*DATA_WIDTH-bit words,
//                     NTILES_MAX*KTILES_MAX*ROWS lines, B_sram convention
//   +C_FILE=<path>    output path this testbench writes C_sram to
//                     (ACC_WIDTH-bit words, MAX_M*MAX_N lines, two's
//                     complement hex -- python/verification/bridge.py
//                     reinterprets sign)
//   +M=<int> +N=<int> +K=<int>   the GEMM command's runtime dimensions
//
// Compile-time array configuration is fixed (ROWS=COLS=4, MAX_M=MAX_N=
// MAX_K=16) so python/verification/vectors.py's layout math has a single,
// documented target to match -- see that file.
// =============================================================================
`timescale 1ns/1ps

module tb_sfx_gemm_vectors;

    localparam int ROWS       = 4;
    localparam int COLS       = 4;
    localparam int DATA_WIDTH = 8;
    localparam int ACC_WIDTH  = 32;
    localparam int MAX_M      = 16;
    localparam int MAX_N      = 16;
    localparam int MAX_K      = 16;

    logic clk = 0;
    logic rst_n;
    always #5 clk = ~clk;

    logic cmd_valid, cmd_ready;
    logic [$clog2(MAX_M+1)-1:0] cmd_m;
    logic [$clog2(MAX_N+1)-1:0] cmd_n;
    logic [$clog2(MAX_K+1)-1:0] cmd_k;
    logic done_valid, done_ready;

    sfx_gemm_controller #(
        .ROWS(ROWS), .COLS(COLS), .DATA_WIDTH(DATA_WIDTH), .ACC_WIDTH(ACC_WIDTH),
        .MAX_M(MAX_M), .MAX_N(MAX_N), .MAX_K(MAX_K)
    ) dut (
        .clk(clk), .rst_n(rst_n),
        .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_m(cmd_m), .cmd_n(cmd_n), .cmd_k(cmd_k),
        .done_valid(done_valid), .done_ready(done_ready)
    );

    longint cycle_count;
    always_ff @(posedge clk) begin
        if (cmd_valid && cmd_ready) cycle_count <= 0;
        else                        cycle_count <= cycle_count + 1;
    end

    initial begin
        string a_file, b_file, c_file;
        int m_val, n_val, k_val;
        int got_a, got_b, got_c, got_m, got_n, got_k;

        got_a = $value$plusargs("A_FILE=%s", a_file);
        got_b = $value$plusargs("B_FILE=%s", b_file);
        got_c = $value$plusargs("C_FILE=%s", c_file);
        got_m = $value$plusargs("M=%d", m_val);
        got_n = $value$plusargs("N=%d", n_val);
        got_k = $value$plusargs("K=%d", k_val);
        if (!(got_a && got_b && got_c && got_m && got_n && got_k)) begin
            $display("SFX_BRIDGE_ERROR: missing required +A_FILE/+B_FILE/+C_FILE/+M/+N/+K plusarg");
            $finish;
        end

        rst_n = 0; cmd_valid = 0; cmd_m = 0; cmd_n = 0; cmd_k = 0; done_ready = 1;
        repeat (3) @(negedge clk);
        rst_n = 1;
        @(negedge clk);

        $readmemh(a_file, dut.u_a_sram.mem);
        $readmemh(b_file, dut.u_b_sram.mem);

        cmd_valid = 1;
        cmd_m = m_val[$bits(cmd_m)-1:0];
        cmd_n = n_val[$bits(cmd_n)-1:0];
        cmd_k = k_val[$bits(cmd_k)-1:0];
        @(negedge clk); // engine is idle here (fresh reset) -> accepted this edge
        cmd_valid = 0;

        while (!done_valid) @(negedge clk);
        @(negedge clk); // done_ready held at 1 -> this edge completes the handshake

        $writememh(c_file, dut.u_c_sram.mem);

        $display("SFX_BRIDGE_CYCLES: %0d", cycle_count);
        $display("SFX_BRIDGE_DONE");
        $finish;
    end

endmodule
