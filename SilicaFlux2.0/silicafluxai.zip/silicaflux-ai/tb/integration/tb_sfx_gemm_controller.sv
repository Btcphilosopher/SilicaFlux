// =============================================================================
// tb_sfx_gemm_controller.sv -- self-checking integration testbench for
// rtl/gemm/sfx_gemm_controller.sv
//
// Preloads A_sram/B_sram directly (via the simulation-only hierarchical
// backdoor, same convention as tb_sfx_dma.sv) in the pre-tiled layout the
// controller's header documents, issues a command, and checks C_sram
// against a plain triple-loop SV golden matrix multiply.
//
// Cases specifically target Phase 5's requirement -- correct handling of
// M/N/K that are not multiples of the array dimensions -- plus K larger
// than ROWS (multi-pass accumulation) and the M=N=K=1 degenerate case.
// =============================================================================
`timescale 1ns/1ps

module tb_sfx_gemm_controller;

    localparam int ROWS       = 4;
    localparam int COLS       = 4;
    localparam int DATA_WIDTH = 8;
    localparam int ACC_WIDTH  = 32;
    localparam int MAX_M      = 10;
    localparam int MAX_N      = 10;
    localparam int MAX_K      = 10;

    localparam int KTILES_MAX = (MAX_K + ROWS - 1) / ROWS;
    localparam int NTILES_MAX = (MAX_N + COLS - 1) / COLS;
    localparam int A_DEPTH    = MAX_M * KTILES_MAX;
    localparam int B_DEPTH    = NTILES_MAX * KTILES_MAX * ROWS;
    localparam int C_DEPTH    = MAX_M * MAX_N;

    logic clk = 0;
    logic rst_n;
    always #5 clk = ~clk;

    logic cmd_valid, cmd_ready;
    logic [$clog2(MAX_M+1)-1:0] cmd_m;
    logic [$clog2(MAX_N+1)-1:0] cmd_n;
    logic [$clog2(MAX_K+1)-1:0] cmd_k;
    logic done_valid, done_ready;

    int errors = 0;

    sfx_gemm_controller #(
        .ROWS(ROWS), .COLS(COLS), .DATA_WIDTH(DATA_WIDTH), .ACC_WIDTH(ACC_WIDTH),
        .MAX_M(MAX_M), .MAX_N(MAX_N), .MAX_K(MAX_K)
    ) dut (
        .clk(clk), .rst_n(rst_n),
        .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_m(cmd_m), .cmd_n(cmd_n), .cmd_k(cmd_k),
        .done_valid(done_valid), .done_ready(done_ready)
    );

    task automatic check(string what, logic cond);
        if (!cond) begin
            $display("MISMATCH %s @t=%0t", what, $time);
            errors++;
        end
    endtask

    // Module-level (not task-local + passed by ref -- Icarus does not
    // support unpacked-array reference ports) scratch golden matrices,
    // reused by each run_case() call.
    logic signed [DATA_WIDTH-1:0] Amat [10][10];
    logic signed [DATA_WIDTH-1:0] Bmat [10][10];
    longint                       Cexp [10][10];

    // Preload A_sram/B_sram in the controller's documented pre-tiled
    // layout, from plain [M][K] / [K][N] golden matrices, zero-padding any
    // position past the real M/K/N (the controller doesn't rely on that --
    // it explicitly zeroes padding itself -- but padding the backing store
    // too keeps this task simple and avoids ever reading X in the trace).
    task automatic preload(input int m_sz, input int n_sz, input int k_sz);
        for (int m = 0; m < m_sz; m++) begin
            for (int kt = 0; kt < KTILES_MAX; kt++) begin
                logic [ROWS*DATA_WIDTH-1:0] word;
                word = '0;
                for (int rr = 0; rr < ROWS; rr++) begin
                    int k;
                    k = kt*ROWS + rr;
                    if (k < k_sz) word[rr*DATA_WIDTH +: DATA_WIDTH] = Amat[m][k];
                end
                dut.u_a_sram.mem[m*KTILES_MAX + kt] = word;
            end
        end
        for (int nt = 0; nt < NTILES_MAX; nt++) begin
            for (int kt = 0; kt < KTILES_MAX; kt++) begin
                for (int rr = 0; rr < ROWS; rr++) begin
                    logic [COLS*DATA_WIDTH-1:0] word;
                    int k;
                    word = '0;
                    k = kt*ROWS + rr;
                    if (k < k_sz) begin
                        for (int c = 0; c < COLS; c++) begin
                            int n;
                            n = nt*COLS + c;
                            if (n < n_sz) word[c*DATA_WIDTH +: DATA_WIDTH] = Bmat[k][n];
                        end
                    end
                    dut.u_b_sram.mem[(nt*KTILES_MAX + kt)*ROWS + rr] = word;
                end
            end
        end
    endtask

    task automatic run_case(input int m_sz, input int n_sz, input int k_sz, input int seed_in);
        int seed;
        seed = seed_in;

        for (int m = 0; m < m_sz; m++)
            for (int k = 0; k < k_sz; k++)
                Amat[m][k] = 8'($urandom(seed));
        for (int k = 0; k < k_sz; k++)
            for (int n = 0; n < n_sz; n++)
                Bmat[k][n] = 8'($urandom(seed));
        for (int m = 0; m < m_sz; m++) begin
            for (int n = 0; n < n_sz; n++) begin
                longint sum;
                sum = 0;
                for (int k = 0; k < k_sz; k++)
                    sum = sum + (longint'($signed(Amat[m][k])) * longint'($signed(Bmat[k][n])));
                Cexp[m][n] = sum;
            end
        end

        preload(m_sz, n_sz, k_sz);

        cmd_valid = 1; cmd_m = m_sz[$bits(cmd_m)-1:0]; cmd_n = n_sz[$bits(cmd_n)-1:0]; cmd_k = k_sz[$bits(cmd_k)-1:0];
        @(negedge clk); // engine is idle on entry (only called back-to-back after a prior done handshake, or after reset)
        cmd_valid = 0;
        while (!done_valid) @(negedge clk);
        @(negedge clk); // done_ready held at 1 throughout this test -> this edge completes the handshake

        for (int m = 0; m < m_sz; m++) begin
            for (int n = 0; n < n_sz; n++) begin
                logic signed [ACC_WIDTH-1:0] got;
                got = dut.u_c_sram.mem[m*n_sz + n];
                if (got !== Cexp[m][n][ACC_WIDTH-1:0]) begin
                    $display("MISMATCH C[%0d][%0d] (M=%0d,N=%0d,K=%0d): got=%0d exp=%0d",
                              m, n, m_sz, n_sz, k_sz, got, Cexp[m][n]);
                    errors++;
                end
            end
        end
    endtask

    initial begin
        rst_n = 0; cmd_valid = 0; cmd_m = 0; cmd_n = 0; cmd_k = 0; done_ready = 1;
        repeat (3) @(negedge clk);
        rst_n = 1;
        @(negedge clk);

        run_case(4, 4, 4, 32'hA001); // exact single tile
        check("after_case1_idle", cmd_ready === 1'b1);

        run_case(4, 4, 8, 32'hA002); // K = 2*ROWS: multi-pass kt accumulation
        run_case(5, 6, 7, 32'hA003); // fully non-multiple M/N/K (Phase 5 requirement)
        run_case(1, 1, 1, 32'hA004); // degenerate 1x1x1
        run_case(8, 8, 8, 32'hA005); // multiple N-tiles AND K-tiles together
        run_case(9, 5, 3, 32'hA006); // N not a multiple of COLS, M > one N/K-tile width
        run_case(3, 9, 9, 32'hA007); // N and K both exceed one tile, M small

        if (errors == 0) $display("SFX_TB_RESULT: PASS");
        else              $display("SFX_TB_RESULT: FAIL (%0d mismatches)", errors);
        $finish;
    end

endmodule
