# SilicaFlux-AI

A SystemVerilog-first hardware architecture framework for designing,
simulating, and verifying AI-specialised semiconductor accelerators.

SilicaFlux does not replace SystemVerilog — it organises, parameterises,
generates, and verifies it. SystemVerilog remains the authoritative
implementation of the semiconductor datapath; Python is the synthetic
modelling, verification, and optimisation environment around it.

```
architecture.yaml  →  SilicaFlux compiler  →  SystemVerilog parameters
                                                       ↓
                                            AI accelerator RTL
                                                       ↓
                                              RTL testbench
                                                       ↓
                                          Python golden model
                                                       ↓
                                              verification
```

## What's actually here

This is a real, deeply-verified core, not a superficial pass across the
whole vision described in the project brief. It implements a **single
weight-stationary INT8 systolic tensor core**, a **tiled GEMM controller**
around it (correctly handling matrix dimensions that are not multiples of
the array size), a **DMA engine**, and a **YAML → RTL compiler + CLI** —
each piece backed by a real testbench, and the whole loop verified twice:
once by a hand-written SystemVerilog testbench, and once independently by
a Python golden model driving the actual RTL through Icarus Verilog. That
second, independent check caught real bugs the first one missed — see
[`docs/TOOLING.md`](docs/TOOLING.md) for the specifics, and
[`docs/PHASE_STATUS.md`](docs/PHASE_STATUS.md) for an honest,
phase-by-phase accounting of what's built, what's schema-only, and what
doesn't exist yet, against the project's full 30-phase vision. Read that
file before assuming any capability described in the wider vision below is
implemented — the master project brief describes a much larger platform
(transformers, sparsity, NoC, multi-cluster, a vector engine, a general
command processor) than this milestone builds; `docs/PHASE_STATUS.md` says
exactly which of that is real here today.

**Numbers**: 14/14 RTL testbenches pass (`scripts/run_unit_tests.sh`) —
each one a self-checking testbench that itself runs many directed and
randomized checks internally (the FIFO and DMA testbenches alone each run
hundreds of randomized transactions per invocation), not 14 individual
assertions. 63/63 Python tests pass (`pytest`, most parametrized across
several architectures/shapes). 6/6 reference architectures validate and
generate RTL that actually compiles against the hand-written RTL library.
Every one of these numbers is reproducible from this repository in a few
minutes by running the commands below — not a claim to take on faith.

## Quickstart

```bash
# RTL regression (needs Icarus Verilog -- `apt install iverilog` or
# equivalent; see docs/TOOLING.md)
./scripts/run_unit_tests.sh

# Python tests (models, schema, CLI, and the RTL<->Python verification
# bridge -- the bridge tests are skipped, not faked, if iverilog is absent)
pip install -e ".[dev]"
pytest

# The CLI, on any of the six reference architectures:
python -m silicaflux.cli validate architectures/tensor16.yaml
python -m silicaflux.cli compile architectures/tensor16.yaml
python -m silicaflux.cli generate-rtl architectures/tensor16.yaml --out build/gen/tensor16
python -m silicaflux.cli simulate architectures/tensor16.yaml
python -m silicaflux.cli verify architectures/tensor16.yaml --json build/results/tensor16.json
python -m silicaflux.cli benchmark architectures/tensor16.yaml --m 64 --n 64 --k 64
python -m silicaflux.cli optimise architectures/tensor16.yaml
python -m silicaflux.cli report build/results/tensor16.json
# (or, once installed: `sfx-ai <command>` instead of `python -m silicaflux.cli <command>`)
```

## Repository structure

```
silicaflux-ai/
├── rtl/               SystemVerilog. common/interfaces/arithmetic (built);
│                       memory/dma/tensor/gemm (built); vector/attention/
│                       sparsity/scheduler/noc/command/top (scaffolded --
│                       see docs/PHASE_STATUS.md)
├── tb/                 unit/ (per-module testbenches) + integration/
│                       (GEMM controller + RTL<->Python bridge testbenches)
├── python/
│   ├── models/          bit-accurate golden reference models
│   └── verification/     the RTL<->Python bridge (PHASE 17)
├── silicaflux/
│   ├── schema/           Pydantic architecture schema
│   ├── parser/            YAML loader/validator
│   ├── compiler/          rtlgen.py, simgen.py, simulate.py
│   └── cli.py             sfx-ai CLI
├── architectures/       6 reference architecture YAMLs (tiny, tensor16,
│                        tensor32, transformer, sparse, multicluster)
├── scripts/              scripts/run_unit_tests.sh (RTL regression runner)
├── docs/                 ARCHITECTURE, PHASE_STATUS, MEMORY_PROTOCOL,
│                        DATATYPES_AND_PRECISION, TIMING_AND_RESET, TOOLING
└── tests/                pytest suite (models, schema/compiler, CLI, bridge)
```

## Documentation

- [`docs/PHASE_STATUS.md`](docs/PHASE_STATUS.md) — what's real, phase by
  phase. **Read this first.**
- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — systolic array dataflow
  and timing (with the derivation and empirical validation of when each
  result becomes valid), GEMM tiling, SRAM layout convention.
- [`docs/MEMORY_PROTOCOL.md`](docs/MEMORY_PROTOCOL.md) — the valid/ready
  streaming protocol and the SRAM read/write protocol every module here
  follows.
- [`docs/DATATYPES_AND_PRECISION.md`](docs/DATATYPES_AND_PRECISION.md) —
  signed wraparound vs. saturation, and where each is used deliberately.
- [`docs/TIMING_AND_RESET.md`](docs/TIMING_AND_RESET.md) — clocking, reset,
  and what is/isn't reset (and why).
- [`docs/TOOLING.md`](docs/TOOLING.md) — Icarus Verilog limitations hit
  along the way, and a log of real bugs this project's own testbenches and
  the RTL<->Python bridge caught, with root causes and fixes. This is the
  evidence behind the "verified" claims elsewhere in this repository.

## Engineering rules this repository follows

1. Prefer synthesizable SystemVerilog; keep simulation-only code (immediate
   assertions, hierarchical backdoors) clearly marked and out of the
   synthesizable datapath.
2. Every module is parameterised and independently testable — see `rtl/`'s
   one-module-per-file structure and `tb/unit/`'s one-testbench-per-module
   mirror.
3. Valid/ready protocols and SRAM timing are explicit and documented (see
   `docs/MEMORY_PROTOCOL.md`), never implicit.
4. Every numeric claim about performance is labelled by its source
   (RTL SIMULATION vs. ANALYTICAL) — see `docs/PHASE_STATUS.md`'s legend.
   Nothing here reports a SYNTHETIC, FPGA MEASUREMENT, POST-SYNTHESIS,
   POST-LAYOUT, or SILICON MEASUREMENT number, because none of those flows
   exist in this repository.
5. A "verified" claim always points at the test that verifies it — see
   `docs/TOOLING.md`'s bug log for what that verification actually caught.
