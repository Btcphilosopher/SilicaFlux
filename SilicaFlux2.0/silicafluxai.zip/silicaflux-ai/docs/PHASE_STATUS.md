# SilicaFlux-AI — Phase Status

This is the single source of truth for what in this repository is **real
and verified**, what is **scaffolded/descriptive**, and what is **not yet
started**, mapped against the 30-phase plan in the project brief. Nothing
in this document is aspirational marketing copy — every "DONE" row below
corresponds to code that compiles/runs in this repository and a test that
actually exercises it (see the "Evidence" column). This file is the answer
to "did you actually build X" for any phase.

Status legend:
- **DONE** — implemented, simulated, and passing a real regression test.
- **PARTIAL** — some real, tested functionality exists but the phase's
  full scope is not covered.
- **SCAFFOLDED** — directory/schema/documentation exists to receive this
  phase's work, but no RTL or working code implements it yet.
- **NOT STARTED** — nothing exists for this phase.

## Engineering-rule discipline

Per this project's own engineering rules (never fabricate synthesis or
silicon results; distinguish estimates from measurements), every numeric
result anywhere in this repository is labelled with where it came from:

| Label | Meaning | Where it's used |
|---|---|---|
| **RTL SIMULATION** | A real Icarus Verilog run of the actual RTL | `sfx-ai simulate`/`verify`/`benchmark`, `python/verification/bridge.py`, all `tb/unit`/`tb/integration` testbenches |
| **ANALYTICAL** | Closed-form arithmetic estimate, no RTL executed | `sfx-ai optimise` |
| SYNTHETIC, FPGA MEASUREMENT, POST-SYNTHESIS, POST-LAYOUT, SILICON MEASUREMENT | Not produced anywhere in this repository | — no synthesis/FPGA/silicon flow exists here; area, power, and post-synthesis timing are never estimated or reported anywhere in this codebase |

## Phase-by-phase status

| Phase | Topic | Status | Evidence |
|---|---|---|---|
| 1 | RTL architecture / parameterisation layer | **DONE** | `silicaflux/schema/architecture.py` → `silicaflux/compiler/rtlgen.py` → real SV parameters, verified end-to-end in `tests/test_silicaflux_compiler.py` |
| 2 | SystemVerilog RTL foundation | **PARTIAL** | Built: `sfx_register`, `sfx_fifo`, `sfx_skid_buffer`, `sfx_pipeline_reg`, `sfx_stream_if`. Not built: `sfx_arbiter`, `sfx_crossbar`, `sfx_router`, `sfx_reducer`, `sfx_command_queue`, `sfx_dispatcher`, `sfx_event_counter` (not needed by anything built so far; scaffolded directories exist under `rtl/`) |
| 3 | AI datatypes / numerical RTL | **PARTIAL** | Built: `sfx_mac` (signed MAC, wraparound accumulation), `sfx_saturate` (signed clamp), `sfx_accumulator` (addressable RMW accumulator). All INT-only (INT4/INT8/INT16 as narrower `DATA_WIDTH`, no separate "INT4 mode"). Not built: rounding, scaling/requantization, zero-point handling, dequantization, float conversion RTL — `python/models/datatypes.py`'s `quantize_affine`/`dequantize_affine` are the **PYTHON-MODEL-ONLY** reference for this, explicitly marked as not connected to any RTL |
| 4 | AI tensor core | **DONE** | `sfx_pe`, `sfx_systolic_array` — weight-stationary, arbitrary ROWS×COLS, verified at 4×4 and 16×16 against a golden matmul with 100% of expected results checked (`tb/unit/tb_sfx_systolic_array.sv`) |
| 5 | GEMM/matmul engine | **DONE** | `sfx_gemm_controller` — tiled M/N/K (M in one pass up to `MAX_M`, N/K tiled over COLS/ROWS with explicit zero-padding for partial tiles), verified against a Python golden model for exact-tile, partial-tile, multi-K-tile, and every-dimension-at-compile-time-max cases (`tb/integration/tb_sfx_gemm_controller.sv`, `python/verification/bridge.py`) |
| 6 | AI memory system | **PARTIAL** | Built: `sfx_sram_interface` (single-port, byte-strobed, 1-cycle-latency SRAM wrapper), `sfx_dma` (descriptor-driven, FIFO-decoupled read/write, tested with FIFO-depth-forced backpressure). Not built: `sfx_global_buffer`, `sfx_weight_buffer`/`sfx_activation_buffer`/`sfx_output_buffer` as distinct modules (the GEMM controller uses three plain `sfx_sram_interface` instances directly instead), multi-bank/alignment/bank-conflict modelling |
| 7 | AI dataflow engine | **PARTIAL** | `sfx_gemm_controller`'s FSM *is* a weight-stationary scheduler (decides load/stream/writeback ordering), but there is no standalone `sfx_scheduler`/`sfx_tile_controller`/`sfx_operand_router`/`sfx_reduction_controller`, no overlap between tiles (each tile's load→stream→writeback is fully sequential), and no other dataflow modes (output/input/row-stationary, streaming) |
| 8 | Transformer acceleration | **NOT STARTED** | `rtl/attention/` is an empty scaffold directory. `architectures/transformer.yaml` validates against the schema and documents intended QKV/attention/softmax/LayerNorm parameters, all marked schema-DESCRIPTIVE; `generate-rtl` on it produces the same dense-GEMM top-level as any other architecture |
| 9 | Sparsity / AI-specific optimisation | **NOT STARTED** | `rtl/sparsity/` is an empty scaffold directory. `architectures/sparse.yaml` is schema-only, same caveat as Phase 8 |
| 10 | AI command processor | **NOT STARTED** | `rtl/command/` is an empty scaffold directory. `sfx_gemm_controller`'s own command interface (`cmd_valid/cmd_ready/cmd_m/cmd_n/cmd_k`) is a single fixed opcode ("do one GEMM"), not a general instruction stream/decoder |
| 11 | Vector/scalar AI engine | **NOT STARTED** | `rtl/vector/` is an empty scaffold directory |
| 12 | Special function hardware | **NOT STARTED** | No activation-function RTL exists. No error/range/latency/resource analysis has been done because there is nothing to analyse yet |
| 13 | Multi-core AI accelerator | **NOT STARTED** | `rtl/scheduler/` is an empty scaffold directory. `architectures/multicluster.yaml`'s `compute.clusters` field is schema-DESCRIPTIVE only — `generate-rtl` always produces exactly one tensor core |
| 14 | On-chip network | **NOT STARTED** | `rtl/noc/` is an empty scaffold directory. `architectures/multicluster.yaml`'s `interconnect.topology: mesh` is schema-DESCRIPTIVE only |
| 15 | SilicaFlux top-level AI chip (SFX-AI-CORE) | **NOT STARTED** | No host/command-interface/NoC/multi-cluster top-level exists. `rtl/top/` is an empty scaffold directory. What *does* exist is a single-tensor-core "GEMM engine" top (`sfx_gemm_controller` + the per-architecture generated wrapper), which is a real, working, much smaller thing than SFX-AI-CORE |
| 16 | Python synthetic laboratory | **PARTIAL** | Built: bit-accurate `wrap_signed`/`saturate_signed`/`mac_int` (`python/models/datatypes.py`), tiled GEMM golden model (`python/models/gemm.py`), affine quantize/dequantize (PYTHON-MODEL-ONLY). Not built: attention reference model, standalone memory/bandwidth/latency models, workload generator |
| 17 | Python ↔ SystemVerilog verification | **DONE** | `python/verification/bridge.py` + `tb/integration/tb_sfx_gemm_vectors.sv`: real `$readmemh`/`$writememh`-based RTL↔Python bridge, directed + boundary cases, machine-readable JSON results (`{"test", "status", "cycles", "mismatches", ...}`) — this bridge is what actually caught the width bug described in `docs/TOOLING.md` |
| 18 | SystemVerilog assertions | **PARTIAL** | Concurrent SVA (`assert property`, `disable iff`, `\|->`/`\|=>`) is **not runnable** in this repo's regression simulator, Icarus Verilog 12.0 ("sorry: concurrent_assertion_item not supported") — see `docs/TOOLING.md`. Every module that would use them (`sfx_fifo`, `sfx_skid_buffer`, `sfx_stream_if`, `sfx_dma`, `sfx_gemm_controller`) instead carries hand-written **immediate assertions** driven off explicit shadow registers, which *do* run in every regression and did catch real bugs during development. `assertions/sfx_fifo_assertions.sva`, `assertions/sfx_skid_buffer_assertions.sva`, and `assertions/sfx_stream_if_assertions.sva` hold the "authoritative" concurrent-SVA form of the same invariants for a capable tool (Questa/VCS/JasperGold/...) — written, but **never actually executed by anything in this repository**, since no such tool is available here; do not mistake their presence for evidence they've been run. `sfx_dma`/`sfx_gemm_controller` have no `.sva` counterpart yet (only the immediate-assertion form) |
| 19 | Functional coverage | **NOT STARTED** | No coverage collection (opcode/datatype/tile/sparsity/etc.) exists. The directed+randomized testbenches provide real bug-finding power (see `docs/TOOLING.md`'s bug log) but do not report coverage metrics |
| 20 | RTL performance analysis | **PARTIAL** | Real per-run cycle counts from actual simulation (`sfx-ai benchmark`, labelled RTL SIMULATION) and a closed-form cycle estimator (`sfx-ai optimise`, labelled ANALYTICAL) exist. MAC utilisation is derived from real cycle counts. No memory-bandwidth/SRAM-traffic/DMA-traffic/NoC-traffic/stall-cycle/pipeline-bubble instrumentation exists beyond the whole-command cycle count |
| 21 | Design-space exploration | **PARTIAL** | `sfx-ai optimise` sweeps (rows, cols) and reports an ANALYTICAL cycles/MACs-per-cycle table for one workload shape. No Pareto-frontier generation, no sweep over SRAM size/datatype/pipeline depth, and — deliberately — no area/power estimation of any kind (this repo has no synthesis or technology data to ground such a number) |
| 22 | Synthesis-ready RTL | **PARTIAL** | All hand-written RTL avoids unsynthesizable constructs, uses synchronous reset, has no accidental latches, and separates `rtl/`/`tb/`/`assertions/`/`python/`/`silicaflux/` cleanly. It has never actually been run through a synthesis tool (no Yosys/Vivado/DC flow exists in this repo) — "synthesis-ready" is a design discipline claim, not a verified-by-synthesis claim |
| 23 | Formal verification | **NOT STARTED** | No formal tool (SymbiYosys, JasperGold, ...) is used anywhere in this repository |
| 24 | Reference AI architectures | **DONE** (as architecture YAML + generated RTL) | `architectures/{tiny,tensor16,tensor32,transformer,sparse,multicluster}.yaml` all validate, generate RTL, and (transformer/sparse/multicluster's tensor-core subset) pass real RTL simulation via `sfx-ai verify` — but transformer/sparse/multicluster's namesake features (attention, sparse decode, multi-cluster/NoC) are schema-only, per Phases 8/9/13/14 above |
| 25 | Machine-readable hardware description | **DONE** | `silicaflux/schema/architecture.py` (Pydantic, JSON-Schema-exportable), every field marked WIRED or DESCRIPTIVE against what `rtlgen.py` actually consumes |
| 26 | RTL generation | **DONE** (for the tensor-core/GEMM subset) | `silicaflux/compiler/rtlgen.py` generates a parameter header + a thin top-level composition over the hand-written `sfx_gemm_controller` — deliberately does *not* generate bulk PE/MAC/FIFO RTL, per the brief's own "prefer reusable primitives + generated configuration" guidance |
| 27 | Project structure | **DONE** | Matches the brief's tree (see repository root) |
| 28 | Command-line interface | **DONE** | `sfx-ai validate/compile/generate-rtl/simulate/verify/benchmark/optimise/report`, all real (see table above for which commands run RTL vs. analytical-only) |
| 29 | Hardware development workflow | **PARTIAL** | Steps 1-9 of the 13-step workflow (define → validate → compile → generate RTL → generate vectors → simulate → compare vs. golden → run assertions → collect coverage) work through step 7; step 8 (assertions) runs the immediate-assertion subset (see Phase 18); step 9 (coverage) is not implemented (Phase 19). Steps 10-13 (synthesis → timing/area analysis → feed back → explore variants) do not exist (Phases 21-23) |
| 30 | Final objective (architecture → RTL → testbench → golden model → verification → synthesis) | **PARTIAL** | The full loop *does* run, real, end to end — for one workload (dense INT8 GEMM) and one hardware shape (a single weight-stationary systolic tensor core + DMA). Synthesis is the one link in that diagram not built anywhere in this repository |

## What "first implementation target" (STEP 1-20) actually covers

The brief's own incremental build order (STEP 1 through STEP 20) is followed
literally for STEP 1-10 in this milestone, each with a real testbench:

| Step | Item | Status |
|---|---|---|
| 1 | SystemVerilog infrastructure | **DONE** |
| 2 | PE | **DONE** |
| 3 | MAC | **DONE** |
| 4 | 4×4 systolic array | **DONE** (as a specific instantiation of the parameterized array) |
| 5 | 16×16 parameterised systolic array | **DONE** |
| 6 | SRAM interfaces | **DONE** |
| 7 | DMA | **DONE** |
| 8 | GEMM controller | **DONE** |
| 9 | Python golden model | **DONE** |
| 10 | RTL ↔ Python verification | **DONE** |
| 11 | Vector engine | NOT STARTED |
| 12 | Command processor | NOT STARTED (beyond the GEMM controller's own single-opcode command) |
| 13 | Transformer primitives | NOT STARTED |
| 14 | NoC | NOT STARTED |
| 15 | Multi-cluster accelerator | NOT STARTED |
| 16 | SilicaFlux architecture compiler | **DONE** |
| 17 | RTL generator | **DONE** (parameter+top-level scope, see Phase 26) |
| 18 | Design-space explorer | **PARTIAL** (ANALYTICAL cycle sweep only) |
| 19 | Synthesis integration | NOT STARTED |
| 20 | Complete SFX-AI reference chip | NOT STARTED |

This is a deliberate scope decision, not an oversight: the brief itself says
"Do not attempt to implement the entire platform simultaneously" and "Do not
merely describe the architecture. Actually create..." — this repository
prioritizes a real, deeply-verified STEP 1-10 core (including catching and
fixing several genuine RTL and testbench bugs along the way — see
`docs/TOOLING.md`) over a superficial pass across all 20 steps.
