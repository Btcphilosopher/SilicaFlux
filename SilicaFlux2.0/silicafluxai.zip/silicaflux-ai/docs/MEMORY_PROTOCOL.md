# Memory and streaming protocol conventions

Every point-to-point connection in this repository's RTL uses one of two
protocols, applied consistently so every module's timing assumptions are
predictable from its port names alone.

## Valid/ready streaming (`sfx_stream_if`, and the loose-signal equivalent
used at most module boundaries: `*_valid`/`*_ready`/`*_data`)

- A transfer happens on a clock edge **iff `valid && ready`** on that edge.
- The producer must **not retract `valid`**, and must not change the
  accompanying data, while `valid && !ready` (a stalled transfer). Every
  producer testbench in this repo (`tb_sfx_fifo.sv`, `tb_sfx_skid_buffer.sv`,
  ...) enforces this in its own stimulus generation, and every consumer
  module (`sfx_fifo`, `sfx_skid_buffer`, `sfx_stream_if`) asserts it on its
  input as an immediate assertion (see `docs/TOOLING.md` for why immediate,
  not concurrent, assertions).
- The consumer's `ready` **may change freely** on any cycle, including
  depending combinationally on `valid`. `valid` must **never**
  combinationally depend on `ready` — that would create a combinational
  handshake loop across the module boundary.
- `last` (where present) marks the final beat of a burst/packet; its
  meaning (e.g. "last row of a tile") is defined by the module pair using
  it, not by the protocol itself.

A command/response pair (`cmd_valid/cmd_ready/...`, `done_valid/done_ready`)
is just this protocol used for a single-beat handshake — no special-casing.
`sfx_dma.sv` and `sfx_gemm_controller.sv` both use exactly this shape for
their command interfaces, and only accept a new command while idle
(`cmd_ready == (state == IDLE)`) — see `docs/TOOLING.md`'s bug #6 for a
testbench mistake this asymmetry (busy is a *level*, not a one-shot
"just accepted" pulse) once caused.

## SRAM protocol (`sfx_sram_interface`)

- Single port, one address bus shared between read and write:
  `en` qualifies the request, `we` selects write (1) vs. read (0).
- **Write**: on `en && we`, for each byte `i` where `wstrb[i]` is set,
  `mem[addr][8*i +: 8] <= wdata[8*i +: 8]`. This is a **masked write**, not
  a read-modify-write merge through the read port — bytes with
  `wstrb[i]=0` are simply left untouched.
- **Read**: on `en && !we`, `rdata <= mem[addr]`, visible the cycle *after*
  the request, with `rvalid` pulsing exactly one cycle later to mark it.
  **There is no combinational (0-latency) read mode** — real SRAM/BRAM
  macros don't have one, and this module is written to teach downstream
  logic the timing it will actually need to handle in a real design.
- A write and a read cannot both be issued the same cycle (there is one
  `addr`/`en`/`we` per instance). A caller needing concurrent read+write
  bandwidth must arbitrate or instantiate two SRAMs — `sfx_arbiter` is a
  documented, not-yet-built, roadmap module for this (see
  `docs/PHASE_STATUS.md`, Phase 2).
- `mem` is **deliberately not reset** — real SRAM/BRAM macros power up
  with whatever the process leaves them in, not a defined value, and this
  module should not teach a habit (relying on power-on-zero memory) that
  silently breaks on real silicon or synthesis. Simulation-only preload/
  readback uses the hierarchical backdoor `<instance>.mem[addr]` directly
  (see `tb/unit/tb_sfx_sram_interface.sv`, `tb/unit/tb_sfx_dma.sv`,
  `tb/integration/tb_sfx_gemm_controller.sv`, and
  `python/verification/vectors.py` for the Python-side equivalent via
  `$readmemh`/`$writememh`) — this is explicitly a simulation convenience,
  not part of the module's synthesizable interface.

`sfx_dma.sv` is built directly on top of two `sfx_sram_interface`-shaped
ports (one read-only "source", one write-only "destination"), decoupled
through an `sfx_fifo` so the SRAM's 1-cycle read latency and any
backpressure on the destination side don't need to be reasoned about
together — see that module's header for the full architecture.
