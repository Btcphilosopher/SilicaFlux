# Timing and reset discipline

## Clocking

Every module in this repository is **single-clock-domain**: one `clk`
input, no internal clock gating or multiplication. There is no
clock-domain-crossing logic anywhere in this repository — every module
implicitly assumes its inputs come from the same clock domain it runs in.
A design that needs multiple clock domains (e.g. a DMA bridging to a
slower external memory clock) would need CDC synchronizers this repo does
not provide; that is a documented gap (see `docs/PHASE_STATUS.md`), not an
implicit claim that any of this RTL is CDC-safe.

## Reset

- Reset (`rst_n`) is **active-low and synchronous** everywhere. Every
  `always_ff` in this repository samples `rst_n` on the same clock edge as
  its data, e.g.:

  ```systemverilog
  always_ff @(posedge clk) begin
      if (!rst_n) q <= RESET_VALUE;
      else if (en) q <= d;
  end
  ```

- `rst_n` must already be **synchronized to `clk`** by the caller (e.g. via
  a reset synchronizer at the clock domain boundary) before it reaches any
  module here — no module performs asynchronous reset or its own
  synchronization.
- **Not everything is reset**, and this is deliberate, not an oversight:
  - `sfx_sram_interface.mem` and `sfx_accumulator.mem` are **not** reset.
    Real SRAM/BRAM macros and register files don't power up to a defined
    value on real silicon, and giving them one in RTL would teach
    downstream logic to (incorrectly) rely on it. Every caller either
    writes before reading (the normal case) or, in simulation, preloads
    explicitly via the documented hierarchical backdoor
    (`<instance>.mem[addr] = ...`, see `docs/MEMORY_PROTOCOL.md`).
  - `sfx_pipeline_reg`'s data shift register (as opposed to its `valid`
    shift register) is not reset — only `valid_out` is guaranteed low
    after reset; stale data sitting behind a low `valid` is harmless and
    resetting it would be pure overhead.
- Every register that *does* need a defined reset value states it
  explicitly (`sfx_register`'s `RESET_VALUE` parameter, or a literal `'0`/
  `1'b0` in the reset branch) rather than relying on simulator defaults.

## Latches

No module in this repository contains an unintended latch: every
combinational `always_comb`/`assign` in the RTL has a complete branch
covering all cases it's sensitized to (default assignments at the top of
`always_comb` blocks where a `case`/`if` doesn't otherwise cover every
input combination), and every stateful element is an explicit `always_ff`.

## Pipeline latency documentation

Every module with more than one cycle of latency documents that latency
explicitly in its header rather than leaving it implicit:

- `sfx_sram_interface`: 1 cycle (registered read).
- `sfx_pe`/`sfx_systolic_array`: see `docs/ARCHITECTURE.md`'s systolic
  timing section — `T = ROWS + c + m` cycles from wave 0's presentation to
  column `c`'s result for wave `m`.
- `sfx_pipeline_reg`: exactly `STAGES` cycles, by construction (a plain
  shift register) — used throughout `sfx_gemm_controller.sv` specifically
  *because* its latency is trivially provable rather than needing separate
  verification each time it's instantiated.
- `sfx_dma`: variable, bounded by `FIFO_DEPTH` outstanding reads plus
  whatever backpressure the destination SRAM applies.
- `sfx_gemm_controller`: see `docs/ARCHITECTURE.md`'s tiling section; real
  cycle counts for specific shapes come from actual RTL simulation
  (`sfx-ai benchmark`, always labelled RTL SIMULATION — never estimated),
  or from `sfx-ai optimise`'s explicitly-labelled ANALYTICAL closed-form
  model.
