# Datatypes, precision, and numerical semantics

## What's implemented in RTL today

Every compute datapath in this repository (`sfx_mac`, `sfx_pe`,
`sfx_systolic_array`, `sfx_gemm_controller`) is a **plain signed integer**
datapath. INT4/INT8/INT16 are not separate hardware "modes" — they are
simply narrower `DATA_WIDTH` parameters on the same multiply-accumulate
logic (`rtl/arithmetic/sfx_mac.sv`'s `a`/`b` ports, `sfx_pe`'s activation/
weight ports). There is no floating-point (BF16/FP16/FP32) arithmetic
anywhere in this repository's RTL. `silicaflux/schema/architecture.py`
enforces this: `compute.tensor.precision` only accepts `int4`/`int8`/
`int16`, and rejects `bf16`/`fp16`/`fp32` with an explicit error naming why
(no floating-point PE exists to generate).

## Two different overflow behaviours, used deliberately in different places

- **Wraparound (two's-complement, silent).** `sfx_mac.sv`'s accumulator
  and `sfx_accumulator.sv`'s register file both do plain
  `acc <= acc + product`/`data` on a fixed-width signed register — exactly
  what SystemVerilog does on overflow, and what real hardware does at
  this point in a datapath. This is intentional, not an oversight: within
  one systolic pass (up to `ROWS` terms), the accumulator width is sized
  so this never actually overflows for any configuration this project
  targets (INT8×INT8 product magnitude ≤ 16384, `ROWS` realistically ≤ a
  few hundred, `ACC_WIDTH=32` gives enormous headroom) — see
  `sfx_mac.sv`'s header for the exact reasoning and
  `rtl/gemm/sfx_gemm_controller.sv`'s header for why the *inter*-tile
  accumulation (across `kt` passes, in `sfx_accumulator`) also relies on
  each individual K-tile pass not overflowing.
  `python/models/datatypes.py::wrap_signed` and
  `python/models/datatypes.py::mac_int` reproduce this wraparound exactly,
  bit-accurately, including in the deliberately-constructed overflow test
  in `tests/test_models.py::TestMacInt::test_wraps_on_overflow` — this is
  what "bit-accurate golden model" means in this repository: not just
  "gets the right answer for normal inputs," but reproduces the same wrong
  answer hardware would give when actually pushed into overflow.
- **Saturation (clamped, explicit).** `sfx_saturate.sv` is a separate,
  purely combinational module: given a wide signed value, it clamps to the
  narrower output's representable range and reports whether it did
  (`saturated` output). This is used where narrowing to a smaller output
  width is the intent (a future requantization stage narrowing an INT32
  accumulator to an INT8 output, for instance) — nothing in this
  repository's current RTL calls it yet (the GEMM controller's output,
  `C_sram`, stays at the full `ACC_WIDTH`; see below), but it is built and
  independently tested (`tb/unit/tb_sfx_saturate.sv`, including an
  exhaustive sweep of every representable INT8 value into INT4) precisely
  because the eventual requantization stage will need it.
  `python/models/datatypes.py::saturate_signed` mirrors it exactly.

**These are not interchangeable** — `2^31 mod 2^32` is not the same value
as `clamp(2^31, INT32_MIN, INT32_MAX)`, and this repository never conflates
them: wraparound only where hardware actually wraps (accumulation within a
fixed-width register), saturation only where a value is being deliberately
narrowed.

## Why `sfx_gemm_controller`'s output is INT32, not requantized

The GEMM controller's `C_sram` stores the raw accumulator value at
`ACC_WIDTH` bits (32 by default) — there is no requantization/activation
step inside it. This matches the project's own dataflow model
(`Tensor → Tile → Buffer → DMA → Compute → Reduction → Activation →
Writeback`): the GEMM controller covers up through *Reduction*.
*Activation* (and any requantization back down to INT8) is explicitly
out of scope for this module (see `docs/PHASE_STATUS.md`, Phase 3/12) —
not because it was forgotten, but because it belongs in a separate,
not-yet-built activation/requantization unit downstream of this one, and
building that unit means giving it its own real, tested implementation
rather than bolting an unverified narrowing step onto an already-complex
controller.

## Quantization reference model (Python-only, not connected to RTL)

`python/models/datatypes.py::quantize_affine`/`dequantize_affine` implement
standard affine (scale + zero-point) quantization —
`q = clamp(round(x/scale) + zero_point)`. This is explicitly marked
**PYTHON-MODEL-ONLY** in its docstring: no RTL module in this repository
implements requantization yet. It exists to document the intended
numerical convention for that future RTL, and is tested for its own
internal consistency (round-trip error bounded by half a quantization
step, correct saturation at the representable range) — never claimed as
verified *against* RTL, because there is no RTL to verify it against.
