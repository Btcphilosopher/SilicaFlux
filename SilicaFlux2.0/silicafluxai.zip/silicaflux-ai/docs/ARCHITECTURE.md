# SilicaFlux-AI — Architecture

This document describes what is actually built: a single weight-stationary
INT8 systolic tensor core, a tiled GEMM controller around it, DMA, and the
SilicaFlux configuration→RTL compiler that generates a top-level wrapper
for it. For what is *not* built yet (attention, sparsity, NoC,
multi-cluster, vector engine, command processor), see
`docs/PHASE_STATUS.md` — this document does not repeat those caveats
inline; assume anything described here as present has a passing test
referenced in that file.

## Hierarchy (as actually implemented)

```
architecture.yaml (silicaflux/schema/architecture.py)
        |  silicaflux/parser/loader.py (validate)
        v
silicaflux/compiler/rtlgen.py
        |  generates: <name>_params.svh, <name>_top.sv
        v
<name>_top.sv  --instantiates-->  rtl/gemm/sfx_gemm_controller.sv
                                          |
                        +-----------------+-----------------+
                        |                 |                 |
                   rtl/memory/       rtl/tensor/        rtl/arithmetic/
                sfx_sram_interface  sfx_systolic_array   sfx_accumulator
                  (A, B, C SRAMs)    (built from sfx_pe)  (one per column)
```

`rtl/dma/sfx_dma.sv` is a separately-tested, standalone module (see
`tb/unit/tb_sfx_dma.sv`) that moves data between two `sfx_sram_interface`
ports; it is not yet wired into the GEMM controller's own A/B/C SRAMs in
this milestone (see `docs/PHASE_STATUS.md`, Phase 6) — a host or testbench
preloads/reads those SRAMs directly today (see "SRAM layout convention"
below).

## Systolic array dataflow and timing

`rtl/tensor/sfx_systolic_array.sv` is a ROWS×COLS grid of `sfx_pe`
instances: weight `W[r][c]` sits stationary at `PE(r,c)`; activations enter
each row's west boundary and flow east; partial sums enter each column's
north boundary and flow south, accumulating one `PE`'s multiply-add per
row hop.

### Weight loading

Each column has an independent `weight_in` lane. To end up with `PE(r,c)`
holding `W[r][c]`, feed column `c`'s ROWS values in **reverse row order**
(row `ROWS-1`'s weight first, row 0's last) over exactly ROWS consecutive
`load_mode=1` cycles. This works because each PE's weight register is a
plain one-stage shift element: `weight_out` is a *combinational* tap of the
same register `weight_reg` that captures `weight_in` on each load cycle
(see `sfx_pe.sv`'s header for why an earlier, separately-registered
`weight_out` gave 2 cycles of delay per row instead of 1, and broke this
scheme silently). A worked ROWS=4 example: feeding `W[3][c], W[2][c],
W[1][c], W[0][c]` in that order over 4 cycles leaves `PE(0,c)` holding
`W[0][c]` (captured last, never shifted further) and `PE(3,c)` holding
`W[3][c]` (captured first, shifted 3 times).

### Compute skew

For `PE(r,c)`'s product to combine the *matching* activation and
partial-sum term, activation row `r` must be injected `r` cycles later
than row 0 (a "systolic skew"). Concretely, for an M-row streaming pass
where wave `m` is the `m`-th activation vector: row `r` should receive wave
`m` at local time `t = r + m`. `rtl/gemm/sfx_gemm_controller.sv` implements
this with one `sfx_pipeline_reg` per row, `STAGES = r`, rather than hand-
tracking cycle offsets in the controller's own arithmetic.

### When does a result become valid?

Derived and empirically validated (100% of expected results checked, see
`tb/unit/tb_sfx_systolic_array.sv`) for a `ROWS`×`COLS` array: column `c`'s
result for wave `m` becomes valid at cycle **T = ROWS + c + m**, counting
from the cycle wave 0 is first presented at row 0's boundary. Worked
`ROWS=2` example: wave `m=0`'s row-0 contribution is used at `PE(0,0)` at
local time 0 and becomes visible to `PE(1,0)` one cycle later; `PE(1,0)`
also receives row 1's own wave-0 value at that same cycle (fed with 1
cycle of skew) and produces the combined result one cycle after that —
`T = 2 = ROWS + 0 + 0`, matching the formula.

`sfx_gemm_controller.sv` does **not** re-derive this formula against a raw
cycle counter in its own control logic (a fragile pattern that produced
several of the bugs logged in `docs/TOOLING.md`). Instead it threads a
wave-index "tag" through one `sfx_pipeline_reg` per column with
`STAGES = ROWS + c`, injected at the exact cycle each wave's data reaches
the array's row-0 boundary — the tag pipeline is latency-matched to the
real datapath by construction, not by arithmetic that has to be
independently re-verified for every `ROWS`/`COLS`/`M` combination.

## GEMM tiling

```
DMA / host preload (external)
      |
  A_sram, B_sram (pre-tiled, see layout below)
      |
  for nt in 0..ceil(N/COLS)-1:
      for kt in 0..ceil(K/ROWS)-1:
          load weight tile (ROWS cycles, zero-padded past K or N)
          stream all M waves through the array (skewed, see above)
          add each result into this column's sfx_accumulator
              (clear on kt==0, accumulate on kt>0)
      drain this nt's COLS accumulators (each MAX_M entries deep) into
      C_sram, in natural row-major (m*N + n) order
      |
  C_sram (host/DMA reads back)
```

M is handled in a **single pass up to `MAX_M`** — there is no separate
M-tile loop (a real, documented scope decision, not an oversight; see
`sfx_gemm_controller.sv`'s header). N and K tiling is exact for any
M/N/K ≤ MAX_M/MAX_N/MAX_K, including values that are not multiples of
COLS/ROWS (Phase 5's requirement) — partial tiles are handled by
explicitly forcing the out-of-range weight/activation lanes to zero, never
by relying on SRAM content happening to be zero there.

### Why an external accumulator, not psum feedback

`sfx_systolic_array` exposes a `psum_in` boundary that *could* chain
K-tile passes by feeding a previous pass's result back in — but that needs
re-injecting each element's partial sum at the exact skewed cycle its wave
re-arrives, which is as much machinery as the activation skew network
itself. Instead, each column's `sfx_accumulator` (a small addressable
register file, not an SRAM macro) reduces across `kt` passes by simple
add-or-clear as `psum_out` arrives, addressed by wave index. This is a
deliberate scope decision for this reference controller — chaining
`psum_in` directly is a documented roadmap item, not a limitation of
`sfx_systolic_array` itself.

## SRAM layout convention

The GEMM controller's three internal SRAMs (via `sfx_sram_interface`) use
this pre-tiled layout, which a host/DMA/test harness must produce:

- **A_sram**: `DATA_WIDTH = ROWS × DATA_WIDTH_elem` (one word = a full
  systolic row's worth of one K-tile's activations). `addr = m*KTILES_MAX + kt`.
- **B_sram**: `DATA_WIDTH = COLS × DATA_WIDTH_elem`. `addr = (nt*KTILES_MAX + kt)*ROWS + rr`,
  where `rr` is which array row that word loads.
- **C_sram**: `DATA_WIDTH = ACC_WIDTH`, natural row-major `addr = m*N + n`
  using the command's *actual* runtime `N` (so a host reads back a plain
  M×N matrix, no tile padding baked in).

`python/verification/vectors.py` and
`tb/integration/tb_sfx_gemm_controller.sv`'s `preload` task are two
independent implementations of this same convention (one Python, one SV) —
both exist because a bridge that shares its layout code with the RTL it's
checking can't catch a layout bug shared between them.

## Protocol conventions

See `docs/MEMORY_PROTOCOL.md` for the valid/ready and SRAM protocols, and
`docs/TIMING_AND_RESET.md` for clocking/reset discipline. See
`docs/DATATYPES_AND_PRECISION.md` for numerical semantics (signed
wraparound vs. saturation, where each is used).
