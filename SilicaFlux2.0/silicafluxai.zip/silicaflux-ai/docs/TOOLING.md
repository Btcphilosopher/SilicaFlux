# Tooling notes

This repository's default regression flow uses **Icarus Verilog** (`iverilog`
12.0 / `vvp`) — an open-source, freely installable simulator, chosen so
`scripts/run_unit_tests.sh` and `pytest` work in any environment without a
commercial license. It is not a full IEEE 1800-2017 implementation. This
page documents where that matters, and — because several of these
limitations were only discovered by hitting them mid-development — the real
bugs (in both RTL and testbenches) that turned up along the way. Treat the
bug log as evidence for the phase-status claims in `docs/PHASE_STATUS.md`,
not as trivia: a project that claims "verified" needs to show what its
verification actually caught.

## Known Icarus Verilog 12.0 limitations hit in this repository

- **No concurrent assertions.** `assert property (@(posedge clk) ...)`,
  `disable iff`, and the `|->`/`|=>` operators all fail with `sorry:
  concurrent_assertion_item not supported`, even in the simplest form with
  no temporal operators at all. Every module in this repo that needs a
  protocol invariant (`sfx_fifo`, `sfx_skid_buffer`, `sfx_stream_if`,
  `sfx_dma`, `sfx_gemm_controller`) instead uses **immediate assertions**
  (`assert (expr) else $error(...)` inside `always_ff`) driven off explicit
  one-cycle shadow registers that reproduce the same `disable iff`/`|=>`
  timing by hand. These run in every regression and did catch real bugs.
  `assertions/*.sva` holds the "authoritative" concurrent-SVA form of the
  same invariants for `sfx_fifo`/`sfx_skid_buffer`/`sfx_stream_if`, for use
  with a capable tool -- but nothing in this repo's own toolchain can run
  them; see `docs/PHASE_STATUS.md`'s Phase 18 entry for exactly what that
  does and doesn't mean.
- **Unpacked array ports do not propagate to the caller.** A module output
  port declared as an unpacked array (`output logic [W-1:0] out [N]`)
  elaborates and even *simulates internally* without error, but the
  parent-scope signal connected to it reads back `x` forever — confirmed
  with a minimal two-module repro before assuming it was a design bug.
  `rtl/tensor/sfx_systolic_array.sv`'s boundary ports were originally
  unpacked arrays and were changed to flattened packed vectors
  (`logic [N*W-1:0]`, unpacked internally with `[i*W +: W]`) specifically
  because of this — see that file's header for the full rationale. This is
  also, independently, a more broadly synthesis-tool-portable convention.
- **`automatic` on a variable declaration inside a plain (non-automatic)
  `initial`/`begin...end` block** fails with `sorry: Overriding the default
  variable lifetime is not yet supported`. Declare the variable without the
  keyword instead (acceptable here since these testbenches are
  single-threaded, not re-entrant).
- **`ref` ports with unpacked-array dimensions** are not supported
  (`sorry: Reference ports not supported yet`) — module-level (not
  task-argument) scratch arrays are used instead where a testbench needs
  to build multiple golden matrices across calls (see
  `tb/integration/tb_sfx_gemm_controller.sv`).
- **A ternary between two enum values, assigned directly**
  (`state_n = cond ? ST_A : ST_B;`) needs `error: This assignment requires
  an explicit cast.` — rewritten as an explicit `if/else`.
- **`$writememh` prefixes its dump with an address comment** (`// 0x...`)
  rather than repeating an address per line; `python/verification/vectors.py`'s
  `read_c_sram` filters comment/blank lines before indexing.
- **`unique case` is accepted but not enforced** — `vvp.tgt sorry: Case
  unique/unique0 qualities are ignored.` This is a warning, not a
  correctness issue (the `case` still simulates as a plain `case`); the
  `unique` qualifier is kept in the source for documentation/lint value
  and because it costs nothing when synthesized by a tool that does honor
  it.

None of the above are workarounds for RTL bugs — every one was confirmed
with an isolated minimal repro (see the two-module unpacked-array-port test
built while debugging `sfx_systolic_array`) before changing any design
code.

## Real bugs this project's own testbenches caught

Kept here, with root cause and fix, because a "verified" claim is only as
good as the list of things verification actually found. All were found and
fixed during this repository's own development, before any test was
reported as passing.

1. **`sfx_fifo`'s registered-output mode under-reported occupancy.** The
   `REGISTERED_OUTPUT=1` prefetch stage adds one extra element of storage
   beyond `DEPTH` (an item can sit in the output "peek" register *and*
   the backing array can independently be full), but `count`/`almost_full`
   were computed from the backing array's pointers alone. Fixed by
   including the prefetch register in `count`; documented as
   "effective capacity is DEPTH+1 in this mode" in the module header.

2. **Testbench sampling one cycle late is not the same bug as sampling one
   cycle early — both showed up.** `tb_sfx_fifo.sv`'s directed drain loop
   checked `rd_data`/`rd_valid` *after* crossing the clock edge that
   consumed them, so it observed the *next* prefetched item instead of the
   one that had just fired. Separately, `random_backpressure`'s "was this
   write stalled" check re-derived `wr_ready` *after* crossing an edge
   (post-update), which raced against unrelated activity on the other port
   (e.g. a concurrent read draining a slot a stalled write was waiting on)
   — this bug was **seed-dependent**: it passed by chance on one random
   seed and failed on others. The fix in both cases was the same
   discipline: compute a "will this transfer fire / was it held" flag from
   a *single, consistently-timed* sample taken *before* crossing the edge
   it predicts, never re-derived from a fresh signal read after an edge
   has already updated the state that signal depends on. The same fix was
   then needed in `tb_sfx_skid_buffer.sv`'s equivalent logic — same root
   cause, different file.

3. **`sfx_pe`'s weight shift register was double-registered.** The first
   version stored the *previous* weight value in `weight_out` (registered
   separately from `weight_reg`), giving each row hop 2 cycles of delay
   instead of 1. Every row below row 0 loaded incorrectly, silently,
   because the PE-level unit test only checked one PE in isolation and
   never noticed the row-to-row timing was wrong. Only
   `tb_sfx_systolic_array.sv` — a *different testbench at a different
   level* — caught it, by comparing full-array output against a golden
   matmul. Fixed by making `weight_out` a combinational tap of the single
   `weight_reg` (`assign weight_out = weight_reg;`), giving exactly 1
   cycle of delay per row as the loading scheme requires. This is the case
   for why this repo has both a PE-level *and* an array-level test, not
   just the smaller one.

4. **`sfx_gemm_controller`'s weight-load padding gate read a signal one
   cycle too early relative to the SRAM data it was gating.**
   `load_row_is_padding` was computed combinationally from the *current*
   cycle's `load_rr` counter, but the B_sram data arriving that same cycle
   was requested with the *previous* cycle's `load_rr` (1-cycle SRAM read
   latency). At the boundary cycle this also silently underflowed
   (`ROWS-1-load_cycle_r` computed for an out-of-range `load_cycle_r`,
   wrapping in the unsigned field). Every case with a partial K-tile
   failed; cases with `K` an exact multiple of `ROWS` happened to pass
   because they never exercised the padding path at all. Fixed by
   latching the padding decision at request-issue time
   (`if (b_en) load_row_is_padding_d <= load_row_is_padding;`) so the
   value consumed always matches the request that produced the
   currently-arriving response.

5. **`sfx_gemm_controller`'s N/K value registers were one bit too narrow —
   a `$clog2`-of-an-exact-power-of-two trap.** `n_r`/`k_r` were sized with
   `$clog2(MAX_N)`/`$clog2(MAX_K)`, which is correct for an *index* into
   `0..MAX_N-1` but one bit short of holding the *value* `MAX_N` itself
   when `MAX_N` is an exact power of two (`$clog2(16) == 4`, and 4 bits
   cannot represent 16). `N=MAX_N` (or `K=MAX_K`) silently truncated to 0.
   Depending on which dimension truncated, the visible symptom was
   different: `K=0` made every weight/activation read as padding, so the
   whole result was defined-but-wrong (all zeros); `N=0` made the
   writeback loop's own completion condition true on its very first cycle,
   so most of `C_sram` was never written at all and read back as `x`. Both
   symptoms trace to the same one-line width bug. **This is the bug that
   most directly demonstrates why the RTL↔Python bridge
   (`python/verification/bridge.py`) exists as a *second, independent*
   check alongside the hand-written SV testbench
   (`tb/integration/tb_sfx_gemm_controller.sv`)**: the directed SV test's
   own hand-picked dimensions never happened to hit exactly `N=MAX_N` or
   `K=MAX_K`, so it passed while this bug was live. The Python bridge's
   default suite includes cases at every dimension's compile-time maximum
   specifically because of this, and now both suites pass.

6. **A testbench polling loop couldn't tell "not yet accepted" from
   "already accepted, now busy."** Several places (`tb_sfx_dma.sv`,
   `tb_sfx_gemm_controller.sv`) originally waited for a command to be
   accepted with `while (!cmd_ready) @(negedge clk);`. `cmd_ready` is a
   plain `state == IDLE` level signal, not an acceptance pulse — it reads
   0 for the *entire rest of the transaction*, not just until acceptance.
   The loop would not exit until the whole operation (including its
   `done` handshake) completed and the engine returned to idle — at which
   point `cmd_valid` (never cleared, because the loop never got past its
   `while`) plus the now-1 `cmd_ready` looked exactly like a *second*,
   accidental command with the same fields, which got accepted too,
   forever. Since every real call site only issues a command when the
   engine is already idle (by construction — either right after reset or
   right after a previous command's `done` handshake completed), the fix
   was to delete the polling loop entirely: a single unconditional
   `@(negedge clk)` after driving `cmd_valid` is sufficient and correct.

The throughline across nearly all of these: **a registered/pipelined
signal's value is only meaningful at the specific cycle it was produced
for; sampling it one cycle before or after that point — in either the RTL
or the testbench driving it — silently reads the wrong thing rather than
raising an error.** Every fix above is some form of "compute the check from
a value at the moment it's actually valid, not from a fresh re-read after
time has moved on."
