"""
tests/test_cli.py

Exercises every `sfx-ai` subcommand through click's CliRunner (in-process,
no subprocess) against architectures/tiny.yaml -- the smallest reference
architecture, so this suite stays fast. simulate/verify/benchmark still
launch real Icarus Verilog runs (skipped if unavailable).
"""
from __future__ import annotations

import json
import shutil

import pytest
from click.testing import CliRunner

from silicaflux.cli import main

ICARUS_AVAILABLE = shutil.which("iverilog") is not None and shutil.which("vvp") is not None
needs_iverilog = pytest.mark.skipif(not ICARUS_AVAILABLE, reason="iverilog/vvp not on PATH")


@pytest.fixture()
def runner() -> CliRunner:
    return CliRunner()


def test_validate_ok(runner: CliRunner):
    result = runner.invoke(main, ["validate", "architectures/tiny.yaml"])
    assert result.exit_code == 0
    assert "SFX_TINY" in result.output


def test_validate_missing_file(runner: CliRunner):
    result = runner.invoke(main, ["validate", "architectures/does_not_exist.yaml"])
    assert result.exit_code != 0


def test_compile_prints_resolved_params(runner: CliRunner):
    result = runner.invoke(main, ["compile", "architectures/tensor16.yaml"])
    assert result.exit_code == 0
    assert "ROWS" in result.output and "16" in result.output


def test_compile_warns_on_descriptive_fields(runner: CliRunner):
    result = runner.invoke(main, ["compile", "architectures/transformer.yaml"])
    assert result.exit_code == 0
    assert "DESCRIPTIVE" in result.output


def test_generate_rtl(runner: CliRunner, tmp_path):
    out_dir = tmp_path / "gen"
    result = runner.invoke(main, ["generate-rtl", "architectures/tiny.yaml", "--out", str(out_dir)])
    assert result.exit_code == 0
    assert (out_dir / "sfx_tiny_top.sv").exists()
    assert (out_dir / "sfx_tiny_params.svh").exists()


@needs_iverilog
def test_simulate(runner: CliRunner, tmp_path):
    result = runner.invoke(main, ["simulate", "architectures/tiny.yaml", "--out", str(tmp_path)])
    assert result.exit_code == 0
    assert "PASS" in result.output


@needs_iverilog
def test_verify_writes_json(runner: CliRunner, tmp_path):
    json_path = tmp_path / "results.json"
    result = runner.invoke(main, [
        "verify", "architectures/tiny.yaml", "--out", str(tmp_path / "build"), "--json", str(json_path),
    ])
    assert result.exit_code == 0
    data = json.loads(json_path.read_text())
    assert len(data) >= 1
    assert all(r["status"] == "PASS" for r in data)


@needs_iverilog
def test_benchmark(runner: CliRunner):
    result = runner.invoke(main, ["benchmark", "architectures/tiny.yaml"])
    assert result.exit_code == 0
    assert "RTL SIMULATION" in result.output
    assert "MACs/cycle" in result.output


def test_optimise_is_labelled_analytical(runner: CliRunner):
    result = runner.invoke(main, ["optimise", "architectures/tiny.yaml"])
    assert result.exit_code == 0
    assert "[ANALYTICAL]" in result.output
    assert "Area/power are NOT estimated" in result.output


def test_report(runner: CliRunner, tmp_path):
    results_path = tmp_path / "r.json"
    results_path.write_text(json.dumps([{"test": "x", "status": "PASS", "cycles": 10, "mismatches": 0}]))
    result = runner.invoke(main, ["report", str(results_path)])
    assert result.exit_code == 0
    assert "1/1 passed" in result.output
