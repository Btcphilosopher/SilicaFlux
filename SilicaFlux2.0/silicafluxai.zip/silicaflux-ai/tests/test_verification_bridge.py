"""
tests/test_verification_bridge.py

pytest wrapper around python/verification/bridge.py: actually invokes Icarus
Verilog on rtl/gemm/sfx_gemm_controller.sv for a handful of directed cases
(including the M/N/K-at-compile-time-maximum boundary that once exposed a
real width bug, see docs/TOOLING.md) and checks the RTL output against the
Python golden model. Skipped (not faked as passing) if iverilog/vvp are not
on PATH, so this file behaves in CI environments without the simulator too.
"""
from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from python.verification.bridge import run_case

pytestmark = pytest.mark.skipif(
    shutil.which("iverilog") is None or shutil.which("vvp") is None,
    reason="iverilog/vvp not on PATH -- see docs/TOOLING.md",
)


@pytest.fixture(scope="module")
def build_dir(tmp_path_factory):
    return tmp_path_factory.mktemp("gemm_bridge_build")


@pytest.mark.parametrize(
    ("m", "n", "k", "seed"),
    [
        (4, 4, 4, 1001),
        (5, 6, 7, 1003),
        (1, 1, 1, 1004),
        (16, 16, 16, 1006),  # every dimension at the compile-time max simultaneously
        (16, 4, 4, 2001),
        (4, 16, 4, 2002),
        (4, 4, 16, 2003),
    ],
)
def test_gemm_rtl_matches_golden(build_dir: Path, m, n, k, seed):
    result = run_case(m, n, k, seed, build_dir=build_dir)
    assert result.status == "PASS", (
        f"{result.test}: {result.mismatches} mismatches, "
        f"samples={result.mismatch_samples}, detail={result.detail}"
    )
    assert result.cycles is not None and result.cycles > 0
