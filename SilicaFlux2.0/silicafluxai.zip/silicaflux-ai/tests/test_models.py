"""
tests/test_models.py

pytest coverage for python/models/*.py's own internal correctness (these do
NOT touch RTL simulation -- that cross-check lives in
python/verification/bridge.py and tests/test_verification_bridge.py).
"""
from __future__ import annotations

import numpy as np
import pytest

from python.models.datatypes import (
    dequantize_affine,
    from_unsigned_bits,
    mac_int,
    quantize_affine,
    saturate_signed,
    to_unsigned_bits,
    wrap_signed,
)
from python.models.gemm import gemm_reference, gemm_reference_fast


class TestWrapSigned:
    def test_in_range_values_unchanged(self):
        for v in (0, 1, -1, 127, -128):
            assert wrap_signed(v, 8) == v

    def test_positive_overflow_wraps(self):
        # 8-bit signed range is [-128, 127]; 128 wraps to -128
        assert wrap_signed(128, 8) == -128
        assert wrap_signed(255, 8) == -1
        assert wrap_signed(256, 8) == 0

    def test_negative_underflow_wraps(self):
        assert wrap_signed(-129, 8) == 127
        assert wrap_signed(-256, 8) == 0

    def test_32_bit_matches_numpy_int32_overflow(self):
        # Cross-check against numpy's own int32 wraparound as an
        # independent implementation of the same two's-complement rule.
        rng = np.random.default_rng(1234)
        for _ in range(200):
            v = int(rng.integers(-(2**40), 2**40))
            expected = int(np.int32(np.uint32(v & 0xFFFFFFFF)))
            assert wrap_signed(v, 32) == expected


class TestSaturateSigned:
    def test_in_range(self):
        v, sat = saturate_signed(100, 8)
        assert (v, sat) == (100, False)

    def test_positive_saturation(self):
        v, sat = saturate_signed(200, 8)
        assert (v, sat) == (127, True)

    def test_negative_saturation(self):
        v, sat = saturate_signed(-200, 8)
        assert (v, sat) == (-128, True)

    def test_boundary_values_do_not_saturate(self):
        assert saturate_signed(127, 8) == (127, False)
        assert saturate_signed(-128, 8) == (-128, False)


class TestMacInt:
    def test_clear_loads_fresh_product(self):
        assert mac_int(5, -3, acc=999, acc_width=32, clear=True) == -15

    def test_accumulates_when_not_cleared(self):
        acc = mac_int(5, -3, acc=0, acc_width=32, clear=True)
        acc = mac_int(7, 7, acc=acc, acc_width=32, clear=False)
        acc = mac_int(-8, -8, acc=acc, acc_width=32, clear=False)
        assert acc == -15 + 49 + 64

    def test_matches_rtl_extreme_int8_product(self):
        assert mac_int(-128, -128, acc=0, acc_width=32, clear=True) == 16384

    def test_wraps_on_overflow(self):
        # acc_width=8: 100 + 100 = 200, wraps to -56
        acc = mac_int(10, 10, acc=0, acc_width=8, clear=True)  # 100
        acc = mac_int(10, 10, acc=acc, acc_width=8, clear=False)  # 200 -> wraps
        assert acc == wrap_signed(200, 8)


class TestBitPatternRoundTrip:
    @pytest.mark.parametrize("width", [4, 8, 16, 32])
    def test_round_trip(self, width):
        lo = -(1 << (width - 1))
        hi = (1 << (width - 1)) - 1
        for v in (0, 1, -1, lo, hi, lo + 1, hi - 1):
            bits = to_unsigned_bits(v, width)
            assert 0 <= bits < (1 << width)
            assert from_unsigned_bits(bits, width) == v


class TestQuantizeDequantizeAffine:
    def test_round_trip_within_one_step(self):
        x = np.array([0.0, 1.0, -1.0, 2.5, -2.5], dtype=np.float64)
        scale = 0.5
        zero_point = 0
        q = quantize_affine(x, scale, zero_point, out_width=8)
        recon = dequantize_affine(q, scale, zero_point)
        # Rounding to the nearest quantization step means reconstruction
        # error is bounded by half a step.
        assert np.all(np.abs(recon - x) <= scale / 2 + 1e-9)

    def test_saturates_out_of_range(self):
        x = np.array([1000.0, -1000.0])
        q = quantize_affine(x, scale=1.0, zero_point=0, out_width=8)
        assert q[0] == 127
        assert q[1] == -128


class TestGemmReference:
    def test_matches_numpy_for_small_case(self):
        rng = np.random.default_rng(42)
        a = rng.integers(-128, 128, size=(5, 6), dtype=np.int64)
        b = rng.integers(-128, 128, size=(6, 7), dtype=np.int64)
        expected = a @ b
        got = gemm_reference(a, b, rows=4, cols=4, acc_width=32)
        assert np.array_equal(got, expected)

    def test_handles_k_larger_than_rows(self):
        rng = np.random.default_rng(7)
        a = rng.integers(-128, 128, size=(3, 20), dtype=np.int64)
        b = rng.integers(-128, 128, size=(20, 3), dtype=np.int64)
        expected = a @ b
        got = gemm_reference(a, b, rows=4, cols=4, acc_width=32)
        assert np.array_equal(got, expected)

    def test_tile_boundary_independence(self):
        # The same logical product must come out identically regardless of
        # ROWS/COLS tiling choice, as long as no overflow occurs.
        rng = np.random.default_rng(99)
        a = rng.integers(-128, 128, size=(9, 17), dtype=np.int64)
        b = rng.integers(-128, 128, size=(17, 5), dtype=np.int64)
        r1 = gemm_reference(a, b, rows=4, cols=4, acc_width=32)
        r2 = gemm_reference(a, b, rows=8, cols=2, acc_width=32)
        r3 = gemm_reference(a, b, rows=16, cols=16, acc_width=32)
        assert np.array_equal(r1, r2)
        assert np.array_equal(r1, r3)

    def test_fast_matches_tiled_when_no_overflow(self):
        rng = np.random.default_rng(5)
        a = rng.integers(-128, 128, size=(6, 12), dtype=np.int64)
        b = rng.integers(-128, 128, size=(12, 6), dtype=np.int64)
        tiled = gemm_reference(a, b, rows=4, cols=4, acc_width=32)
        fast = gemm_reference_fast(a, b, acc_width=32)
        assert np.array_equal(tiled, fast)

    def test_mismatched_inner_dims_raises(self):
        a = np.zeros((2, 3), dtype=np.int64)
        b = np.zeros((4, 2), dtype=np.int64)
        with pytest.raises(ValueError):
            gemm_reference(a, b, rows=4, cols=4)
