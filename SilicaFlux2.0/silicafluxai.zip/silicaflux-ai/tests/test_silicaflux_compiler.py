"""
tests/test_silicaflux_compiler.py

Coverage for the SilicaFlux schema/parser/compiler pipeline (PHASE 1/25/26):
every architectures/*.yaml file must validate against the schema, generate
RTL, and (when iverilog is available) that generated top-level module must
actually compile against the real hand-written RTL library -- not just
produce text that looks plausible.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest
from pydantic import ValidationError

from silicaflux.compiler.rtlgen import generate_rtl
from silicaflux.parser.loader import ArchitectureLoadError, load_architecture
from silicaflux.schema.architecture import ArchitectureSpec

REPO_ROOT = Path(__file__).resolve().parents[1]
ARCH_DIR = REPO_ROOT / "architectures"
RTL_LIB = [
    REPO_ROOT / "rtl" / "common" / "sfx_fifo.sv",
    REPO_ROOT / "rtl" / "common" / "sfx_pipeline_reg.sv",
    REPO_ROOT / "rtl" / "arithmetic" / "sfx_accumulator.sv",
    REPO_ROOT / "rtl" / "arithmetic" / "sfx_saturate.sv",
    REPO_ROOT / "rtl" / "tensor" / "sfx_pe.sv",
    REPO_ROOT / "rtl" / "tensor" / "sfx_systolic_array.sv",
    REPO_ROOT / "rtl" / "memory" / "sfx_sram_interface.sv",
    REPO_ROOT / "rtl" / "gemm" / "sfx_gemm_controller.sv",
]

ARCH_FILES = sorted(ARCH_DIR.glob("*.yaml"))


@pytest.mark.parametrize("path", ARCH_FILES, ids=lambda p: p.name)
def test_reference_architecture_validates(path: Path):
    spec = load_architecture(path)
    assert isinstance(spec, ArchitectureSpec)
    assert spec.architecture.name


@pytest.mark.parametrize("path", ARCH_FILES, ids=lambda p: p.name)
def test_reference_architecture_generates_rtl(path: Path, tmp_path: Path):
    spec = load_architecture(path)
    gen = generate_rtl(spec, tmp_path)
    assert gen.params_file.exists()
    assert gen.top_file.exists()
    top_text = gen.top_file.read_text()
    assert "sfx_gemm_controller" in top_text
    params_text = gen.params_file.read_text()
    assert f"{spec.compute.tensor.rows}" in params_text


@pytest.mark.skipif(shutil.which("iverilog") is None, reason="iverilog not on PATH")
@pytest.mark.parametrize("path", ARCH_FILES, ids=lambda p: p.name)
def test_generated_top_compiles(path: Path, tmp_path: Path):
    spec = load_architecture(path)
    gen = generate_rtl(spec, tmp_path)
    out_vvp = tmp_path / "check.vvp"
    cmd = [
        "iverilog", "-g2012", "-I", str(tmp_path), "-o", str(out_vvp),
        *[str(f) for f in RTL_LIB],
        str(gen.top_file), "-s", gen.module_name,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    assert proc.returncode == 0, f"iverilog failed for {path.name}:\n{proc.stdout}\n{proc.stderr}"
    assert out_vvp.exists()


class TestSchemaValidation:
    def test_rejects_float_element_precision(self):
        from silicaflux.schema.architecture import ArchitectureSpec

        bad = {
            "architecture": {"name": "bad"},
            "compute": {"tensor": {"rows": 4, "cols": 4, "precision": "fp32", "accumulator_precision": "int32"}},
            "memory": {"max_m": 8, "max_n": 8, "max_k": 8},
        }
        with pytest.raises(ValidationError):
            ArchitectureSpec.model_validate(bad)

    def test_rejects_undersized_accumulator(self):
        from silicaflux.schema.architecture import ArchitectureSpec

        bad = {
            "architecture": {"name": "bad"},
            "compute": {"tensor": {"rows": 4, "cols": 4, "precision": "int16", "accumulator_precision": "int16"}},
            "memory": {"max_m": 8, "max_n": 8, "max_k": 8},
        }
        with pytest.raises(ValidationError):
            ArchitectureSpec.model_validate(bad)

    def test_rejects_non_power_of_two_fifo_depth(self):
        from silicaflux.schema.architecture import ArchitectureSpec

        bad = {
            "architecture": {"name": "bad"},
            "compute": {"tensor": {"rows": 4, "cols": 4, "precision": "int8", "accumulator_precision": "int32"}},
            "memory": {"max_m": 8, "max_n": 8, "max_k": 8, "dma_fifo_depth": 6},
        }
        with pytest.raises(ValidationError):
            ArchitectureSpec.model_validate(bad)

    def test_missing_file_raises_load_error(self, tmp_path: Path):
        with pytest.raises(ArchitectureLoadError):
            load_architecture(tmp_path / "does_not_exist.yaml")

    def test_malformed_yaml_raises_load_error(self, tmp_path: Path):
        bad_file = tmp_path / "bad.yaml"
        bad_file.write_text("architecture: [this is not a mapping")
        with pytest.raises(ArchitectureLoadError):
            load_architecture(bad_file)
