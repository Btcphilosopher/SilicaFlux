#!/usr/bin/env bash
# =============================================================================
# scripts/run_unit_tests.sh
#
# SilicaFlux-AI RTL unit-test regression runner.
#
# Compiles and simulates each entry in the TESTS manifest below with Icarus
# Verilog (iverilog/vvp), and reports PASS/FAIL based on the standard
# "SFX_TB_RESULT: PASS|FAIL" convention every testbench in tb/unit/ prints as
# its last line (see any tb/unit/tb_*.sv file for the convention).
#
# Each manifest entry is: "<top_module_file> :: <space-separated rtl deps>"
# The top_module_file's basename (minus .sv) becomes the test name and the
# vvp output file name under build/.
#
# Usage:
#   scripts/run_unit_tests.sh            # run everything in the manifest
#   scripts/run_unit_tests.sh fifo skid  # run only tests whose name contains
#                                         # one of the given substrings
# =============================================================================
set -u
cd "$(dirname "${BASH_SOURCE[0]}")/.."
ROOT="$(pwd)"
BUILD="$ROOT/build"
mkdir -p "$BUILD"

# --- manifest: "<tb top file>::<rtl deps, space separated>" ----------------
TESTS=(
  "tb/unit/tb_sfx_register.sv::rtl/common/sfx_register.sv"
  "tb/unit/tb_sfx_fifo_registered.sv::rtl/common/sfx_fifo.sv tb/unit/tb_sfx_fifo.sv"
  "tb/unit/tb_sfx_fifo_combinational.sv::rtl/common/sfx_fifo.sv tb/unit/tb_sfx_fifo.sv"
  "tb/unit/tb_sfx_skid_buffer.sv::rtl/common/sfx_skid_buffer.sv"
  "tb/unit/tb_sfx_pipeline_reg.sv::rtl/common/sfx_pipeline_reg.sv"
  "tb/unit/tb_sfx_mac.sv::rtl/arithmetic/sfx_mac.sv"
  "tb/unit/tb_sfx_saturate.sv::rtl/arithmetic/sfx_saturate.sv"
  "tb/unit/tb_sfx_accumulator.sv::rtl/arithmetic/sfx_accumulator.sv"
  "tb/unit/tb_sfx_pe.sv::rtl/tensor/sfx_pe.sv"
  "tb/unit/tb_sfx_systolic_array_4x4.sv::rtl/tensor/sfx_pe.sv rtl/tensor/sfx_systolic_array.sv tb/unit/tb_sfx_systolic_array.sv"
  "tb/unit/tb_sfx_systolic_array_16x16.sv::rtl/tensor/sfx_pe.sv rtl/tensor/sfx_systolic_array.sv tb/unit/tb_sfx_systolic_array.sv"
  "tb/unit/tb_sfx_sram_interface.sv::rtl/memory/sfx_sram_interface.sv"
  "tb/unit/tb_sfx_dma.sv::rtl/common/sfx_fifo.sv rtl/memory/sfx_sram_interface.sv rtl/dma/sfx_dma.sv"
  "tb/integration/tb_sfx_gemm_controller.sv::rtl/common/sfx_fifo.sv rtl/common/sfx_pipeline_reg.sv rtl/arithmetic/sfx_accumulator.sv rtl/arithmetic/sfx_saturate.sv rtl/tensor/sfx_pe.sv rtl/tensor/sfx_systolic_array.sv rtl/memory/sfx_sram_interface.sv rtl/gemm/sfx_gemm_controller.sv"
)

filters=("$@")

pass=0
fail=0
skip=0
declare -a failed_names

matches_filter() {
  local name="$1"
  if [ ${#filters[@]} -eq 0 ]; then return 0; fi
  for f in "${filters[@]}"; do
    if [[ "$name" == *"$f"* ]]; then return 0; fi
  done
  return 1
}

for entry in "${TESTS[@]}"; do
  tb_file="${entry%%::*}"
  deps="${entry#*::}"
  name="$(basename "$tb_file" .sv)"

  if ! matches_filter "$name"; then
    continue
  fi

  if [ ! -f "$tb_file" ]; then
    echo "SKIP  $name (testbench not yet written: $tb_file)"
    skip=$((skip+1))
    continue
  fi

  vvp_out="$BUILD/$name.vvp"
  compile_log="$BUILD/$name.compile.log"
  run_log="$BUILD/$name.run.log"

  # shellcheck disable=SC2086
  if ! iverilog -g2012 -Wall -o "$vvp_out" $deps "$tb_file" > "$compile_log" 2>&1; then
    echo "FAIL  $name (compile error -- see $compile_log)"
    fail=$((fail+1))
    failed_names+=("$name")
    continue
  fi

  # 60s per test is generous for these sizes; a hang (e.g. an unterminated
  # `while` polling loop in a testbench -- see docs/TOOLING.md for a real
  # example encountered building tb_sfx_dma.sv) shows up as a timeout
  # instead of blocking the whole regression run indefinitely.
  timeout 60 vvp "$vvp_out" > "$run_log" 2>&1
  vvp_status=$?

  if [ $vvp_status -eq 124 ]; then
    echo "FAIL  $name (TIMEOUT -- see $run_log)"
    fail=$((fail+1))
    failed_names+=("$name")
  elif grep -q "SFX_TB_RESULT: PASS" "$run_log"; then
    echo "PASS  $name"
    pass=$((pass+1))
  else
    echo "FAIL  $name (see $run_log)"
    fail=$((fail+1))
    failed_names+=("$name")
  fi
done

echo ""
echo "================================================================"
echo "SilicaFlux-AI unit regression: $pass passed, $fail failed, $skip skipped"
echo "================================================================"

if [ $fail -gt 0 ]; then
  echo "Failed tests:"
  for n in "${failed_names[@]}"; do
    echo "  - $n"
  done
  exit 1
fi
exit 0
