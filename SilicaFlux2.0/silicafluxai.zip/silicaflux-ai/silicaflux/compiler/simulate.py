"""
silicaflux/compiler/simulate.py
SilicaFlux-AI :: per-architecture simulate/verify backend for the CLI

Compiles an ArchitectureSpec's generated top module (rtlgen.py +
simgen.py) and runs one or more small GEMM cases against it through Icarus
Verilog, checked against python/models/gemm.py's golden model -- the same
RTL<->Python bridge discipline as python/verification/bridge.py (PHASE 17),
just parameterized by the architecture instead of a fixed test config, and
driving the *generated* top-level rather than sfx_gemm_controller directly.

Backs `sfx-ai simulate` (one small case, human-readable) and
`sfx-ai verify` (several cases, JSON result file) -- see silicaflux/cli.py.
"""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from python.models.gemm import gemm_reference
from python.verification.vectors import ArrayConfig, read_c_sram, write_a_sram, write_b_sram
from silicaflux.compiler.rtlgen import GeneratedRtl, generate_rtl
from silicaflux.compiler.simgen import generate_smoke_testbench
from silicaflux.schema.architecture import ArchitectureSpec

REPO_ROOT = Path(__file__).resolve().parents[2]
RTL_LIB = [
    REPO_ROOT / "rtl" / "common" / "sfx_fifo.sv",
    REPO_ROOT / "rtl" / "common" / "sfx_pipeline_reg.sv",
    REPO_ROOT / "rtl" / "arithmetic" / "sfx_accumulator.sv",
    REPO_ROOT / "rtl" / "arithmetic" / "sfx_saturate.sv",
    REPO_ROOT / "rtl" / "tensor" / "sfx_pe.sv",
    REPO_ROOT / "rtl" / "tensor" / "sfx_systolic_array.sv",
    REPO_ROOT / "rtl" / "memory" / "sfx_sram_interface.sv",
    REPO_ROOT / "rtl" / "gemm" / "sfx_gemm_controller.sv",
]


@dataclass
class SimResult:
    test: str
    status: str
    cycles: int | None
    mismatches: int
    m: int
    n: int
    k: int
    seed: int
    detail: str = ""

    def to_json_dict(self) -> dict:
        return {
            "test": self.test, "status": self.status, "cycles": self.cycles,
            "mismatches": self.mismatches, "m": self.m, "n": self.n, "k": self.k,
            "seed": self.seed, "detail": self.detail,
        }


def _require_iverilog() -> None:
    if shutil.which("iverilog") is None or shutil.which("vvp") is None:
        raise RuntimeError(
            "iverilog/vvp not found on PATH -- simulate/verify require a real "
            "Icarus Verilog run and never fabricate a result. See docs/TOOLING.md."
        )


def build_and_compile(spec: ArchitectureSpec, out_dir: Path) -> tuple[GeneratedRtl, Path]:
    """Generates RTL + a smoke testbench for `spec`, compiles it, and
    returns (GeneratedRtl, compiled .vvp path)."""
    _require_iverilog()
    out_dir.mkdir(parents=True, exist_ok=True)
    gen = generate_rtl(spec, out_dir)
    tb_path = generate_smoke_testbench(gen, out_dir)

    vvp_path = out_dir / f"tb_{gen.module_name}_smoke.vvp"
    cmd = [
        "iverilog", "-g2012", "-I", str(out_dir), "-o", str(vvp_path),
        *[str(f) for f in RTL_LIB], str(gen.top_file), str(tb_path),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if proc.returncode != 0:
        raise RuntimeError(f"iverilog compile failed for architecture {spec.architecture.name!r}:\n{proc.stdout}\n{proc.stderr}")
    return gen, vvp_path


def run_one_case(vvp_path: Path, cfg: ArrayConfig, m: int, n: int, k: int, seed: int, work_dir: Path, timeout_s: float = 60.0) -> SimResult:
    test_name = f"{cfg.rows}x{cfg.cols}_gemm_m{m}_n{n}_k{k}_seed{seed}"
    work_dir.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(seed)
    a = rng.integers(-128, 128, size=(m, k), dtype=np.int64)
    b = rng.integers(-128, 128, size=(k, n), dtype=np.int64)
    golden = gemm_reference(a, b, rows=cfg.rows, cols=cfg.cols, acc_width=cfg.acc_width)

    a_file, b_file, c_file = work_dir / "a.hex", work_dir / "b.hex", work_dir / "c.hex"
    write_a_sram(a_file, a, cfg)
    write_b_sram(b_file, b, cfg)

    cmd = ["vvp", str(vvp_path), f"+A_FILE={a_file}", f"+B_FILE={b_file}", f"+C_FILE={c_file}",
           f"+M={m}", f"+N={n}", f"+K={k}"]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_s)
    stdout = proc.stdout

    if "SFX_BRIDGE_DONE" not in stdout:
        return SimResult(test=test_name, status="FAIL", cycles=None, mismatches=-1,
                          m=m, n=n, k=k, seed=seed, detail=f"simulation incomplete: {stdout[-1000:]}")

    cycles = None
    for line in stdout.splitlines():
        if line.startswith("SFX_BRIDGE_CYCLES:"):
            cycles = int(line.split(":", 1)[1].strip())

    got = read_c_sram(c_file, m, n, cfg)
    mismatches = int(np.count_nonzero(got != golden))
    return SimResult(test=test_name, status="PASS" if mismatches == 0 else "FAIL",
                      cycles=cycles, mismatches=mismatches, m=m, n=n, k=k, seed=seed)


def simulate_one(spec: ArchitectureSpec, out_dir: Path) -> SimResult:
    """`sfx-ai simulate`: one small case sized to fit the architecture
    (min(4, max_dim) per axis) run through the generated top."""
    cfg = ArrayConfig.from_spec(spec)
    gen, vvp_path = build_and_compile(spec, out_dir)
    m, n, k = min(4, cfg.max_m), min(4, cfg.max_n), min(4, cfg.max_k)
    with tempfile.TemporaryDirectory(prefix="sfx_sim_") as wd:
        return run_one_case(vvp_path, cfg, m, n, k, seed=1, work_dir=Path(wd))


def verify_suite(spec: ArchitectureSpec, out_dir: Path, n_cases: int = 5) -> list[dict]:
    """`sfx-ai verify`: a handful of directed + boundary cases sized to the
    architecture, including every dimension at its compile-time max (the
    exact class of case that once caught a real width bug -- see
    docs/TOOLING.md)."""
    cfg = ArrayConfig.from_spec(spec)
    gen, vvp_path = build_and_compile(spec, out_dir)

    def clamp(v: int, lim: int) -> int:
        return max(1, min(v, lim))

    cases = [
        (clamp(cfg.rows, cfg.max_m), clamp(cfg.cols, cfg.max_n), clamp(cfg.rows, cfg.max_k), 101),
        (cfg.max_m, cfg.max_n, cfg.max_k, 102),  # every dimension at compile-time max simultaneously
        (clamp(cfg.rows + 1, cfg.max_m), clamp(cfg.cols - 1 if cfg.cols > 1 else cfg.cols, cfg.max_n),
         clamp(cfg.rows * 2, cfg.max_k), 103),  # deliberately non-multiple-of-array-size shape
        (1, 1, 1, 104),
        (cfg.max_m, clamp(cfg.cols, cfg.max_n), 1, 105),
    ][:n_cases]

    results = []
    with tempfile.TemporaryDirectory(prefix="sfx_verify_") as wd:
        for (m, n, k, seed) in cases:
            r = run_one_case(vvp_path, cfg, m, n, k, seed, work_dir=Path(wd) / f"case_{seed}")
            results.append(r.to_json_dict())
    return results
