"""
silicaflux/parser/loader.py

Loads and validates an architecture YAML file against
silicaflux.schema.architecture.ArchitectureSpec. This is the "SilicaFlux
compiler" front end referenced in the project brief's
`architecture.yaml -> SilicaFlux compiler -> generated parameters` diagram
-- see silicaflux/compiler/rtlgen.py for the back end.
"""
from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import ValidationError

from silicaflux.schema.architecture import ArchitectureSpec


class ArchitectureLoadError(Exception):
    """Raised for a malformed YAML file or a schema validation failure.
    Always carries a human-readable message; never silently substitutes
    defaults for an invalid document."""


def load_architecture(path: str | Path) -> ArchitectureSpec:
    p = Path(path)
    if not p.exists():
        raise ArchitectureLoadError(f"architecture file not found: {p}")
    try:
        raw = yaml.safe_load(p.read_text())
    except yaml.YAMLError as e:
        raise ArchitectureLoadError(f"{p}: invalid YAML: {e}") from e
    if not isinstance(raw, dict):
        raise ArchitectureLoadError(f"{p}: top-level YAML document must be a mapping, got {type(raw).__name__}")
    try:
        return ArchitectureSpec.model_validate(raw)
    except ValidationError as e:
        raise ArchitectureLoadError(f"{p}: schema validation failed:\n{e}") from e
