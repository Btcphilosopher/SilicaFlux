"""
silicaflux/cli.py
SilicaFlux-AI :: command-line interface (PHASE 28)

    sfx-ai validate <architecture.yaml>
    sfx-ai compile <architecture.yaml>
    sfx-ai generate-rtl <architecture.yaml> --out <dir>
    sfx-ai simulate <architecture.yaml> [--out <dir>]
    sfx-ai verify <architecture.yaml> [--out <dir>] [--json <path>]
    sfx-ai benchmark <architecture.yaml> [--m --n --k]
    sfx-ai optimise <architecture.yaml>
    sfx-ai report <results.json>

Honesty discipline (engineering rules 14-16): validate/compile/generate-rtl/
simulate/verify only ever report what a real Pydantic validation or a real
Icarus Verilog run actually produced -- see silicaflux/compiler/simulate.py.
benchmark's RTL-simulated cycle counts are real for the same reason;
its/optimise's ANALYTICAL estimates are clearly labelled as closed-form
arithmetic, not measurement, and neither this file nor anything it calls
ever invents area, power, or silicon timing numbers -- see
docs/PHASE_STATUS.md for exactly which PHASE 20 result categories
(ANALYTICAL / SYNTHETIC / RTL SIMULATION / FPGA MEASUREMENT / POST-SYNTHESIS
/ POST-LAYOUT / SILICON MEASUREMENT) this repository can actually produce.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import click

from python.verification.vectors import ArrayConfig
from silicaflux.compiler.rtlgen import generate_rtl
from silicaflux.compiler.simulate import simulate_one, verify_suite
from silicaflux.parser.loader import ArchitectureLoadError, load_architecture


def _load_or_die(path: str) -> "ArchitectureSpec":  # noqa: F821
    try:
        return load_architecture(path)
    except ArchitectureLoadError as e:
        click.secho(str(e), fg="red", err=True)
        sys.exit(1)


@click.group()
@click.version_option(package_name="silicaflux-ai", prog_name="sfx-ai")
def main() -> None:
    """SilicaFlux-AI: architecture-to-RTL compiler and verification CLI."""


@main.command()
@click.argument("architecture", type=click.Path(exists=False))
def validate(architecture: str) -> None:
    """Validate an architecture YAML against the SilicaFlux schema."""
    spec = _load_or_die(architecture)
    click.secho(f"OK: {architecture} validates as architecture {spec.architecture.name!r}", fg="green")
    click.echo(f"  compute.tensor: {spec.compute.tensor.rows}x{spec.compute.tensor.cols} "
               f"{spec.compute.tensor.precision} -> {spec.compute.tensor.accumulator_precision}")
    click.echo(f"  memory: max_m={spec.memory.max_m} max_n={spec.memory.max_n} max_k={spec.memory.max_k}")


@main.command()
@click.argument("architecture", type=click.Path(exists=False))
def compile(architecture: str) -> None:  # noqa: A001 (shadows builtin, matches project brief's CLI verb)
    """Validate and resolve an architecture into its concrete RTL parameter set."""
    spec = _load_or_die(architecture)
    cfg = ArrayConfig.from_spec(spec)
    click.secho(f"Resolved parameters for {spec.architecture.name}:", fg="cyan")
    resolved = {
        "ROWS": cfg.rows, "COLS": cfg.cols,
        "DATA_WIDTH": cfg.data_width, "ACC_WIDTH": cfg.acc_width,
        "MAX_M": cfg.max_m, "MAX_N": cfg.max_n, "MAX_K": cfg.max_k,
        "KTILES_MAX": cfg.ktiles_max, "NTILES_MAX": cfg.ntiles_max,
        "A_SRAM_DEPTH": cfg.a_depth, "B_SRAM_DEPTH": cfg.b_depth, "C_SRAM_DEPTH": cfg.c_depth,
        "DMA_ADDR_WIDTH": spec.dma.addr_width, "DMA_MAX_LEN": spec.dma.max_len,
        "DMA_FIFO_DEPTH": spec.memory.dma_fifo_depth,
    }
    for k, v in resolved.items():
        click.echo(f"  {k:16s} = {v}")
    if spec.attention.enabled or spec.sparsity.enabled or spec.compute.clusters > 1:
        click.secho(
            "  NOTE: this architecture also declares attention/sparsity/multi-cluster fields -- "
            "these are schema-DESCRIPTIVE only in this milestone (see docs/PHASE_STATUS.md); "
            "`generate-rtl` below produces a single dense tensor-core top-level regardless.",
            fg="yellow",
        )


@main.command(name="generate-rtl")
@click.argument("architecture", type=click.Path(exists=False))
@click.option("--out", "out_dir", type=click.Path(), required=True, help="Output directory for generated RTL")
def generate_rtl_cmd(architecture: str, out_dir: str) -> None:
    """Generate a parameter header + top-level module for an architecture."""
    spec = _load_or_die(architecture)
    gen = generate_rtl(spec, Path(out_dir))
    click.secho(f"Generated RTL for {spec.architecture.name}:", fg="green")
    click.echo(f"  {gen.params_file}")
    click.echo(f"  {gen.top_file}  (module {gen.module_name})")


@main.command()
@click.argument("architecture", type=click.Path(exists=False))
@click.option("--out", "out_dir", type=click.Path(), default=None, help="Build directory (default: temp)")
def simulate(architecture: str, out_dir: str | None) -> None:
    """Generate RTL, compile it, and run one small GEMM case (real Icarus Verilog run)."""
    spec = _load_or_die(architecture)
    build_dir = Path(out_dir) if out_dir else Path("build") / "sfx_ai_sim" / spec.architecture.name.lower()
    try:
        result = simulate_one(spec, build_dir)
    except RuntimeError as e:
        click.secho(str(e), fg="red", err=True)
        sys.exit(1)
    color = "green" if result.status == "PASS" else "red"
    click.secho(f"[RTL SIMULATION] {result.test}: {result.status}", fg=color)
    click.echo(f"  cycles={result.cycles} mismatches={result.mismatches}")
    if result.detail:
        click.echo(f"  detail: {result.detail}")
    sys.exit(0 if result.status == "PASS" else 1)


@main.command()
@click.argument("architecture", type=click.Path(exists=False))
@click.option("--out", "out_dir", type=click.Path(), default=None, help="Build directory (default: temp)")
@click.option("--json", "json_out", type=click.Path(), default=None, help="Write JSON results here (PHASE 17 format)")
def verify(architecture: str, out_dir: str | None, json_out: str | None) -> None:
    """Run a directed verification suite (incl. compile-time-max boundary cases) via Icarus Verilog."""
    spec = _load_or_die(architecture)
    build_dir = Path(out_dir) if out_dir else Path("build") / "sfx_ai_verify" / spec.architecture.name.lower()
    try:
        results = verify_suite(spec, build_dir)
    except RuntimeError as e:
        click.secho(str(e), fg="red", err=True)
        sys.exit(1)
    n_pass = sum(1 for r in results if r["status"] == "PASS")
    for r in results:
        color = "green" if r["status"] == "PASS" else "red"
        click.secho(f"[RTL SIMULATION] {r['status']:5s} {r['test']:35s} cycles={r['cycles']} mismatches={r['mismatches']}", fg=color)
    click.echo(f"\n{n_pass}/{len(results)} passed")
    if json_out:
        Path(json_out).write_text(json.dumps(results, indent=2) + "\n")
        click.echo(f"wrote {json_out}")
    sys.exit(0 if n_pass == len(results) else 1)


@main.command()
@click.argument("architecture", type=click.Path(exists=False))
@click.option("--m", type=int, default=None)
@click.option("--n", type=int, default=None)
@click.option("--k", type=int, default=None)
def benchmark(architecture: str, m: int | None, n: int | None, k: int | None) -> None:
    """Report RTL-simulated cycle count for one GEMM shape (real measurement, not an estimate)."""
    spec = _load_or_die(architecture)
    cfg = ArrayConfig.from_spec(spec)
    m = m or cfg.max_m
    n = n or cfg.max_n
    k = k or cfg.max_k
    build_dir = Path("build") / "sfx_ai_bench" / spec.architecture.name.lower()
    from silicaflux.compiler.simulate import build_and_compile, run_one_case
    import tempfile
    try:
        gen, vvp_path = build_and_compile(spec, build_dir)
    except RuntimeError as e:
        click.secho(str(e), fg="red", err=True)
        sys.exit(1)
    with tempfile.TemporaryDirectory(prefix="sfx_bench_") as wd:
        result = run_one_case(vvp_path, cfg, m, n, k, seed=42, work_dir=Path(wd))
    click.secho(f"[RTL SIMULATION] {spec.architecture.name} GEMM {m}x{k} @ {k}x{n}:", fg="cyan")
    click.echo(f"  cycles = {result.cycles}  (status={result.status}, mismatches={result.mismatches})")
    macs = m * n * k
    if result.cycles:
        click.echo(f"  MACs = {macs}, MACs/cycle = {macs / result.cycles:.2f} "
                    f"(array peak = {cfg.rows * cfg.cols} MACs/cycle -- utilisation "
                    f"{100 * (macs / result.cycles) / (cfg.rows * cfg.cols):.1f}%)")
    click.secho("  NOTE: this is a real Icarus Verilog cycle count for functional RTL, "
                "not a post-synthesis or silicon timing number -- see docs/PHASE_STATUS.md.", fg="yellow")


@main.command()
@click.argument("architecture", type=click.Path(exists=False))
def optimise(architecture: str) -> None:
    """[ANALYTICAL] Sweep a small set of (rows, cols) configurations and report a
    closed-form cycle estimate for this architecture's max GEMM shape -- no RTL is run."""
    spec = _load_or_die(architecture)
    cfg = ArrayConfig.from_spec(spec)
    m, n, k = cfg.max_m, cfg.max_n, cfg.max_k

    click.secho(f"[ANALYTICAL] Design-space sweep for {spec.architecture.name}'s max shape "
                f"M={m} N={n} K={k} (closed-form cycle model, no RTL run -- see "
                f"docs/PHASE_STATUS.md; this is Phase 21's estimator, not measured data):", fg="cyan")
    click.echo(f"  {'rows':>5} {'cols':>5} {'ntiles':>7} {'ktiles':>7} {'est_cycles':>12} {'MACs/cyc':>10}")
    candidates = sorted({cfg.rows, 4, 8, 16, 32})
    for r in candidates:
        for c in candidates:
            ntiles = (n + c - 1) // c
            ktiles = (k + r - 1) // r
            # Same per-(nt,kt)-pass structure as sfx_gemm_controller.sv:
            # r load cycles + 1 settle + (m+r+c+2) stream + m*min(c,n) writeback.
            per_pass = r + 1 + (m + r + c + 2) + m * min(c, n)
            est_cycles = ntiles * ktiles * per_pass
            macs_per_cycle = (m * n * k) / est_cycles
            marker = "  <- this architecture" if (r, c) == (cfg.rows, cfg.cols) else ""
            click.echo(f"  {r:>5} {c:>5} {ntiles:>7} {ktiles:>7} {est_cycles:>12} {macs_per_cycle:>10.2f}{marker}")
    click.secho("  Area/power are NOT estimated -- no synthesis or technology data exists in this "
                "repository to ground such a number (see engineering rule against fabricating results).", fg="yellow")


@main.command()
@click.argument("results_json", type=click.Path(exists=True))
def report(results_json: str) -> None:
    """Summarize a JSON results file produced by `sfx-ai verify --json`."""
    data = json.loads(Path(results_json).read_text())
    if not isinstance(data, list):
        data = [data]
    n_pass = sum(1 for r in data if r.get("status") == "PASS")
    click.secho(f"SilicaFlux-AI verification report: {results_json}", fg="cyan")
    click.echo(f"  {n_pass}/{len(data)} passed\n")
    for r in data:
        color = "green" if r.get("status") == "PASS" else "red"
        click.secho(f"  {r.get('status', '?'):5s} {r.get('test', '?'):40s} "
                    f"cycles={r.get('cycles')} mismatches={r.get('mismatches')}", fg=color)


if __name__ == "__main__":
    main()
