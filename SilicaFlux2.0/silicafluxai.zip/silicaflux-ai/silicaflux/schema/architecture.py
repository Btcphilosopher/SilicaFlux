"""
silicaflux/schema/architecture.py

Pydantic schema for a SilicaFlux-AI architecture description (PHASE 1 / 25).
This is the machine-readable layer between an architecture YAML file and
generated SystemVerilog -- see silicaflux/compiler/rtlgen.py for the
compiler that consumes a validated ArchitectureSpec.

IMPORTANT -- read this before adding a field or trusting one:
This schema intentionally covers the *full* vision described in the
SilicaFlux-AI project brief (compute, memory, interconnect, precision,
clusters, vector engine, NoC, sparsity, transformer primitives...), because
architecture YAML files are meant to describe a whole chip, not just the
slice this repository currently generates RTL for. But only a subset of
these fields is actually WIRED into rtl generation today. Every section
below is marked either:

  WIRED     -- silicaflux/compiler/rtlgen.py reads this field and it
               changes the generated SystemVerilog parameters.
  DESCRIPTIVE -- validated and round-tripped, but rtlgen.py does not yet
               consume it; the corresponding RTL (NoC, vector engine,
               attention, sparsity, multi-cluster) is not implemented in
               this milestone (see docs/PHASE_STATUS.md). Treat these
               fields as forward-declared schema for a roadmap item, not as
               evidence that generating that hardware works.

Never let a DESCRIPTIVE field's presence in a validated architecture.yaml
imply the generated RTL implements it -- silicaflux/compiler/rtlgen.py's
own docstring and this file's WIRED/DESCRIPTIVE markings are the source of
truth for what actually happens on `sfx-ai generate-rtl`.
"""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, model_validator

Precision = Literal["int4", "int8", "int16", "int32", "bf16", "fp16", "fp32"]

_PRECISION_BITS: dict[Precision, int] = {
    "int4": 4, "int8": 8, "int16": 16, "int32": 32, "bf16": 16, "fp16": 16, "fp32": 32,
}


class ArchitectureInfo(BaseModel):
    """WIRED (name only; clock_hz is descriptive -- no clock-domain-crossing
    or timing-closure modelling exists in this repo, see
    docs/TIMING_AND_RESET.md)."""
    name: str = Field(..., min_length=1, description="Architecture/chip name, becomes the generated top module's prefix")
    clock_hz: int = Field(1_000_000_000, gt=0, description="Target clock frequency (DESCRIPTIVE: informs docs/reports only, not enforced by any timing analysis in this repo)")


class TensorCoreSpec(BaseModel):
    """WIRED: maps directly to rtl/tensor/sfx_systolic_array.sv's
    ROWS/COLS and rtl/gemm/sfx_gemm_controller.sv's DATA_WIDTH/ACC_WIDTH."""
    rows: int = Field(..., gt=0, le=128, description="Systolic array rows (K-tile size) -> sfx_systolic_array ROWS")
    cols: int = Field(..., gt=0, le=128, description="Systolic array columns (N-tile size) -> sfx_systolic_array COLS")
    precision: Precision = Field("int8", description="Input/weight element precision -> sfx_pe/sfx_mac DATA_WIDTH")
    accumulator_precision: Precision = Field("int32", description="Accumulator precision -> ACC_WIDTH")

    @model_validator(mode="after")
    def _check_precisions_supported_by_rtl(self) -> "TensorCoreSpec":
        if self.precision not in ("int4", "int8", "int16"):
            raise ValueError(
                f"compute.tensor.precision={self.precision!r}: rtl/tensor/sfx_pe.sv's datapath is a plain "
                "signed integer multiply (rtl/arithmetic/sfx_mac.sv-style) -- bf16/fp16/fp32 element types "
                "are schema-DESCRIPTIVE only in this milestone, no floating-point PE exists to generate. "
                "Use int4/int8/int16."
            )
        if self.accumulator_precision not in ("int16", "int32"):
            raise ValueError(
                f"compute.tensor.accumulator_precision={self.accumulator_precision!r}: only integer "
                "accumulators are wired to rtl generation. Use int16 or int32."
            )
        acc_bits = _PRECISION_BITS[self.accumulator_precision]
        elem_bits = _PRECISION_BITS[self.precision]
        if acc_bits < 2 * elem_bits:
            raise ValueError(
                f"compute.tensor.accumulator_precision ({acc_bits} bits) must be >= 2x precision "
                f"({elem_bits} bits) -- matches rtl/arithmetic/sfx_mac.sv's own elaboration-time check "
                f"(ACC_WIDTH >= A_WIDTH+B_WIDTH)."
            )
        return self


class ComputeSpec(BaseModel):
    tensor: TensorCoreSpec
    vector_width: int | None = Field(None, gt=0, description="DESCRIPTIVE: rtl/vector/ is not implemented yet (Phase 11, see docs/PHASE_STATUS.md)")
    clusters: int = Field(1, gt=0, description="DESCRIPTIVE: rtl/scheduler + multi-cluster top-level (Phase 13) not implemented yet; this repo generates a single tensor-core+GEMM-controller instance regardless of this value")


class MemorySpec(BaseModel):
    """WIRED (max_m/max_n/max_k) -> rtl/gemm/sfx_gemm_controller.sv's
    MAX_M/MAX_N/MAX_K, which in turn size the internal A/B/C SRAMs (see
    that module's header for the exact depth formulas). The *_kb fields
    from the project brief's example (input_sram_kb etc.) are accepted for
    schema compatibility but are DESCRIPTIVE here: this repo's SRAMs are
    sized by the matrix-dimension bounds they need to hold pre-tiled
    operands for, not an independent capacity knob -- see rtlgen.py."""
    max_m: int = Field(..., gt=0, le=4096, description="Largest M this generated engine will accept -> sfx_gemm_controller MAX_M")
    max_n: int = Field(..., gt=0, le=4096, description="Largest N -> MAX_N")
    max_k: int = Field(..., gt=0, le=4096, description="Largest K -> MAX_K")
    global_buffer_kb: int | None = Field(None, gt=0, description="DESCRIPTIVE: rtl/memory/sfx_global_buffer.sv (Phase 6) not implemented yet")
    dma_fifo_depth: int = Field(16, description="WIRED -> rtl/dma/sfx_dma.sv FIFO_DEPTH, must be a power of 2 (see rtl/common/sfx_fifo.sv)")

    @model_validator(mode="after")
    def _check_fifo_depth_power_of_two(self) -> "MemorySpec":
        d = self.dma_fifo_depth
        if d <= 0 or (d & (d - 1)) != 0:
            raise ValueError(f"memory.dma_fifo_depth={d} must be a power of 2 (rtl/common/sfx_fifo.sv's elaboration-time check)")
        return self


class InterconnectSpec(BaseModel):
    """DESCRIPTIVE in full: rtl/noc/ (Phase 14) is not implemented in this
    milestone. Recorded for forward compatibility with a future rtlgen
    that does generate a NoC."""
    topology: Literal["mesh", "none"] = Field("none", description="DESCRIPTIVE: 'mesh' documents intent for a future rtl/noc/sfx_noc_mesh.sv; this repo has no NoC to generate regardless of this value")
    data_width: int = Field(256, gt=0, description="DESCRIPTIVE")


class DmaSpec(BaseModel):
    """WIRED -> rtl/dma/sfx_dma.sv."""
    addr_width: int = Field(16, gt=0, le=64, description="-> sfx_dma ADDR_WIDTH")
    max_len: int = Field(4096, gt=0, description="-> sfx_dma MAX_LEN")


class SparsitySpec(BaseModel):
    """Entirely DESCRIPTIVE: rtl/sparsity/ (Phase 9 -- sfx_sparse_decoder,
    sfx_zero_skipper, sfx_metadata_engine) is not implemented in this
    milestone. Present so an SFX-SPARSE-style architecture.yaml validates
    and documents intent; generate-rtl ignores this section entirely."""
    enabled: bool = False
    mode: Literal["structured", "unstructured"] = "structured"


class AttentionSpec(BaseModel):
    """Entirely DESCRIPTIVE: rtl/attention/ (Phase 8) is not implemented in
    this milestone. Present so an SFX-TRANSFORMER-style architecture.yaml
    validates and documents intent; generate-rtl ignores this section."""
    enabled: bool = False
    num_heads: int = Field(1, gt=0)
    head_dim: int = Field(64, gt=0)


class ArchitectureSpec(BaseModel):
    """Top-level schema, matching architecture.yaml's document shape:
    `architecture:`, `compute:`, `memory:`, `interconnect:`, `dma:`,
    optionally `sparsity:` / `attention:` for architectures that document
    (but, in this milestone, do not generate RTL for) those extensions.
    """
    architecture: ArchitectureInfo
    compute: ComputeSpec
    memory: MemorySpec
    interconnect: InterconnectSpec = Field(default_factory=InterconnectSpec)
    dma: DmaSpec = Field(default_factory=DmaSpec)
    sparsity: SparsitySpec = Field(default_factory=SparsitySpec)
    attention: AttentionSpec = Field(default_factory=AttentionSpec)

    def data_width_bits(self) -> int:
        return _PRECISION_BITS[self.compute.tensor.precision]

    def acc_width_bits(self) -> int:
        return _PRECISION_BITS[self.compute.tensor.accumulator_precision]
