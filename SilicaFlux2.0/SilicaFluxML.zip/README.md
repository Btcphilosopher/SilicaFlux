# SilicaFlux-ML

**Hardware-native machine-learning optimisation engine for the SilicaFlux
parallel compute fabric.**

> SilicaFlux is an adaptive computing architecture in which machine
> learning is embedded into the hardware control fabric itself, allowing
> the system to observe its own performance, update a compact model, and
> continuously search for better operating configurations within
> deterministic physical and safety constraints.

This is **not** a neural network running on a processor. Every learning
and inference block — feature extraction, prediction, reward, online
weight updates, action selection, safety constraints, learning memory — is
written as a bit-accurate model of digital hardware: fixed-point registers,
multiply-accumulate pipelines, ring-buffer statistics, a nine-stage
pipeline driven by one central finite state machine. Nothing in the
inference or learning path uses Python's floats, NumPy, PyTorch, or any
other ML runtime; the Python package here is a reference *model* of that
hardware, runnable and testable without any of it existing in silicon yet.

SilicaFlux-ML does not make computation mathematically faster. It
adaptively optimises **scheduling, resource utilisation, power, and
thermal behaviour** of an existing compute fabric by learning online, from
the fabric's own telemetry, which discrete configuration changes tend to
produce better outcomes — subject to hard safety limits the learning
algorithm can never override.

## Quickstart

Zero external dependencies — standard library only.

```bash
cd python
python3 -m unittest discover -s tests          # 62 tests, ~5s

cd benchmarks
python3 run_convergence.py                      # Section 29
python3 run_ablation.py                          # Section 30
python3 run_precision_comparison.py              # Sections 21/32
python3 run_synthesis_estimate.py                # Sections 25/26
python3 run_mode4_demo.py                        # Sections 16/26
```

or `bash python/scripts/run_all.sh` to run everything in one shot. Output
(CSV + dependency-free SVG charts) lands in `python/results/`.

## A five-line tour of the control loop

```python
from silicaflux_ml.fabric import SilicaFluxFabric, WorkloadGenerator
from silicaflux_ml.controller import SilicaFluxController
from silicaflux_ml.learning_engine import EngineConfig
from silicaflux_ml.modes import Mode

fabric = SilicaFluxFabric(rows=4, cols=4, seed=1)
controller = SilicaFluxController(fabric, EngineConfig(mode=Mode.MODE_3_ONLINE_RL))
workload = WorkloadGenerator(seed=1)

for cycle in range(10_000):
    intensity, fault_pe = workload.next(cycle, (4, 4))
    result = controller.step(intensity, fault_pe)   # telemetry -> features -> predict ->
                                                       # reward -> learn -> select -> validate -> apply
    print(cycle, result.reward_float, result.throughput, result.applied_action)
```

## Directory layout

```
docs/         architecture specification, 9 documents -- start at docs/01_ARCHITECTURE.md
rtl/          RTL-oriented SystemVerilog pseudocode, one file per hardware block
dsl/          native SilicaFlux-DSL-style module sketch (silicaflux_ml.sf)
python/
  silicaflux_ml/   bit-accurate reference implementation (stdlib only, ~2k lines)
  tests/           62 unit + integration tests (stdlib unittest)
  benchmarks/      convergence / ablation / precision / synthesis-estimate scripts
  results/         generated CSV + SVG output of the benchmark scripts
  scripts/run_all.sh
```

## Where to read next

| I want to... | read |
|---|---|
| understand the whole architecture and module hierarchy | `docs/01_ARCHITECTURE.md` |
| understand the central FSM and 9-stage pipeline | `docs/02_STATE_MACHINE_AND_PIPELINE.md` |
| understand the fixed-point math and the learning algorithm | `docs/03_FIXED_POINT_AND_LEARNING.md` |
| understand the safety/constraint architecture | `docs/04_CONSTRAINTS_AND_SAFETY.md` |
| understand the fabric model, thermal/power/fault models, workload scheduler | `docs/05_FABRIC_AND_DIGITAL_TWIN.md` |
| understand the resource estimator and the 5 complexity modes | `docs/06_SYNTHESIS_ESTIMATION.md` |
| know what's verified and how to run the benchmarks | `docs/07_VERIFICATION_AND_BENCHMARKS.md` |
| see actual numbers from a reference run | `docs/08_RESULTS.md` |
| see the Python <-> RTL <-> DSL mapping, and every disclosed limitation | `docs/09_DSL_AND_RTL_MAPPING.md` |

`docs/09_DSL_AND_RTL_MAPPING.md`'s closing section is worth reading before
citing any number from this project elsewhere — it lists, plainly, what
is a bit-accurate guarantee (the fixed-point arithmetic, the unit tests)
versus what is an illustrative heuristic (the synthesis-resource
estimator, the fabric's physical model) versus what is a disclosed design
simplification (Modes 0-2's non-contextual bandit; softmax/UCB as
software-reference-only strategies).
