// =============================================================================
// reward_engine.sv
// -----------------------------------------------------------------------------
// Section 9: reward = tw*throughput + ew*efficiency - pw*power - thw*thermal
//                      - erw*errors
// Five multiplies, four adds, fully combinational (or single-cycle
// pipelined, as latched below) -- configurable coefficient registers.
// Python reference: python/silicaflux_ml/reward_engine.py.
// =============================================================================

`include "silicaflux_ml_pkg.sv"

module reward_engine (
  input  logic                        clk,
  input  logic                        rst_n,
  input  logic                        valid_in,

  input  silicaflux_ml_pkg::fixed_t   throughput_weight,
  input  silicaflux_ml_pkg::fixed_t   efficiency_weight,
  input  silicaflux_ml_pkg::fixed_t   power_weight,
  input  silicaflux_ml_pkg::fixed_t   thermal_weight,
  input  silicaflux_ml_pkg::fixed_t   error_weight,
  input  silicaflux_ml_pkg::fixed_t   invalid_action_penalty,

  input  silicaflux_ml_pkg::fixed_t   throughput,
  input  silicaflux_ml_pkg::fixed_t   efficiency,
  input  silicaflux_ml_pkg::fixed_t   power,
  input  silicaflux_ml_pkg::fixed_t   thermal_penalty,
  input  silicaflux_ml_pkg::fixed_t   errors,
  input  logic                        action_invalid,   // from constraint_engine

  output silicaflux_ml_pkg::fixed_t   reward_out,
  output logic                        valid_out
);
  import silicaflux_ml_pkg::*;
  import fixed_point_ops::*;

  fixed_t base_reward;
  always_comb begin
    automatic fixed_t r;
    r = fixed_mul(throughput_weight, throughput);
    r = fixed_add(r, fixed_mul(efficiency_weight, efficiency));
    r = fixed_sub(r, fixed_mul(power_weight, power));
    r = fixed_sub(r, fixed_mul(thermal_weight, thermal_penalty));
    r = fixed_sub(r, fixed_mul(error_weight, errors));
    base_reward = r;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      reward_out <= '0;
      valid_out  <= 1'b0;
    end else begin
      reward_out <= action_invalid ? fixed_sub(base_reward, invalid_action_penalty) : base_reward;
      valid_out  <= valid_in;
    end
  end

endmodule : reward_engine
