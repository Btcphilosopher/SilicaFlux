// =============================================================================
// telemetry_engine.sv
// -----------------------------------------------------------------------------
// Section 15: per-processing-element telemetry capture and fabric-wide
// aggregation into one silicaflux_ml_pkg::state_vector_t per cycle
// (Stage 1 of the Section 20 pipeline). Each PE exposes a fixed telemetry
// bus; this block averages/sums across the RxC grid on a simple streaming
// accumulate-then-divide schedule (one PE's contribution per cycle, ROWS*COLS
// cycles per full sample -- trades sample latency for a single shared
// adder/divider instead of an RxC-wide combinational reduction tree).
//
// Python reference: python/silicaflux_ml/fabric.py (SilicaFluxFabric.aggregate_state).
// =============================================================================

`include "silicaflux_ml_pkg.sv"

module pe_telemetry_bus (
  output silicaflux_ml_pkg::fixed_t utilisation,
  output silicaflux_ml_pkg::fixed_t latency,
  output silicaflux_ml_pkg::fixed_t temperature,
  output silicaflux_ml_pkg::fixed_t power,
  output silicaflux_ml_pkg::fixed_t errors,
  output silicaflux_ml_pkg::fixed_t throughput,
  output silicaflux_ml_pkg::fixed_t queue_depth
);
  // Interface only -- driven by each PE's own local counters/sensors in
  // the full SilicaFlux fabric; left unconnected here as a port-shape
  // reference for docs/08_FABRIC_MODEL.md.
endmodule


module telemetry_engine #(
  parameter int ROWS = 4,
  parameter int COLS = 4
) (
  input  logic                              clk,
  input  logic                              rst_n,
  input  logic                              sample_start,     // begin one fabric-wide sweep

  // Flattened per-PE telemetry, ROWS*COLS entries, PE (r,c) at index r*COLS+c.
  input  silicaflux_ml_pkg::fixed_t         pe_utilisation [ROWS*COLS],
  input  silicaflux_ml_pkg::fixed_t         pe_throughput  [ROWS*COLS],
  input  silicaflux_ml_pkg::fixed_t         pe_power       [ROWS*COLS],
  input  silicaflux_ml_pkg::fixed_t         pe_temperature [ROWS*COLS],
  input  silicaflux_ml_pkg::fixed_t         pe_errors      [ROWS*COLS],
  input  silicaflux_ml_pkg::fixed_t         pe_queue_depth [ROWS*COLS],
  input  logic [ROWS*COLS-1:0]              pe_active,

  input  silicaflux_ml_pkg::fixed_t         clock_frequency_reg,
  input  silicaflux_ml_pkg::fixed_t         voltage_reg,

  output silicaflux_ml_pkg::state_vector_t  state_out,
  output logic                              state_valid
);
  import silicaflux_ml_pkg::*;
  import fixed_point_ops::*;

  localparam int NUM_PE = ROWS*COLS;
  localparam int IDX_W  = $clog2(NUM_PE);

  typedef enum logic [1:0] {S_IDLE, S_SWEEP, S_DONE} state_e;
  state_e state;
  logic [IDX_W-1:0] idx;
  logic [15:0] active_count;

  acc_t util_sum, thr_sum, pow_sum, temp_sum, err_sum, queue_sum;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE; idx <= '0; state_valid <= 1'b0;
      util_sum <= '0; thr_sum <= '0; pow_sum <= '0; temp_sum <= '0; err_sum <= '0; queue_sum <= '0;
      active_count <= '0;
    end else begin
      state_valid <= 1'b0;
      unique case (state)
        S_IDLE: if (sample_start) begin
          idx <= '0; active_count <= '0;
          util_sum <= '0; thr_sum <= '0; pow_sum <= '0; temp_sum <= '0; err_sum <= '0; queue_sum <= '0;
          state <= S_SWEEP;
        end

        S_SWEEP: begin
          if (pe_active[idx]) begin
            util_sum  <= util_sum  + acc_t'(pe_utilisation[idx]);
            thr_sum   <= thr_sum   + acc_t'(pe_throughput[idx]);
            pow_sum   <= pow_sum   + acc_t'(pe_power[idx]);
            temp_sum  <= temp_sum  + acc_t'(pe_temperature[idx]);
            err_sum   <= err_sum   + acc_t'(pe_errors[idx]);
            queue_sum <= queue_sum + acc_t'(pe_queue_depth[idx]);
            active_count <= active_count + 1'b1;
          end
          if (idx == NUM_PE-1) state <= S_DONE;
          else idx <= idx + 1'b1;
        end

        S_DONE: begin
          automatic int unsigned n = (active_count == 0) ? 1 : active_count;
          state_out.utilisation          <= fixed_div_int(fixed_clip(util_sum), n);
          state_out.throughput           <= fixed_div_int(fixed_clip(thr_sum), n);
          state_out.power                <= fixed_div_int(fixed_clip(pow_sum), n);   // mean per-PE power
          state_out.temperature          <= fixed_div_int(fixed_clip(temp_sum), n);
          state_out.error_rate           <= fixed_div_int(fixed_clip(err_sum), n);
          state_out.queue_depth          <= fixed_div_int(fixed_clip(queue_sum), n);
          state_out.pipeline_utilisation <= fixed_div_int(fixed_clip(util_sum), n);
          state_out.clock_frequency      <= clock_frequency_reg;
          state_out.voltage              <= voltage_reg;
          // latency, memory_pressure, thermal_headroom: analogous
          // accumulate-and-divide (thermal_headroom instead tracks a
          // running MAX rather than a mean -- see the Python model).
          state_valid <= 1'b1;
          state <= S_IDLE;
        end
      endcase
    end
  end

endmodule : telemetry_engine
