// =============================================================================
// feature_engine.sv
// -----------------------------------------------------------------------------
// Section 5: streaming feature extraction. One `ring_channel` instance per
// raw state-vector input (NUM_STATE_FEATURES of them), each an independent
// depth-RING_DEPTH shift-register file plus running sum/sum-of-squares
// accumulators -- NOT a growing history. Python reference:
// python/silicaflux_ml/feature_engine.py (RingChannel / FeatureEngine).
// =============================================================================

`include "silicaflux_ml_pkg.sv"

module ring_channel #(
  parameter int RING_DEPTH = 16
) (
  input  logic                        clk,
  input  logic                        rst_n,
  input  logic                        sample_valid,   // one new telemetry sample this cycle
  input  silicaflux_ml_pkg::fixed_t   sample_in,

  output silicaflux_ml_pkg::fixed_t   mean_out,
  output silicaflux_ml_pkg::fixed_t   variance_out,
  output silicaflux_ml_pkg::fixed_t   delta_out,
  output silicaflux_ml_pkg::fixed_t   prev_out
);
  import silicaflux_ml_pkg::*;
  import fixed_point_ops::*;

  // Shift-register ring buffer of (value, value^2) pairs. Depth is a
  // synthesis-time parameter -> a fixed-size register file / small BRAM.
  fixed_t val_ring [RING_DEPTH];
  fixed_t sq_ring  [RING_DEPTH];
  logic [$clog2(RING_DEPTH):0] wr_ptr, count;

  acc_t sum_reg, sumsq_reg;
  fixed_t prev_reg;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wr_ptr    <= '0;
      count     <= '0;
      sum_reg   <= '0;
      sumsq_reg <= '0;
      prev_reg  <= '0;
      for (int i = 0; i < RING_DEPTH; i++) begin
        val_ring[i] <= '0;
        sq_ring[i]  <= '0;
      end
    end else if (sample_valid) begin
      automatic fixed_t sq_new = fixed_mul(sample_in, sample_in);
      automatic logic full = (count == RING_DEPTH);
      automatic fixed_t evicted_val = val_ring[wr_ptr];
      automatic fixed_t evicted_sq  = sq_ring[wr_ptr];

      val_ring[wr_ptr] <= sample_in;
      sq_ring[wr_ptr]  <= sq_new;
      wr_ptr           <= (wr_ptr == RING_DEPTH-1) ? '0 : wr_ptr + 1'b1;

      if (full) begin
        sum_reg   <= sum_reg   + acc_t'(sample_in) - acc_t'(evicted_val);
        sumsq_reg <= sumsq_reg + acc_t'(sq_new)     - acc_t'(evicted_sq);
      end else begin
        sum_reg   <= sum_reg   + acc_t'(sample_in);
        sumsq_reg <= sumsq_reg + acc_t'(sq_new);
        count     <= count + 1'b1;
      end

      prev_reg <= sample_in;
    end
  end

  // Combinational read-out: mean/variance/delta derived from the running
  // accumulators, exactly as RingChannel.mean()/.variance()/.delta() do.
  always_comb begin
    automatic int unsigned n = (count == 0) ? 1 : count;
    automatic fixed_t mean_sq;
    mean_out     = fixed_div_int(fixed_clip(sum_reg), n);
    mean_sq      = fixed_div_int(fixed_clip(sumsq_reg), n);
    variance_out = fixed_sub(mean_sq, fixed_mul(mean_out, mean_out));
    if (variance_out[WORD_W-1]) variance_out = '0;   // clamp rounding noise >= 0
    delta_out    = fixed_sub(sample_in, prev_reg);   // uses the OLD prev_reg, pre-update
    prev_out     = prev_reg;
  end

endmodule : ring_channel


module feature_engine (
  input  logic                                clk,
  input  logic                                rst_n,
  input  logic                                sample_valid,
  input  silicaflux_ml_pkg::state_vector_t    state_in,

  output silicaflux_ml_pkg::feature_vec_t     features_out,
  output logic                                features_valid
);
  import silicaflux_ml_pkg::*;
  import fixed_point_ops::*;

  // One ring_channel per raw channel (generate would normally index an
  // array-of-structs port; shown unrolled for the two channels the
  // derived-ratio block below actually needs plus the pattern to repeat
  // for the rest -- see the Python FeatureEngine for the full 12-channel
  // instantiation this generalises).
  fixed_t util_mean, util_delta, util_prev;
  fixed_t thr_mean,  thr_delta,  thr_prev;
  fixed_t pow_mean,  pow_delta,  pow_prev;
  fixed_t temp_mean, temp_delta, temp_prev;
  fixed_t headroom_mean, headroom_delta, headroom_prev;
  fixed_t lat_mean, lat_delta, lat_prev;

  ring_channel #(.RING_DEPTH(16)) u_util (
    .clk, .rst_n, .sample_valid, .sample_in(state_in.utilisation),
    .mean_out(util_mean), .variance_out(), .delta_out(util_delta), .prev_out(util_prev));

  ring_channel #(.RING_DEPTH(16)) u_thr (
    .clk, .rst_n, .sample_valid, .sample_in(state_in.throughput),
    .mean_out(thr_mean), .variance_out(), .delta_out(thr_delta), .prev_out(thr_prev));

  ring_channel #(.RING_DEPTH(16)) u_pow (
    .clk, .rst_n, .sample_valid, .sample_in(state_in.power),
    .mean_out(pow_mean), .variance_out(), .delta_out(pow_delta), .prev_out(pow_prev));

  ring_channel #(.RING_DEPTH(16)) u_temp (
    .clk, .rst_n, .sample_valid, .sample_in(state_in.temperature),
    .mean_out(temp_mean), .variance_out(), .delta_out(temp_delta), .prev_out(temp_prev));

  ring_channel #(.RING_DEPTH(16)) u_headroom (
    .clk, .rst_n, .sample_valid, .sample_in(state_in.thermal_headroom),
    .mean_out(headroom_mean), .variance_out(), .delta_out(headroom_delta), .prev_out(headroom_prev));

  ring_channel #(.RING_DEPTH(16)) u_lat (
    .clk, .rst_n, .sample_valid, .sample_in(state_in.latency),
    .mean_out(lat_mean), .variance_out(), .delta_out(lat_delta), .prev_out(lat_prev));

  // ... remaining 6 channels (clock_frequency, voltage, memory_pressure,
  // pipeline_utilisation, queue_depth, error_rate) instantiate identically.

  // Derived cross-channel ratios (Section 5), with a divisor floor at ~1%
  // of full scale rather than raw-unit "1" -- see the min_divisor comment
  // in feature_engine.py for why that distinction matters.
  localparam fixed_t MIN_DIVISOR = fixed_t'(1 <<< (FRAC_BITS - 7)); // ~0.0078

  fixed_t pow_floor, util_floor, temp_floor;
  always_comb begin
    pow_floor  = (pow_mean  > MIN_DIVISOR) ? pow_mean  : MIN_DIVISOR;
    util_floor = (util_mean > MIN_DIVISOR) ? util_mean : MIN_DIVISOR;
    temp_floor = (temp_mean > MIN_DIVISOR) ? temp_mean : MIN_DIVISOR;
  end

  fixed_t power_efficiency, thermal_efficiency, throughput_efficiency;
  always_comb begin
    power_efficiency      = fixed_div(thr_mean, pow_floor);
    thermal_efficiency    = fixed_div(headroom_mean, temp_floor);
    throughput_efficiency = fixed_div(thr_mean, util_floor);
  end

  // Pack the curated NUM_FEATURES-wide vector that feeds the predictors /
  // action-value datapath (Section 4's compact-state-vector principle).
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      features_valid <= 1'b0;
    end else begin
      features_out[0]  <= util_mean;
      features_out[1]  <= util_delta;
      features_out[2]  <= thr_mean;
      features_out[3]  <= thr_delta;
      features_out[4]  <= pow_mean;
      features_out[5]  <= pow_delta;
      features_out[6]  <= temp_mean;
      features_out[7]  <= temp_delta;
      features_out[8]  <= headroom_mean;
      // features_out[9..11] <= queue_depth_mean, pipeline_util_mean, error_rate_mean;
      features_out[12] <= util_mean;              // normalised_utilisation
      features_out[13] <= power_efficiency;
      features_out[14] <= thermal_efficiency;
      features_out[15] <= throughput_efficiency;
      features_out[16] <= lat_delta;               // latency_gradient
      features_valid   <= sample_valid;
    end
  end

endmodule : feature_engine
