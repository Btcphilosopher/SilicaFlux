// =============================================================================
// silicaflux_ml_pkg.sv
// -----------------------------------------------------------------------------
// SilicaFlux-ML :: shared package (parameters, typedefs, enums)
//
// RTL-ORIENTED PSEUDOCODE, not a lint-clean synthesisable file: it exists to
// show the register/port-level shape of every block in this directory and how
// they compose, using real SystemVerilog syntax and idiom. Every block here
// has a one-to-one Python reference model in ../python/silicaflux_ml/, which
// IS executable and bit-accurate; this file (and its siblings) are the
// hardware-facing expression of the exact same algorithm.
//
// Section references are to the SilicaFlux-ML architecture specification
// (see ../docs/).
// =============================================================================

package silicaflux_ml_pkg;

  // ---------------------------------------------------------------------
  // Section 21: fixed-point format. Default Q16.16; change FRAC_BITS /
  // INT_BITS together and every block below re-elaborates at the new
  // width -- nothing here hardcodes 32 bits.
  // ---------------------------------------------------------------------
  parameter int INT_BITS  = 16;
  parameter int FRAC_BITS = 16;
  parameter int WORD_W    = INT_BITS + FRAC_BITS;      // Q16.16 -> 32
  parameter int ACC_GUARD_BITS = 8;                    // MAC accumulator guard bits
  parameter int ACC_W     = WORD_W + ACC_GUARD_BITS;   // wide accumulator width

  typedef logic signed [WORD_W-1:0] fixed_t;
  typedef logic signed [ACC_W-1:0]  acc_t;

  // ---------------------------------------------------------------------
  // Section 4: hardware state vector, X0..X11. Order is load-bearing --
  // every block below indexes into a `state_vector_t` by these names.
  // ---------------------------------------------------------------------
  parameter int NUM_STATE_FEATURES = 12;

  typedef struct packed {
    fixed_t utilisation;            // X0
    fixed_t throughput;             // X1
    fixed_t latency;                // X2
    fixed_t power;                  // X3
    fixed_t temperature;            // X4
    fixed_t clock_frequency;        // X5
    fixed_t voltage;                // X6
    fixed_t memory_pressure;        // X7
    fixed_t pipeline_utilisation;   // X8
    fixed_t queue_depth;            // X9
    fixed_t error_rate;             // X10
    fixed_t thermal_headroom;       // X11
  } state_vector_t;

  // ---------------------------------------------------------------------
  // Section 5: feature engine output width. NUM_FEATURES is the CURATED
  // subset actually fed to the predictors/action-value datapath (Section
  // 4's "compact state vector" principle) -- not every raw/derived
  // statistic the feature engine computes internally.
  // ---------------------------------------------------------------------
  parameter int NUM_FEATURES = 17;
  typedef fixed_t feature_vec_t [NUM_FEATURES];

  // ---------------------------------------------------------------------
  // Section 7: multi-output predictor. One of these per predicted
  // quantity (throughput/power/temperature/latency/error_probability).
  // ---------------------------------------------------------------------
  parameter int NUM_OUTPUTS = 5;
  typedef enum logic [2:0] {
    OUT_THROUGHPUT        = 3'd0,
    OUT_POWER             = 3'd1,
    OUT_TEMPERATURE       = 3'd2,
    OUT_LATENCY           = 3'd3,
    OUT_ERROR_PROBABILITY = 3'd4
  } predictor_output_e;

  // ---------------------------------------------------------------------
  // Section 10: action space (default 10 actions, extend NUM_ACTIONS +
  // the enum together to reconfigure).
  // ---------------------------------------------------------------------
  parameter int NUM_ACTIONS = 10;
  typedef enum logic [3:0] {
    ACTION_INCREASE_PARALLELISM   = 4'd0,
    ACTION_DECREASE_PARALLELISM   = 4'd1,
    ACTION_INCREASE_FREQUENCY     = 4'd2,
    ACTION_DECREASE_FREQUENCY     = 4'd3,
    ACTION_INCREASE_BATCH_SIZE    = 4'd4,
    ACTION_DECREASE_BATCH_SIZE    = 4'd5,
    ACTION_ACTIVATE_COMPUTE_UNIT  = 4'd6,
    ACTION_DEACTIVATE_COMPUTE_UNIT= 4'd7,
    ACTION_CHANGE_WORK_DIST       = 4'd8,
    ACTION_MAINTAIN_CONFIGURATION = 4'd9
  } action_e;

  // ---------------------------------------------------------------------
  // Section 14: candidate configuration presented to the constraint
  // engine, and the hard-limit register file it is checked against.
  // ---------------------------------------------------------------------
  typedef struct packed {
    fixed_t power;
    fixed_t temperature;
    fixed_t frequency;
    fixed_t voltage;
    fixed_t parallelism;
  } candidate_cfg_t;

  typedef struct packed {
    fixed_t power_max;
    fixed_t temperature_max;
    fixed_t freq_min;
    fixed_t freq_max;
    fixed_t voltage_min;
    fixed_t voltage_max;
    fixed_t parallelism_min;
    fixed_t parallelism_max;
  } hard_limits_t;

  typedef struct packed {
    logic power_violation;
    logic thermal_violation;
    logic frequency_violation;
    logic voltage_violation;
    logic resource_violation;
  } violation_flags_t;

  // ---------------------------------------------------------------------
  // Section 24: central learning FSM states.
  // ---------------------------------------------------------------------
  typedef enum logic [3:0] {
    ST_IDLE     = 4'd0,
    ST_OBSERVE  = 4'd1,
    ST_FEATURE  = 4'd2,
    ST_PREDICT  = 4'd3,
    ST_EVALUATE = 4'd4,
    ST_UPDATE   = 4'd5,
    ST_SELECT   = 4'd6,
    ST_VALIDATE = 4'd7,
    ST_APPLY    = 4'd8
  } fsm_state_e;

endpackage : silicaflux_ml_pkg
