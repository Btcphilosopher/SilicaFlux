// =============================================================================
// constraint_engine.sv
// -----------------------------------------------------------------------------
// Section 14: candidate configuration -> {power, thermal, frequency,
// voltage, resource} checks -> VALID/INVALID. Pure combinational comparator
// logic against a hard-limit register file that is configured by firmware/a
// safety authority and is NEVER written by the learning datapath -- there is
// no port on this module the WeightUpdater or ActionValueTable can reach.
//
// `trip_action` is the independent safety watchdog: given the fabric's
// ACTUAL current telemetry (not a proposed candidate), it can force a
// corrective action outside the learning algorithm entirely, the same way a
// thermal-throttling circuit (e.g. PROCHOT) works independently of firmware.
//
// Python reference: python/silicaflux_ml/constraint_engine.py.
// =============================================================================

`include "silicaflux_ml_pkg.sv"

module constraint_engine (
  input  silicaflux_ml_pkg::candidate_cfg_t   candidate_in,
  input  silicaflux_ml_pkg::hard_limits_t     limits,          // firmware/fuse-configured, read-only to the ML datapath

  output logic                                valid_out,
  output silicaflux_ml_pkg::violation_flags_t violations_out
);
  import silicaflux_ml_pkg::*;

  always_comb begin
    violations_out.power_violation      = candidate_in.power > limits.power_max;
    violations_out.thermal_violation    = candidate_in.temperature > limits.temperature_max;
    violations_out.frequency_violation  = (candidate_in.frequency < limits.freq_min) ||
                                           (candidate_in.frequency > limits.freq_max);
    violations_out.voltage_violation    = (candidate_in.voltage < limits.voltage_min) ||
                                           (candidate_in.voltage > limits.voltage_max);
    violations_out.resource_violation   = (candidate_in.parallelism < limits.parallelism_min) ||
                                           (candidate_in.parallelism > limits.parallelism_max);

    valid_out = !(violations_out.power_violation  || violations_out.thermal_violation ||
                  violations_out.frequency_violation || violations_out.voltage_violation ||
                  violations_out.resource_violation);
  end

endmodule : constraint_engine


module safety_watchdog (
  input  silicaflux_ml_pkg::candidate_cfg_t   actual_in,       // fabric's ACTUAL current telemetry
  input  silicaflux_ml_pkg::hard_limits_t     limits,

  output logic                                trip,
  output silicaflux_ml_pkg::action_e          trip_action_out
);
  import silicaflux_ml_pkg::*;

  always_comb begin
    trip = (actual_in.power > limits.power_max) || (actual_in.temperature > limits.temperature_max);
    trip_action_out = ACTION_DECREASE_FREQUENCY;   // independent of whatever action_selector chose
  end

endmodule : safety_watchdog
