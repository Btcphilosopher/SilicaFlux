// =============================================================================
// weight_updater.sv
// -----------------------------------------------------------------------------
// Section 8: online learning engine.
//   error     = observed - predicted
//   weight[i] = clamp(weight[i] + learning_rate * error * feature[i])
// with an error_threshold noise gate and an update_interval cycle-counter
// gate. Python reference: python/silicaflux_ml/weight_updater.py.
// =============================================================================

`include "silicaflux_ml_pkg.sv"

module weight_updater #(
  parameter int NUM_FEATURES = silicaflux_ml_pkg::NUM_FEATURES
) (
  input  logic                              clk,
  input  logic                              rst_n,
  input  logic                              start,

  input  silicaflux_ml_pkg::fixed_t         learning_rate,
  input  silicaflux_ml_pkg::fixed_t         weight_min,
  input  silicaflux_ml_pkg::fixed_t         weight_max,
  input  silicaflux_ml_pkg::fixed_t         error_threshold,
  input  logic [15:0]                       update_interval,   // cycles between updates

  input  silicaflux_ml_pkg::feature_vec_t   features_in,       // feature vector from the PREVIOUS cycle
  input  silicaflux_ml_pkg::fixed_t         observed,
  input  silicaflux_ml_pkg::fixed_t         predicted,

  inout  silicaflux_ml_pkg::fixed_t         weights [NUM_FEATURES],  // read-modify-write register file
  inout  silicaflux_ml_pkg::fixed_t         bias,

  output silicaflux_ml_pkg::fixed_t         error_out,
  output logic                              updated,
  output logic                              done
);
  import silicaflux_ml_pkg::*;
  import fixed_point_ops::*;

  typedef enum logic [1:0] {S_IDLE, S_GATE, S_RUN, S_DONE} state_e;
  state_e state;
  logic [$clog2(NUM_FEATURES)-1:0] idx;
  logic [15:0] interval_counter;
  fixed_t error_reg;
  logic gate_pass;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE; idx <= '0; interval_counter <= '0;
      done <= 1'b0; updated <= 1'b0; error_reg <= '0;
    end else begin
      done    <= 1'b0;
      unique case (state)
        S_IDLE: if (start) begin
          error_reg <= fixed_sub(observed, predicted);
          state <= S_GATE;
        end

        S_GATE: begin
          // update_interval counter: only fire once every N cycles this
          // block is invoked, bounding weight-register switching activity.
          interval_counter <= interval_counter + 1'b1;
          gate_pass = (fixed_abs(error_reg) >= error_threshold) &&
                      (interval_counter >= update_interval);
          if (gate_pass) begin
            interval_counter <= '0;
            idx     <= '0;
            state   <= S_RUN;
            updated <= 1'b1;
          end else begin
            updated <= 1'b0;
            state   <= S_DONE;
          end
        end

        S_RUN: begin
          automatic fixed_t grad = fixed_mul(learning_rate, fixed_mul(error_reg, features_in[idx]));
          weights[idx] <= fixed_clamp_range(fixed_add(weights[idx], grad), weight_min, weight_max);
          if (idx == NUM_FEATURES-1) begin
            bias  <= fixed_clamp_range(fixed_add(bias, fixed_mul(learning_rate, error_reg)), weight_min, weight_max);
            state <= S_DONE;
          end else begin
            idx <= idx + 1'b1;
          end
        end

        S_DONE: begin
          error_out <= error_reg;
          done      <= 1'b1;
          state     <= S_IDLE;
        end
      endcase
    end
  end

endmodule : weight_updater
