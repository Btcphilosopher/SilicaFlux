// =============================================================================
// learning_fsm.sv
// -----------------------------------------------------------------------------
// Section 24: central learning state machine.
//
//   IDLE -> OBSERVE -> FEATURE -> PREDICT -> EVALUATE -> UPDATE -> SELECT ->
//   VALIDATE -> APPLY -> IDLE
//
// A strict one-state-per-cycle Moore machine with a per-pass timeout counter
// that forces a reset to IDLE if a downstream block never asserts its "done"
// pulse (a stuck pipeline stage trips the same kind of watchdog a real
// design would use). Each state asserts exactly one enable pulse into the
// datapath in silicaflux_ml_top.sv.
//
// Python reference: python/silicaflux_ml/fsm.py.
// =============================================================================

`include "silicaflux_ml_pkg.sv"

module learning_fsm #(
  parameter int TIMEOUT_CYCLES = 32
) (
  input  logic                              clk,
  input  logic                              rst_n,

  // Per-stage completion pulses from the datapath blocks the FSM is
  // sequencing (tie a stage's `_done` high combinationally if it always
  // completes within one cycle, e.g. OBSERVE/SELECT/VALIDATE/APPLY below).
  input  logic                              feature_done,
  input  logic                              predict_done,
  input  logic                              update_done,

  output silicaflux_ml_pkg::fsm_state_e     state_out,
  output logic                              observe_en,
  output logic                              feature_en,
  output logic                              predict_en,
  output logic                              evaluate_en,
  output logic                              update_en,
  output logic                              select_en,
  output logic                              validate_en,
  output logic                              apply_en,
  output logic [15:0]                       timeout_count
);
  import silicaflux_ml_pkg::*;

  fsm_state_e state, next_state;
  logic [$clog2(TIMEOUT_CYCLES+1)-1:0] timer;
  logic timed_out;

  assign timed_out = (timer >= TIMEOUT_CYCLES);

  // -- next-state logic: each state waits for its own stage's `done` pulse
  //    where one exists, otherwise advances unconditionally after one cycle.
  always_comb begin
    unique case (state)
      ST_IDLE:     next_state = ST_OBSERVE;              // free-running: OBSERVE begins every cycle
      ST_OBSERVE:  next_state = ST_FEATURE;
      ST_FEATURE:  next_state = feature_done ? ST_PREDICT  : ST_FEATURE;
      ST_PREDICT:  next_state = predict_done ? ST_EVALUATE : ST_PREDICT;
      ST_EVALUATE: next_state = ST_UPDATE;
      ST_UPDATE:   next_state = update_done  ? ST_SELECT   : ST_UPDATE;
      ST_SELECT:   next_state = ST_VALIDATE;
      ST_VALIDATE: next_state = ST_APPLY;
      ST_APPLY:    next_state = ST_IDLE;
      default:     next_state = ST_IDLE;
    endcase
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= ST_IDLE;
      timer <= '0;
      timeout_count <= '0;
    end else if (timed_out) begin
      state <= ST_IDLE;
      timer <= '0;
      timeout_count <= timeout_count + 1'b1;
    end else begin
      state <= next_state;
      timer <= (next_state == ST_IDLE) ? '0 : timer + 1'b1;
    end
  end

  assign state_out   = state;
  assign observe_en  = (state == ST_OBSERVE);
  assign feature_en  = (state == ST_FEATURE);
  assign predict_en  = (state == ST_PREDICT);
  assign evaluate_en = (state == ST_EVALUATE);
  assign update_en   = (state == ST_UPDATE);
  assign select_en   = (state == ST_SELECT);
  assign validate_en = (state == ST_VALIDATE);
  assign apply_en    = (state == ST_APPLY);

endmodule : learning_fsm
