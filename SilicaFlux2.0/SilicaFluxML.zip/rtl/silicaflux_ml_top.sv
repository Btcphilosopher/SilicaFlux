// =============================================================================
// silicaflux_ml_top.sv
// -----------------------------------------------------------------------------
// Section 13/20/22/27: top-level wiring of every block in this directory into
// one learning-and-control loop, sequenced by learning_fsm. This is the RTL
// expression of:
//
//   SilicaFlux fabric -> telemetry -> feature engine -> predictor ->
//   reward engine -> weight updater -> action selector -> constraint
//   engine -> configuration controller -> (back to) SilicaFlux fabric
//
// Exactly one silicaflux_ml_top instance is Modes 0-3's whole learning
// engine; Mode 4 (Section 16/26) instantiates ROWS*COLS of these, one per
// PE, each fed that PE's own local telemetry instead of the fabric-wide
// aggregate the telemetry_engine produces here.
//
// Python reference: python/silicaflux_ml/learning_engine.py (LearningEngine).
// =============================================================================

`include "silicaflux_ml_pkg.sv"

module silicaflux_ml_top #(
  parameter int ROWS = 4,
  parameter int COLS = 4,
  parameter int NUM_FEATURES = silicaflux_ml_pkg::NUM_FEATURES,
  parameter int NUM_OUTPUTS  = silicaflux_ml_pkg::NUM_OUTPUTS,
  parameter int NUM_ACTIONS  = silicaflux_ml_pkg::NUM_ACTIONS,
  parameter int MEMORY_DEPTH = 64
) (
  input  logic                              clk,
  input  logic                              rst_n,

  // -- telemetry in (see telemetry_engine.sv for the per-PE bus shape) --
  input  silicaflux_ml_pkg::fixed_t         pe_utilisation [ROWS*COLS],
  input  silicaflux_ml_pkg::fixed_t         pe_throughput  [ROWS*COLS],
  input  silicaflux_ml_pkg::fixed_t         pe_power       [ROWS*COLS],
  input  silicaflux_ml_pkg::fixed_t         pe_temperature [ROWS*COLS],
  input  silicaflux_ml_pkg::fixed_t         pe_errors      [ROWS*COLS],
  input  silicaflux_ml_pkg::fixed_t         pe_queue_depth [ROWS*COLS],
  input  logic [ROWS*COLS-1:0]              pe_active,

  // -- configuration registers (firmware-writable) --
  input  silicaflux_ml_pkg::fixed_t         weights_predict [NUM_OUTPUTS][NUM_FEATURES],
  input  silicaflux_ml_pkg::fixed_t         biases_predict  [NUM_OUTPUTS],
  input  silicaflux_ml_pkg::fixed_t         learning_rate,
  input  silicaflux_ml_pkg::fixed_t         weight_min,
  input  silicaflux_ml_pkg::fixed_t         weight_max,
  input  silicaflux_ml_pkg::fixed_t         error_threshold,
  input  logic [15:0]                       update_interval,
  input  silicaflux_ml_pkg::fixed_t         reward_throughput_weight,
  input  silicaflux_ml_pkg::fixed_t         reward_efficiency_weight,
  input  silicaflux_ml_pkg::fixed_t         reward_power_weight,
  input  silicaflux_ml_pkg::fixed_t         reward_thermal_weight,
  input  silicaflux_ml_pkg::fixed_t         reward_error_weight,
  input  silicaflux_ml_pkg::fixed_t         invalid_action_penalty,
  input  silicaflux_ml_pkg::fixed_t         epsilon,
  input  silicaflux_ml_pkg::fixed_t         action_learning_rate,
  input  silicaflux_ml_pkg::hard_limits_t   hard_limits,          // Section 14 -- NOT reachable from the ML datapath

  // -- outputs to the configuration controller (Section 13) --
  output silicaflux_ml_pkg::action_e        action_out,
  output logic                              action_valid,
  output logic                              safety_override,
  output silicaflux_ml_pkg::fsm_state_e     fsm_state_out,
  output logic [15:0]                       fsm_timeout_count
);
  import silicaflux_ml_pkg::*;

  // ---------------------------------------------------------------------
  // FSM
  // ---------------------------------------------------------------------
  logic feature_done, predict_done, update_done;
  logic observe_en, feature_en, predict_en, evaluate_en, update_en, select_en, validate_en, apply_en;

  learning_fsm #(.TIMEOUT_CYCLES(32)) u_fsm (
    .clk, .rst_n,
    .feature_done, .predict_done, .update_done,
    .state_out(fsm_state_out),
    .observe_en, .feature_en, .predict_en, .evaluate_en, .update_en, .select_en, .validate_en, .apply_en,
    .timeout_count(fsm_timeout_count)
  );

  // ---------------------------------------------------------------------
  // Stage 1/2: telemetry capture + feature extraction
  // ---------------------------------------------------------------------
  state_vector_t   state_vec;
  logic            state_valid;
  feature_vec_t    features;
  logic            features_valid;

  telemetry_engine #(.ROWS(ROWS), .COLS(COLS)) u_telemetry (
    .clk, .rst_n, .sample_start(observe_en),
    .pe_utilisation, .pe_throughput, .pe_power, .pe_temperature, .pe_errors, .pe_queue_depth, .pe_active,
    .clock_frequency_reg(state_vec.clock_frequency), .voltage_reg(state_vec.voltage),
    .state_out(state_vec), .state_valid
  );

  feature_engine u_features (
    .clk, .rst_n, .sample_valid(feature_en && state_valid),
    .state_in(state_vec),
    .features_out(features), .features_valid
  );
  assign feature_done = features_valid;

  // ---------------------------------------------------------------------
  // Stage 3: prediction
  // ---------------------------------------------------------------------
  fixed_t predicted [NUM_OUTPUTS];
  logic   predict_all_done;

  predictor #(.NUM_FEATURES(NUM_FEATURES), .NUM_OUTPUTS(NUM_OUTPUTS)) u_predictor (
    .clk, .rst_n, .start(predict_en),
    .features_in(features),
    .weights(weights_predict), .biases(biases_predict),
    .predicted_out(predicted), .all_done(predict_all_done)
  );
  assign predict_done = predict_all_done;

  // ---------------------------------------------------------------------
  // Stage 4/6: error + weight update (one output_model's weights per
  // instance -- replicate weight_updater NUM_OUTPUTS times in the full
  // design; a single instance is shown here for clarity).
  // ---------------------------------------------------------------------
  fixed_t observed_throughput;   // from state_vec / features, wired per-output in the full design
  assign observed_throughput = state_vec.throughput;

  fixed_t error_throughput;
  logic   weight_updated, weight_update_done;

  weight_updater #(.NUM_FEATURES(NUM_FEATURES)) u_weight_updater_throughput (
    .clk, .rst_n, .start(update_en),
    .learning_rate, .weight_min, .weight_max, .error_threshold, .update_interval,
    .features_in(features), .observed(observed_throughput), .predicted(predicted[OUT_THROUGHPUT]),
    .weights(weights_predict[OUT_THROUGHPUT]), .bias(biases_predict[OUT_THROUGHPUT]),
    .error_out(error_throughput), .updated(weight_updated), .done(weight_update_done)
  );
  assign update_done = weight_update_done;

  // ---------------------------------------------------------------------
  // Stage 5/7: reward + action selection (contextual linear-Q path per
  // learning_engine.py's Mode-3 policy: action_value_table rows are
  // written externally each cycle from a per-action output_model bank,
  // omitted here for brevity -- see docs/05_LEARNING_ALGORITHM.md).
  // ---------------------------------------------------------------------
  fixed_t reward;
  logic   reward_valid;
  fixed_t efficiency, thermal_penalty; // computed upstream from `features` (power_efficiency, temp-vs-threshold)

  reward_engine u_reward (
    .clk, .rst_n, .valid_in(select_en),
    .throughput_weight(reward_throughput_weight), .efficiency_weight(reward_efficiency_weight),
    .power_weight(reward_power_weight), .thermal_weight(reward_thermal_weight), .error_weight(reward_error_weight),
    .invalid_action_penalty,
    .throughput(state_vec.throughput), .efficiency, .power(state_vec.power),
    .thermal_penalty, .errors(state_vec.error_rate),
    .action_invalid(1'b0),   // latched true post-hoc once constraint_engine below has run
    .reward_out(reward), .valid_out(reward_valid)
  );

  fixed_t action_values [NUM_ACTIONS];
  logic [31:0] action_visits [NUM_ACTIONS];

  action_value_table u_action_values (
    .clk, .rst_n, .update_en(select_en && reward_valid),
    .update_action(action_out), .reward_in(reward), .action_learning_rate,
    .value_out(action_values), .visits_out(action_visits)
  );

  action_selector u_action_selector (
    .clk, .rst_n, .select_en,
    .value_in(action_values), .epsilon,
    .action_out, .valid_out(action_valid)
  );

  // ---------------------------------------------------------------------
  // Stage 8: constraint validation + independent safety watchdog
  // ---------------------------------------------------------------------
  candidate_cfg_t candidate, actual;
  logic constraint_valid;
  violation_flags_t violations;

  // `candidate` is built by a small combinational "what would this action
  // do" block (fabric-specific -- see fabric.py candidate_for_action for
  // the reference mapping) omitted here; `actual` is simply the fabric's
  // present configuration readback.
  constraint_engine u_constraints (
    .candidate_in(candidate), .limits(hard_limits),
    .valid_out(constraint_valid), .violations_out(violations)
  );

  safety_watchdog u_watchdog (
    .actual_in(actual), .limits(hard_limits),
    .trip(safety_override), .trip_action_out()
  );

  // ---------------------------------------------------------------------
  // Stage 9: learning-memory retirement
  // ---------------------------------------------------------------------
  fixed_t predicted_arr [NUM_OUTPUTS], observed_arr [NUM_OUTPUTS], error_arr [NUM_OUTPUTS];
  assign predicted_arr = predicted;

  learning_memory #(.DEPTH(MEMORY_DEPTH), .NUM_FEATURES(NUM_FEATURES), .NUM_OUTPUTS(NUM_OUTPUTS)) u_memory (
    .clk, .rst_n, .write_en(apply_en),
    .state_in(features), .action_in(action_out),
    .predicted_in(predicted_arr), .observed_in(observed_arr), .reward_in(reward), .error_in(error_arr),
    .read_addr('0),
    .state_out(), .action_out(), .predicted_out(), .observed_out(), .reward_out(), .error_out(),
    .count_out()
  );

endmodule : silicaflux_ml_top
