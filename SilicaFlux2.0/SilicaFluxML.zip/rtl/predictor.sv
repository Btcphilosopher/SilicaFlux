// =============================================================================
// predictor.sv
// -----------------------------------------------------------------------------
// Section 6/7: hardware-native affine model, Y = W . X + B, replicated once
// per predicted output (throughput/power/temperature/latency/error_prob).
// Python reference: python/silicaflux_ml/predictor.py (OutputModel/Predictor).
// =============================================================================

`include "silicaflux_ml_pkg.sv"

module mac_unit (
  input  logic                        clk,
  input  logic                        rst_n,
  input  logic                        clear,     // start a new dot-product
  input  logic                        mac_en,
  input  silicaflux_ml_pkg::fixed_t   a_in,
  input  silicaflux_ml_pkg::fixed_t   b_in,
  output silicaflux_ml_pkg::fixed_t   result_out  // saturated read-out
);
  import silicaflux_ml_pkg::*;
  import fixed_point_ops::*;

  acc_t acc_reg;
  localparam acc_t ACC_MAX = {1'b0, {(ACC_W-1){1'b1}}};
  localparam acc_t ACC_MIN = {1'b1, {(ACC_W-1){1'b0}}};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      acc_reg <= '0;
    end else if (clear) begin
      acc_reg <= '0;
    end else if (mac_en) begin
      automatic logic signed [2*WORD_W-1:0] product = a_in * b_in;
      automatic acc_t rescaled = acc_t'(product >>> FRAC_BITS);
      automatic acc_t sum = acc_reg + rescaled;
      // Accumulate at full ACC_W width -- do NOT saturate between terms,
      // only clip on the final read-out below (fixed_point.MacUnit.mac()).
      if (sum > ACC_MAX) acc_reg <= ACC_MAX;
      else if (sum < ACC_MIN) acc_reg <= ACC_MIN;
      else acc_reg <= sum;
    end
  end

  assign result_out = fixed_clip(acc_reg);

endmodule : mac_unit


// One output model: a weight-register file, a bias register, and a MAC
// pipeline that walks the feature vector one MAC per cycle (a fully
// unrolled / combinational NUM_FEATURES-wide tree is the obvious
// alternative at higher LUT cost for lower latency -- see
// docs/09_SYNTHESIS_ESTIMATION.md for the area/latency trade discussion).
module output_model #(
  parameter int NUM_FEATURES = silicaflux_ml_pkg::NUM_FEATURES
) (
  input  logic                                clk,
  input  logic                                rst_n,
  input  logic                                start,
  input  silicaflux_ml_pkg::feature_vec_t     features_in,
  input  silicaflux_ml_pkg::fixed_t           weights [NUM_FEATURES],  // weight register file
  input  silicaflux_ml_pkg::fixed_t           bias,

  output silicaflux_ml_pkg::fixed_t           predicted_out,
  output logic                                done
);
  import silicaflux_ml_pkg::*;
  import fixed_point_ops::*;

  typedef enum logic [1:0] {S_IDLE, S_RUN, S_DONE} state_e;
  state_e state;
  logic [$clog2(NUM_FEATURES)-1:0] idx;
  logic mac_clear, mac_en;
  fixed_t mac_result;

  mac_unit u_mac (
    .clk, .rst_n, .clear(mac_clear), .mac_en,
    .a_in(weights[idx]), .b_in(features_in[idx]), .result_out(mac_result)
  );

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE; idx <= '0; done <= 1'b0; mac_clear <= 1'b0; mac_en <= 1'b0;
    end else begin
      mac_clear <= 1'b0;
      mac_en    <= 1'b0;
      unique case (state)
        S_IDLE: begin
          done <= 1'b0;
          if (start) begin
            idx <= '0; mac_clear <= 1'b1; state <= S_RUN;
          end
        end
        S_RUN: begin
          mac_en <= 1'b1;
          if (idx == NUM_FEATURES-1) state <= S_DONE;
          else idx <= idx + 1'b1;
        end
        S_DONE: begin
          predicted_out <= fixed_add(mac_result, bias);
          done  <= 1'b1;
          state <= S_IDLE;
        end
      endcase
    end
  end

endmodule : output_model


// Section 7: fan the shared feature vector out to NUM_OUTPUTS parallel
// output_model instances -- the STATE VECTOR -> {THROUGHPUT, POWER,
// TEMPERATURE, ...} MODEL diagram.
module predictor #(
  parameter int NUM_FEATURES = silicaflux_ml_pkg::NUM_FEATURES,
  parameter int NUM_OUTPUTS  = silicaflux_ml_pkg::NUM_OUTPUTS
) (
  input  logic                              clk,
  input  logic                              rst_n,
  input  logic                              start,
  input  silicaflux_ml_pkg::feature_vec_t   features_in,
  input  silicaflux_ml_pkg::fixed_t         weights [NUM_OUTPUTS][NUM_FEATURES],
  input  silicaflux_ml_pkg::fixed_t         biases  [NUM_OUTPUTS],

  output silicaflux_ml_pkg::fixed_t         predicted_out [NUM_OUTPUTS],
  output logic                              all_done
);
  logic [NUM_OUTPUTS-1:0] done_vec;
  assign all_done = &done_vec;

  genvar g;
  generate
    for (g = 0; g < NUM_OUTPUTS; g++) begin : g_output_models
      output_model #(.NUM_FEATURES(NUM_FEATURES)) u_model (
        .clk, .rst_n, .start,
        .features_in,
        .weights(weights[g]),
        .bias(biases[g]),
        .predicted_out(predicted_out[g]),
        .done(done_vec[g])
      );
    end
  endgenerate

endmodule : predictor
