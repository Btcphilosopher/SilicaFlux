// =============================================================================
// action_selector.sv
// -----------------------------------------------------------------------------
// Section 10/11: action-value table (one fixed-point value register + visit
// counter per action) and the epsilon-greedy selector -- the default
// strategy because it needs only a comparator tree and one PRNG compare.
//
// Softmax and UCB (also named in Section 11) need a LUT-approximated exp()/
// log()/sqrt() to go to silicon; python/silicaflux_ml/action_selector.py
// implements them in floating point for SOFTWARE-SIDE comparison only, and
// this file intentionally does not restate that caveat in gates -- see
// docs/06_ACTION_SPACE.md for the LUT-approximation sketch if silicon
// support for those strategies is ever required.
//
// Python reference: python/silicaflux_ml/action_selector.py.
// =============================================================================

`include "silicaflux_ml_pkg.sv"

module lfsr_prng #(parameter int WIDTH = 16) (
  input  logic             clk,
  input  logic             rst_n,
  input  logic             advance,
  output logic [WIDTH-1:0] value
);
  // A maximal-length Fibonacci LFSR is a perfectly adequate, fully
  // deterministic (and therefore bit-accurate-testbench-friendly) PRNG
  // for epsilon-greedy exploration -- no claim of cryptographic quality.
  logic [WIDTH-1:0] state;
  wire feedback = state[WIDTH-1] ^ state[WIDTH-2] ^ state[WIDTH-3] ^ state[WIDTH-5];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) state <= {WIDTH{1'b1}};
    else if (advance) state <= {state[WIDTH-2:0], feedback};
  end
  assign value = state;
endmodule


module action_value_table (
  input  logic                              clk,
  input  logic                              rst_n,
  input  logic                              update_en,
  input  silicaflux_ml_pkg::action_e        update_action,
  input  silicaflux_ml_pkg::fixed_t         reward_in,
  input  silicaflux_ml_pkg::fixed_t         action_learning_rate,

  output silicaflux_ml_pkg::fixed_t         value_out [silicaflux_ml_pkg::NUM_ACTIONS],
  output logic [31:0]                       visits_out [silicaflux_ml_pkg::NUM_ACTIONS]
);
  import silicaflux_ml_pkg::*;
  import fixed_point_ops::*;

  fixed_t value_reg [NUM_ACTIONS];
  logic [31:0] visits_reg [NUM_ACTIONS];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NUM_ACTIONS; i++) begin
        value_reg[i]  <= '0;
        visits_reg[i] <= '0;
      end
    end else if (update_en) begin
      automatic fixed_t err = fixed_sub(reward_in, value_reg[update_action]);
      value_reg[update_action]  <= fixed_add(value_reg[update_action], fixed_mul(action_learning_rate, err));
      visits_reg[update_action] <= visits_reg[update_action] + 1'b1;
    end
  end

  assign value_out  = value_reg;
  assign visits_out = visits_reg;

endmodule : action_value_table


module action_selector (
  input  logic                              clk,
  input  logic                              rst_n,
  input  logic                              select_en,

  input  silicaflux_ml_pkg::fixed_t         value_in [silicaflux_ml_pkg::NUM_ACTIONS],
  input  silicaflux_ml_pkg::fixed_t         epsilon,          // Q-format probability in [0, 1<<FRAC_BITS]

  output silicaflux_ml_pkg::action_e        action_out,
  output logic                              valid_out
);
  import silicaflux_ml_pkg::*;
  import fixed_point_ops::*;

  // -- greedy argmax over the value table (used every cycle: as the
  //    exploit branch of epsilon-greedy, and directly for pure "greedy") --
  action_e greedy_action;
  always_comb begin
    automatic fixed_t best_val = value_in[0];
    greedy_action = action_e'(0);
    for (int i = 1; i < NUM_ACTIONS; i++) begin
      if (value_in[i] > best_val) begin
        best_val = value_in[i];
        greedy_action = action_e'(i);
      end
    end
  end

  // -- epsilon-greedy: one PRNG draw compared against the epsilon
  //    register, one mux between "explore" (PRNG-selected action) and
  //    "exploit" (greedy_action) --
  logic [15:0] prng_value;
  lfsr_prng #(.WIDTH(16)) u_prng (.clk, .rst_n, .advance(select_en), .value(prng_value));

  fixed_t epsilon_scaled;
  action_e explore_action;
  assign epsilon_scaled = fixed_t'((acc_t'(epsilon) * (1 <<< 16)) >>> FRAC_BITS); // epsilon on a 16-bit PRNG scale
  assign explore_action = action_e'(prng_value % NUM_ACTIONS);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      action_out <= ACTION_MAINTAIN_CONFIGURATION;
      valid_out  <= 1'b0;
    end else if (select_en) begin
      action_out <= (prng_value < epsilon_scaled[15:0]) ? explore_action : greedy_action;
      valid_out  <= 1'b1;
    end else begin
      valid_out <= 1'b0;
    end
  end

endmodule : action_selector
