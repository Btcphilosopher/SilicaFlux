// =============================================================================
// learning_memory.sv
// -----------------------------------------------------------------------------
// Section 12: a small circular buffer of recent (state, action, predicted,
// observed, reward, error) records -- a single on-chip BRAM with a wrapping
// write pointer, NOT a neural-network-scale replay memory. Depth is a
// synthesis-time parameter (default 64).
//
// Python reference: python/silicaflux_ml/learning_memory.py.
// =============================================================================

`include "silicaflux_ml_pkg.sv"

module learning_memory #(
  parameter int DEPTH        = 64,
  parameter int NUM_FEATURES = silicaflux_ml_pkg::NUM_FEATURES,
  parameter int NUM_OUTPUTS  = silicaflux_ml_pkg::NUM_OUTPUTS
) (
  input  logic                              clk,
  input  logic                              rst_n,
  input  logic                              write_en,

  input  silicaflux_ml_pkg::feature_vec_t   state_in,
  input  silicaflux_ml_pkg::action_e        action_in,
  input  silicaflux_ml_pkg::fixed_t         predicted_in [NUM_OUTPUTS],
  input  silicaflux_ml_pkg::fixed_t         observed_in  [NUM_OUTPUTS],
  input  silicaflux_ml_pkg::fixed_t         reward_in,
  input  silicaflux_ml_pkg::fixed_t         error_in     [NUM_OUTPUTS],

  // Read port: combinational read of the entry `read_addr` cycles behind
  // the current write pointer (0 = most recently written entry).
  input  logic [$clog2(DEPTH)-1:0]          read_addr,
  output silicaflux_ml_pkg::feature_vec_t   state_out,
  output silicaflux_ml_pkg::action_e        action_out,
  output silicaflux_ml_pkg::fixed_t         predicted_out [NUM_OUTPUTS],
  output silicaflux_ml_pkg::fixed_t         observed_out  [NUM_OUTPUTS],
  output silicaflux_ml_pkg::fixed_t         reward_out,
  output silicaflux_ml_pkg::fixed_t         error_out     [NUM_OUTPUTS],

  output logic [$clog2(DEPTH):0]            count_out       // number of valid entries, saturates at DEPTH
);
  import silicaflux_ml_pkg::*;

  localparam int ADDR_W = $clog2(DEPTH);

  silicaflux_ml_pkg::feature_vec_t   state_mem     [DEPTH];
  action_e                           action_mem    [DEPTH];
  fixed_t                            predicted_mem [DEPTH][NUM_OUTPUTS];
  fixed_t                            observed_mem  [DEPTH][NUM_OUTPUTS];
  fixed_t                            reward_mem    [DEPTH];
  fixed_t                            error_mem     [DEPTH][NUM_OUTPUTS];

  logic [ADDR_W-1:0] wr_ptr;
  logic [ADDR_W:0]   count;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wr_ptr <= '0;
      count  <= '0;
    end else if (write_en) begin
      state_mem[wr_ptr]     <= state_in;
      action_mem[wr_ptr]    <= action_in;
      predicted_mem[wr_ptr] <= predicted_in;
      observed_mem[wr_ptr]  <= observed_in;
      reward_mem[wr_ptr]    <= reward_in;
      error_mem[wr_ptr]     <= error_in;

      wr_ptr <= (wr_ptr == DEPTH-1) ? '0 : wr_ptr + 1'b1;
      if (count < DEPTH) count <= count + 1'b1;   // saturates: circular OVERWRITE after this
    end
  end

  // read_addr indexes back from the most-recently-written entry.
  wire [ADDR_W-1:0] phys_addr = (wr_ptr - 1'b1 - read_addr[ADDR_W-1:0]) % DEPTH;

  assign state_out     = state_mem[phys_addr];
  assign action_out    = action_mem[phys_addr];
  assign predicted_out = predicted_mem[phys_addr];
  assign observed_out  = observed_mem[phys_addr];
  assign reward_out    = reward_mem[phys_addr];
  assign error_out     = error_mem[phys_addr];
  assign count_out     = count;

endmodule : learning_memory
