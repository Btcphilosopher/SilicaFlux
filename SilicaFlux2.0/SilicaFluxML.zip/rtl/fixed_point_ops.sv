// =============================================================================
// fixed_point_ops.sv
// -----------------------------------------------------------------------------
// Section 21: fixed-point arithmetic primitives, as combinational functions
// over silicaflux_ml_pkg::fixed_t. Mirrors python/silicaflux_ml/fixed_point.py
// term for term -- same saturate-don't-wrap discipline, same wide-then-clip
// multiply, same truncating divide.
// =============================================================================

package fixed_point_ops;

  import silicaflux_ml_pkg::*;

  // ---- saturation ------------------------------------------------------
  function automatic fixed_t fixed_clip(input acc_t wide);
    if (wide > $signed({1'b0, {(WORD_W-1){1'b1}}}))
      fixed_clip = {1'b0, {(WORD_W-1){1'b1}}};          // +max
    else if (wide < $signed({1'b1, {(WORD_W-1){1'b0}}}))
      fixed_clip = {1'b1, {(WORD_W-1){1'b0}}};          // -min
    else
      fixed_clip = wide[WORD_W-1:0];
  endfunction

  // ---- add / sub ---------------------------------------------------------
  function automatic fixed_t fixed_add(input fixed_t a, input fixed_t b);
    fixed_add = fixed_clip(acc_t'(a) + acc_t'(b));
  endfunction

  function automatic fixed_t fixed_sub(input fixed_t a, input fixed_t b);
    fixed_sub = fixed_clip(acc_t'(a) - acc_t'(b));
  endfunction

  // ---- multiply ------------------------------------------------------------
  // Full double-width product, rescaled by FRAC_BITS (an arithmetic right
  // shift = truncating divide by 2**FRAC_BITS), THEN saturated. This is
  // exactly what a single DSP-slice multiplier + rescale/saturate output
  // stage does.
  function automatic fixed_t fixed_mul(input fixed_t a, input fixed_t b);
    logic signed [2*WORD_W-1:0] product;
    logic signed [2*WORD_W-1:0] rescaled;
    product  = a * b;
    rescaled = product >>> FRAC_BITS;
    fixed_mul = fixed_clip(acc_t'(rescaled));
  endfunction

  // ---- divide --------------------------------------------------------------
  // Guarded: b == 0 saturates to +max/-min by sign of `a`, matching a
  // hardware divider that refuses to hang the pipeline on a zero divisor.
  function automatic fixed_t fixed_div(input fixed_t a, input fixed_t b);
    logic signed [2*WORD_W-1:0] numerator;
    logic signed [2*WORD_W-1:0] quotient;
    if (b == '0) begin
      fixed_div = (a >= 0) ? {1'b0, {(WORD_W-1){1'b1}}} : {1'b1, {(WORD_W-1){1'b0}}};
    end else begin
      numerator = acc_t'(a) <<< FRAC_BITS;
      quotient  = numerator / b;   // truncating divide toward zero
      fixed_div = fixed_clip(acc_t'(quotient));
    end
  endfunction

  // ---- divide by a plain integer count register (ring-buffer averages) ----
  function automatic fixed_t fixed_div_int(input fixed_t a, input int unsigned n);
    if (n == 0)
      fixed_div_int = '0;
    else
      fixed_div_int = fixed_clip(acc_t'(a) / acc_t'(n));
  endfunction

  // ---- abs / compare ---------------------------------------------------------
  function automatic fixed_t fixed_abs(input fixed_t a);
    fixed_abs = (a[WORD_W-1]) ? fixed_clip(-acc_t'(a)) : a;
  endfunction

  typedef enum logic [1:0] {CMP_LT = 2'b00, CMP_EQ = 2'b01, CMP_GT = 2'b10} cmp_e;

  function automatic cmp_e fixed_compare(input fixed_t a, input fixed_t b);
    if (a < b) fixed_compare = CMP_LT;
    else if (a > b) fixed_compare = CMP_GT;
    else fixed_compare = CMP_EQ;
  endfunction

  function automatic fixed_t fixed_clamp_range(input fixed_t a, input fixed_t lo, input fixed_t hi);
    if (a < lo) fixed_clamp_range = lo;
    else if (a > hi) fixed_clamp_range = hi;
    else fixed_clamp_range = a;
  endfunction

endpackage : fixed_point_ops
