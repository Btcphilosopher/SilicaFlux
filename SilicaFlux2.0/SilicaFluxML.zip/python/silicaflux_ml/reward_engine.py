"""
silicaflux_ml.reward_engine
==============================

Section 9 (Reward Engine).

    reward = throughput_weight * throughput
           + efficiency_weight * efficiency
           - power_weight      * power
           - thermal_weight    * thermal_penalty
           - error_weight      * errors

All five coefficients are configurable registers; the whole computation
is five multiplies and four adds through fixed-point saturating
arithmetic -- a fixed, small, combinational (or single-cycle pipelined)
block.
"""

from __future__ import annotations

from .fixed_point import FixedFormat, DEFAULT_FORMAT, fixed_add, fixed_sub, fixed_mul


class RewardConfig:
    __slots__ = (
        "throughput_weight",
        "efficiency_weight",
        "power_weight",
        "thermal_weight",
        "error_weight",
        "invalid_action_penalty",
    )

    def __init__(
        self,
        throughput_weight: int,
        efficiency_weight: int,
        power_weight: int,
        thermal_weight: int,
        error_weight: int,
        invalid_action_penalty: int,
    ):
        self.throughput_weight = throughput_weight
        self.efficiency_weight = efficiency_weight
        self.power_weight = power_weight
        self.thermal_weight = thermal_weight
        self.error_weight = error_weight
        self.invalid_action_penalty = invalid_action_penalty


class RewardEngine:
    """Hardware reward-calculation block (Section 9)."""

    def __init__(self, fmt: FixedFormat, cfg: RewardConfig):
        self.fmt = fmt
        self.cfg = cfg

    def compute(self, throughput: int, efficiency: int, power: int, thermal_penalty: int, errors: int) -> int:
        fmt = self.fmt
        cfg = self.cfg
        reward = fixed_mul(cfg.throughput_weight, throughput, fmt)
        reward = fixed_add(reward, fixed_mul(cfg.efficiency_weight, efficiency, fmt), fmt)
        reward = fixed_sub(reward, fixed_mul(cfg.power_weight, power, fmt), fmt)
        reward = fixed_sub(reward, fixed_mul(cfg.thermal_weight, thermal_penalty, fmt), fmt)
        reward = fixed_sub(reward, fixed_mul(cfg.error_weight, errors, fmt), fmt)
        return reward

    def penalise_invalid(self, reward: int) -> int:
        """Applied by the ConstraintEngine path (Section 14): an invalid
        candidate configuration receives a negative reward on top of
        whatever the natural reward computation produced."""
        return fixed_sub(reward, self.cfg.invalid_action_penalty, self.fmt)
