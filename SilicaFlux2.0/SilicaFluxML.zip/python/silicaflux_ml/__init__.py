"""
SilicaFlux-ML
=============

Hardware-native machine-learning optimisation engine for the SilicaFlux
parallel compute fabric.

Every class in this package is a *bit-accurate software model* of a
digital hardware block: registers are plain attributes, counters are
integers, "memory" is a bounded ring/circular buffer, and all arithmetic
goes through :mod:`silicaflux_ml.fixed_point` instead of Python floats.
Nothing in the inference or learning path uses floating point, numpy,
or any external ML runtime -- the only floats that exist anywhere in
this package live in the *digital-twin fabric simulator*
(:mod:`silicaflux_ml.fabric`), which stands in for physical silicon and
would not exist in the real chip.

See ``docs/`` in the repository root for the full architecture
specification, and ``rtl/`` for RTL-oriented pseudocode of each block.
"""

__version__ = "1.0.0"
