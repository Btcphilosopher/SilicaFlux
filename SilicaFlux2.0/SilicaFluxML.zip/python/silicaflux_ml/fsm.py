"""
silicaflux_ml.fsm
====================

Section 24 (Hardware State Machine) / Section 20 (Model Update Pipeline).

    IDLE -> OBSERVE -> FEATURE -> PREDICT -> EVALUATE -> UPDATE ->
    SELECT -> VALIDATE -> APPLY -> IDLE

A strict Moore machine: exactly one state transition per ``step()`` call
(one call == one clock edge), with a per-pass timeout counter that forces
a return to IDLE if a handler never completes (a stuck pipeline stage on
real silicon would trip the same kind of watchdog).
"""

from __future__ import annotations

from enum import IntEnum


class FSMState(IntEnum):
    IDLE = 0
    OBSERVE = 1
    FEATURE = 2
    PREDICT = 3
    EVALUATE = 4
    UPDATE = 5
    SELECT = 6
    VALIDATE = 7
    APPLY = 8


class LearningFSM:
    """Central learning finite-state machine (Section 24).

    ``handlers`` passed to :meth:`step` is a ``{FSMState: callable}`` map;
    the callable for the CURRENT state is invoked before advancing. A
    missing handler is legal (that state becomes a pure pass-through
    cycle) so callers only need to wire the stages they use.
    """

    ORDER = (
        FSMState.IDLE,
        FSMState.OBSERVE,
        FSMState.FEATURE,
        FSMState.PREDICT,
        FSMState.EVALUATE,
        FSMState.UPDATE,
        FSMState.SELECT,
        FSMState.VALIDATE,
        FSMState.APPLY,
    )

    def __init__(self, timeout_cycles: int = 32):
        self.state = FSMState.IDLE
        self.timeout_cycles = timeout_cycles
        self._timer = 0
        self.timeout_count = 0

    def reset(self) -> None:
        self.state = FSMState.IDLE
        self._timer = 0

    def next_state(self) -> FSMState:
        idx = self.ORDER.index(self.state)
        return self.ORDER[(idx + 1) % len(self.ORDER)]

    def step(self, handlers: dict | None = None) -> FSMState:
        handlers = handlers or {}
        self._timer += 1
        if self._timer > self.timeout_cycles:
            self.timeout_count += 1
            self.reset()
            return self.state

        handler = handlers.get(self.state)
        if handler is not None:
            handler()

        self.state = self.next_state()
        if self.state == FSMState.IDLE:
            self._timer = 0
        return self.state

    def run_full_pass(self, handlers: dict) -> list:
        """Advance through exactly one full IDLE->...->APPLY->IDLE pass,
        returning the sequence of states visited (for verification)."""
        visited = [self.state]
        for _ in range(len(self.ORDER)):
            visited.append(self.step(handlers))
        return visited
