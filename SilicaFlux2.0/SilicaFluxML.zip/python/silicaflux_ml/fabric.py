"""
silicaflux_ml.fabric
=======================

Section 15 (SilicaFlux Fabric Model) / 16 (Workload Distribution Learning)
/ 17 (Thermal-Aware Learning) / 18 (Power-Aware Learning) / 19
(Fault-Aware Learning).

This is the ONE part of the package that is explicitly a *simulation*
model of physical silicon, not a hardware block itself -- it stands in
for what a real SilicaFlux die would do physically in response to a
configuration, so the learning engine has something to learn from. It
is intentionally built with plain floats: nothing here is meant to be
synthesised, only the LearningEngine/RTL side is.

Grid of processing elements:

    PE PE PE PE
    PE PE PE PE
    PE PE PE PE
    PE PE PE PE

Each PE exposes: utilisation, latency, temperature, power, errors,
throughput, queue_depth -- and a thermal-diffusion coupling to its
4-connected neighbours so concentrating workload in one region visibly
heats that region (Section 17).
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from .action_selector import Action
from .constraint_engine import CandidateConfiguration
from .state_vector import HardwareStateVector


def clip01(x: float) -> float:
    return 0.0 if x < 0.0 else (1.0 if x > 1.0 else x)


@dataclass
class PEState:
    row: int
    col: int
    utilisation: float = 0.0
    throughput: float = 0.0
    latency: float = 0.05
    temperature: float = 40.0
    power: float = 0.2
    errors: float = 0.0
    queue_depth: float = 0.0
    allocation: float = 1.0  # relative workload share, redistributed by the scheduler
    active: bool = True
    degraded: bool = False  # permanent fault flag (Section 19)

    @property
    def pid(self):
        return (self.row, self.col)


@dataclass
class WorkloadGenerator:
    """Synthetic workload generator (Section 28): sinusoidal base load +
    noise + occasional step changes + occasional injected faults."""

    seed: int = 0
    base_period: int = 400
    fault_probability: float = 0.0015
    fault_duration: int = 60

    def __post_init__(self):
        self.rng = random.Random(self.seed)
        self._fault_pe = None
        self._fault_remaining = 0
        self._step_level = 0.6

    def next(self, cycle: int, grid_shape: tuple[int, int]):
        import math

        wave = 0.5 + 0.35 * math.sin(2 * math.pi * cycle / self.base_period)
        noise = self.rng.uniform(-0.05, 0.05)
        if cycle % (self.base_period * 3) == 0 and cycle > 0:
            self._step_level = self.rng.uniform(0.35, 0.95)
        intensity = clip01(0.5 * wave + 0.5 * self._step_level + noise)

        if self._fault_remaining > 0:
            self._fault_remaining -= 1
            if self._fault_remaining == 0:
                self._fault_pe = None
        elif self.rng.random() < self.fault_probability:
            rows, cols = grid_shape
            self._fault_pe = (self.rng.randrange(rows), self.rng.randrange(cols))
            self._fault_remaining = self.fault_duration

        return intensity, self._fault_pe


class SilicaFluxFabric:
    """Digital-twin model of the SilicaFlux parallel compute fabric
    (Section 15): an R x C grid of PEs plus fabric-wide knobs
    (frequency, voltage, parallelism, batch size) that actions act on."""

    def __init__(self, rows: int = 4, cols: int = 4, seed: int = 0):
        self.rows = rows
        self.cols = cols
        self.pes = {(r, c): PEState(row=r, col=c) for r in range(rows) for c in range(cols)}
        self.rng = random.Random(seed)

        # Fabric-wide configuration registers, all normalised to ~[0, 2].
        self.frequency = 1.0
        self.voltage = 1.0
        # `parallelism` is a per-PE concurrency multiplier register: the
        # rows*cols baseline is 1.0x, with room to run down to 0.5x or up to
        # 4x so INCREASE/DECREASE_PARALLELISM both have somewhere to go.
        self.parallelism_min = 0.5 * (rows * cols)
        self.parallelism_max = 4.0 * (rows * cols)
        self.parallelism_step = 0.25 * (rows * cols)
        self.parallelism = float(rows * cols)
        self.batch_size = 1.0
        self.active_units = rows * cols

    # -- Section 16/19: scoring -------------------------------------------------

    def health_score(self, pe: PEState) -> float:
        """PE health = f(throughput, errors, temperature, power) (Section 19)."""
        throughput_term = clip01(pe.throughput)
        error_penalty = min(1.0, pe.errors * 6.0)
        thermal_penalty = max(0.0, (pe.temperature - 80.0) / 40.0)
        power_penalty = max(0.0, (pe.power - 1.3) / 1.0)
        score = throughput_term - error_penalty - 0.5 * thermal_penalty - 0.3 * power_penalty
        return max(0.0, min(1.0, score))

    def workload_score(self, pe: PEState) -> float:
        """workload_score(PE) (Section 16): higher = better candidate to
        receive MORE work. Combines health, thermal headroom, and current
        idle capacity."""
        if not pe.active:
            return 0.0
        health = self.health_score(pe)
        thermal_room = max(0.0, 1.0 - pe.temperature / 100.0)
        idle_room = 1.0 - clip01(pe.utilisation)
        return 0.55 * health + 0.30 * thermal_room + 0.15 * idle_room

    def redistribute(self) -> None:
        """Recompute per-PE allocation shares from workload_score() -- this
        is the learning scheduler's spatial-distribution decision
        (Section 16/17): route more work toward healthy, thermally-cool,
        under-utilised PEs."""
        scores = {pid: self.workload_score(pe) for pid, pe in self.pes.items()}
        total = sum(scores.values())
        if total <= 1e-9:
            share = 1.0 / max(1, len(self.pes))
            for pid, pe in self.pes.items():
                pe.allocation = share
            return
        for pid, pe in self.pes.items():
            pe.allocation = scores[pid] / total

    # -- Section 15/17/18/19: physical step --------------------------------------

    def step(self, workload_intensity: float, fault_pe=None) -> None:
        total_alloc = sum(p.allocation for p in self.pes.values() if p.active) or 1.0
        active_count = max(1, sum(1 for p in self.pes.values() if p.active))
        # ACTION_0/1 (parallelism) map onto a per-PE concurrency multiplier:
        # 1.0 at the (rows*cols) baseline, up to 4.0x at parallelism_max.
        # More concurrency drains queued demand faster (helps latency/error
        # during spikes) but costs proportionally more power -- the
        # MAXIMUM-USEFUL-COMPUTE-per-MINIMUM-ENERGY trade-off of Section 18.
        capacity_factor = self.parallelism / (self.rows * self.cols)

        for pid, pe in self.pes.items():
            if not pe.active:
                # A powered-down PE does no work at all -- every telemetry
                # field it exposes must decay toward its idle value, not
                # just utilisation, or a stale throughput/queue reading
                # divided by a near-zero utilisation blows up the feature
                # engine's efficiency ratios (Section 5).
                pe.utilisation *= 0.85
                pe.throughput *= 0.85
                pe.queue_depth *= 0.85
                pe.errors *= 0.9
                pe.power = max(0.05, pe.power * 0.9)
                pe.temperature = max(25.0, pe.temperature - 0.5)
                pe.latency = 0.03
                continue

            share = pe.allocation / total_alloc
            # `share` sums to 1 across active PEs, so scaling it back up by
            # active_count recovers a per-PE demand of ~workload_intensity
            # under uniform allocation (share == 1/active_count).
            demand = workload_intensity * share * active_count * self.batch_size
            effective_capacity = max(0.25, capacity_factor)

            pe.utilisation = clip01(0.6 * pe.utilisation + 0.4 * min(1.6, demand / effective_capacity))

            serviced = min(demand, effective_capacity)
            fault_penalty = 0.3 if (fault_pe == pid or pe.degraded) else 1.0
            pe.throughput = clip01(serviced * fault_penalty * (1.0 - pe.errors))

            overflow = max(0.0, demand - effective_capacity)
            pe.queue_depth = max(0.0, pe.queue_depth * 0.5 + overflow)
            pe.latency = 0.03 + pe.queue_depth * 0.12 + (0.25 if (fault_pe == pid or pe.degraded) else 0.0)

            pe.power = 0.15 + 0.85 * pe.utilisation * (self.voltage ** 2) * self.frequency * capacity_factor

            neighbours = list(self._neighbours(pid))
            neighbour_temp = sum(self.pes[n].temperature for n in neighbours) / max(1, len(neighbours))
            heat_in = pe.power * 9.0 + 0.06 * (neighbour_temp - pe.temperature)
            cooling = (pe.temperature - 25.0) * 0.09
            pe.temperature = max(20.0, pe.temperature + heat_in - cooling)

            base_error = (
                (0.02 if (fault_pe == pid or pe.degraded) else 0.0)
                + max(0.0, (pe.temperature - 90.0) / 500.0)
                + min(0.05, overflow * 0.02)  # sustained under-provisioning -> backpressure drops
            )
            pe.errors = clip01(0.8 * pe.errors + 0.2 * base_error)

        self.redistribute()

    def _neighbours(self, pid):
        r, c = pid
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nr, nc = r + dr, c + dc
            if 0 <= nr < self.rows and 0 <= nc < self.cols:
                yield (nr, nc)

    # -- aggregate telemetry into the Section 4 state vector ---------------------

    def aggregate_state(self, fmt=None) -> HardwareStateVector:
        """NOTE on units: every field here is normalised to roughly [0, 1.5]
        so the feature engine / predictors / reward engine see comparable
        magnitudes across channels -- `power` is the mean per-PE power, NOT
        the fabric's total power draw. Total power (an absolute budget) is
        what the constraint engine checks separately in
        :meth:`candidate_for_action`.

        ``fmt`` MUST match whatever :class:`~silicaflux_ml.learning_engine.LearningEngine`
        this state is destined for -- every value here is a raw two's-
        complement register value, meaningless without the format that
        defines its binary point. Passing the wrong format silently
        misinterprets every reading by a factor of 2**(frac_bits delta).
        """
        active = [p for p in self.pes.values() if p.active] or list(self.pes.values())
        n = len(active)
        avg = lambda f: sum(f(p) for p in active) / n
        thermal_headroom = max(0.0, 100.0 - max(p.temperature for p in active))

        from .fixed_point import to_fixed, DEFAULT_FORMAT

        fmt = fmt or DEFAULT_FORMAT
        return HardwareStateVector(
            utilisation=to_fixed(avg(lambda p: p.utilisation), fmt),
            throughput=to_fixed(avg(lambda p: p.throughput), fmt),
            latency=to_fixed(avg(lambda p: p.latency), fmt),
            power=to_fixed(avg(lambda p: p.power), fmt),
            temperature=to_fixed(avg(lambda p: p.temperature) / 100.0, fmt),
            clock_frequency=to_fixed(self.frequency, fmt),
            voltage=to_fixed(self.voltage, fmt),
            memory_pressure=to_fixed(avg(lambda p: p.queue_depth) / 4.0, fmt),
            pipeline_utilisation=to_fixed(avg(lambda p: p.utilisation), fmt),
            queue_depth=to_fixed(avg(lambda p: p.queue_depth), fmt),
            error_rate=to_fixed(avg(lambda p: p.errors), fmt),
            thermal_headroom=to_fixed(thermal_headroom / 100.0, fmt),
        )

    # -- Section 13/14: apply a validated action onto the fabric knobs -----------

    def candidate_for_action(self, action: Action, fmt=None) -> CandidateConfiguration:
        """Build the CANDIDATE configuration an action WOULD produce, for
        the constraint engine to check -- does not mutate fabric state.
        ``fmt`` must match the calling LearningEngine's format; see the
        note on :meth:`aggregate_state`."""
        freq, volt, par, batch, active_units = (
            self.frequency, self.voltage, self.parallelism, self.batch_size, self.active_units,
        )
        if action == Action.INCREASE_FREQUENCY:
            freq = freq * 1.1
        elif action == Action.DECREASE_FREQUENCY:
            freq = freq * 0.9
        elif action == Action.INCREASE_PARALLELISM:
            par = min(self.parallelism_max, par + self.parallelism_step)
        elif action == Action.DECREASE_PARALLELISM:
            par = max(self.parallelism_min, par - self.parallelism_step)
        elif action == Action.INCREASE_BATCH_SIZE:
            batch = batch * 1.2
        elif action == Action.DECREASE_BATCH_SIZE:
            batch = batch * 0.8
        elif action == Action.ACTIVATE_COMPUTE_UNIT:
            active_units = min(self.rows * self.cols, active_units + 1)
        elif action == Action.DEACTIVATE_COMPUTE_UNIT:
            active_units = max(1, active_units - 1)

        # Both estimates below MUST track every knob the physical step()
        # model actually uses (frequency, voltage, parallelism/capacity,
        # active_units) -- leaving one out (e.g. checking frequency but not
        # parallelism) is exactly how a candidate sails through the
        # constraint checker while the real thermal/power trajectory keeps
        # climbing underneath it.
        candidate_capacity_factor = max(0.25, par / (self.rows * self.cols))
        current_capacity_factor = max(0.25, self.parallelism / (self.rows * self.cols))

        avg_util = sum(p.utilisation for p in self.pes.values()) / len(self.pes)
        per_pe_power = 0.15 + 0.85 * avg_util * (volt ** 2) * freq * candidate_capacity_factor
        approx_power = per_pe_power * active_units

        # Steady-state temperature RISE above ambient is roughly proportional
        # to dissipated power, so scale the current temperature-above-ambient
        # by the ratio of candidate to current power-driving factors, rather
        # than naively rescaling the absolute reading (Section 17).
        ambient = 25.0
        avg_temp = sum(p.temperature for p in self.pes.values()) / len(self.pes)
        current_drive = max(1e-6, self.frequency * current_capacity_factor)
        candidate_drive = freq * candidate_capacity_factor
        approx_temp = ambient + max(0.0, avg_temp - ambient) * (candidate_drive / current_drive)

        from .fixed_point import to_fixed, DEFAULT_FORMAT
        fmt = fmt or DEFAULT_FORMAT
        return CandidateConfiguration(
            power=to_fixed(approx_power, fmt),
            temperature=to_fixed(approx_temp / 100.0, fmt),
            frequency=to_fixed(freq, fmt),
            voltage=to_fixed(volt, fmt),
            parallelism=to_fixed(par, fmt),
        )

    def apply_action(self, action: Action) -> None:
        """Configuration controller (Section 13): actually WRITE the new
        configuration, called only after ConstraintEngine has validated it."""
        if action == Action.INCREASE_FREQUENCY:
            self.frequency *= 1.1
        elif action == Action.DECREASE_FREQUENCY:
            self.frequency *= 0.9
        elif action == Action.INCREASE_PARALLELISM:
            self.parallelism = min(self.parallelism_max, self.parallelism + self.parallelism_step)
        elif action == Action.DECREASE_PARALLELISM:
            self.parallelism = max(self.parallelism_min, self.parallelism - self.parallelism_step)
        elif action == Action.INCREASE_BATCH_SIZE:
            self.batch_size *= 1.2
        elif action == Action.DECREASE_BATCH_SIZE:
            self.batch_size = max(0.25, self.batch_size * 0.8)
        elif action == Action.ACTIVATE_COMPUTE_UNIT:
            self._set_active_units(min(self.rows * self.cols, self.active_units + 1))
        elif action == Action.DEACTIVATE_COMPUTE_UNIT:
            self._set_active_units(max(1, self.active_units - 1))
        elif action == Action.CHANGE_WORK_DISTRIBUTION:
            self.redistribute()
        # MAINTAIN_CONFIGURATION: no-op by definition.

        self.frequency = max(0.2, min(3.0, self.frequency))
        self.batch_size = max(0.25, min(4.0, self.batch_size))

    def _set_active_units(self, n: int) -> None:
        self.active_units = n
        ranked = sorted(self.pes.values(), key=lambda p: self.health_score(p), reverse=True)
        for i, pe in enumerate(ranked):
            pe.active = i < n
