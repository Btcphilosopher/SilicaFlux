"""
silicaflux_ml.constraint_engine
==================================

Section 14 (Hardware Constraint Engine) / Section 13 (Adaptive Hardware).

    candidate configuration
            |
        power check
            |
        thermal check
            |
        frequency check
            |
        voltage check
            |
        resource check
            |
        VALID / INVALID

This block is DELIBERATELY outside the learning loop: its limits are
plain configuration registers set by a safety authority (firmware/fuses),
never written by WeightUpdater or ActionValueTable. The learning engine
can propose any candidate it likes; this block is the only thing that
can turn a proposal into a real configuration write, and it is pure
combinational comparator logic -- nothing here is "learned".
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class HardLimits:
    """Hard safety limits. These registers are configured by firmware /
    a safety authority and are NEVER touched by the learning algorithm."""

    power_max: int
    temperature_max: int
    freq_min: int
    freq_max: int
    voltage_min: int
    voltage_max: int
    parallelism_min: int
    parallelism_max: int


@dataclass
class CandidateConfiguration:
    """One proposed hardware configuration, produced by applying an action
    to the current configuration (Section 13's "configuration
    recommendation")."""

    power: int
    temperature: int
    frequency: int
    voltage: int
    parallelism: int


class ConstraintEngine:
    """Hardware constraint engine (Section 14): six independent checks,
    each a single comparator against a fixed limit register."""

    CHECK_ORDER = ("power", "thermal", "frequency", "voltage", "resource")

    def __init__(self, limits: HardLimits):
        self.limits = limits

    def check(self, candidate: CandidateConfiguration):
        """Returns (valid: bool, violations: list[str])."""
        L = self.limits
        violations = []

        if candidate.power > L.power_max:
            violations.append("power")
        if candidate.temperature > L.temperature_max:
            violations.append("thermal")
        if not (L.freq_min <= candidate.frequency <= L.freq_max):
            violations.append("frequency")
        if not (L.voltage_min <= candidate.voltage <= L.voltage_max):
            violations.append("voltage")
        if not (L.parallelism_min <= candidate.parallelism <= L.parallelism_max):
            violations.append("resource")

        return (len(violations) == 0), violations

    def trip_action(self, actual: CandidateConfiguration):
        """Independent safety watchdog (Section 14: "Hard safety limits
        must exist outside the learning algorithm. The ML algorithm cannot
        learn its way around them.").

        Unlike :meth:`check`, which only vets a PROPOSED candidate before
        it is written, this inspects the fabric's ACTUAL current telemetry
        and, if a hard limit is already being exceeded, returns a
        corrective action for the configuration controller to apply
        immediately -- bypassing action selection entirely, the same way a
        real chip's thermal/power throttling circuit (e.g. PROCHOT) acts
        independently of firmware or software policy. Returns None when
        the current operating point is within all limits.
        """
        from .action_selector import Action

        L = self.limits
        if actual.power > L.power_max or actual.temperature > L.temperature_max:
            return Action.DECREASE_FREQUENCY
        return None
