"""
silicaflux_ml.action_selector
================================

Section 10 (Action Space) / Section 11 (Action Selector).

The action space is a small, configurable, discrete enum -- ten actions
by default. Each action carries a fixed-point *value register* updated
like a contextual-bandit arm (Section 11's "highest predicted action"):

    value[a] += lr * (reward - value[a])

which is the same incremental-update shape as WeightUpdater, just scalar
per action instead of per-feature. Four selectable strategies are
implemented; the default is epsilon-greedy because -- per the spec --
it is "simple and hardware-efficient" (one comparator tree + one PRNG
compare, no transcendental functions). Softmax and UCB are provided for
software-side comparison and both need a piecewise-linear LUT
approximation of exp()/log()/sqrt() to actually go to silicon; that
substitution is called out explicitly below rather than hidden.
"""

from __future__ import annotations

import math
import random
from enum import IntEnum

from .fixed_point import FixedFormat, DEFAULT_FORMAT, fixed_add, fixed_sub, fixed_mul


class Action(IntEnum):
    """Section 10 default action space. Replace/extend freely -- every
    strategy below only assumes `table.actions` is an iterable of hashable
    action ids, so the space is fully configurable."""

    INCREASE_PARALLELISM = 0
    DECREASE_PARALLELISM = 1
    INCREASE_FREQUENCY = 2
    DECREASE_FREQUENCY = 3
    INCREASE_BATCH_SIZE = 4
    DECREASE_BATCH_SIZE = 5
    ACTIVATE_COMPUTE_UNIT = 6
    DEACTIVATE_COMPUTE_UNIT = 7
    CHANGE_WORK_DISTRIBUTION = 8
    MAINTAIN_CONFIGURATION = 9


DEFAULT_ACTIONS = list(Action)


class ActionValueTable:
    """One fixed-point value register + one visit counter per action.

    This IS the "predicted reward per action" referenced in Section 11 --
    a tiny table, not a second predictor network. Section 7's per-quantity
    OutputModels feed the reward function that trains these values; this
    table itself is the RL policy state (Section 12's compact learning
    memory keeps the episodic log, this is the live registers).
    """

    __slots__ = ("fmt", "actions", "value", "visits")

    def __init__(self, actions=DEFAULT_ACTIONS, fmt: FixedFormat = DEFAULT_FORMAT):
        self.fmt = fmt
        self.actions = list(actions)
        self.value = {a: 0 for a in self.actions}
        self.visits = {a: 0 for a in self.actions}

    def update(self, action, reward: int, learning_rate: int) -> None:
        self.visits[action] = self.visits.get(action, 0) + 1
        error = fixed_sub(reward, self.value[action], self.fmt)
        self.value[action] = fixed_add(self.value[action], fixed_mul(learning_rate, error, self.fmt), self.fmt)

    def best_action(self):
        return max(self.actions, key=lambda a: self.value[a])


class ActionSelector:
    """Strategy-selectable action-selection block (Section 11).

    strategy in {"greedy", "epsilon_greedy" (default), "softmax", "ucb"}.
    """

    STRATEGIES = ("greedy", "epsilon_greedy", "softmax", "ucb")

    def __init__(
        self,
        table: ActionValueTable,
        strategy: str = "epsilon_greedy",
        epsilon_raw: int = 0,
        ucb_c_raw: int = 0,
        rng: random.Random | None = None,
    ):
        if strategy not in self.STRATEGIES:
            raise ValueError(f"unknown action-selection strategy: {strategy!r}")
        self.table = table
        self.strategy = strategy
        self.epsilon_raw = epsilon_raw
        self.ucb_c_raw = ucb_c_raw
        self.rng = rng if rng is not None else random.Random(0)

    def select(self, total_steps: int = 0):
        if self.strategy == "greedy":
            return self.table.best_action()
        if self.strategy == "epsilon_greedy":
            return self._epsilon_greedy()
        if self.strategy == "softmax":
            return self._softmax()
        return self._ucb(total_steps)

    def _epsilon_greedy(self):
        # epsilon is a fixed-point probability in [0, 1*scale]; comparing
        # it against a uniform PRNG draw is one comparator in hardware.
        epsilon = self.epsilon_raw / self.table.fmt.scale
        if self.rng.random() < epsilon:
            return self.rng.choice(self.table.actions)
        return self.table.best_action()

    def _softmax(self):
        # Reference / comparison only: real exp() needs a LUT+interpolate
        # approximation in RTL (e.g. piecewise-linear over 2^k segments).
        fmt = self.table.fmt
        values = [self.table.value[a] / fmt.scale for a in self.table.actions]
        m = max(values)
        exps = [math.exp(v - m) for v in values]
        total = sum(exps)
        probs = [e / total for e in exps]
        draw = self.rng.random()
        cumulative = 0.0
        for action, p in zip(self.table.actions, probs):
            cumulative += p
            if draw <= cumulative:
                return action
        return self.table.actions[-1]

    def _ucb(self, total_steps: int):
        # Reference / comparison only: real sqrt()/log() need LUT
        # approximation in RTL, same caveat as softmax above.
        fmt = self.table.fmt
        c = self.ucb_c_raw / fmt.scale
        log_term = math.log(total_steps + 1)

        def score(a):
            n = self.table.visits[a]
            if n == 0:
                return float("inf")
            value = self.table.value[a] / fmt.scale
            return value + c * math.sqrt(log_term / n)

        return max(self.table.actions, key=score)
