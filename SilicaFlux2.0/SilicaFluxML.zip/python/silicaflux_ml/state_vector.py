"""
silicaflux_ml.state_vector
============================

Section 4 (Hardware State Vector).

A compact, fixed-width vector of telemetry registers sampled once per
learning cycle. Field order below IS the X0..X11 order from the spec --
keep it stable, since RTL ports and the synthesis estimator both assume
this ordering.
"""

from __future__ import annotations

from dataclasses import dataclass, fields

# X0 .. X11, in order.
STATE_FIELD_NAMES = [
    "utilisation",           # X0
    "throughput",            # X1
    "latency",                # X2
    "power",                  # X3
    "temperature",             # X4
    "clock_frequency",        # X5
    "voltage",                 # X6
    "memory_pressure",        # X7
    "pipeline_utilisation",   # X8
    "queue_depth",             # X9
    "error_rate",              # X10
    "thermal_headroom",       # X11
]

NUM_STATE_FEATURES = len(STATE_FIELD_NAMES)


@dataclass
class HardwareStateVector:
    """One sampled hardware state, X0..X11, all raw fixed-point registers."""

    utilisation: int = 0
    throughput: int = 0
    latency: int = 0
    power: int = 0
    temperature: int = 0
    clock_frequency: int = 0
    voltage: int = 0
    memory_pressure: int = 0
    pipeline_utilisation: int = 0
    queue_depth: int = 0
    error_rate: int = 0
    thermal_headroom: int = 0

    def as_dict(self) -> dict:
        return {f.name: getattr(self, f.name) for f in fields(self)}

    def as_list(self) -> list:
        return [getattr(self, name) for name in STATE_FIELD_NAMES]

    @classmethod
    def from_dict(cls, values: dict) -> "HardwareStateVector":
        return cls(**{name: values.get(name, 0) for name in STATE_FIELD_NAMES})

    @classmethod
    def from_list(cls, values: list) -> "HardwareStateVector":
        return cls(**dict(zip(STATE_FIELD_NAMES, values)))

    def index_of(self, name: str) -> int:
        return STATE_FIELD_NAMES.index(name)
