"""
silicaflux_ml.learning_engine
================================

Top-level orchestrator. Wires every hardware block behind the Section 20
nine-stage model-update pipeline, driven by the Section 24 central FSM:

    Stage 1  capture telemetry        (caller samples HardwareStateVector)
    Stage 2  feature extraction       -> FeatureEngine            [FSM: FEATURE]
    Stage 3  prediction               -> Predictor                [FSM: PREDICT]
    Stage 4  error calculation        -> (observed - predicted)   [FSM: EVALUATE]
    Stage 5  reward calculation       -> RewardEngine              [FSM: SELECT*]
    Stage 6  weight update            -> WeightUpdater             [FSM: UPDATE]
    Stage 7  action selection         -> ActionSelector             [FSM: SELECT*]
    Stage 8  constraint validation    -> ConstraintEngine           [FSM: VALIDATE]
    Stage 9  configuration output     -> LearningMemory + caller    [FSM: APPLY]

    (*reward calc and action selection are pipelined together in the
     SELECT state since the action-value update needs the freshly
     computed reward from the previous cycle's chosen action.)

One :class:`LearningEngine` instance is one control loop. Section 26's
five complexity modes reuse the exact same blocks -- only which blocks
are active, and how many predictor outputs / feature inputs they see,
changes between modes. This is what lets the synthesis estimator show a
smooth resource/capability curve instead of five unrelated designs.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .action_selector import Action, ActionSelector, ActionValueTable, DEFAULT_ACTIONS
from .constraint_engine import CandidateConfiguration, ConstraintEngine, HardLimits
from .feature_engine import FeatureEngine
from .fixed_point import DEFAULT_FORMAT, FixedFormat, fixed_mul, fixed_sub, to_fixed
from .fsm import FSMState, LearningFSM
from .learning_memory import LearningMemory, LearningRecord
from .modes import Mode
from .predictor import Predictor
from .reward_engine import RewardConfig, RewardEngine
from .state_vector import HardwareStateVector
from .weight_updater import WeightUpdater, WeightUpdaterConfig

# ---------------------------------------------------------------------------
# Curated compact feature set fed to the predictors (Section 4: "compact
# hardware state vector" -- we don't feed all 53 FeatureEngine outputs into
# every MAC pipeline, we pick the ones that matter, same as a real design
# would to bound resource cost).
# ---------------------------------------------------------------------------

DEFAULT_FEATURE_ORDER = [
    "utilisation_avg", "utilisation_delta",
    "throughput_avg", "throughput_delta",
    "power_avg", "power_delta",
    "temperature_avg", "temperature_delta",
    "thermal_headroom_avg",
    "queue_depth_avg",
    "pipeline_utilisation_avg",
    "error_rate_avg",
    "normalised_utilisation",
    "power_efficiency",
    "thermal_efficiency",
    "throughput_efficiency",
    "latency_gradient",
]

FEATURE_CATEGORY = {
    "utilisation_avg": "core", "utilisation_delta": "core",
    "throughput_avg": "core", "throughput_delta": "core",
    "power_avg": "power", "power_delta": "power",
    "temperature_avg": "thermal", "temperature_delta": "thermal",
    "thermal_headroom_avg": "thermal",
    "queue_depth_avg": "workload",
    "pipeline_utilisation_avg": "workload",
    "error_rate_avg": "core",
    "normalised_utilisation": "core",
    "power_efficiency": "power",
    "thermal_efficiency": "thermal",
    "throughput_efficiency": "core",
    "latency_gradient": "core",
}


def feature_subset(exclude_categories: tuple = (), order: list | None = None) -> list:
    """Used by the ablation runner (Section 30) to build e.g. 'learning
    without thermal features' by dropping a whole category at once."""
    order = order or DEFAULT_FEATURE_ORDER
    return [f for f in order if FEATURE_CATEGORY.get(f, "core") not in exclude_categories]


OUTPUT_TO_STATE_FIELD = {
    "predicted_throughput": "throughput",
    "predicted_power": "power",
    "predicted_temperature": "temperature",
    "predicted_latency": "latency",
    "predicted_error_probability": "error_rate",
}


def outputs_for_mode(mode: Mode) -> list:
    if mode == Mode.MODE_0_STATIC:
        return []
    if mode == Mode.MODE_1_LINEAR_ADAPTIVE:
        return ["predicted_throughput"]
    return list(OUTPUT_TO_STATE_FIELD.keys())


def default_strategy_for_mode(mode: Mode) -> str:
    if mode.value >= Mode.MODE_3_ONLINE_RL.value:
        return "epsilon_greedy"
    return "greedy"


@dataclass
class EngineConfig:
    fmt: FixedFormat = DEFAULT_FORMAT
    mode: Mode = Mode.MODE_3_ONLINE_RL
    ring_depth: int = 16
    feature_order: list = field(default_factory=lambda: list(DEFAULT_FEATURE_ORDER))
    output_names: list | None = None  # None => derived from mode via outputs_for_mode()
    actions: list = field(default_factory=lambda: list(DEFAULT_ACTIONS))
    action_strategy: str | None = None  # None => derived from mode via default_strategy_for_mode()
    epsilon: float = 0.2
    epsilon_min: float = 0.1  # floor kept fairly high: the workload/fault process is non-stationary
    epsilon_decay: float = 0.9995  # multiplicative per-cycle decay register, 1.0 = no decay
    action_learning_rate: float = 0.1
    ucb_c: float = 0.5
    weight_learning_rate: float = 0.02
    weight_min: float = -8.0
    weight_max: float = 8.0
    error_threshold: float = 0.0
    update_interval: int = 1
    memory_depth: int = 64
    fsm_timeout: int = 32
    throughput_weight: float = 1.0
    efficiency_weight: float = 0.5
    power_weight: float = 0.4
    thermal_weight: float = 0.6
    error_weight: float = 2.0
    thermal_penalty_threshold: float = 0.75  # same normalised [0,~1.5] scale as the temperature feature
    invalid_action_penalty: float = 5.0


@dataclass
class EngineOutput:
    cycle: int
    features: dict
    predicted: dict
    errors: dict
    reward: int
    action: Action
    valid: bool
    violations: list


class LearningEngine:
    """One learning-and-control loop instance (Section 20 pipeline,
    Section 24 FSM), covering Modes 0-3. Mode 4 is one of these PER PE,
    orchestrated by :class:`~silicaflux_ml.fabric.SilicaFluxController`."""

    def __init__(self, cfg: EngineConfig):
        self.cfg = cfg
        self.mode = cfg.mode
        fmt = cfg.fmt
        self.fmt = fmt

        self.feature_engine = FeatureEngine(fmt, ring_depth=cfg.ring_depth)

        output_names = cfg.output_names if cfg.output_names is not None else outputs_for_mode(cfg.mode)
        self.output_names = output_names
        self.predictor = Predictor(
            num_features=len(cfg.feature_order),
            fmt=fmt,
            output_names=output_names or Predictor.DEFAULT_OUTPUTS[:1],
        ) if output_names else None

        weight_min_raw = to_fixed(cfg.weight_min, fmt)
        weight_max_raw = to_fixed(cfg.weight_max, fmt)
        self.weight_updater = WeightUpdater(
            fmt,
            WeightUpdaterConfig(
                learning_rate=to_fixed(cfg.weight_learning_rate, fmt),
                weight_min=weight_min_raw,
                weight_max=weight_max_raw,
                error_threshold=to_fixed(cfg.error_threshold, fmt),
                update_interval=cfg.update_interval,
            ),
        )

        self.reward_engine = RewardEngine(
            fmt,
            RewardConfig(
                throughput_weight=to_fixed(cfg.throughput_weight, fmt),
                efficiency_weight=to_fixed(cfg.efficiency_weight, fmt),
                power_weight=to_fixed(cfg.power_weight, fmt),
                thermal_weight=to_fixed(cfg.thermal_weight, fmt),
                error_weight=to_fixed(cfg.error_weight, fmt),
                invalid_action_penalty=to_fixed(cfg.invalid_action_penalty, fmt),
            ),
        )
        self.thermal_penalty_threshold_raw = to_fixed(cfg.thermal_penalty_threshold, fmt)

        self.action_table = ActionValueTable(cfg.actions, fmt)
        strategy = cfg.action_strategy or default_strategy_for_mode(cfg.mode)
        self.selector = ActionSelector(
            self.action_table,
            strategy=strategy,
            epsilon_raw=to_fixed(cfg.epsilon, fmt),
            ucb_c_raw=to_fixed(cfg.ucb_c, fmt),
        )
        self.action_lr_raw = to_fixed(cfg.action_learning_rate, fmt)
        self.epsilon_min_raw = to_fixed(cfg.epsilon_min, fmt)
        self.epsilon_decay_raw = to_fixed(cfg.epsilon_decay, fmt)

        # Modes 0-2 pick from a single context-FREE value per action (a
        # plain multi-armed bandit averaged over all history, appropriate
        # for a "static"/"adaptive"/"multi-output-PREDICTOR" design that
        # never claimed to be state-conditioned). Mode 3+ instead learns
        # one small linear Q(state, action) = w_a . features + b_a per
        # action -- reusing the exact same Predictor/WeightUpdater MAC
        # datapath as the value predictors above, just with one output per
        # action instead of one per physical quantity. This is what makes
        # the feature ablation study (Section 30) actually bite on the
        # policy: with no state input, no feature category could possibly
        # change which action gets picked.
        self.contextual_policy = cfg.mode.value >= Mode.MODE_3_ONLINE_RL.value
        if self.contextual_policy:
            self._q_action_key = {a: f"q_{int(a)}" for a in cfg.actions}
            self.q_predictor = Predictor(
                num_features=len(cfg.feature_order),
                fmt=fmt,
                output_names=list(self._q_action_key.values()),
                weight_min=weight_min_raw,
                weight_max=weight_max_raw,
            )
        else:
            self.q_predictor = None

        self.constraint_engine = ConstraintEngine(HardLimits(
            power_max=0, temperature_max=0, freq_min=0, freq_max=0,
            voltage_min=0, voltage_max=0, parallelism_min=0, parallelism_max=0,
        ))  # overwritten by set_limits(); placeholder keeps constructor order simple

        self.memory = LearningMemory(depth=cfg.memory_depth)
        self.fsm = LearningFSM(timeout_cycles=cfg.fsm_timeout)

        self.cycle = 0
        self._prev = None  # {"feat_vec", "predicted", "action"} from the previous cycle

    def set_limits(self, limits: HardLimits) -> None:
        self.constraint_engine = ConstraintEngine(limits)

    def _reward_inputs(self, feats: dict, state_raw: dict):
        fmt = self.fmt
        throughput = feats.get("throughput_avg", state_raw.get("throughput", 0))
        efficiency = feats.get("power_efficiency", 0)
        power = feats.get("power_avg", state_raw.get("power", 0))
        temperature = feats.get("temperature_avg", state_raw.get("temperature", 0))
        errors = feats.get("error_rate_avg", state_raw.get("error_rate", 0))
        thermal_penalty = max(0, fixed_sub(temperature, self.thermal_penalty_threshold_raw, fmt))
        return throughput, efficiency, power, thermal_penalty, errors

    def run_cycle(self, state: HardwareStateVector, candidate_fn) -> EngineOutput:
        """Run exactly one full FSM pass (Stage 1 through Stage 9) for one
        sampled hardware state. ``candidate_fn(action) -> CandidateConfiguration``
        lets the caller (fabric/controller) translate an action id into the
        power/thermal/frequency/voltage/parallelism numbers the constraint
        engine checks against."""
        fmt = self.fmt
        state_raw = state.as_dict()
        ctx: dict = {}

        def do_observe():
            ctx["state_raw"] = state_raw

        def do_feature():
            ctx["feats"] = self.feature_engine.observe(ctx["state_raw"])
            ctx["feat_vec"] = self.feature_engine.feature_vector(ctx["feats"], self.cfg.feature_order)

        def do_predict():
            ctx["predicted"] = self.predictor.predict(ctx["feat_vec"]) if self.predictor else {}

        def do_evaluate():
            errors = {}
            if self.predictor is not None and self._prev is not None:
                for name, pred in self._prev["predicted"].items():
                    field_name = OUTPUT_TO_STATE_FIELD.get(name)
                    observed = ctx["feats"].get(f"{field_name}_avg", pred)
                    errors[name] = fixed_sub(observed, pred, fmt)
            ctx["errors"] = errors

        def do_update():
            if self.predictor is not None and self._prev is not None:
                for name, pred in self._prev["predicted"].items():
                    field_name = OUTPUT_TO_STATE_FIELD.get(name)
                    observed = ctx["feats"].get(f"{field_name}_avg", pred)
                    self.weight_updater.maybe_update(
                        self.predictor.models[name], self._prev["feat_vec"], observed, pred
                    )

        def do_select():
            throughput, efficiency, power, thermal_penalty, errors_r = self._reward_inputs(
                ctx["feats"], ctx["state_raw"]
            )
            reward = self.reward_engine.compute(throughput, efficiency, power, thermal_penalty, errors_r)
            ctx["reward_raw"] = reward

            if self.contextual_policy:
                # Linear Q(state, action) path (Mode 3+): TD-update the
                # PREVIOUS cycle's chosen action using the reward that
                # action's state now produced, then re-evaluate Q(.) for
                # every action against THIS cycle's features so selection
                # is state-conditioned.
                if self._prev is not None:
                    prev_key = self._q_action_key[self._prev["action"]]
                    prev_q = self._prev["q_values"][prev_key]
                    self.weight_updater.maybe_update(
                        self.q_predictor.models[prev_key], self._prev["feat_vec"], reward, prev_q
                    )
                q_values = self.q_predictor.predict(ctx["feat_vec"])
                for a in self.cfg.actions:
                    self.action_table.value[a] = q_values[self._q_action_key[a]]
                ctx["q_values"] = q_values
            elif self._prev is not None and self.mode.value >= Mode.MODE_1_LINEAR_ADAPTIVE.value:
                self.action_table.update(self._prev["action"], reward, self.action_lr_raw)

            if self.mode == Mode.MODE_0_STATIC:
                ctx["action"] = Action.MAINTAIN_CONFIGURATION
            else:
                ctx["action"] = self.selector.select(self.cycle)
                if self.selector.strategy == "epsilon_greedy":
                    # Exploration-rate register decays a single multiply per
                    # cycle, floored at epsilon_min -- explore heavily early,
                    # settle toward exploitation as the policy matures
                    # (Section 29's "policy stability" over time).
                    decayed = fixed_mul(self.selector.epsilon_raw, self.epsilon_decay_raw, fmt)
                    self.selector.epsilon_raw = max(self.epsilon_min_raw, decayed)

        def do_validate():
            candidate = candidate_fn(ctx["action"])
            valid, violations = self.constraint_engine.check(candidate)
            ctx["valid"] = valid
            ctx["violations"] = violations
            if not valid:
                ctx["reward_raw"] = self.reward_engine.penalise_invalid(ctx["reward_raw"])
                ctx["action"] = Action.MAINTAIN_CONFIGURATION

        def do_apply():
            self.memory.push(LearningRecord(
                cycle=self.cycle,
                state=state.as_list(),
                action=int(ctx["action"]),
                predicted=dict(ctx["predicted"]),
                observed={},
                reward=ctx["reward_raw"],
                error=dict(ctx.get("errors", {})),
            ))

        handlers = {
            FSMState.OBSERVE: do_observe,
            FSMState.FEATURE: do_feature,
            FSMState.PREDICT: do_predict,
            FSMState.EVALUATE: do_evaluate,
            FSMState.UPDATE: do_update,
            FSMState.SELECT: do_select,
            FSMState.VALIDATE: do_validate,
            FSMState.APPLY: do_apply,
        }
        self.fsm.run_full_pass(handlers)

        self._prev = {
            "feat_vec": ctx["feat_vec"],
            "predicted": ctx["predicted"],
            "action": ctx["action"],
            "q_values": ctx.get("q_values"),
        }
        result = EngineOutput(
            cycle=self.cycle,
            features=ctx["feats"],
            predicted=ctx["predicted"],
            errors=ctx.get("errors", {}),
            reward=ctx["reward_raw"],
            action=ctx["action"],
            valid=ctx["valid"],
            violations=ctx["violations"],
        )
        self.cycle += 1
        return result
