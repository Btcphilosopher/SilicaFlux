"""
silicaflux_ml.feature_engine
===============================

Section 5 (Feature Engine).

Streaming feature extraction using fixed-depth ring buffers plus
incrementally-maintained sum / sum-of-squares accumulator registers --
NOT a stored history that grows with runtime. Every statistic here is
O(1) per new sample regardless of how long the fabric has been running,
which is what makes it representable as a fixed amount of hardware.

Per raw channel (one of the 12 state-vector fields) we compute:
    moving average          -- RingChannel.mean()
    moving variance         -- RingChannel.variance()
    delta                   -- RingChannel.delta()   (current - previous)
    rate of change          -- alias of delta (dt = 1 sample period)

Plus a small combinational block of cross-channel derived ratios:
    normalised utilisation
    power efficiency        (throughput / power)
    thermal efficiency      (thermal_headroom / temperature)
    throughput efficiency   (throughput / utilisation)
    latency gradient        (delta of latency)
"""

from __future__ import annotations

from collections import deque

from .fixed_point import (
    FixedFormat,
    DEFAULT_FORMAT,
    fixed_add,
    fixed_sub,
    fixed_mul,
    fixed_div,
    fixed_div_int,
    fixed_clip,
)
from .state_vector import STATE_FIELD_NAMES


class RingChannel:
    """One streaming statistics channel = a depth-N ring buffer register
    file plus a running-sum and running-sum-of-squares accumulator.

    Hardware mapping:
        buf        -> small dual-port RAM / shift register file, depth N
        sum        -> accumulator register, updated +new -evicted
        sumsq      -> accumulator register, updated +new^2 -evicted^2
        prev       -> single delay register (for delta/rate-of-change)
    """

    __slots__ = ("depth", "fmt", "buf", "sum", "sumsq", "prev", "count", "_last_delta")

    def __init__(self, depth: int, fmt: FixedFormat = DEFAULT_FORMAT):
        self.depth = depth
        self.fmt = fmt
        self.buf: deque = deque()
        self.sum = 0
        self.sumsq = 0
        self.prev = 0
        self.count = 0
        self._last_delta = 0

    def push(self, x: int) -> None:
        self._last_delta = fixed_sub(x, self.prev, self.fmt)
        self.prev = x

        sq = (x * x) >> self.fmt.frac_bits  # x^2, rescaled once, still fixed-point
        self.buf.append((x, sq))
        self.sum += x
        self.sumsq += sq
        self.count += 1

        if len(self.buf) > self.depth:
            old_x, old_sq = self.buf.popleft()
            self.sum -= old_x
            self.sumsq -= old_sq
            self.count -= 1

    def mean(self) -> int:
        return fixed_div_int(self.sum, max(self.count, 1), self.fmt)

    def variance(self) -> int:
        n = max(self.count, 1)
        mean_sq = fixed_div_int(self.sumsq, n, self.fmt)
        mean = self.mean()
        mean_squared = fixed_mul(mean, mean, self.fmt)
        var = fixed_sub(mean_sq, mean_squared, self.fmt)
        # Rounding in fixed-point can drive this a hair below zero for a
        # near-constant signal; a variance register can't go negative.
        return max(0, var)

    def delta(self) -> int:
        return self._last_delta


class FeatureEngine:
    """Hardware feature-extraction block (Section 5).

    One :class:`RingChannel` per raw state-vector input, sized identically
    (``ring_depth``), plus the small combinational derived-ratio block.
    """

    DERIVED_NAMES = [
        "normalised_utilisation",
        "power_efficiency",
        "thermal_efficiency",
        "throughput_efficiency",
        "latency_gradient",
    ]

    def __init__(self, fmt: FixedFormat = DEFAULT_FORMAT, ring_depth: int = 16):
        self.fmt = fmt
        self.ring_depth = ring_depth
        self.channels = {name: RingChannel(ring_depth, fmt) for name in STATE_FIELD_NAMES}

    def feature_names(self) -> list:
        names = []
        for ch in STATE_FIELD_NAMES:
            names += [f"{ch}_avg", f"{ch}_var", f"{ch}_delta", f"{ch}_roc"]
        names += self.DERIVED_NAMES
        return names

    def observe(self, state_raw: dict) -> dict:
        """Push one new sample per channel, return the full feature dict."""
        for name in STATE_FIELD_NAMES:
            self.channels[name].push(state_raw.get(name, 0))

        feats = {}
        for name in STATE_FIELD_NAMES:
            ch = self.channels[name]
            feats[f"{name}_avg"] = ch.mean()
            feats[f"{name}_var"] = ch.variance()
            delta = ch.delta()
            feats[f"{name}_delta"] = delta
            feats[f"{name}_roc"] = delta  # sample period (dt) = 1 cycle

        fmt = self.fmt
        # A divisor floor of raw-unit "1" is a no-op guard once a register
        # has decayed toward zero (raw 1 == 1/65536 in Q16.16) -- it still
        # lets a near-zero denominator blow the ratio up to the format's
        # saturation ceiling. Floor at ~1% of full scale instead, a small
        # but numerically meaningful minimum in real units.
        min_divisor = max(1, fmt.scale // 100)
        util = self.channels["utilisation"].prev
        thr = self.channels["throughput"].prev
        pwr = max(self.channels["power"].prev, min_divisor)
        temp = max(self.channels["temperature"].prev, min_divisor)
        headroom = self.channels["thermal_headroom"].prev

        feats["normalised_utilisation"] = fixed_clip(util, fmt)
        feats["power_efficiency"] = fixed_div(thr, pwr, fmt)
        feats["thermal_efficiency"] = fixed_div(headroom, temp, fmt)
        feats["throughput_efficiency"] = fixed_div(thr, max(util, min_divisor), fmt)
        feats["latency_gradient"] = self.channels["latency"].delta()
        return feats

    def feature_vector(self, feats: dict, order: list | None = None) -> list:
        order = order or self.feature_names()
        return [feats[name] for name in order]
