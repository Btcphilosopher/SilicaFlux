"""
silicaflux_ml.synthesis_estimator
====================================

Section 25 (Synthesis Estimation) / Section 26 (ML Complexity Modes).

A resource-cost ESTIMATOR, not a synthesis tool. It exists to show how
LUT-equivalent / register / MAC / memory cost scales as Section 26's five
complexity modes add capability, using coarse, clearly-labelled scaling
heuristics (roughly DSP48/LUT-slice shaped, but NOT calibrated against a
real PDK or FPGA family). Treat every number here as "which of these two
designs is bigger and by roughly how much", never as a real timing-closed
area/power number -- getting that requires an actual synthesis flow
against a real cell library, which is explicitly out of scope for a
software reference model.
"""

from __future__ import annotations

from dataclasses import dataclass

from .fixed_point import FixedFormat
from .learning_engine import EngineConfig, outputs_for_mode
from .modes import Mode
from .state_vector import NUM_STATE_FEATURES


# Coarse, order-of-magnitude heuristics (LUT-equivalents per primitive,
# on a generic 6-input-LUT FPGA fabric). NOT a substitute for synthesis.
LUTS_PER_BIT_ADDER = 1.0
LUTS_PER_BIT_COMPARATOR = 0.6
LUTS_PER_BIT_MULTIPLIER = 2.4  # a plain LUT-fabric multiplier; a DSP-slice MAC would use ~0 LUTs instead
REGS_PER_MAC_PIPELINE_STAGE_BITS = 1.2  # pipeline/guard registers around one MAC
CLOCK_NS_PER_BIT_OF_MULTIPLIER = 0.06  # crude critical-path-length proxy
BASE_CLOCK_NS = 1.2
DYNAMIC_POWER_PER_LUT_MW = 0.0009
DYNAMIC_POWER_PER_REG_MW = 0.0006
DYNAMIC_POWER_PER_MAC_MW = 0.02
STATIC_POWER_MW = 4.0


@dataclass
class SynthesisEstimate:
    mode: str
    fixed_format: str
    num_features: int
    num_outputs: int
    num_actions: int
    ring_depth: int
    memory_depth: int
    register_count: int
    mac_count: int
    lut_equivalent: int
    memory_bits: int
    pipeline_depth: int
    estimated_clock_mhz: float
    estimated_power_mw: float

    def as_row(self) -> dict:
        return {
            "mode": self.mode,
            "fixed_format": self.fixed_format,
            "num_features": self.num_features,
            "num_outputs": self.num_outputs,
            "num_actions": self.num_actions,
            "ring_depth": self.ring_depth,
            "memory_depth": self.memory_depth,
            "register_count": self.register_count,
            "mac_count": self.mac_count,
            "lut_equivalent": self.lut_equivalent,
            "memory_bits": self.memory_bits,
            "pipeline_depth": self.pipeline_depth,
            "estimated_clock_mhz": round(self.estimated_clock_mhz, 2),
            "estimated_power_mw": round(self.estimated_power_mw, 3),
        }


PIPELINE_DEPTH = 9  # Section 20's nine model-update-pipeline stages


def estimate_resources(cfg: EngineConfig, num_agents: int = 1) -> SynthesisEstimate:
    """``num_agents`` > 1 replicates the whole per-agent estimate that many
    times before returning it -- this is how Mode 4 (Section 16/26: one
    LearningEngine instance PER PE) is estimated: as N independent copies
    of the same Mode-3-shaped datapath, not a fundamentally different
    block."""
    fmt: FixedFormat = cfg.fmt
    bits = fmt.total_bits
    num_features = len(cfg.feature_order)
    num_outputs = len(cfg.output_names) if cfg.output_names is not None else len(outputs_for_mode(cfg.mode))
    num_outputs = max(num_outputs, 0)
    num_actions = len(cfg.actions)
    ring_depth = cfg.ring_depth

    # Mode 3+ (contextual policy, see learning_engine.py) adds a SECOND
    # Predictor-shaped weight bank: one linear Q(state, action) output per
    # action, sharing the same feature vector. Omitting this is exactly
    # how a resource estimate quietly under-counts a design -- it must
    # track every weight bank the engine actually instantiates.
    is_contextual = cfg.mode.value >= Mode.MODE_3_ONLINE_RL.value
    q_outputs = num_actions if is_contextual else 0

    # -- Registers -------------------------------------------------------
    # FeatureEngine: per raw channel (NUM_STATE_FEATURES of them) a ring
    # buffer of `ring_depth` (value,sq) register pairs + 3 accumulator/delay
    # registers (sum, sumsq, prev).
    feature_registers = NUM_STATE_FEATURES * (ring_depth * 2 + 3) * bits
    # Predictor(s): (weights + bias) per output, value predictor + Q predictor.
    predictor_registers = (num_outputs + q_outputs) * (num_features + 1) * bits
    # Action-value table: value + visit-counter per action.
    action_registers = num_actions * (bits + 32)
    # Pipeline/guard registers threaded through the 9-stage FSM datapath.
    pipeline_registers = PIPELINE_DEPTH * bits * 4
    # Learning memory: one register-equivalent word per stored field per entry.
    learning_memory_words_per_entry = num_features + 1 + num_outputs * 2 + 1 + num_outputs
    register_count = int(feature_registers + predictor_registers + action_registers + pipeline_registers)

    # -- MACs --------------------------------------------------------------
    # One MAC per (feature, output) pair for prediction, plus one more for
    # the matching weight-update multiply-accumulate per output -- for
    # BOTH the value predictor(s) and (Mode 3+) the Q-function predictor.
    total_outputs = num_outputs + q_outputs
    predict_macs = num_features * total_outputs
    update_macs = num_features * total_outputs
    mac_count = predict_macs + update_macs

    # -- Memory (learning memory + ring buffers, already counted above as
    # registers on a small FPGA-class design; reported again here as raw
    # bit-capacity for a BRAM-mapping estimate) --------------------------
    memory_bits = int(cfg.memory_depth * learning_memory_words_per_entry * bits)

    # -- LUT equivalent ----------------------------------------------------
    multiplier_luts = mac_count * bits * LUTS_PER_BIT_MULTIPLIER
    adder_luts = (mac_count + total_outputs + num_actions) * bits * LUTS_PER_BIT_ADDER
    comparator_luts = (num_actions + 5) * bits * LUTS_PER_BIT_COMPARATOR  # constraint engine's 5 checks + action-select compares
    register_luts = register_count * 0.15  # flops usually come "free" on an FPGA slice, but routing/mux logic isn't
    lut_equivalent = int(multiplier_luts + adder_luts + comparator_luts + register_luts)

    # -- Timing / power (order-of-magnitude only, see module docstring) ---
    critical_path_ns = BASE_CLOCK_NS + bits * CLOCK_NS_PER_BIT_OF_MULTIPLIER
    estimated_clock_mhz = 1000.0 / critical_path_ns

    dynamic_power = (
        lut_equivalent * DYNAMIC_POWER_PER_LUT_MW
        + register_count * DYNAMIC_POWER_PER_REG_MW
        + mac_count * DYNAMIC_POWER_PER_MAC_MW
    )
    estimated_power_mw = STATIC_POWER_MW + dynamic_power

    return SynthesisEstimate(
        mode=cfg.mode.name if num_agents == 1 else f"{cfg.mode.name} x{num_agents} PEs",
        fixed_format=fmt.name,
        num_features=num_features,
        num_outputs=num_outputs,
        num_actions=num_actions,
        ring_depth=ring_depth,
        memory_depth=cfg.memory_depth,
        register_count=register_count * num_agents,
        mac_count=mac_count * num_agents,
        lut_equivalent=lut_equivalent * num_agents,
        memory_bits=memory_bits * num_agents,
        pipeline_depth=PIPELINE_DEPTH,
        estimated_clock_mhz=estimated_clock_mhz,  # per-agent critical path is unchanged by replication
        estimated_power_mw=STATIC_POWER_MW + (estimated_power_mw - STATIC_POWER_MW) * num_agents,
    )


def estimate_all_modes(fmt: FixedFormat, feature_order: list, actions: list, distributed_agents: int = 16) -> list:
    """One estimate per Section 26 complexity mode, sharing the same
    fixed-point format/feature/action config so the comparison isolates
    ONLY the effect of mode (predictor width, mostly). Mode 4 is reported
    as ``distributed_agents`` replicated copies of the per-PE datapath."""
    rows = []
    for mode in Mode:
        cfg = EngineConfig(fmt=fmt, mode=mode, feature_order=list(feature_order), actions=list(actions))
        num_agents = distributed_agents if mode == Mode.MODE_4_DISTRIBUTED else 1
        rows.append(estimate_resources(cfg, num_agents=num_agents))
    return rows
