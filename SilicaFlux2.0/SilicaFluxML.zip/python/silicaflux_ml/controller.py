"""
silicaflux_ml.controller
===========================

Section 13 (Adaptive Hardware) / Section 27 (Self-Optimising SilicaFlux).

    SilicaFlux fabric -> telemetry -> ML engine -> configuration
    recommendation -> constraint checker -> configuration controller
    -> (back to) SilicaFlux fabric

:class:`SilicaFluxController` is the glue object that actually closes
this loop each cycle: sample the fabric, run one LearningEngine pass
(which internally does its own constraint check), and only if VALID
call ``fabric.apply_action`` -- the configuration controller step.

Mode 4 (Section 26/16) additionally instantiates one LearningEngine PER
PE and layers a fabric-wide workload-redistribution decision informed by
every PE-local agent's action, showing the "distributed learning
fabric" end of the complexity curve.
"""

from __future__ import annotations

from dataclasses import dataclass

from .action_selector import Action
from .constraint_engine import HardLimits
from .fabric import SilicaFluxFabric
from .fixed_point import DEFAULT_FORMAT, FixedFormat
from .learning_engine import EngineConfig, EngineOutput, LearningEngine
from .modes import Mode


def default_hard_limits() -> HardLimits:
    """Sensible hard safety limits for the default fabric model's
    normalised units. These are configuration, not learned state."""
    return HardLimits(
        power_max=18.0,  # total fabric power budget (16 PEs * ~1.1 typical ceiling)
        temperature_max=1.05,  # normalised temperature register, 1.0 == 100C
        freq_min=0.2,
        freq_max=2.2,
        voltage_min=0.5,
        voltage_max=1.5,
        parallelism_min=8.0,   # 0.5x concurrency at the default 4x4 fabric
        parallelism_max=64.0,  # 4.0x concurrency at the default 4x4 fabric
    )


def _limits_to_fixed(limits: HardLimits, fmt: FixedFormat) -> HardLimits:
    from .fixed_point import to_fixed

    return HardLimits(
        power_max=to_fixed(limits.power_max, fmt),
        temperature_max=to_fixed(limits.temperature_max, fmt),
        freq_min=to_fixed(limits.freq_min, fmt),
        freq_max=to_fixed(limits.freq_max, fmt),
        voltage_min=to_fixed(limits.voltage_min, fmt),
        voltage_max=to_fixed(limits.voltage_max, fmt),
        parallelism_min=to_fixed(limits.parallelism_min, fmt),
        parallelism_max=to_fixed(limits.parallelism_max, fmt),
    )


@dataclass
class CycleResult:
    cycle: int
    engine_output: EngineOutput
    applied_action: int
    reward_float: float
    throughput: float
    power: float
    temperature: float
    safety_override: bool = False


class SilicaFluxController(object):
    """Closes the Section 13 / 27 feedback loop for Modes 0-3 (a single
    fabric-wide LearningEngine)."""

    def __init__(
        self,
        fabric: SilicaFluxFabric,
        engine_cfg: EngineConfig | None = None,
        limits: HardLimits | None = None,
    ):
        self.fabric = fabric
        self.engine_cfg = engine_cfg or EngineConfig()
        self.engine = LearningEngine(self.engine_cfg)
        raw_limits = limits or default_hard_limits()
        self.engine.set_limits(_limits_to_fixed(raw_limits, self.engine_cfg.fmt))

    def step(self, workload_intensity: float, fault_pe=None) -> CycleResult:
        fmt = self.engine.fmt
        self.fabric.step(workload_intensity, fault_pe=fault_pe)
        state = self.fabric.aggregate_state(fmt)

        output = self.engine.run_cycle(state, lambda action: self.fabric.candidate_for_action(action, fmt))

        # Independent safety watchdog (Section 14): looks at the fabric's
        # ACTUAL current telemetry, not the learning engine's candidate,
        # and can override the chosen action entirely. This sits fully
        # outside the learning algorithm -- it runs whether or not the
        # engine's own constraint check already passed.
        actual = self.fabric.candidate_for_action(Action.MAINTAIN_CONFIGURATION, fmt)
        trip = self.engine.constraint_engine.trip_action(actual)
        safety_override = trip is not None
        action_to_apply = trip if safety_override else output.action

        if safety_override or output.valid:
            self.fabric.apply_action(action_to_apply)

        return CycleResult(
            cycle=output.cycle,
            engine_output=output,
            applied_action=int(action_to_apply),
            reward_float=output.reward / fmt.scale,
            throughput=state.throughput / fmt.scale,
            safety_override=safety_override,
            power=state.power / fmt.scale,
            temperature=state.temperature / fmt.scale,
        )


class DistributedSilicaFluxController(object):
    """Mode 4 (Section 16/26): one LearningEngine PER PE, each seeing only
    its own PE's local telemetry, plus the fabric's existing
    workload_score()-based spatial scheduler (Section 16/17) reacting to
    each PE-local agent's ACTIVATE/DEACTIVATE/frequency actions."""

    def __init__(
        self,
        fabric: SilicaFluxFabric,
        engine_cfg: EngineConfig | None = None,
        limits: HardLimits | None = None,
    ):
        self.fabric = fabric
        base_cfg = engine_cfg or EngineConfig(mode=Mode.MODE_4_DISTRIBUTED)
        raw_limits = limits or default_hard_limits()
        self.limits = _limits_to_fixed(raw_limits, base_cfg.fmt)
        self.agents: dict = {}
        for pid in fabric.pes:
            cfg = EngineConfig(**{**base_cfg.__dict__})
            engine = LearningEngine(cfg)
            engine.set_limits(self.limits)
            self.agents[pid] = engine

    def _pe_state(self, pe, fmt):
        from .fixed_point import to_fixed
        from .state_vector import HardwareStateVector

        return HardwareStateVector(
            utilisation=to_fixed(pe.utilisation, fmt),
            throughput=to_fixed(pe.throughput, fmt),
            latency=to_fixed(pe.latency, fmt),
            power=to_fixed(pe.power, fmt),
            temperature=to_fixed(pe.temperature / 100.0, fmt),
            clock_frequency=to_fixed(self.fabric.frequency, fmt),
            voltage=to_fixed(self.fabric.voltage, fmt),
            memory_pressure=to_fixed(pe.queue_depth / 4.0, fmt),
            pipeline_utilisation=to_fixed(pe.utilisation, fmt),
            queue_depth=to_fixed(pe.queue_depth, fmt),
            error_rate=to_fixed(pe.errors, fmt),
            thermal_headroom=to_fixed(max(0.0, 1.0 - pe.temperature / 100.0), fmt),
        )

    def step(self, workload_intensity: float, fault_pe=None) -> dict:
        self.fabric.step(workload_intensity, fault_pe=fault_pe)

        per_pe_reward = {}
        for pid, pe in self.fabric.pes.items():
            engine = self.agents[pid]
            fmt = engine.fmt
            state = self._pe_state(pe, fmt)

            def candidate_fn(action, _pe=pe, fmt=fmt):
                # A PE-local action only ever scales THAT PE's own
                # utilisation/temperature/power proxy -- fabric-wide
                # frequency/voltage/parallelism stay under the (absent, in
                # this mode) fabric-level controller, so those limits pass
                # through unchanged and only the PE's own thermal/power
                # numbers are actually being checked.
                from .constraint_engine import CandidateConfiguration
                from .fixed_point import to_fixed

                return CandidateConfiguration(
                    power=to_fixed(_pe.power, fmt),
                    temperature=to_fixed(_pe.temperature / 100.0, fmt),
                    frequency=to_fixed(self.fabric.frequency, fmt),
                    voltage=to_fixed(self.fabric.voltage, fmt),
                    parallelism=to_fixed(self.fabric.parallelism, fmt),
                )

            output = engine.run_cycle(state, candidate_fn)
            per_pe_reward[pid] = output.reward / engine.fmt.scale

            if output.valid:
                from .action_selector import Action

                if output.action == Action.ACTIVATE_COMPUTE_UNIT:
                    pe.active = True
                elif output.action == Action.DEACTIVATE_COMPUTE_UNIT:
                    pe.active = False
                elif output.action == Action.INCREASE_PARALLELISM:
                    pe.allocation *= 1.1
                elif output.action == Action.DECREASE_PARALLELISM:
                    pe.allocation *= 0.9

        self.fabric.redistribute()
        return per_pe_reward
