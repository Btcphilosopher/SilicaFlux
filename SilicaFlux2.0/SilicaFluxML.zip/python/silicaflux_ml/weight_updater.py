"""
silicaflux_ml.weight_updater
==============================

Section 8 (Online Learning).

Incremental, hardware-friendly gradient-style update:

    error     = observed - predicted
    weight[i] = weight[i] + learning_rate * error * feature[i]

with saturation on every intermediate step (Section 8: "prevent numerical
instability") and two configurable gate registers that a pure software
optimiser wouldn't need but a control-loop ASIC does:

    error_threshold  -- suppress updates from measurement noise
    update_interval  -- update once every N cycles, not every cycle,
                        to bound switching activity / dynamic power
"""

from __future__ import annotations

from .fixed_point import (
    FixedFormat,
    DEFAULT_FORMAT,
    fixed_add,
    fixed_sub,
    fixed_mul,
    fixed_abs,
    fixed_clamp_range,
)
from .predictor import OutputModel


class WeightUpdaterConfig:
    __slots__ = (
        "learning_rate",
        "weight_min",
        "weight_max",
        "error_threshold",
        "update_interval",
    )

    def __init__(
        self,
        learning_rate: int,
        weight_min: int,
        weight_max: int,
        error_threshold: int = 0,
        update_interval: int = 1,
    ):
        self.learning_rate = learning_rate  # fixed-point raw, typically << 1.0
        self.weight_min = weight_min
        self.weight_max = weight_max
        self.error_threshold = error_threshold
        self.update_interval = max(1, update_interval)


class WeightUpdater:
    """Online learning engine (Section 8) driving one or more OutputModels.

    One instance is shared by every :class:`~silicaflux_ml.predictor.OutputModel`
    it updates -- in RTL this is the shared weight-update datapath that time-
    multiplexes across the per-output weight-register files.
    """

    def __init__(self, fmt: FixedFormat, cfg: WeightUpdaterConfig):
        self.fmt = fmt
        self.cfg = cfg
        self._tick = 0

    def maybe_update(self, model: OutputModel, features: list, observed: int, predicted: int):
        """Run stage 4 (error) + stage 6 (weight update) of the model-update
        pipeline for a single OutputModel. Returns (error, updated: bool)."""
        fmt = self.fmt
        cfg = self.cfg
        self._tick += 1

        error = fixed_sub(observed, predicted, fmt)

        gated_by_threshold = fixed_abs(error, fmt) < cfg.error_threshold
        gated_by_interval = (self._tick % cfg.update_interval) != 0
        if gated_by_threshold or gated_by_interval:
            return error, False

        for i, x in enumerate(features):
            grad = fixed_mul(cfg.learning_rate, fixed_mul(error, x, fmt), fmt)
            updated = fixed_add(model.weights[i], grad, fmt)
            model.weights[i] = fixed_clamp_range(updated, cfg.weight_min, cfg.weight_max, fmt)

        bias_grad = fixed_mul(cfg.learning_rate, error, fmt)
        model.bias = fixed_clamp_range(
            fixed_add(model.bias, bias_grad, fmt), cfg.weight_min, cfg.weight_max, fmt
        )
        return error, True
