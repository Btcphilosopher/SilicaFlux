"""
silicaflux_ml.learning_memory
================================

Section 12 (Learning Memory).

A bounded circular buffer of recent (state, action, predicted, observed,
reward, error) tuples -- explicitly NOT a neural-network-scale replay
buffer. Depth is a synthesis-time parameter (a small on-chip SRAM/BRAM),
default 64 entries, and old entries are simply overwritten -- exactly
what ``collections.deque(maxlen=depth)`` does, which is why it's used
here as the bit-accurate stand-in for that SRAM's write pointer wrap.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field


@dataclass
class LearningRecord:
    cycle: int
    state: list
    action: int
    predicted: dict
    observed: dict
    reward: int
    error: dict


class LearningMemory:
    """Circular buffer of recent learning observations (Section 12)."""

    def __init__(self, depth: int = 64):
        self.depth = depth
        self.buf: deque = deque(maxlen=depth)

    def push(self, record: LearningRecord) -> None:
        self.buf.append(record)

    def __len__(self) -> int:
        return len(self.buf)

    def __iter__(self):
        return iter(self.buf)

    def latest(self):
        return self.buf[-1] if self.buf else None

    def as_list(self) -> list:
        return list(self.buf)
