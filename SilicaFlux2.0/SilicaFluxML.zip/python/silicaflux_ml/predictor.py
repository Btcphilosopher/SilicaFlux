"""
silicaflux_ml.predictor
=========================

Section 6 (Hardware-Native Model) / Section 7 (Multi-Model Prediction).

Baseline model is affine/linear, evaluated entirely with fixed-point
multiply-accumulate hardware:

    Y = W0*X0 + W1*X1 + ... + Wn*Xn + B

One :class:`OutputModel` (one weight-register file + bias register + MAC
pipeline) exists per predicted quantity; :class:`Predictor` just fans the
shared feature vector out to N of them in parallel, matching the
STATE VECTOR -> {THROUGHPUT, POWER, TEMPERATURE, ...} MODEL diagram in
Section 7.
"""

from __future__ import annotations

from .fixed_point import FixedFormat, DEFAULT_FORMAT, MacUnit, fixed_add, fixed_clamp_range


class OutputModel:
    """Weight-register file + bias register + MAC pipeline for ONE
    predicted output.

    Hardware mapping:
        weights[i]  -> one register per feature, width = fmt.total_bits
        bias        -> one register, width = fmt.total_bits
        predict()   -> one pass through a MacUnit pipeline (Section 20,
                       stage 3) then a single saturating adder for the bias
    """

    __slots__ = ("name", "fmt", "num_features", "weights", "bias", "weight_min", "weight_max")

    def __init__(
        self,
        name: str,
        num_features: int,
        fmt: FixedFormat = DEFAULT_FORMAT,
        weight_min: int | None = None,
        weight_max: int | None = None,
    ):
        self.name = name
        self.fmt = fmt
        self.num_features = num_features
        self.weights = [0] * num_features
        self.bias = 0
        self.weight_min = fmt.min_raw if weight_min is None else weight_min
        self.weight_max = fmt.max_raw if weight_max is None else weight_max

    def predict(self, features: list) -> int:
        mac = MacUnit(self.fmt)
        for w, x in zip(self.weights, features):
            mac.mac(w, x)
        return fixed_add(mac.read(), self.bias, self.fmt)

    def clamp_weights(self) -> None:
        self.weights = [
            fixed_clamp_range(w, self.weight_min, self.weight_max, self.fmt) for w in self.weights
        ]
        self.bias = fixed_clamp_range(self.bias, self.weight_min, self.weight_max, self.fmt)

    def snapshot(self) -> dict:
        return {"name": self.name, "weights": list(self.weights), "bias": self.bias}


class Predictor:
    """Multi-output prediction block (Section 7): STATE/FEATURE VECTOR
    fanned out to one :class:`OutputModel` per predicted quantity, in
    parallel."""

    DEFAULT_OUTPUTS = (
        "predicted_throughput",
        "predicted_power",
        "predicted_temperature",
        "predicted_latency",
        "predicted_error_probability",
    )

    def __init__(
        self,
        num_features: int,
        fmt: FixedFormat = DEFAULT_FORMAT,
        output_names: tuple | list = DEFAULT_OUTPUTS,
        weight_min: int | None = None,
        weight_max: int | None = None,
    ):
        self.fmt = fmt
        self.num_features = num_features
        self.output_names = list(output_names)
        self.models = {
            name: OutputModel(name, num_features, fmt, weight_min, weight_max)
            for name in self.output_names
        }

    def predict(self, features: list) -> dict:
        return {name: model.predict(features) for name, model in self.models.items()}

    def clamp_all(self) -> None:
        for m in self.models.values():
            m.clamp_weights()
