"""
silicaflux_ml.modes
======================

Section 26 (ML Complexity Modes).

Five points on the same architecture's complexity/capability curve, used
by the benchmark suite and the synthesis estimator to show how resource
cost scales with capability:

    MODE_0  static optimiser            -- no learning, fixed action
    MODE_1  linear adaptive optimiser   -- single-output predictor + WeightUpdater
    MODE_2  multi-output predictor      -- Section 7's parallel per-quantity models
    MODE_3  online reinforcement learner -- full action-value RL loop
    MODE_4  distributed learning fabric -- one Mode-3 agent per PE + fabric scheduler
"""

from __future__ import annotations

from enum import IntEnum


class Mode(IntEnum):
    MODE_0_STATIC = 0
    MODE_1_LINEAR_ADAPTIVE = 1
    MODE_2_MULTI_OUTPUT = 2
    MODE_3_ONLINE_RL = 3
    MODE_4_DISTRIBUTED = 4


MODE_DESCRIPTIONS = {
    Mode.MODE_0_STATIC: "Static optimiser: fixed configuration, no prediction, no learning.",
    Mode.MODE_1_LINEAR_ADAPTIVE: "Linear adaptive optimiser: one affine predictor + online weight updates.",
    Mode.MODE_2_MULTI_OUTPUT: "Multi-output predictor: parallel throughput/power/temperature/latency/error models.",
    Mode.MODE_3_ONLINE_RL: "Online reinforcement learner: full action-value RL loop with epsilon-greedy exploration.",
    Mode.MODE_4_DISTRIBUTED: "Distributed learning fabric: one online-RL agent per PE plus fabric-level workload scheduling.",
}
