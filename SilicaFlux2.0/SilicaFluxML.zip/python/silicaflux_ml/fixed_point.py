"""
silicaflux_ml.fixed_point
==========================

Section 21 (Fixed-Point Arithmetic) / Section 32 (Bit-Accurate Simulation).

Every numeric value that would eventually live in a hardware register is
represented here as a plain Python ``int`` holding a two's-complement
*raw* value, plus a :class:`FixedFormat` describing how many integer and
fractional bits that register is synthesised with. There is exactly one
implicit assumption matching real silicon: the format of a given
register/wire is a synthesis-time constant, not something carried around
per-value -- callers pass the format in explicitly, the same way a
Verilog signal's width is fixed at elaboration time.

    raw_value  ==  round(real_value * 2**frac_bits)

All arithmetic primitives below round-trip through a **wider intermediate
value** and then saturate (never wrap) back down to the format's native
range, which is how a well-behaved DSP/MAC slice or ALU is built in
RTL: multiply into a double-width product register, then clip when it is
read back out through a narrower output port.

    fixed_mul() fixed_add() fixed_sub() fixed_div()
    fixed_clip() fixed_abs() fixed_compare()

are the exact set of primitives requested in Section 21; everything else
in this module (MacUnit, format constants, float<->fixed conversion) is
built strictly on top of them.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class FixedFormat:
    """A synthesis-time fixed-point number format, Q<int_bits>.<frac_bits>.

    ``int_bits`` follows the common Qm.n convention: it INCLUDES the sign
    bit. So Q16.16 is a 32-bit register: 16 bits of integer part
    (including sign) + 16 bits of fraction.
    """

    int_bits: int
    frac_bits: int
    signed: bool = True

    @property
    def total_bits(self) -> int:
        return self.int_bits + self.frac_bits

    @property
    def scale(self) -> int:
        return 1 << self.frac_bits

    @property
    def max_raw(self) -> int:
        if self.signed:
            return (1 << (self.total_bits - 1)) - 1
        return (1 << self.total_bits) - 1

    @property
    def min_raw(self) -> int:
        if self.signed:
            return -(1 << (self.total_bits - 1))
        return 0

    @property
    def name(self) -> str:
        return f"Q{self.int_bits}.{self.frac_bits}"

    def resolution(self) -> float:
        """Smallest representable positive step (an LSB), as a real number."""
        return 1.0 / self.scale

    def full_scale_range(self) -> tuple[float, float]:
        """(min, max) representable real values for this format."""
        return (self.min_raw / self.scale, self.max_raw / self.scale)


# Standard formats named in Section 21, provided as ready-made registers.
Q8_8 = FixedFormat(int_bits=8, frac_bits=8)
Q16_16 = FixedFormat(int_bits=16, frac_bits=16)
Q24_8 = FixedFormat(int_bits=24, frac_bits=8)

DEFAULT_FORMAT = Q16_16


# ---------------------------------------------------------------------------
# Conversion (test-bench / telemetry-ingest side only -- a real chip never
# does float math; this is how a testbench hands a real-world number to a
# register, and how a waveform viewer would render one back for a human).
# ---------------------------------------------------------------------------

def to_fixed(value: float, fmt: FixedFormat = DEFAULT_FORMAT) -> int:
    """Quantise a real number into the raw two's-complement register value."""
    raw = int(round(value * fmt.scale))
    return fixed_clip(raw, fmt)


def to_float(raw: int, fmt: FixedFormat = DEFAULT_FORMAT) -> float:
    """De-quantise a raw register value back to a real number (for display)."""
    return raw / fmt.scale


# ---------------------------------------------------------------------------
# Core RTL-style primitives
# ---------------------------------------------------------------------------

def fixed_clip(raw: int, fmt: FixedFormat = DEFAULT_FORMAT) -> int:
    """Saturate ``raw`` into the register's representable range.

    This is the behaviour of a saturating output port / accumulator
    read-out mux, NOT a wraparound truncation -- wraparound in a control
    loop like this would be a safety bug, so every primitive below routes
    its result through this function before it is allowed to leave the
    "hardware".
    """
    if raw > fmt.max_raw:
        return fmt.max_raw
    if raw < fmt.min_raw:
        return fmt.min_raw
    return raw


def fixed_add(a: int, b: int, fmt: FixedFormat = DEFAULT_FORMAT) -> int:
    """Saturating fixed-point add. Same format in, same format out."""
    return fixed_clip(a + b, fmt)


def fixed_sub(a: int, b: int, fmt: FixedFormat = DEFAULT_FORMAT) -> int:
    """Saturating fixed-point subtract."""
    return fixed_clip(a - b, fmt)


def fixed_mul(a: int, b: int, fmt: FixedFormat = DEFAULT_FORMAT) -> int:
    """Saturating fixed-point multiply.

    Mirrors a single DSP-slice multiplier: the raw integer product is
    computed at full (double) width, right-shifted by ``frac_bits`` to
    rescale back to the format's binary point, and only THEN saturated
    down to the native width. Python's ``>>`` on an int is an arithmetic
    (floor) shift, which is exactly the truncating rescale a plain
    combinational shifter performs.
    """
    wide_product = a * b
    rescaled = wide_product >> fmt.frac_bits
    return fixed_clip(rescaled, fmt)


def fixed_div(a: int, b: int, fmt: FixedFormat = DEFAULT_FORMAT) -> int:
    """Saturating fixed-point divide, truncating toward zero.

    A divide-by-zero saturates to +max/-min depending on the sign of the
    numerator, matching a guarded hardware divider that refuses to hang
    the pipeline on a zero divisor and instead asserts its output rail.
    """
    if b == 0:
        return fmt.max_raw if a >= 0 else fmt.min_raw
    wide_numerator = a << fmt.frac_bits
    magnitude = abs(wide_numerator) // abs(b)
    result = magnitude if (wide_numerator >= 0) == (b > 0) else -magnitude
    return fixed_clip(result, fmt)


def fixed_div_int(raw: int, n: int, fmt: FixedFormat = DEFAULT_FORMAT) -> int:
    """Divide a fixed-point accumulator by a plain integer COUNT register.

    Used by rolling-average style hardware where the divisor is a small
    counter (e.g. ring-buffer occupancy), not another fixed-point value --
    on real silicon this is either a shifter (power-of-two depth) or a
    small integer divider, never a fixed-point/fixed-point division.
    """
    if n <= 0:
        return 0
    magnitude = abs(raw) // n
    result = magnitude if raw >= 0 else -magnitude
    return fixed_clip(result, fmt)


def fixed_abs(a: int, fmt: FixedFormat = DEFAULT_FORMAT) -> int:
    """Saturating absolute value (handles the min_raw edge case)."""
    return fixed_clip(abs(a), fmt)


def fixed_compare(a: int, b: int) -> int:
    """Three-way compare, exactly what a hardware comparator's {LT,EQ,GT}
    flag bits encode: -1 (a<b), 0 (a==b), +1 (a>b)."""
    if a < b:
        return -1
    if a > b:
        return 1
    return 0


def fixed_clamp_range(raw: int, lo: int, hi: int, fmt: FixedFormat = DEFAULT_FORMAT) -> int:
    """Clamp to an arbitrary [lo, hi] register-pair range, then saturate to
    the format. Used by WeightUpdater for configurable weight_min/weight_max."""
    if raw < lo:
        raw = lo
    elif raw > hi:
        raw = hi
    return fixed_clip(raw, fmt)


class MacUnit:
    """A single multiply-accumulate pipeline slice (Section 6/20).

    Mirrors a DSP48-style MAC: each ``mac()`` call performs one
    multiply-rescale-add against a *wider* accumulator register
    (``total_bits + guard_bits``) so a long dot-product does not
    overflow between terms the way naively saturating after every term
    would. Only ``read()`` saturates down to the caller-visible format,
    matching an accumulator register with a narrower saturating output
    mux.
    """

    __slots__ = ("fmt", "guard_bits", "acc", "_acc_max", "_acc_min")

    def __init__(self, fmt: FixedFormat = DEFAULT_FORMAT, guard_bits: int = 8):
        self.fmt = fmt
        self.guard_bits = guard_bits
        acc_bits = fmt.total_bits + guard_bits
        self._acc_max = (1 << (acc_bits - 1)) - 1
        self._acc_min = -(1 << (acc_bits - 1))
        self.acc = 0

    def reset(self) -> None:
        self.acc = 0

    def mac(self, a: int, b: int) -> None:
        product = (a * b) >> self.fmt.frac_bits
        acc = self.acc + product
        if acc > self._acc_max:
            acc = self._acc_max
        elif acc < self._acc_min:
            acc = self._acc_min
        self.acc = acc

    def read(self) -> int:
        return fixed_clip(self.acc, self.fmt)


def dot(weights, features, fmt: FixedFormat = DEFAULT_FORMAT, guard_bits: int = 8) -> int:
    """Convenience wrapper: run a full weight/feature dot product through a
    single MacUnit pipeline, as :class:`~silicaflux_ml.predictor.OutputModel`
    does per output."""
    mac = MacUnit(fmt, guard_bits=guard_bits)
    for w, x in zip(weights, features):
        mac.mac(w, x)
    return mac.read()
