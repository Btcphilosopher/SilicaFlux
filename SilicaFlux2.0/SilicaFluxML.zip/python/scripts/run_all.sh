#!/usr/bin/env bash
# Runs the full verification + benchmark suite in one shot.
# Usage: bash python/scripts/run_all.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PYTHON_DIR"
echo "=== unit + integration tests ==="
python3 -m unittest discover -s tests

cd "$PYTHON_DIR/benchmarks"
echo
echo "=== convergence analysis (Section 29) ==="
python3 run_convergence.py

echo
echo "=== ablation suite (Section 30) ==="
python3 run_ablation.py

echo
echo "=== fixed-point precision comparison (Section 21/32) ==="
python3 run_precision_comparison.py

echo
echo "=== synthesis resource estimate (Section 25/26) ==="
python3 run_synthesis_estimate.py

echo
echo "=== Mode 4 (distributed) demo (Section 16/26) ==="
python3 run_mode4_demo.py

echo
echo "All done. See $PYTHON_DIR/results/ for CSV + SVG output."
