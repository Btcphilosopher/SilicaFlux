#!/usr/bin/env python3
"""
Section 29 (Convergence Analysis).

Runs each Section 26 complexity mode (0/1/2/3) for the same synthetic
workload/fault trace and tracks:

    reward over time
    throughput over time
    energy efficiency over time     (throughput / power)
    prediction error over time      (mean |observed - predicted| across outputs)
    temperature over time
    policy stability                (fraction of cycles the chosen action
                                      CHANGED from the previous cycle,
                                      over a sliding window -- lower means
                                      a more settled policy)

Writes one CSV of raw per-cycle metrics per mode plus four SVG learning
curves into ``results/``.
"""

import csv
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from silicaflux_ml.fabric import SilicaFluxFabric, WorkloadGenerator
from silicaflux_ml.controller import SilicaFluxController
from silicaflux_ml.learning_engine import EngineConfig
from silicaflux_ml.modes import Mode

from svg_chart import line_chart

RESULTS_DIR = os.path.join(os.path.dirname(__file__), "..", "results")
CYCLES = int(os.environ.get("SF_CONVERGENCE_CYCLES", "8000"))
GRID = (4, 4)
SEED = 3
STABILITY_WINDOW = 200


def run_mode(mode: Mode, cycles: int = CYCLES, seed: int = SEED):
    fabric = SilicaFluxFabric(*GRID, seed=seed)
    ctrl = SilicaFluxController(fabric, EngineConfig(mode=mode))
    gen = WorkloadGenerator(seed=seed)

    rows = []
    prev_action = None
    change_window = []
    for i in range(cycles):
        intensity, fault_pe = gen.next(i, GRID)
        result = ctrl.step(intensity, fault_pe)
        out = result.engine_output

        pred_error = 0.0
        if out.errors:
            pred_error = sum(abs(e) for e in out.errors.values()) / (65536.0 * len(out.errors))

        efficiency = result.throughput / max(result.power, 1e-6)

        changed = 0 if prev_action is None else int(result.applied_action != prev_action)
        prev_action = result.applied_action
        change_window.append(changed)
        if len(change_window) > STABILITY_WINDOW:
            change_window.pop(0)
        instability = sum(change_window) / len(change_window)

        rows.append({
            "cycle": i,
            "reward": round(result.reward_float, 6),
            "throughput": round(result.throughput, 6),
            "power": round(result.power, 6),
            "temperature": round(result.temperature, 6),
            "efficiency": round(efficiency, 6),
            "prediction_error": round(pred_error, 6),
            "action": result.applied_action,
            "valid": int(out.valid),
            "safety_override": int(result.safety_override),
            "policy_instability": round(instability, 6),
        })
    return rows


def write_csv(rows, path):
    if not rows:
        return
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main():
    os.makedirs(RESULTS_DIR, exist_ok=True)
    modes = [Mode.MODE_0_STATIC, Mode.MODE_1_LINEAR_ADAPTIVE, Mode.MODE_2_MULTI_OUTPUT, Mode.MODE_3_ONLINE_RL]
    all_rows = {}

    print(f"Running convergence analysis: {CYCLES} cycles x {len(modes)} modes on a {GRID[0]}x{GRID[1]} fabric\n")
    for mode in modes:
        rows = run_mode(mode)
        all_rows[mode] = rows
        write_csv(rows, os.path.join(RESULTS_DIR, f"convergence_{mode.name}.csv"))

        tail = rows[-1000:]
        avg_reward = sum(r["reward"] for r in tail) / len(tail)
        avg_thr = sum(r["throughput"] for r in tail) / len(tail)
        avg_eff = sum(r["efficiency"] for r in tail) / len(tail)
        avg_temp = sum(r["temperature"] for r in tail) / len(tail)
        avg_instability = sum(r["policy_instability"] for r in tail) / len(tail)
        print(
            f"{mode.name:22s}  reward={avg_reward:+7.3f}  throughput={avg_thr:5.3f}  "
            f"efficiency={avg_eff:6.3f}  temp={avg_temp:5.3f}  policy_instability={avg_instability:5.3f}"
        )

    print(f"\nWriting learning curves to {RESULTS_DIR}/ ...")
    metrics = [
        ("reward", "reward_curve.svg", "Reward over time", "reward (float)"),
        ("throughput", "learning_curve.svg", "Throughput over time", "throughput"),
        ("prediction_error", "prediction_error_curve.svg", "Prediction error over time", "mean |observed - predicted|"),
        ("efficiency", "efficiency_curve.svg", "Energy efficiency over time (throughput / power)", "efficiency"),
    ]
    for key, filename, title, ylabel in metrics:
        series = {mode.name: [r[key] for r in all_rows[mode]] for mode in modes}
        line_chart(series, os.path.join(RESULTS_DIR, filename), title=title, xlabel="cycle", ylabel=ylabel, rolling=100)

    print("Done.")


if __name__ == "__main__":
    main()
