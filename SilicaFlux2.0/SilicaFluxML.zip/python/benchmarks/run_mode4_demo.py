#!/usr/bin/env python3
"""
Section 16/26: Mode 4 (distributed learning fabric) demonstration.

One LearningEngine PER PE, each seeing only its own local telemetry, plus
the fabric's workload_score() spatial scheduler reacting to every agent's
ACTIVATE/DEACTIVATE/parallelism actions. Slower than the fabric-level
modes (16x the per-cycle engine work on the default 4x4 grid), so this is
a shorter demonstration run rather than a full convergence sweep.
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from silicaflux_ml.fabric import SilicaFluxFabric, WorkloadGenerator
from silicaflux_ml.controller import DistributedSilicaFluxController
from silicaflux_ml.learning_engine import EngineConfig
from silicaflux_ml.modes import Mode

CYCLES = int(os.environ.get("SF_MODE4_CYCLES", "3000"))
GRID = (4, 4)
SEED = 11


def main():
    fabric = SilicaFluxFabric(*GRID, seed=SEED)
    ctrl = DistributedSilicaFluxController(fabric, EngineConfig(mode=Mode.MODE_4_DISTRIBUTED))
    gen = WorkloadGenerator(seed=SEED)

    print(f"Mode 4 distributed fabric: {CYCLES} cycles, {GRID[0]}x{GRID[1]} PEs, one LearningEngine each\n")
    checkpoints = [0, CYCLES // 4, CYCLES // 2, (3 * CYCLES) // 4, CYCLES - 1]
    for i in range(CYCLES):
        intensity, fault_pe = gen.next(i, GRID)
        rewards = ctrl.step(intensity, fault_pe)
        if i in checkpoints:
            active = sum(1 for p in fabric.pes.values() if p.active)
            avg_reward = sum(rewards.values()) / len(rewards)
            avg_temp = sum(p.temperature for p in fabric.pes.values()) / len(fabric.pes)
            print(
                f"cycle {i:5d}  active_PEs={active:2d}/{len(fabric.pes)}  "
                f"avg_per_PE_reward={avg_reward:+6.3f}  avg_temp={avg_temp:5.1f}C"
            )

    print("\nFinal per-PE health snapshot:")
    for (r, c), pe in fabric.pes.items():
        health = fabric.health_score(pe)
        print(f"  PE({r},{c})  active={pe.active!s:5s}  util={pe.utilisation:.2f}  temp={pe.temperature:5.1f}C  health={health:.2f}")


if __name__ == "__main__":
    main()
