#!/usr/bin/env python3
"""
Section 25 (Synthesis Estimation) / Section 26 (ML Complexity Modes).

Runs the resource-cost estimator (heuristic, NOT a synthesis tool -- see
synthesis_estimator.py's module docstring) across every complexity mode,
at every Section 21 fixed-point format, and writes one CSV table plus
grouped bar charts of the register/MAC/LUT/power curve across modes.
"""

import csv
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from silicaflux_ml.fixed_point import Q8_8, Q16_16, Q24_8
from silicaflux_ml.synthesis_estimator import estimate_all_modes
from silicaflux_ml.learning_engine import DEFAULT_FEATURE_ORDER
from silicaflux_ml.action_selector import DEFAULT_ACTIONS

from svg_chart import bar_chart

RESULTS_DIR = os.path.join(os.path.dirname(__file__), "..", "results")
FORMATS = [("Q8.8", Q8_8), ("Q16.16", Q16_16), ("Q24.8", Q24_8)]


def main():
    os.makedirs(RESULTS_DIR, exist_ok=True)
    all_rows = []

    for fmt_name, fmt in FORMATS:
        print(f"\n=== {fmt_name} ===")
        estimates = estimate_all_modes(fmt, DEFAULT_FEATURE_ORDER, DEFAULT_ACTIONS, distributed_agents=16)
        for est in estimates:
            row = est.as_row()
            all_rows.append(row)
            print(
                f"{row['mode']:24s}  regs={row['register_count']:7d}  macs={row['mac_count']:5d}  "
                f"LUTs={row['lut_equivalent']:7d}  mem_bits={row['memory_bits']:8d}  "
                f"clk={row['estimated_clock_mhz']:6.1f}MHz  power={row['estimated_power_mw']:7.2f}mW"
            )

    csv_path = os.path.join(RESULTS_DIR, "synthesis_estimates.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(all_rows[0].keys()))
        writer.writeheader()
        writer.writerows(all_rows)

    # Bar chart: register/MAC/LUT growth across modes, at Q16.16 only
    # (the fixed-point format barely moves these counts -- it moves clock
    # and power instead, shown in the second chart).
    q16_rows = [r for r in all_rows if r["fixed_format"] == "Q16.16"]
    categories = [r["mode"] for r in q16_rows]
    bar_chart(
        categories,
        {
            "register_count": [r["register_count"] for r in q16_rows],
            "lut_equivalent": [r["lut_equivalent"] for r in q16_rows],
        },
        os.path.join(RESULTS_DIR, "synthesis_resource_curve.svg"),
        title="Resource cost vs. ML complexity mode (Q16.16)",
        ylabel="count",
    )

    non_distributed = [r for r in all_rows if "x16" not in r["mode"]]
    fmt_categories = [f"{r['mode']}/{r['fixed_format']}" for r in non_distributed]
    bar_chart(
        fmt_categories,
        {"estimated_power_mw": [r["estimated_power_mw"] for r in non_distributed]},
        os.path.join(RESULTS_DIR, "synthesis_power_by_format.svg"),
        title="Estimated power vs. mode x fixed-point format",
        ylabel="estimated power (mW)",
    )

    print(f"\nWrote {csv_path} and synthesis_*.svg to {RESULTS_DIR}/")


if __name__ == "__main__":
    main()
