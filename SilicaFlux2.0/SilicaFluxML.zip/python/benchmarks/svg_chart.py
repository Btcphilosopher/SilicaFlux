"""
Tiny, dependency-free SVG chart writer used by the benchmark suite.

Deliberately hand-rolled instead of pulling in matplotlib: this package's
whole point is a transparent, inspectable pipeline with no hidden runtime,
and the benchmark plots are simple enough (line series, grouped bars) that
~120 lines of plain SVG generation covers everything Section 29/30 need
without adding a dependency the recipient has to pip-install.
"""

from __future__ import annotations

import html


PALETTE = ["#2f6fed", "#e0592a", "#1f9e6f", "#8a3ffc", "#c4180c", "#0f7b8a"]


def _scale(value, lo, hi, out_lo, out_hi):
    if hi - lo < 1e-12:
        return (out_lo + out_hi) / 2
    return out_lo + (value - lo) / (hi - lo) * (out_hi - out_lo)


def line_chart(
    series: dict,
    path: str,
    title: str = "",
    xlabel: str = "",
    ylabel: str = "",
    width: int = 900,
    height: int = 480,
    rolling: int = 1,
):
    """``series``: {label: [y0, y1, ...]} -- all lists share an implicit
    x-axis of 0..N-1. ``rolling`` optionally smooths each series with a
    trailing moving average before plotting (purely a display aid)."""
    margin = {"top": 50, "right": 30, "bottom": 60, "left": 70}
    plot_w = width - margin["left"] - margin["right"]
    plot_h = height - margin["top"] - margin["bottom"]

    def smooth(values):
        if rolling <= 1:
            return values
        out = []
        acc = 0.0
        for i, v in enumerate(values):
            acc += v
            if i >= rolling:
                acc -= values[i - rolling]
            out.append(acc / min(i + 1, rolling))
        return out

    smoothed = {label: smooth(values) for label, values in series.items()}
    all_values = [v for values in smoothed.values() for v in values]
    n = max((len(v) for v in smoothed.values()), default=1)
    y_lo, y_hi = (min(all_values), max(all_values)) if all_values else (0.0, 1.0)
    if y_hi - y_lo < 1e-9:
        y_hi = y_lo + 1.0
    pad = (y_hi - y_lo) * 0.08
    y_lo, y_hi = y_lo - pad, y_hi + pad

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}" font-family="Helvetica,Arial,sans-serif">',
        f'<rect width="{width}" height="{height}" fill="#ffffff"/>',
        f'<text x="{width/2}" y="24" font-size="18" text-anchor="middle" fill="#111">{html.escape(title)}</text>',
    ]

    # axes
    x0, y0 = margin["left"], margin["top"]
    x1, y1 = margin["left"] + plot_w, margin["top"] + plot_h
    parts.append(f'<line x1="{x0}" y1="{y1}" x2="{x1}" y2="{y1}" stroke="#333" stroke-width="1.5"/>')
    parts.append(f'<line x1="{x0}" y1="{y0}" x2="{x0}" y2="{y1}" stroke="#333" stroke-width="1.5"/>')

    # y gridlines + labels
    for i in range(5):
        frac = i / 4
        yv = y_lo + frac * (y_hi - y_lo)
        py = _scale(yv, y_lo, y_hi, y1, y0)
        parts.append(f'<line x1="{x0}" y1="{py:.1f}" x2="{x1}" y2="{py:.1f}" stroke="#eee" stroke-width="1"/>')
        parts.append(f'<text x="{x0-8}" y="{py+4:.1f}" font-size="11" text-anchor="end" fill="#444">{yv:.3g}</text>')

    for i in range(5):
        frac = i / 4
        xv = int(frac * (n - 1)) if n > 1 else 0
        px = _scale(xv, 0, max(n - 1, 1), x0, x1)
        parts.append(f'<text x="{px:.1f}" y="{y1+20}" font-size="11" text-anchor="middle" fill="#444">{xv}</text>')

    parts.append(f'<text x="{width/2}" y="{height-8}" font-size="12" text-anchor="middle" fill="#333">{html.escape(xlabel)}</text>')
    parts.append(
        f'<text x="16" y="{height/2}" font-size="12" text-anchor="middle" fill="#333" '
        f'transform="rotate(-90 16 {height/2})">{html.escape(ylabel)}</text>'
    )

    for idx, (label, values) in enumerate(smoothed.items()):
        color = PALETTE[idx % len(PALETTE)]
        points = []
        for i, v in enumerate(values):
            px = _scale(i, 0, max(n - 1, 1), x0, x1)
            py = _scale(v, y_lo, y_hi, y1, y0)
            points.append(f"{px:.1f},{py:.1f}")
        parts.append(f'<polyline points="{" ".join(points)}" fill="none" stroke="{color}" stroke-width="2"/>')
        legend_y = margin["top"] + idx * 18
        parts.append(f'<rect x="{x1-14}" y="{legend_y-10}" width="10" height="10" fill="{color}"/>')
        parts.append(f'<text x="{x1-20}" y="{legend_y-1}" font-size="12" text-anchor="end" fill="#222">{html.escape(label)}</text>')

    parts.append("</svg>")
    with open(path, "w") as f:
        f.write("\n".join(parts))


def bar_chart(categories: list, series: dict, path: str, title: str = "", ylabel: str = "", width: int = 900, height: int = 480):
    """``series``: {label: [value_per_category, ...]} grouped bars."""
    margin = {"top": 50, "right": 30, "bottom": 90, "left": 70}
    plot_w = width - margin["left"] - margin["right"]
    plot_h = height - margin["top"] - margin["bottom"]

    all_values = [v for values in series.values() for v in values]
    y_lo = min(0.0, min(all_values) if all_values else 0.0)
    y_hi = max(all_values) if all_values else 1.0
    if y_hi - y_lo < 1e-9:
        y_hi = y_lo + 1.0
    pad = (y_hi - y_lo) * 0.1
    y_hi += pad
    y_lo -= pad if y_lo < 0 else 0

    x0, y0 = margin["left"], margin["top"]
    x1, y1 = margin["left"] + plot_w, margin["top"] + plot_h
    zero_y = _scale(0.0, y_lo, y_hi, y1, y0)

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}" font-family="Helvetica,Arial,sans-serif">',
        f'<rect width="{width}" height="{height}" fill="#ffffff"/>',
        f'<text x="{width/2}" y="24" font-size="18" text-anchor="middle" fill="#111">{html.escape(title)}</text>',
        f'<line x1="{x0}" y1="{zero_y:.1f}" x2="{x1}" y2="{zero_y:.1f}" stroke="#333" stroke-width="1.5"/>',
        f'<line x1="{x0}" y1="{y0}" x2="{x0}" y2="{y1}" stroke="#333" stroke-width="1.5"/>',
        f'<text x="16" y="{height/2}" font-size="12" text-anchor="middle" fill="#333" '
        f'transform="rotate(-90 16 {height/2})">{html.escape(ylabel)}</text>',
    ]

    n_cat = len(categories)
    n_series = max(len(series), 1)
    group_w = plot_w / max(n_cat, 1)
    bar_w = group_w / (n_series + 1)

    for i in range(5):
        frac = i / 4
        yv = y_lo + frac * (y_hi - y_lo)
        py = _scale(yv, y_lo, y_hi, y1, y0)
        parts.append(f'<line x1="{x0}" y1="{py:.1f}" x2="{x1}" y2="{py:.1f}" stroke="#eee" stroke-width="1"/>')
        parts.append(f'<text x="{x0-8}" y="{py+4:.1f}" font-size="11" text-anchor="end" fill="#444">{yv:.3g}</text>')

    for ci, cat in enumerate(categories):
        gx = x0 + ci * group_w
        parts.append(
            f'<text x="{gx+group_w/2:.1f}" y="{y1+18}" font-size="11" text-anchor="middle" fill="#333" '
            f'transform="rotate(20 {gx+group_w/2:.1f} {y1+18})">{html.escape(str(cat))}</text>'
        )
        for si, (label, values) in enumerate(series.items()):
            v = values[ci]
            bx = gx + (si + 0.5) * bar_w
            by = _scale(v, y_lo, y_hi, y1, y0)
            top, bottom = (by, zero_y) if v >= 0 else (zero_y, by)
            color = PALETTE[si % len(PALETTE)]
            parts.append(f'<rect x="{bx:.1f}" y="{top:.1f}" width="{bar_w*0.8:.1f}" height="{max(bottom-top,0.5):.1f}" fill="{color}"/>')

    for si, label in enumerate(series.keys()):
        color = PALETTE[si % len(PALETTE)]
        legend_y = margin["top"] + si * 18
        parts.append(f'<rect x="{x1-14}" y="{legend_y-10}" width="10" height="10" fill="{color}"/>')
        parts.append(f'<text x="{x1-20}" y="{legend_y-1}" font-size="12" text-anchor="end" fill="#222">{html.escape(label)}</text>')

    parts.append("</svg>")
    with open(path, "w") as f:
        f.write("\n".join(parts))
