#!/usr/bin/env python3
"""
Section 21 (Fixed-Point Arithmetic) / Section 32 (Bit-Accurate Simulation).

Two comparisons, both against a float64 "reference" model that never
touches the fixed_point module:

  1. MAC-PIPELINE ACCURACY: a fixed random affine model evaluated over a
     deterministic feature stream, once in float64 and once through each
     of Q8.8 / Q16.16 / Q24.8 -- reports mean/median/max absolute error.

  2. CLOSED-LOOP OUTCOME: the full fabric + Mode-3 controller loop run
     once per fixed-point format (same workload/fault trace, same seed),
     reporting how the format choice alone changes steady-state reward.
"""

import csv
import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from silicaflux_ml.fixed_point import Q8_8, Q16_16, Q24_8, to_fixed, to_float, dot, fixed_add
from silicaflux_ml.fabric import SilicaFluxFabric, WorkloadGenerator
from silicaflux_ml.controller import SilicaFluxController
from silicaflux_ml.learning_engine import EngineConfig
from silicaflux_ml.modes import Mode

from svg_chart import bar_chart

RESULTS_DIR = os.path.join(os.path.dirname(__file__), "..", "results")
FORMATS = [("Q8.8", Q8_8), ("Q16.16", Q16_16), ("Q24.8", Q24_8)]
N_FEATURES = 17
N_SAMPLES = 20000
CLOSED_LOOP_CYCLES = int(os.environ.get("SF_PRECISION_CYCLES", "6000"))


def mac_accuracy_sweep():
    rng = random.Random(42)
    true_weights = [rng.uniform(-3.0, 3.0) for _ in range(N_FEATURES)]
    true_bias = rng.uniform(-1.0, 1.0)
    feature_samples = [[rng.uniform(-2.0, 2.0) for _ in range(N_FEATURES)] for _ in range(N_SAMPLES)]

    reference = [
        sum(w * x for w, x in zip(true_weights, feats)) + true_bias for feats in feature_samples
    ]

    rows = []
    for name, fmt in FORMATS:
        w_fixed = [to_fixed(w, fmt) for w in true_weights]
        b_fixed = to_fixed(true_bias, fmt)
        errors = []
        for feats, ref in zip(feature_samples, reference):
            feats_fixed = [to_fixed(x, fmt) for x in feats]
            # Mirrors OutputModel.predict() exactly: MAC pipeline first,
            # THEN a separate saturating add for the bias register.
            mac_raw = dot(w_fixed, feats_fixed, fmt)
            predicted = to_float(fixed_add(mac_raw, b_fixed, fmt), fmt)
            errors.append(abs(predicted - ref))
        errors.sort()
        n = len(errors)
        rows.append({
            "format": name,
            "int_bits": fmt.int_bits,
            "frac_bits": fmt.frac_bits,
            "resolution": fmt.resolution(),
            "mean_abs_error": sum(errors) / n,
            "median_abs_error": errors[n // 2],
            "max_abs_error": errors[-1],
        })
    return rows


def closed_loop_outcomes():
    rows = []
    for name, fmt in FORMATS:
        fabric = SilicaFluxFabric(4, 4, seed=9)
        ctrl = SilicaFluxController(fabric, EngineConfig(fmt=fmt, mode=Mode.MODE_3_ONLINE_RL))
        gen = WorkloadGenerator(seed=9)
        rewards, throughputs = [], []
        for i in range(CLOSED_LOOP_CYCLES):
            intensity, fault_pe = gen.next(i, (4, 4))
            result = ctrl.step(intensity, fault_pe)
            rewards.append(result.reward_float)
            throughputs.append(result.throughput)
        tail = slice(-1000, None)
        rows.append({
            "format": name,
            "avg_reward_tail": sum(rewards[tail]) / len(rewards[tail]),
            "avg_throughput_tail": sum(throughputs[tail]) / len(throughputs[tail]),
        })
    return rows


def main():
    os.makedirs(RESULTS_DIR, exist_ok=True)

    print(f"MAC-pipeline accuracy sweep: {N_SAMPLES} samples x {N_FEATURES} features per format\n")
    mac_rows = mac_accuracy_sweep()
    for r in mac_rows:
        print(
            f"{r['format']:8s}  resolution={r['resolution']:.6f}  "
            f"mean_abs_err={r['mean_abs_error']:.6f}  median={r['median_abs_error']:.6f}  max={r['max_abs_error']:.6f}"
        )

    with open(os.path.join(RESULTS_DIR, "precision_mac_accuracy.csv"), "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(mac_rows[0].keys()))
        writer.writeheader()
        for r in mac_rows:
            writer.writerow({k: (round(v, 8) if isinstance(v, float) else v) for k, v in r.items()})

    bar_chart(
        [r["format"] for r in mac_rows],
        {"mean_abs_error": [r["mean_abs_error"] for r in mac_rows], "max_abs_error": [r["max_abs_error"] for r in mac_rows]},
        os.path.join(RESULTS_DIR, "precision_mac_accuracy.svg"),
        title="MAC-pipeline accuracy vs. fixed-point format",
        ylabel="absolute error vs. float64 reference",
    )

    print(f"\nClosed-loop outcome by format: {CLOSED_LOOP_CYCLES} cycles, Mode 3, identical seed/workload\n")
    loop_rows = closed_loop_outcomes()
    for r in loop_rows:
        print(f"{r['format']:8s}  avg_reward(tail)={r['avg_reward_tail']:+7.3f}  avg_throughput(tail)={r['avg_throughput_tail']:5.3f}")

    with open(os.path.join(RESULTS_DIR, "precision_closed_loop.csv"), "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(loop_rows[0].keys()))
        writer.writeheader()
        for r in loop_rows:
            writer.writerow({k: (round(v, 6) if isinstance(v, float) else v) for k, v in r.items()})

    print(f"\nWrote precision_*.csv and precision_*.svg to {RESULTS_DIR}/")


if __name__ == "__main__":
    main()
