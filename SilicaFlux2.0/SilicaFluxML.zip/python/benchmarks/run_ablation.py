#!/usr/bin/env python3
"""
Section 30 (Ablation Testing).

    no learning                       -- MODE_0, fixed configuration
    linear learning                   -- MODE_1, single-output predictor + weight updates
    learning without thermal features -- MODE_3, thermal-category features dropped
    learning without power features   -- MODE_3, power-category features dropped
    learning without workload features-- MODE_3, workload-category features dropped
    full SilicaFlux-ML                -- MODE_3, full feature set

Every configuration shares the SAME reward function (reward reflects the
fabric's real physical/business objective regardless of what the learner
can see) and the SAME synthetic workload/fault trace -- the only thing
that varies is what the feature engine feeds the predictor and action
selector. This isolates which categories of telemetry actually matter to
the policy, per Section 30's stated goal.
"""

import csv
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from silicaflux_ml.fabric import SilicaFluxFabric, WorkloadGenerator
from silicaflux_ml.controller import SilicaFluxController
from silicaflux_ml.learning_engine import EngineConfig, DEFAULT_FEATURE_ORDER, feature_subset
from silicaflux_ml.modes import Mode

from svg_chart import bar_chart

RESULTS_DIR = os.path.join(os.path.dirname(__file__), "..", "results")
CYCLES = int(os.environ.get("SF_ABLATION_CYCLES", "15000"))
GRID = (4, 4)
SEED = 5
TAIL = 2000  # steady-state window used for the headline comparison


CONFIGS = [
    ("no_learning", Mode.MODE_0_STATIC, DEFAULT_FEATURE_ORDER),
    ("linear_learning", Mode.MODE_1_LINEAR_ADAPTIVE, DEFAULT_FEATURE_ORDER),
    ("no_thermal_features", Mode.MODE_3_ONLINE_RL, feature_subset(exclude_categories=("thermal",))),
    ("no_power_features", Mode.MODE_3_ONLINE_RL, feature_subset(exclude_categories=("power",))),
    ("no_workload_features", Mode.MODE_3_ONLINE_RL, feature_subset(exclude_categories=("workload",))),
    ("full_silicaflux_ml", Mode.MODE_3_ONLINE_RL, DEFAULT_FEATURE_ORDER),
]


def run_config(mode: Mode, feature_order: list, cycles: int = CYCLES, seed: int = SEED):
    fabric = SilicaFluxFabric(*GRID, seed=seed)
    cfg = EngineConfig(mode=mode, feature_order=list(feature_order))
    ctrl = SilicaFluxController(fabric, cfg)
    gen = WorkloadGenerator(seed=seed)

    rows = []
    for i in range(cycles):
        intensity, fault_pe = gen.next(i, GRID)
        result = ctrl.step(intensity, fault_pe)
        out = result.engine_output
        sq_err = 0.0
        if out.errors:
            sq_err = sum((e / 65536.0) ** 2 for e in out.errors.values()) / len(out.errors)
        rows.append({
            "cycle": i,
            "reward": result.reward_float,
            "throughput": result.throughput,
            "power": result.power,
            "temperature": result.temperature,
            "prediction_sq_error": sq_err,
        })
    return rows


def summarise(rows, tail=TAIL):
    tail_rows = rows[-tail:]
    n = len(tail_rows)
    avg = lambda key: sum(r[key] for r in tail_rows) / n
    return {
        "avg_reward": avg("reward"),
        "avg_throughput": avg("throughput"),
        "avg_power": avg("power"),
        "avg_temperature": avg("temperature"),
        "prediction_mse": avg("prediction_sq_error"),
    }


def main():
    os.makedirs(RESULTS_DIR, exist_ok=True)
    summary_rows = []

    print(f"Running ablation suite: {CYCLES} cycles x {len(CONFIGS)} configurations\n")
    for name, mode, feature_order in CONFIGS:
        rows = run_config(mode, feature_order)
        summary = summarise(rows)
        summary["config"] = name
        summary["num_features"] = len(feature_order)
        summary_rows.append(summary)
        print(
            f"{name:24s}  reward={summary['avg_reward']:+7.3f}  throughput={summary['avg_throughput']:5.3f}  "
            f"power={summary['avg_power']:5.3f}  temp={summary['avg_temperature']:5.3f}  "
            f"pred_mse={summary['prediction_mse']:.5f}  (n_features={summary['num_features']})"
        )

    csv_path = os.path.join(RESULTS_DIR, "ablation_summary.csv")
    with open(csv_path, "w", newline="") as f:
        fieldnames = ["config", "num_features", "avg_reward", "avg_throughput", "avg_power", "avg_temperature", "prediction_mse"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in summary_rows:
            writer.writerow({k: (round(v, 6) if isinstance(v, float) else v) for k, v in row.items()})

    categories = [r["config"] for r in summary_rows]
    bar_chart(
        categories,
        {"avg_reward": [r["avg_reward"] for r in summary_rows]},
        os.path.join(RESULTS_DIR, "ablation_reward.svg"),
        title="Ablation: steady-state average reward",
        ylabel="avg reward (last %d cycles)" % TAIL,
    )
    bar_chart(
        categories,
        {"prediction_mse": [r["prediction_mse"] for r in summary_rows]},
        os.path.join(RESULTS_DIR, "ablation_prediction_error.svg"),
        title="Ablation: steady-state prediction MSE",
        ylabel="mean squared error",
    )

    print(f"\nWrote {csv_path} and ablation_*.svg to {RESULTS_DIR}/")


if __name__ == "__main__":
    main()
