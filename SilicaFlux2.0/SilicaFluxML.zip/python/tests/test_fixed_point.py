"""
Section 31/32 verification: deterministic test vectors for every fixed-
point primitive, hand-computed independently of the implementation.
"""

import unittest

from silicaflux_ml.fixed_point import (
    Q8_8,
    Q16_16,
    Q24_8,
    to_fixed,
    to_float,
    fixed_add,
    fixed_sub,
    fixed_mul,
    fixed_div,
    fixed_div_int,
    fixed_clip,
    fixed_abs,
    fixed_compare,
    MacUnit,
    dot,
)


class TestConversion(unittest.TestCase):
    def test_round_trip_q16_16(self):
        for value in (0.0, 1.0, -1.0, 3.5, -3.5, 100.25, -0.0001):
            raw = to_fixed(value, Q16_16)
            self.assertAlmostEqual(to_float(raw, Q16_16), value, places=3)

    def test_known_raw_values(self):
        self.assertEqual(to_fixed(1.0, Q16_16), 65536)
        self.assertEqual(to_fixed(-1.0, Q16_16), -65536)
        self.assertEqual(to_fixed(0.5, Q16_16), 32768)
        self.assertEqual(to_fixed(1.0, Q8_8), 256)

    def test_saturation_on_convert(self):
        # Q8.8 max representable is 127.99609375
        raw = to_fixed(1000.0, Q8_8)
        self.assertEqual(raw, Q8_8.max_raw)
        raw = to_fixed(-1000.0, Q8_8)
        self.assertEqual(raw, Q8_8.min_raw)


class TestArithmetic(unittest.TestCase):
    def test_add_exact(self):
        a = to_fixed(1.5, Q16_16)
        b = to_fixed(2.25, Q16_16)
        self.assertEqual(fixed_add(a, b, Q16_16), to_fixed(3.75, Q16_16))

    def test_sub_exact(self):
        a = to_fixed(1.5, Q16_16)
        b = to_fixed(2.25, Q16_16)
        self.assertEqual(fixed_sub(a, b, Q16_16), to_fixed(-0.75, Q16_16))

    def test_mul_exact(self):
        a = to_fixed(1.5, Q16_16)
        b = to_fixed(2.0, Q16_16)
        result = fixed_mul(a, b, Q16_16)
        self.assertEqual(result, to_fixed(3.0, Q16_16))

    def test_mul_fraction(self):
        a = to_fixed(0.5, Q16_16)
        b = to_fixed(0.5, Q16_16)
        result = fixed_mul(a, b, Q16_16)
        self.assertEqual(to_float(result, Q16_16), 0.25)

    def test_div_exact(self):
        a = to_fixed(6.0, Q16_16)
        b = to_fixed(2.0, Q16_16)
        result = fixed_div(a, b, Q16_16)
        self.assertEqual(to_float(result, Q16_16), 3.0)

    def test_div_negative_signs(self):
        a = to_fixed(-6.0, Q16_16)
        b = to_fixed(2.0, Q16_16)
        self.assertEqual(to_float(fixed_div(a, b, Q16_16), Q16_16), -3.0)
        a = to_fixed(6.0, Q16_16)
        b = to_fixed(-2.0, Q16_16)
        self.assertEqual(to_float(fixed_div(a, b, Q16_16), Q16_16), -3.0)
        a = to_fixed(-6.0, Q16_16)
        b = to_fixed(-2.0, Q16_16)
        self.assertEqual(to_float(fixed_div(a, b, Q16_16), Q16_16), 3.0)

    def test_div_by_zero_saturates(self):
        a = to_fixed(1.0, Q16_16)
        self.assertEqual(fixed_div(a, 0, Q16_16), Q16_16.max_raw)
        a = to_fixed(-1.0, Q16_16)
        self.assertEqual(fixed_div(a, 0, Q16_16), Q16_16.min_raw)

    def test_div_int(self):
        raw = to_fixed(10.0, Q16_16)
        self.assertEqual(to_float(fixed_div_int(raw, 4, Q16_16), Q16_16), 2.5)
        self.assertEqual(fixed_div_int(raw, 0, Q16_16), 0)

    def test_abs(self):
        self.assertEqual(fixed_abs(to_fixed(-3.5, Q16_16), Q16_16), to_fixed(3.5, Q16_16))
        self.assertEqual(fixed_abs(to_fixed(3.5, Q16_16), Q16_16), to_fixed(3.5, Q16_16))

    def test_compare(self):
        a = to_fixed(1.0, Q16_16)
        b = to_fixed(2.0, Q16_16)
        self.assertEqual(fixed_compare(a, b), -1)
        self.assertEqual(fixed_compare(b, a), 1)
        self.assertEqual(fixed_compare(a, a), 0)

    def test_saturating_add_does_not_wrap(self):
        result = fixed_add(Q8_8.max_raw, to_fixed(1.0, Q8_8), Q8_8)
        self.assertEqual(result, Q8_8.max_raw)  # NOT a wrapped negative value

    def test_saturating_sub_does_not_wrap(self):
        result = fixed_sub(Q8_8.min_raw, to_fixed(1.0, Q8_8), Q8_8)
        self.assertEqual(result, Q8_8.min_raw)


class TestMacUnit(unittest.TestCase):
    def test_dot_product_exact(self):
        weights = [to_fixed(w, Q16_16) for w in (1.0, 2.0, -0.5)]
        features = [to_fixed(f, Q16_16) for f in (3.0, 1.0, 4.0)]
        result = dot(weights, features, Q16_16)
        # 1*3 + 2*1 + -0.5*4 = 3 + 2 - 2 = 3
        self.assertAlmostEqual(to_float(result, Q16_16), 3.0, places=3)

    def test_accumulator_does_not_clip_between_terms(self):
        # Each individual product would saturate a NARROW format if clipped
        # immediately; the wide accumulator must not clip until read().
        mac = MacUnit(Q8_8, guard_bits=8)
        big = Q8_8.max_raw
        mac.mac(big, to_fixed(1.0, Q8_8))
        mac.mac(big, to_fixed(1.0, Q8_8))
        # sum should be 2*127.99609375 ~= 255.99, which DOES saturate Q8.8
        # (max ~127.996) on final read, but the accumulator itself carried
        # the full sum without an intermediate clip.
        self.assertGreater(mac.acc, Q8_8.max_raw)
        self.assertEqual(mac.read(), Q8_8.max_raw)


class TestPrecisionFormats(unittest.TestCase):
    """Section 21: compare resolution/range across Q8.8, Q16.16, Q24.8."""

    def test_resolution_ordering(self):
        # Q16.16 has the most fractional bits -> the finest resolution.
        self.assertLess(Q16_16.resolution(), Q8_8.resolution())
        # Q8.8 and Q24.8 share 8 fractional bits -> identical resolution...
        self.assertEqual(Q8_8.resolution(), Q24_8.resolution())

    def test_range_ordering(self):
        # ...but Q24.8 has far more integer bits -> a much wider range.
        lo8, hi8 = Q8_8.full_scale_range()
        lo24, hi24 = Q24_8.full_scale_range()
        self.assertGreater(hi24, hi8)
        self.assertLess(lo24, lo8)
