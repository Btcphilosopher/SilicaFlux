"""Section 31: reward-engine, action-selector, and constraint-engine
verification."""

import random
import unittest

from silicaflux_ml.reward_engine import RewardConfig, RewardEngine
from silicaflux_ml.action_selector import Action, ActionSelector, ActionValueTable
from silicaflux_ml.constraint_engine import CandidateConfiguration, ConstraintEngine, HardLimits
from silicaflux_ml.fixed_point import Q16_16, to_fixed, to_float


class TestRewardEngine(unittest.TestCase):
    def test_known_reward_value(self):
        fmt = Q16_16
        cfg = RewardConfig(
            throughput_weight=to_fixed(1.0, fmt),
            efficiency_weight=to_fixed(0.5, fmt),
            power_weight=to_fixed(0.4, fmt),
            thermal_weight=to_fixed(0.6, fmt),
            error_weight=to_fixed(2.0, fmt),
            invalid_action_penalty=to_fixed(5.0, fmt),
        )
        engine = RewardEngine(fmt, cfg)
        reward = engine.compute(
            throughput=to_fixed(0.8, fmt),
            efficiency=to_fixed(0.5, fmt),
            power=to_fixed(0.3, fmt),
            thermal_penalty=to_fixed(0.1, fmt),
            errors=to_fixed(0.02, fmt),
        )
        # 1*0.8 + 0.5*0.5 - 0.4*0.3 - 0.6*0.1 - 2*0.02 = 0.8+0.25-0.12-0.06-0.04 = 0.83
        self.assertAlmostEqual(to_float(reward, fmt), 0.83, places=2)

    def test_invalid_action_penalises(self):
        fmt = Q16_16
        cfg = RewardConfig(
            throughput_weight=0, efficiency_weight=0, power_weight=0,
            thermal_weight=0, error_weight=0, invalid_action_penalty=to_fixed(5.0, fmt),
        )
        engine = RewardEngine(fmt, cfg)
        base = to_fixed(1.0, fmt)
        penalised = engine.penalise_invalid(base)
        self.assertAlmostEqual(to_float(penalised, fmt), -4.0, places=2)


class TestActionSelector(unittest.TestCase):
    def test_greedy_picks_max_value(self):
        fmt = Q16_16
        table = ActionValueTable(list(Action), fmt)
        table.value[Action.INCREASE_FREQUENCY] = to_fixed(9.0, fmt)
        selector = ActionSelector(table, strategy="greedy")
        self.assertEqual(selector.select(), Action.INCREASE_FREQUENCY)

    def test_epsilon_zero_is_fully_greedy(self):
        fmt = Q16_16
        table = ActionValueTable(list(Action), fmt)
        table.value[Action.MAINTAIN_CONFIGURATION] = to_fixed(5.0, fmt)
        selector = ActionSelector(table, strategy="epsilon_greedy", epsilon_raw=0, rng=random.Random(0))
        for _ in range(20):
            self.assertEqual(selector.select(), Action.MAINTAIN_CONFIGURATION)

    def test_epsilon_one_is_fully_random(self):
        fmt = Q16_16
        table = ActionValueTable(list(Action), fmt)
        table.value[Action.MAINTAIN_CONFIGURATION] = to_fixed(5.0, fmt)
        selector = ActionSelector(
            table, strategy="epsilon_greedy", epsilon_raw=to_fixed(1.0, fmt), rng=random.Random(0)
        )
        picks = {selector.select() for _ in range(50)}
        self.assertGreater(len(picks), 1)  # not always the greedy action

    def test_action_value_update(self):
        fmt = Q16_16
        table = ActionValueTable([Action.MAINTAIN_CONFIGURATION], fmt)
        lr = to_fixed(0.5, fmt)
        table.update(Action.MAINTAIN_CONFIGURATION, to_fixed(10.0, fmt), lr)
        # value += lr*(reward-value) = 0 + 0.5*(10-0) = 5.0
        self.assertAlmostEqual(to_float(table.value[Action.MAINTAIN_CONFIGURATION], fmt), 5.0, places=2)
        self.assertEqual(table.visits[Action.MAINTAIN_CONFIGURATION], 1)


class TestConstraintEngine(unittest.TestCase):
    def setUp(self):
        self.limits = HardLimits(
            power_max=10.0, temperature_max=1.0, freq_min=0.5, freq_max=2.0,
            voltage_min=0.8, voltage_max=1.2, parallelism_min=1.0, parallelism_max=16.0,
        )
        self.engine = ConstraintEngine(self.limits)

    def _candidate(self, **overrides):
        base = dict(power=5.0, temperature=0.5, frequency=1.0, voltage=1.0, parallelism=8.0)
        base.update(overrides)
        return CandidateConfiguration(**base)

    def test_valid_configuration_passes(self):
        valid, violations = self.engine.check(self._candidate())
        self.assertTrue(valid)
        self.assertEqual(violations, [])

    def test_power_violation_detected(self):
        valid, violations = self.engine.check(self._candidate(power=20.0))
        self.assertFalse(valid)
        self.assertIn("power", violations)

    def test_thermal_violation_detected(self):
        valid, violations = self.engine.check(self._candidate(temperature=5.0))
        self.assertFalse(valid)
        self.assertIn("thermal", violations)

    def test_frequency_out_of_range_detected(self):
        valid, violations = self.engine.check(self._candidate(frequency=3.0))
        self.assertFalse(valid)
        self.assertIn("frequency", violations)

    def test_multiple_violations_all_reported(self):
        valid, violations = self.engine.check(self._candidate(power=99.0, voltage=5.0))
        self.assertFalse(valid)
        self.assertIn("power", violations)
        self.assertIn("voltage", violations)

    def test_trip_action_none_when_safe(self):
        self.assertIsNone(self.engine.trip_action(self._candidate()))

    def test_trip_action_fires_on_actual_overshoot(self):
        action = self.engine.trip_action(self._candidate(temperature=2.0))
        self.assertEqual(action, Action.DECREASE_FREQUENCY)


if __name__ == "__main__":
    unittest.main()
