"""Section 31: feature-extraction verification with hand-computed vectors."""

import unittest

from silicaflux_ml.feature_engine import RingChannel, FeatureEngine
from silicaflux_ml.fixed_point import Q16_16, to_fixed, to_float
from silicaflux_ml.state_vector import STATE_FIELD_NAMES


class TestRingChannel(unittest.TestCase):
    def test_mean_of_constant_signal(self):
        ch = RingChannel(depth=4, fmt=Q16_16)
        for _ in range(4):
            ch.push(to_fixed(2.0, Q16_16))
        self.assertAlmostEqual(to_float(ch.mean(), Q16_16), 2.0, places=3)

    def test_mean_over_ramp(self):
        ch = RingChannel(depth=4, fmt=Q16_16)
        for v in (1.0, 2.0, 3.0, 4.0):
            ch.push(to_fixed(v, Q16_16))
        # mean of 1,2,3,4 = 2.5
        self.assertAlmostEqual(to_float(ch.mean(), Q16_16), 2.5, places=2)

    def test_ring_buffer_evicts_oldest(self):
        ch = RingChannel(depth=2, fmt=Q16_16)
        ch.push(to_fixed(10.0, Q16_16))
        ch.push(to_fixed(20.0, Q16_16))
        ch.push(to_fixed(30.0, Q16_16))  # evicts the 10.0
        # mean of remaining (20, 30) = 25
        self.assertAlmostEqual(to_float(ch.mean(), Q16_16), 25.0, places=2)
        self.assertEqual(ch.count, 2)

    def test_delta(self):
        ch = RingChannel(depth=8, fmt=Q16_16)
        ch.push(to_fixed(1.0, Q16_16))
        ch.push(to_fixed(4.0, Q16_16))
        self.assertAlmostEqual(to_float(ch.delta(), Q16_16), 3.0, places=3)

    def test_variance_of_constant_signal_is_zero(self):
        ch = RingChannel(depth=8, fmt=Q16_16)
        for _ in range(8):
            ch.push(to_fixed(5.0, Q16_16))
        self.assertEqual(ch.variance(), 0)

    def test_variance_known_value(self):
        # variance of [1,2,3,4] (population) = mean((x-2.5)^2) = 1.25
        ch = RingChannel(depth=4, fmt=Q16_16)
        for v in (1.0, 2.0, 3.0, 4.0):
            ch.push(to_fixed(v, Q16_16))
        self.assertAlmostEqual(to_float(ch.variance(), Q16_16), 1.25, delta=0.05)


class TestFeatureEngine(unittest.TestCase):
    def test_observe_produces_all_named_features(self):
        fe = FeatureEngine(Q16_16, ring_depth=8)
        state = {name: to_fixed(0.5, Q16_16) for name in STATE_FIELD_NAMES}
        feats = fe.observe(state)
        for name in fe.feature_names():
            self.assertIn(name, feats)

    def test_power_efficiency_ratio(self):
        fe = FeatureEngine(Q16_16, ring_depth=4)
        state = {name: 0 for name in STATE_FIELD_NAMES}
        state["throughput"] = to_fixed(0.8, Q16_16)
        state["power"] = to_fixed(0.4, Q16_16)
        feats = fe.observe(state)
        self.assertAlmostEqual(to_float(feats["power_efficiency"], Q16_16), 2.0, places=2)

    def test_zero_utilisation_does_not_explode_efficiency(self):
        # Regression test: a near-zero divisor must be floored to a small
        # but meaningful minimum, not to raw-unit "1" (a no-op guard) --
        # see the min_divisor fix in FeatureEngine.observe.
        fe = FeatureEngine(Q16_16, ring_depth=4)
        state = {name: 0 for name in STATE_FIELD_NAMES}
        state["throughput"] = to_fixed(0.5, Q16_16)
        state["utilisation"] = 0
        feats = fe.observe(state)
        ratio = to_float(feats["throughput_efficiency"], Q16_16)
        self.assertLess(ratio, 100.0)


if __name__ == "__main__":
    unittest.main()
