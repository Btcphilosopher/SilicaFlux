"""Section 31: central FSM and learning-memory verification."""

import unittest

from silicaflux_ml.fsm import FSMState, LearningFSM
from silicaflux_ml.learning_memory import LearningMemory, LearningRecord


class TestLearningFSM(unittest.TestCase):
    def test_full_pass_visits_every_state_in_order(self):
        fsm = LearningFSM(timeout_cycles=32)
        visited = fsm.run_full_pass({})
        self.assertEqual(visited, list(LearningFSM.ORDER) + [FSMState.IDLE])

    def test_handlers_invoked_in_correct_state(self):
        fsm = LearningFSM(timeout_cycles=32)
        calls = []
        handlers = {state: (lambda s=state: calls.append(s)) for state in LearningFSM.ORDER}
        fsm.run_full_pass(handlers)
        self.assertEqual(calls, list(LearningFSM.ORDER))

    def test_timeout_forces_reset(self):
        fsm = LearningFSM(timeout_cycles=3)

        def stall():
            pass  # a handler that "never completes" in spirit -- we just never leave OBSERVE quickly

        # Advance without going through a full pass so the internal timer
        # exceeds timeout_cycles while stuck reasoning about one state.
        for _ in range(2):
            fsm.step({})
        self.assertNotEqual(fsm.state, FSMState.IDLE)
        fsm.step({})  # timer now exceeds timeout_cycles=3
        fsm.step({})
        self.assertEqual(fsm.timeout_count, 1)
        self.assertEqual(fsm.state, FSMState.IDLE)

    def test_reset_returns_to_idle(self):
        fsm = LearningFSM()
        fsm.step({})
        fsm.step({})
        fsm.reset()
        self.assertEqual(fsm.state, FSMState.IDLE)


class TestLearningMemory(unittest.TestCase):
    def _record(self, cycle):
        return LearningRecord(
            cycle=cycle, state=[0] * 4, action=0, predicted={}, observed={}, reward=0, error={}
        )

    def test_push_and_length(self):
        mem = LearningMemory(depth=4)
        for i in range(3):
            mem.push(self._record(i))
        self.assertEqual(len(mem), 3)

    def test_circular_overwrite(self):
        mem = LearningMemory(depth=4)
        for i in range(10):
            mem.push(self._record(i))
        self.assertEqual(len(mem), 4)
        cycles = [r.cycle for r in mem]
        self.assertEqual(cycles, [6, 7, 8, 9])  # oldest entries evicted

    def test_latest(self):
        mem = LearningMemory(depth=4)
        mem.push(self._record(1))
        mem.push(self._record(2))
        self.assertEqual(mem.latest().cycle, 2)

    def test_empty_latest_is_none(self):
        mem = LearningMemory(depth=4)
        self.assertIsNone(mem.latest())


if __name__ == "__main__":
    unittest.main()
