"""Section 31: predictor / online-weight-update verification."""

import unittest

from silicaflux_ml.predictor import OutputModel, Predictor
from silicaflux_ml.weight_updater import WeightUpdater, WeightUpdaterConfig
from silicaflux_ml.fixed_point import Q16_16, to_fixed, to_float


class TestOutputModel(unittest.TestCase):
    def test_predict_known_weights(self):
        model = OutputModel("y", num_features=2, fmt=Q16_16)
        model.weights = [to_fixed(2.0, Q16_16), to_fixed(-1.0, Q16_16)]
        model.bias = to_fixed(0.5, Q16_16)
        features = [to_fixed(3.0, Q16_16), to_fixed(4.0, Q16_16)]
        # y = 2*3 + -1*4 + 0.5 = 6 - 4 + 0.5 = 2.5
        result = model.predict(features)
        self.assertAlmostEqual(to_float(result, Q16_16), 2.5, places=2)

    def test_zero_weights_predict_bias_only(self):
        model = OutputModel("y", num_features=3, fmt=Q16_16)
        model.bias = to_fixed(1.25, Q16_16)
        result = model.predict([to_fixed(100.0, Q16_16)] * 3)
        self.assertAlmostEqual(to_float(result, Q16_16), 1.25, places=2)


class TestPredictor(unittest.TestCase):
    def test_multi_output_predict(self):
        p = Predictor(num_features=2, fmt=Q16_16, output_names=["a", "b"])
        p.models["a"].weights = [to_fixed(1.0, Q16_16), to_fixed(0.0, Q16_16)]
        p.models["b"].weights = [to_fixed(0.0, Q16_16), to_fixed(1.0, Q16_16)]
        out = p.predict([to_fixed(5.0, Q16_16), to_fixed(9.0, Q16_16)])
        self.assertAlmostEqual(to_float(out["a"], Q16_16), 5.0, places=2)
        self.assertAlmostEqual(to_float(out["b"], Q16_16), 9.0, places=2)


class TestWeightUpdater(unittest.TestCase):
    def test_single_update_matches_hand_calc(self):
        fmt = Q16_16
        model = OutputModel("y", num_features=1, fmt=fmt)
        model.weights = [to_fixed(0.0, fmt)]
        updater = WeightUpdater(fmt, WeightUpdaterConfig(
            learning_rate=to_fixed(0.1, fmt),
            weight_min=to_fixed(-10.0, fmt),
            weight_max=to_fixed(10.0, fmt),
        ))
        features = [to_fixed(2.0, fmt)]
        observed = to_fixed(1.0, fmt)
        predicted = to_fixed(0.0, fmt)
        error, updated = updater.maybe_update(model, features, observed, predicted)
        self.assertTrue(updated)
        self.assertAlmostEqual(to_float(error, fmt), 1.0, places=2)
        # w += lr * error * x = 0.1 * 1.0 * 2.0 = 0.2
        self.assertAlmostEqual(to_float(model.weights[0], fmt), 0.2, places=2)

    def test_error_threshold_gates_update(self):
        fmt = Q16_16
        model = OutputModel("y", num_features=1, fmt=fmt)
        updater = WeightUpdater(fmt, WeightUpdaterConfig(
            learning_rate=to_fixed(0.5, fmt),
            weight_min=to_fixed(-10.0, fmt),
            weight_max=to_fixed(10.0, fmt),
            error_threshold=to_fixed(0.5, fmt),
        ))
        features = [to_fixed(1.0, fmt)]
        # error = 0.1, below the 0.5 threshold -> no update
        _, updated = updater.maybe_update(model, features, to_fixed(0.1, fmt), to_fixed(0.0, fmt))
        self.assertFalse(updated)
        self.assertEqual(model.weights[0], 0)

    def test_update_interval_gates_update(self):
        fmt = Q16_16
        model = OutputModel("y", num_features=1, fmt=fmt)
        updater = WeightUpdater(fmt, WeightUpdaterConfig(
            learning_rate=to_fixed(0.5, fmt),
            weight_min=to_fixed(-10.0, fmt),
            weight_max=to_fixed(10.0, fmt),
            update_interval=3,
        ))
        features = [to_fixed(1.0, fmt)]
        results = [
            updater.maybe_update(model, features, to_fixed(1.0, fmt), to_fixed(0.0, fmt))[1]
            for _ in range(3)
        ]
        self.assertEqual(results, [False, False, True])

    def test_weights_saturate_at_configured_bounds(self):
        fmt = Q16_16
        model = OutputModel("y", num_features=1, fmt=fmt)
        updater = WeightUpdater(fmt, WeightUpdaterConfig(
            learning_rate=to_fixed(1.0, fmt),
            weight_min=to_fixed(-1.0, fmt),
            weight_max=to_fixed(1.0, fmt),
        ))
        features = [to_fixed(10.0, fmt)]
        for _ in range(20):
            updater.maybe_update(model, features, to_fixed(10.0, fmt), to_fixed(0.0, fmt))
        self.assertLessEqual(to_float(model.weights[0], fmt), 1.0)


if __name__ == "__main__":
    unittest.main()
