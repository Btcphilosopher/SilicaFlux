"""End-to-end integration checks: the full 9-stage pipeline (Section 20)
through the fabric digital twin (Section 15) stays numerically stable and
respects the hard safety limits (Section 14) across every mode."""

import unittest

from silicaflux_ml.fabric import SilicaFluxFabric, WorkloadGenerator
from silicaflux_ml.controller import SilicaFluxController, DistributedSilicaFluxController, default_hard_limits
from silicaflux_ml.learning_engine import EngineConfig
from silicaflux_ml.modes import Mode


class TestControllerLoop(unittest.TestCase):
    def _run(self, mode, cycles=400, seed=1):
        fabric = SilicaFluxFabric(4, 4, seed=seed)
        ctrl = SilicaFluxController(fabric, EngineConfig(mode=mode))
        gen = WorkloadGenerator(seed=seed)
        results = []
        for i in range(cycles):
            intensity, fault_pe = gen.next(i, (4, 4))
            results.append(ctrl.step(intensity, fault_pe))
        return fabric, ctrl, results

    def test_all_modes_run_without_error(self):
        for mode in Mode:
            if mode == Mode.MODE_4_DISTRIBUTED:
                continue  # covered separately, needs the distributed controller
            with self.subTest(mode=mode):
                fabric, ctrl, results = self._run(mode, cycles=200)
                self.assertEqual(len(results), 200)

    def test_hard_limits_never_violated_on_applied_configuration(self):
        limits = default_hard_limits()
        for mode in (Mode.MODE_1_LINEAR_ADAPTIVE, Mode.MODE_3_ONLINE_RL):
            fabric, ctrl, results = self._run(mode, cycles=800)
            # Whatever the fabric's knobs end up at, they must sit inside
            # the configured hard limits -- the constraint engine's whole
            # job (Section 14).
            self.assertGreaterEqual(fabric.frequency, limits.freq_min - 1e-6)
            self.assertLessEqual(fabric.frequency, limits.freq_max + 1e-6)
            self.assertGreaterEqual(fabric.parallelism, fabric.parallelism_min - 1e-6)
            self.assertLessEqual(fabric.parallelism, fabric.parallelism_max + 1e-6)

    def test_reward_stays_finite_and_bounded(self):
        fmt_scale = 65536
        _, _, results = self._run(Mode.MODE_3_ONLINE_RL, cycles=1000)
        for r in results:
            self.assertTrue(-1e6 < r.reward_float < 1e6)

    def test_more_capable_modes_do_not_collapse_throughput_to_zero(self):
        for mode in (Mode.MODE_0_STATIC, Mode.MODE_1_LINEAR_ADAPTIVE, Mode.MODE_3_ONLINE_RL):
            _, _, results = self._run(mode, cycles=1500)
            tail_throughput = sum(r.throughput for r in results[-200:]) / 200
            self.assertGreater(tail_throughput, 0.05)

    def test_distributed_mode_runs_and_keeps_some_pes_active(self):
        fabric = SilicaFluxFabric(4, 4, seed=2)
        ctrl = DistributedSilicaFluxController(fabric, EngineConfig(mode=Mode.MODE_4_DISTRIBUTED))
        gen = WorkloadGenerator(seed=2)
        for i in range(300):
            intensity, fault_pe = gen.next(i, (4, 4))
            ctrl.step(intensity, fault_pe)
        active = sum(1 for p in fabric.pes.values() if p.active)
        self.assertGreater(active, 0)


class TestDeterminism(unittest.TestCase):
    def test_same_seed_same_trajectory(self):
        def run():
            fabric = SilicaFluxFabric(4, 4, seed=7)
            ctrl = SilicaFluxController(fabric, EngineConfig(mode=Mode.MODE_3_ONLINE_RL))
            gen = WorkloadGenerator(seed=7)
            rewards = []
            for i in range(300):
                intensity, fault_pe = gen.next(i, (4, 4))
                rewards.append(ctrl.step(intensity, fault_pe).reward_float)
            return rewards

        self.assertEqual(run(), run())  # bit-exact reproducibility


if __name__ == "__main__":
    unittest.main()
