# Constraint Engine, Action Space & Safety

## Action space (Section 10)

`python/silicaflux_ml/action_selector.py::Action` — 10 default discrete
actions (`INCREASE_/DECREASE_PARALLELISM`, `_FREQUENCY`, `_BATCH_SIZE`,
`ACTIVATE_/DEACTIVATE_COMPUTE_UNIT`, `CHANGE_WORK_DISTRIBUTION`,
`MAINTAIN_CONFIGURATION`). The space is fully configurable — every
strategy in `ActionSelector` only assumes `table.actions` is an iterable
of hashable ids, so `EngineConfig.actions` can carry any list.

## Action selector (Section 11)

`ActionSelector.select()` implements four strategies over an
`ActionValueTable` (one fixed-point value + visit counter per action):

- **greedy** — `argmax` over the value table, one comparator tree.
- **epsilon_greedy** (default) — one PRNG draw compared against an
  `epsilon` register; below it, a uniform-random action, otherwise greedy.
  Chosen as the default because it needs no transcendental functions —
  "simple and hardware-efficient" per the spec. `epsilon` decays by a
  configurable multiplicative factor each cycle (`epsilon_decay`, floored
  at `epsilon_min`) — a single fixed-point multiply per cycle, giving
  heavy exploration early and settling toward exploitation as the policy
  matures (see the convergence curves in `docs/08_RESULTS.md`).
- **softmax** / **ucb** — implemented in floating point for *software-side
  comparison only* (per Section 33's carve-out for external tools used in
  research comparison). Reaching silicon with either needs a
  piecewise-linear LUT approximation of `exp()`/`log()`/`sqrt()`; that
  substitution is called out in the module docstring rather than hidden,
  and is not implemented in `rtl/` since it isn't the default path.

## Constraint engine (Section 14)

```
candidate configuration
        |
    power check
        |
    thermal check
        |
    frequency check
        |
    voltage check
        |
    resource check
        |
    VALID / INVALID
```

`constraint_engine.py::ConstraintEngine.check()` — five independent
comparisons against a `HardLimits` register set. `HardLimits` is
constructed once by firmware/a safety authority
(`controller.py::default_hard_limits()`) and is **never** written by
`WeightUpdater` or `ActionValueTable` — there is no code path from the
learning datapath to these registers. An invalid candidate is rejected
*and* the reward is penalised (`RewardEngine.penalise_invalid()`) so the
policy also learns to stop proposing it, but the configuration itself is
never applied.

## The gap a per-action check alone doesn't cover

A candidate-only check validates one *proposed change* — it says nothing
about a configuration that drifted into unsafe territory through a
sequence of individually-valid small steps (e.g. `INCREASE_PARALLELISM`
approved five times in a row, each time against a *slightly* stale
temperature reading, compounding into real overheating between approvals).
This is a real, physically accurate failure mode: it showed up in this
project's own closed-loop simulation before the fix below, and is exactly
the kind of thing a candidate-only gate cannot catch.

**`ConstraintEngine.trip_action()`** is the fix, and it is the literal
Section 14 requirement ("Hard safety limits must exist outside the
learning algorithm. The ML algorithm cannot learn its way around them.")
taken to its logical hardware conclusion: an **independent safety
watchdog** that inspects the fabric's *actual current* telemetry — not a
candidate — every cycle, and can force a corrective action
(`DECREASE_FREQUENCY`) regardless of what the learning engine chose,
bypassing action selection entirely. This is architecturally the same
mechanism as a real chip's thermal-throttling circuit (e.g. Intel's
PROCHOT): it runs independently of firmware/software policy.
`controller.py::SilicaFluxController.step()` calls it every cycle; RTL
counterpart is `rtl/constraint_engine.sv::safety_watchdog`.

```python
actual = self.fabric.candidate_for_action(Action.MAINTAIN_CONFIGURATION, fmt)
trip = self.engine.constraint_engine.trip_action(actual)
action_to_apply = trip if trip is not None else output.action
if trip is not None or output.valid:
    self.fabric.apply_action(action_to_apply)
```

`tests/test_reward_and_actions.py::TestConstraintEngine` verifies both
paths: `check()` catches an unsafe *proposal*, `trip_action()` catches an
unsafe *actual* state regardless of what was proposed.
