# Fixed-Point Mathematics & the Online Learning Algorithm

## Fixed-point format (Section 21)

`python/silicaflux_ml/fixed_point.py::FixedFormat(int_bits, frac_bits,
signed=True)`. `int_bits` follows the Qm.n convention and **includes** the
sign bit, so Q16.16 is a 32-bit register (16 integer + 16 fractional bits).
A value is stored as a plain Python `int` holding the raw two's-complement
register content; `to_fixed()`/`to_float()` are the testbench-only
conversions a simulator uses to hand a real-world number to/from a register.

Every arithmetic primitive routes its result through `fixed_clip()` —
**saturating**, never wrapping:

| primitive | hardware analogue |
|---|---|
| `fixed_add` / `fixed_sub` | saturating adder/subtractor |
| `fixed_mul` | full double-width product, right-shifted by `frac_bits` (an arithmetic shift = truncating rescale), then saturated — one DSP-slice multiplier |
| `fixed_div` | numerator pre-shifted left by `frac_bits`, then integer-divided, truncating toward zero; divide-by-zero saturates to +max/-min by the numerator's sign, matching a guarded hardware divider |
| `fixed_div_int` | divide a fixed-point accumulator by a plain integer *count* register (ring-buffer occupancy) — a shifter for power-of-two depths, a small integer divider otherwise |
| `fixed_abs` / `fixed_compare` / `fixed_clamp_range` | direct hardware equivalents |
| `MacUnit` | one multiply-accumulate pipeline slice: accumulates at `total_bits + guard_bits` width (default 8 guard bits) so a long dot product doesn't overflow between terms, and only saturates down to the native width on `read()` |

Bit-accuracy is verified with hand-computed test vectors in
`tests/test_fixed_point.py` (round-trip conversion, exact arithmetic
results, saturation-not-wraparound, MAC-accumulator non-clipping between
terms).

## Precision comparison: Q8.8 / Q16.16 / Q24.8

`benchmarks/run_precision_comparison.py` runs the same deterministic affine
model, once in float64 and once through each format, and reports:

- **MAC-pipeline accuracy** — mean/median/max absolute error against the
  float64 reference over 20,000 random feature vectors. Q8.8 and Q24.8
  have *identical* accuracy here (both have 8 fractional bits — resolution
  is set by `frac_bits`, not `int_bits`); Q16.16's extra 8 fractional bits
  give roughly 256x finer resolution and a correspondingly smaller error.
  Q24.8's extra integer bits buy dynamic *range*, not precision — useful if
  a register must hold large accumulated quantities (e.g. total fabric
  energy) without saturating.
- **Closed-loop outcome** — the full fabric + Mode-3 controller run once
  per format, same seed and workload trace, comparing steady-state reward
  and throughput. See `docs/08_RESULTS.md` for the actual numbers from the
  reference run; the qualitative takeaway is that precision choice
  measurably changes the trajectory the online learner converges to (via
  different rounding in the weight-update path), not just the final
  numeric error of a static prediction.

## Feature engine (Section 5)

`python/silicaflux_ml/feature_engine.py`. One `RingChannel` per raw
state-vector field: a fixed-depth (`ring_depth`, default 16) ring buffer of
`(value, value^2)` pairs plus running `sum`/`sumsq` accumulators updated
`+new -evicted` each push — O(1) per sample regardless of runtime, i.e. a
fixed amount of hardware, never a growing history. From each channel:
moving average (`mean()`), moving variance (`variance()`, via
`E[x^2] - E[x]^2`, clamped at 0 to absorb fixed-point rounding noise),
delta and rate-of-change (`delta()`, sample period = 1 cycle by
construction). A small combinational block computes five derived
cross-channel ratios (normalised utilisation, power/thermal/throughput
efficiency, latency gradient), each guarded against a near-zero divisor by
flooring at ~1% of full scale (`min_divisor = fmt.scale // 100`) — a raw-
unit-`1` floor is a near no-op once a register has decayed toward zero and
lets the ratio blow up to the format's saturation ceiling (a real bug this
project hit and fixed; see `tests/test_feature_engine.py::
test_zero_utilisation_does_not_explode_efficiency`).

Of the ~53 statistics `FeatureEngine` computes, `learning_engine.py`
curates a compact 17-feature subset (`DEFAULT_FEATURE_ORDER`) actually fed
to the predictors/policy — Section 4's "compact hardware state vector"
principle applied to the derived features too. `feature_subset()` drops a
whole category (`"thermal"`, `"power"`, `"workload"`, `"core"`) at once,
which is what the ablation suite in Section 30 / `docs/07_VERIFICATION_
AND_BENCHMARKS.md` uses.

## Predictor (Section 6/7)

`predictor.py::OutputModel` is `Y = W . X + B`: a weight-register file, a
bias register, and one `MacUnit` pass. `Predictor` fans the same feature
vector out to one `OutputModel` per predicted quantity in parallel
(`predicted_throughput`, `predicted_power`, `predicted_temperature`,
`predicted_latency`, `predicted_error_probability` by default) — the STATE
VECTOR -> {THROUGHPUT, POWER, TEMPERATURE, ...} MODEL diagram of Section 7.

## Online learning (Section 8)

`weight_updater.py::WeightUpdater.maybe_update()`:

```
error     = observed - predicted
weight[i] = clamp(weight[i] + learning_rate * error * feature[i], weight_min, weight_max)
bias      = clamp(bias + learning_rate * error, weight_min, weight_max)
```

Two hardware-motivated gates prevent chasing measurement noise every
cycle: `error_threshold` (skip the update if `|error|` is too small) and
`update_interval` (fire the update once every N invocations, bounding
weight-register switching activity / dynamic power). Every intermediate
term saturates through the shared fixed-point primitives, so weights
cannot diverge past `[weight_min, weight_max]` regardless of how large or
persistent an error is (`tests/test_predictor_and_learning.py::
test_weights_saturate_at_configured_bounds`).

## From "predicted reward per action" to a real policy

A **non-contextual** multi-armed bandit (`action_selector.py::
ActionValueTable`) is what Modes 0-2 use: one fixed-point value register +
visit counter per action, updated as an exponential moving average of the
reward that action produced, regardless of what state the fabric was in.
This is a deliberately simple, cheap "adaptive" baseline — it cannot
condition its choice on telemetry at all, which is a real, disclosed
limitation (see `docs/07_VERIFICATION_AND_BENCHMARKS.md`'s ablation
discussion: feature ablation has **zero** effect on Modes 0-2's chosen
actions, precisely because they never look at features to pick one).

Mode 3+ instead learns a **linear Q(state, action)** function:
`LearningEngine.q_predictor` is a second `Predictor` instance with one
output per action (`w_a . features + b_a`), trained with the exact same
`WeightUpdater` machinery, using a single-step TD-style target (`reward`
observed for the state/action actually taken — no bootstrapped next-state
value, i.e. a contextual bandit rather than a full discounted-return RL
agent, which keeps the design to "one more small MAC-pipeline weight bank"
rather than adding a Bellman-backup datapath). This is what makes the
ablation study in Section 30 meaningful for the full RL mode: with a
state-conditioned policy, which feature *categories* are visible to it
demonstrably changes which actions it learns to prefer.
