# SilicaFlux Fabric Model, Workload Scheduler & Digital Twin

`python/silicaflux_ml/fabric.py` is the **digital twin**: a physics-ish
simulation of the compute fabric that stands in for real silicon so the
learning engine has something to learn from. It is the one module in this
package that intentionally uses plain floats — nothing in it is meant to
be synthesised; `docs/09_DSL_AND_RTL_MAPPING.md` explains why the boundary
is drawn exactly there.

## Fabric model (Section 15)

```
PE PE PE PE
PE PE PE PE
PE PE PE PE
PE PE PE PE
```

`SilicaFluxFabric(rows, cols)` holds one `PEState` per grid cell —
`utilisation, throughput, latency, temperature, power, errors,
queue_depth, allocation, active, degraded` — plus fabric-wide knobs
(`frequency`, `voltage`, `parallelism`, `batch_size`, `active_units`) that
actions mutate. `aggregate_state(fmt)` reduces the grid into one
`HardwareStateVector`, and **must** be called with the same `fmt` the
consuming `LearningEngine` is configured for — every value is a raw
register content, meaningless without the format defining its binary
point (this project hit exactly that unit-mismatch bug once; see the note
in `fabric.py::aggregate_state`'s docstring and the fix in
`controller.py::SilicaFluxController.step()`).

## Workload distribution learning (Section 16)

`workload_score(pe)` combines three terms into one spatial-allocation
score: `0.55*health + 0.30*thermal_room + 0.15*idle_room`.
`redistribute()` turns the per-PE scores into normalised allocation shares
every cycle — routing more work toward healthy, thermally-cool,
under-utilised PEs, and away from hot or degraded ones, without any
action needing to name a specific PE.

## Thermal model (Section 17)

Each PE's temperature update includes 4-connected-neighbour heat
diffusion (`heat_in = power*9.0 + 0.06*(neighbour_temp - pe.temperature)`)
so concentrating workload in one region visibly heats that region and its
neighbours, and `thermal_headroom = 100 - max(pe.temperature)` feeds the
feature engine directly. `ACTION_INCREASE_PARALLELISM` raises a per-PE
*concurrency multiplier* (`capacity_factor = parallelism / (rows*cols)`,
1.0x at the grid-size baseline, configurable range 0.5x-4.0x) that both
drains queued demand faster (less latency/backpressure under a spike) and
raises power/heat proportionally — the real trade-off the reward function
and constraint engine are there to balance.

## Power model (Section 18)

Per-PE `power = 0.15 + 0.85*utilisation*(voltage**2)*frequency*
capacity_factor`; the state vector's `power` feature is the fleet
**average** (comparable in magnitude to the other ~[0,1.5]-scaled
features), while `candidate_for_action()`'s power estimate for the
constraint engine is the fleet **total** against an absolute
`power_max` budget — deliberately different aggregations for two
deliberately different purposes (a learned feature vs. a hard safety
limit), documented at the point they're computed so the distinction
isn't silently lost. Optimisation target, per Section 18, is *maximum
useful compute / minimum energy* subject to the hard constraints in
`docs/04_CONSTRAINTS_AND_SAFETY.md` — the reward function's throughput +
efficiency terms vs. its power + thermal penalty terms encode exactly
that ratio.

## Fault model (Section 19)

`WorkloadGenerator` injects a randomly-timed, randomly-placed fault
(`fault_probability` per cycle, `fault_duration` cycles) that multiplies
the affected PE's throughput by 0.3 and adds a fixed error-rate/latency
penalty for its duration. `health_score(pe)` —
`throughput - error_penalty - 0.5*thermal_penalty - 0.3*power_penalty`,
clamped to `[0,1]` — is exactly the `f(throughput, errors, temperature,
power)` Section 19 asks for, and directly drives `workload_score()`'s
health term, so a degraded PE is automatically routed less work without
any action needing to single it out.

## Digital-twin simulation mode (Section 28)

`WorkloadGenerator.next(cycle, grid_shape)` generates a sinusoidal base
load, uniform noise, an occasional regime-shift step change (a new base
level every `base_period*3` cycles), and the fault process above — no
external dataset, purely synthetic, unbounded in length. Every benchmark
script in `benchmarks/` drives thousands to tens of thousands of virtual
cycles through this generator; see `docs/07_VERIFICATION_AND_BENCHMARKS.md`
for what each script measures and `docs/08_RESULTS.md` for actual numbers
from a reference run.
