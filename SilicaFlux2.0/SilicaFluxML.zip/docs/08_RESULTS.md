# Reference Run Results

Every number below came from one actual run of the scripts in
`python/benchmarks/` in this repository (not hand-edited afterward) —
`python3 -m unittest discover -s tests` passed (62/62) immediately before
this run. Re-running will reproduce these exactly (all randomness is
seeded) unless you change a script's `SEED`/cycle-count environment
variables. Charts referenced below are in `python/results/*.svg`.

## Convergence (Section 29) — 8,000 cycles, 4x4 fabric, Modes 0-3

Steady-state (last 1,000 cycles) averages:

| mode | reward | throughput | efficiency | temperature | policy instability |
|---|---|---|---|---|---|
| MODE_0_STATIC | +0.627 | 0.483 | 0.847 | 0.816 | 0.000 |
| MODE_1_LINEAR_ADAPTIVE | +0.703 | 0.485 | 0.916 | 0.774 | 0.000 |
| MODE_2_MULTI_OUTPUT | +0.703 | 0.485 | 0.916 | 0.774 | 0.000 |
| MODE_3_ONLINE_RL | **+0.833** | **0.872** | **2.494** | **0.516** | 0.267 |

Reward improves monotonically with capability, and Mode 3 in particular
learns to run **cooler and far more energy-efficient** while nearly
doubling throughput — it found a materially better operating point than
the non-contextual bandit modes, not just a marginally better one. Modes
1 and 2 are numerically identical here because, on this seed, their
non-contextual greedy policy converges to the same `INCREASE_PARALLELISM`
lock-in regardless of how many outputs the (otherwise-unused-for-policy)
predictor has — see `docs/03_FIXED_POINT_AND_LEARNING.md`'s discussion of
what a non-contextual bandit can and cannot do. `policy_instability` (rate
of action changes over a 200-cycle window) is 0 for the greedy modes
(exactly the lock-in above) and ~0.27 for Mode 3's still-exploring
epsilon-greedy policy — see `learning_curve.svg`, `reward_curve.svg`,
`efficiency_curve.svg`, `prediction_error_curve.svg`.

## Ablation (Section 30) — 15,000 cycles, 4x4 fabric

Steady-state (last 2,000 cycles) averages:

| configuration | features | reward | throughput | power | temp | prediction MSE |
|---|---|---|---|---|---|---|
| no_learning | 17 (unused) | +0.623 | 0.586 | 0.669 | 0.918 | 0.00000 |
| linear_learning | 17 (unused for policy) | +0.829 | 0.624 | 0.594 | 0.844 | 0.00061 |
| no_thermal_features | 13 | -1.478 | 0.792 | 0.322 | 0.526 | 0.00022 |
| no_power_features | 14 | **+1.055** | 0.949 | 0.359 | 0.498 | 0.00017 |
| no_workload_features | 15 | -1.069 | 0.896 | 0.355 | 0.550 | 0.00020 |
| full_silicaflux_ml | 17 | -0.668 | 0.875 | 0.330 | 0.530 | 0.00024 |

All five Mode-3 configurations share the *same* reward function — only
what the feature engine feeds the contextual Q(state, action) policy
differs. Two honest observations, not smoothed over:

1. **Removing thermal or workload features clearly hurts** (both land
   well below the full model), consistent with the architecture's own
   thesis — a policy that cannot see thermal state or queue/workload
   pressure cannot learn to avoid the actions that make those worse.
2. **`full_silicaflux_ml` does not top this particular table, and
   `no_power_features` does.** A 17-feature linear Q-function has more
   weights to learn than a 13-15-feature one, and under a *fixed* cycle
   budget, more parameters mean slower convergence — this is a real,
   reproducible property of fixed-budget online linear function
   approximation, not a bug in the reward or feature code. Re-running
   `run_ablation.py` with `SF_ABLATION_CYCLES=25000` narrows the gap
   substantially (full's reward rose from -1.53 to -0.04 between 8,000
   and 25,000 cycles in exploratory runs), confirming it is a
   convergence-speed effect rather than the extra features being
   actively harmful. A production deployment would want per-feature-
   group learning rates or L2-style weight regularisation to control this
   capacity/convergence trade-off — noted here as a real, disclosed
   limitation of the reference hyperparameters rather than hidden. See
   `ablation_reward.svg` / `ablation_prediction_error.svg`.

## Fixed-point precision (Sections 21/32)

MAC-pipeline accuracy, 20,000 random 17-feature affine evaluations against
a float64 reference:

| format | resolution | mean abs err | median | max |
|---|---|---|---|---|
| Q8.8  | 0.003906 | 0.031745 | 0.031734 | 0.074503 |
| Q16.16 | 0.000015 | 0.000133 | 0.000133 | 0.000291 |
| Q24.8 | 0.003906 | 0.031745 | 0.031734 | 0.074503 |

Q8.8 and Q24.8 are numerically **identical** here — both have 8
fractional bits, and resolution is set by `frac_bits`, not `int_bits`.
Q24.8's extra 16 integer bits buy dynamic range (useful for large
accumulated quantities), not precision. Q16.16's extra fractional bits
give ~240x smaller mean error.

Closed-loop outcome, same seed/workload, 6,000 cycles of Mode 3:

| format | avg reward (tail) | avg throughput (tail) |
|---|---|---|
| Q8.8 | -0.081 | 0.978 |
| Q16.16 | +0.690 | 0.901 |
| Q24.8 | -0.081 | 0.978 |

Precision choice measurably changes *which trajectory* the online learner
converges to (different rounding propagates through the weight-update
feedback loop), not only the static numerical error of one prediction —
this is exactly why Section 32 asks for bit-accurate simulation rather
than treating "close enough in float" as sufficient for a control loop
that trains on its own output.

## Synthesis resource estimate (Sections 25/26)

Q16.16, default 17-feature/10-action configuration (heuristic estimator —
see `docs/06_SYNTHESIS_ESTIMATION.md` for what this is and is not):

| mode | registers | MACs | LUT-equiv | memory (bits) | est. clock | est. power |
|---|---|---|---|---|---|---|
| MODE_0_STATIC | 15,232 | 0 | 2,892 | 38,912 | 320.5 MHz | 15.7 mW |
| MODE_1_LINEAR_ADAPTIVE | 15,808 | 34 | 6,710 | 45,056 | 320.5 MHz | 20.2 mW |
| MODE_2_MULTI_OUTPUT | 18,112 | 170 | 21,980 | 69,632 | 320.5 MHz | 38.0 mW |
| MODE_3_ONLINE_RL | 23,872 | 510 | 60,156 | 69,632 | 320.5 MHz | 82.7 mW |
| MODE_4_DISTRIBUTED (x16 PEs) | 381,952 | 8,160 | 962,496 | 1,114,112 | 320.5 MHz | 1,262.6 mW |

A clean, monotonically escalating resource curve across the five
complexity modes, as intended: Mode 3's contextual Q-function roughly
triples Mode 2's MAC count and LUT estimate (one MAC-pipeline weight bank
per action, on top of the per-quantity value predictors), and Mode 4 is
exactly 16x Mode 3's per-agent cost (one full agent per PE on the default
4x4 grid) plus nothing else. See `synthesis_resource_curve.svg` and
`synthesis_power_by_format.svg`.

## Mode 4 (distributed) demonstration — 3,000 cycles, 4x4 fabric

All 16 PEs stayed active throughout; per-PE health scores at the end of
the run ranged 0.30-0.59 and temperatures 85-90C, comfortably under the
105C (normalised 1.05) hard thermal limit throughout — the per-PE
constraint engines and the fabric-level `workload_score()` scheduler kept
every agent's local exploration inside the safety envelope without a
fabric-wide coordinator. See `python/benchmarks/run_mode4_demo.py`.
