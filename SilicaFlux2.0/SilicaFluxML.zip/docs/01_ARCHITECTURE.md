# SilicaFlux-ML — Architecture Specification

## Research proposition

> SilicaFlux is an adaptive computing architecture in which machine learning
> is embedded into the hardware control fabric itself, allowing the system
> to observe its own performance, update a compact model, and continuously
> search for better operating configurations within deterministic physical
> and safety constraints.

SilicaFlux-ML does **not** make any algorithm run mathematically faster. It
adaptively optimises *computation scheduling, resource utilisation, power,
and thermal behaviour* of an existing parallel compute fabric, by learning
online, from the fabric's own telemetry, which discrete configuration
changes tend to produce better outcomes. The learning algorithm itself is
representable as deterministic digital hardware — registers, counters,
comparators, accumulators, MAC pipelines, and a fixed number of pipeline
stages driven by one central state machine. Nothing in the inference or
learning path depends on Python, R, CUDA, or an external ML runtime; the
Python package in `python/silicaflux_ml/` is a **bit-accurate reference
model** of that hardware, not the hardware's implementation.

## Top-level loop

```
                    SILICAFLUX FABRIC
                           |
                           v
                    HARDWARE TELEMETRY
                           |
            +--------------+--------------+
            |                             |
       FEATURE ENGINE                 SENSOR DATA
            |                             |
            +--------------+--------------+
                           v
                   ML INFERENCE CORE          (Predictor, Section 6/7)
                           |
                           v
                  PERFORMANCE PREDICTOR
                           |
                           v
                   OPTIMISATION ENGINE        (RewardEngine + ActionValueTable)
                           |
                           v
                    ACTION SELECTOR
                           |
                           v
                  NEW CONFIGURATION
                           |
                           v
                    SILICAFLUX FABRIC
                           |
                           +------ feedback ------>
```

Every arrow in this diagram is a real data path in the code: telemetry ->
`FeatureEngine.observe()` -> `Predictor.predict()` -> `RewardEngine.compute()`
-> `ActionSelector.select()` -> `ConstraintEngine.check()` ->
`SilicaFluxFabric.apply_action()` -> (next cycle) telemetry again. See
`python/silicaflux_ml/controller.py::SilicaFluxController.step()` for the
literal one-cycle implementation of this loop, and `rtl/silicaflux_ml_top.sv`
for its RTL-oriented counterpart.

## Module hierarchy

```
SilicaFluxController / DistributedSilicaFluxController      (controller.py)
 |
 +-- SilicaFluxFabric                                        (fabric.py)
 |    +-- PEState x (rows*cols)         per-processing-element telemetry
 |    +-- WorkloadGenerator             synthetic workload + fault injection
 |
 +-- LearningEngine  (one per fabric [Modes 0-3], one per PE [Mode 4])
      |                                                       (learning_engine.py)
      +-- FeatureEngine                                       (feature_engine.py)
      |    +-- RingChannel x 12         one per raw state-vector field
      +-- Predictor                                            (predictor.py)
      |    +-- OutputModel x N_outputs  weights + bias + MacUnit
      +-- WeightUpdater                                         (weight_updater.py)
      +-- RewardEngine                                          (reward_engine.py)
      +-- Predictor (q_predictor)       Mode>=3 only: linear Q(state,action)
      +-- ActionValueTable + ActionSelector                     (action_selector.py)
      +-- ConstraintEngine                                      (constraint_engine.py)
      +-- LearningMemory                                        (learning_memory.py)
      +-- LearningFSM                                           (fsm.py)
```

Every Python class above has a named RTL counterpart in `rtl/` (see
`docs/09_DSL_AND_RTL_MAPPING.md` for the exact file-to-file mapping) and a
sketch in the native `silicaflux.ml` DSL in `dsl/silicaflux_ml.sf`.

## Design principle: hardware, not software-on-a-processor

Nothing in `python/silicaflux_ml/` (excluding `fabric.py`, which is
explicitly a *simulation* of physical silicon, not a hardware block) uses:

- floating-point arithmetic — everything routes through
  `fixed_point.py`'s saturating integer primitives;
- unbounded data structures — `FeatureEngine` uses fixed-depth ring
  buffers, `LearningMemory` is a fixed-depth circular buffer;
- a general-purpose ML framework, dynamic-shape tensors, or backprop
  through an arbitrary graph — the only "model" is a small number of
  affine (linear) predictors and a linear Q-function, each just a
  weight-register file, a bias register, and a multiply-accumulate
  pipeline.

Every class is written the way it would be built in RTL: registers as
plain attributes, state machines as explicit enums with a `step()`
function, "memory" as `collections.deque(maxlen=N)`.

## Directory layout

```
docs/         architecture specification (this directory)
rtl/          RTL-oriented SystemVerilog pseudocode, one file per block
dsl/          native SilicaFlux-DSL-style module sketch (silicaflux_ml.sf)
python/
  silicaflux_ml/   bit-accurate reference implementation (stdlib only)
  tests/           unit + integration verification suite (unittest, stdlib)
  benchmarks/      convergence / ablation / precision / synthesis-estimate scripts
  results/         CSV + SVG output of the benchmark scripts (generated)
```
