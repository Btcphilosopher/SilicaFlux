# Hardware State Machine & Model-Update Pipeline

## Section 24: central learning FSM

```
IDLE
 |
 v
OBSERVE   -- Stage 1: capture telemetry (HardwareStateVector sampled)
 |
 v
FEATURE   -- Stage 2: FeatureEngine.observe()
 |
 v
PREDICT   -- Stage 3: Predictor.predict()
 |
 v
EVALUATE  -- Stage 4: error = observed - predicted
 |
 v
UPDATE    -- Stage 6: WeightUpdater.maybe_update()
 |
 v
SELECT    -- Stage 5 + 7: RewardEngine.compute(), then ActionSelector.select()
 |
 v
VALIDATE  -- Stage 8: ConstraintEngine.check()
 |
 v
APPLY     -- Stage 9: LearningMemory.push(), configuration handed to controller
 |
 v
IDLE
```

Implementation: `python/silicaflux_ml/fsm.py::LearningFSM`. It is a strict
Moore machine — `step()` advances exactly one state per call (one call = one
clock edge) and a per-pass timeout counter (`timeout_cycles`, default 32)
forces a return to `IDLE` if a handler never completes, mirroring a stuck
pipeline stage tripping a watchdog on real silicon.
`LearningFSM.run_full_pass()` drives one complete `IDLE -> ... -> APPLY ->
IDLE` traversal and is what `LearningEngine.run_cycle()` calls once per
telemetry sample.

Reward and action-selection are pipelined together in a single `SELECT`
state because computing the *previous* cycle's action-value update needs
that cycle's freshly-computed reward before the *current* cycle's action can
be chosen — see `LearningEngine.run_cycle()`'s `do_select()` closure.

RTL: `rtl/learning_fsm.sv`. Same nine states, same timeout register, plus
explicit per-stage `_done` handshake signals so a variable-latency stage
(e.g. the multi-cycle `output_model` MAC walk in `rtl/predictor.sv`) can
hold the FSM in `FEATURE`/`PREDICT`/`UPDATE` for more than one cycle without
changing the Python model's single-call-per-stage semantics.

## Why nine stages, not one big combinational block

Two independent reasons, both real hardware-engineering trade-offs rather
than arbitrary choices:

1. **Timing closure.** A single-cycle "compute everything" datapath would
   chain a 17-feature MAC reduction, a divide (constraint check ratios),
   another 17-feature MAC reduction for the Q-function, an argmax over 10
   actions, and five more constraint comparisons into one combinational
   path. Splitting into pipeline stages keeps each stage's critical path
   short enough to hit a reasonable clock target (see
   `docs/06_SYNTHESIS_ESTIMATION.md`'s clock estimate).
2. **Reuse.** `OBSERVE`/`FEATURE`/`PREDICT`/`UPDATE` all share the same MAC
   datapath (`MacUnit`/`mac_unit`) time-multiplexed across different
   operands. A single-cycle design would need that MAC replicated instead
   of shared.

## Timeout and reset handling

`LearningFSM.timeout_cycles` (default 32, comfortably above the 9 stages'
worst-case multi-cycle latency at the default ring depth / feature count)
bounds how long any one pass may take. `LearningFSM.reset()` returns to
`IDLE` and clears the timer; `LearningFSM.timeout_count` is incremented
every time the timeout fires, giving a directly observable "how often did
this design stall" verification signal (`tests/test_fsm_and_memory.py::
TestLearningFSM::test_timeout_forces_reset` exercises this path with a
deliberately short timeout).
