# Synthesis-Resource Estimation & ML Complexity Modes

## What the estimator is (and is not)

`python/silicaflux_ml/synthesis_estimator.py::estimate_resources()` is a
**relative-cost heuristic**, not a synthesis tool. It exists to answer "how
much bigger is design B than design A", using coarse, explicitly-labelled
per-primitive constants (LUTs-per-bit for an adder/comparator/multiplier,
register-count formulas, a crude critical-path-length proxy for clock
estimation, a linear activity-based power model). None of these constants
are calibrated against a real PDK or FPGA family. Getting a real,
timing-closed area/power number requires an actual synthesis flow against
a real cell library — explicitly out of scope for a software reference
model, and this project is not going to pretend otherwise (see Section 33
/ the closing note in `docs/01_ARCHITECTURE.md`).

What it computes, from an `EngineConfig` (fixed-point format, feature
count, output count, action count, ring depth, memory depth):

| quantity | how |
|---|---|
| register count | FeatureEngine ring buffers + accumulators, Predictor weight/bias register files, action-value table, pipeline/guard registers |
| MAC count | `num_features * num_outputs` for prediction, doubled for the matching weight-update multiply-accumulate |
| LUT-equivalent | multiplier + adder + comparator LUT estimates, plus a small per-register routing/mux allowance |
| memory bits | `LearningMemory` depth x per-entry word count x register width |
| pipeline depth | fixed at 9 (Section 20's stage count) |
| estimated clock | `1000 / (1.2ns + bits * 0.06ns)` — a proxy for "wider fixed-point format -> longer multiplier critical path -> lower achievable clock", nothing more |
| estimated power | static floor + activity-weighted LUT/register/MAC power |

`estimate_resources(cfg, num_agents=N)` scales every count by `N` — this
is how Mode 4 (Section 16/26: one `LearningEngine` **per PE**) is
estimated: `N` = `rows*cols` literal replicas of the exact same per-agent
datapath, not a fundamentally different block.

## ML complexity modes (Section 26)

| mode | what changes vs. the previous mode | code |
|---|---|---|
| `MODE_0_STATIC` | no predictor, no policy: `MAINTAIN_CONFIGURATION` always | `output_names = []` |
| `MODE_1_LINEAR_ADAPTIVE` | one affine predictor (`predicted_throughput`), online weight updates, **greedy** (non-contextual) action selection | `output_names = ["predicted_throughput"]` |
| `MODE_2_MULTI_OUTPUT` | Section 7's parallel per-quantity predictors (5 outputs), still greedy/non-contextual policy | `output_names = ` all 5 |
| `MODE_3_ONLINE_RL` | + linear Q(state, action) policy with epsilon-greedy exploration (Section 8's docs/03 discussion) | `contextual_policy = True` |
| `MODE_4_DISTRIBUTED` | Mode 3's engine replicated once per PE, plus the fabric-level `workload_score()` scheduler reacting to each agent's actions | `DistributedSilicaFluxController` |

`estimate_all_modes(fmt, feature_order, actions)` runs the estimator for
all five and is what `benchmarks/run_synthesis_estimate.py` reports —
see `docs/08_RESULTS.md` for the actual escalating register/MAC/LUT/power
curve from a reference run at Q16.16.

## Running it

```
python3 python/benchmarks/run_synthesis_estimate.py
```
