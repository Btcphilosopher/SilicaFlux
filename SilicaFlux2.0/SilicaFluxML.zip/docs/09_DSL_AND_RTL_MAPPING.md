# RTL / DSL / Python Mapping, and Honest Limitations

## Three representations of the same algorithm

| hardware block | Python (bit-accurate) | SystemVerilog RTL pseudocode | SilicaFlux DSL sketch |
|---|---|---|---|
| fixed-point primitives | `fixed_point.py` | `fixed_point_ops.sv` | `Fixed16_16`, inline ops in `.sf` |
| FeatureEngine | `feature_engine.py` | `feature_engine.sv` | `module FeatureEngine` |
| Predictor | `predictor.py` | `predictor.sv` | `module Predictor` / `OutputModel` |
| WeightUpdater | `weight_updater.py` | `weight_updater.sv` | `module WeightUpdater` |
| RewardEngine | `reward_engine.py` | `reward_engine.sv` | `module RewardEngine` |
| ActionSelector / ActionValueTable | `action_selector.py` | `action_selector.sv` | `module ActionSelector` / `ActionValueTable` |
| ConstraintEngine + safety watchdog | `constraint_engine.py` | `constraint_engine.sv` | `module ConstraintEngine` / `SafetyWatchdog` |
| LearningMemory | `learning_memory.py` | `learning_memory.sv` | (circular buffer, see `LearningEngine`'s `memory`) |
| TelemetryEngine | `fabric.py::aggregate_state()` | `telemetry_engine.sv` | (aggregation sketch omitted, same pattern as `.sv`) |
| Central FSM | `fsm.py` | `learning_fsm.sv` | `state machine { ... }` block in `module LearningEngine` |
| Top-level composition | `learning_engine.py::LearningEngine` | `silicaflux_ml_top.sv` | `module LearningEngine` |

Every RTL/DSL file carries a `Python reference:` comment pointing back to
its Python counterpart, and vice versa in spirit — read them side by side.

## Where the hardware/simulation boundary actually is

`python/silicaflux_ml/fabric.py` is the **only** module in the package
that is not a hardware-block model. It represents the physical compute
fabric's *response* to a configuration (thermal diffusion, power draw,
fault injection, workload arrival) — a digital twin, standing in for
silicon that does not exist. It is written in plain floats, on purpose:
the boundary between "this is the ML hardware being specified" and "this
is the test rig that hardware would be soldered onto" needs to be sharp,
or the "no floating point in the learning path" claim becomes hollow. No
RTL file corresponds to `fabric.py` for that reason — it isn't meant to.

## What Section 23's DSL file is and is not

No public SilicaFlux hardware description language specification exists
to target, so `dsl/silicaflux_ml.sf` is a **speculative sketch**: a
plausible strongly-typed, Chisel/Bluespec-flavoured surface syntax
(`module`, typed `signal`/`reg` declarations, explicit `clock`/`reset`, an
explicit `state machine` block) chosen to map cleanly onto both the
Python reference model and the SystemVerilog in `rtl/`. It is not a
parseable or compiled language — treat it as an architecture-level
translation target to adapt once SilicaFlux's actual DSL grammar (if one
exists) is available, not as source code.

## Known, disclosed limitations (read this before citing a number above)

- **The synthesis estimator is a heuristic**, not a synthesis tool — see
  `docs/06_SYNTHESIS_ESTIMATION.md`'s opening section. Every LUT/clock/
  power constant in it is an order-of-magnitude placeholder.
- **Softmax and UCB action-selection strategies are software-reference
  only.** Reaching silicon with either needs a LUT-approximated
  `exp()`/`log()`/`sqrt()`; epsilon-greedy (the default) needs none of
  that, which is exactly why the spec calls it out as the hardware-
  efficient default.
- **The RTL in `rtl/` is pseudocode**, explicitly per the brief ("RTL-
  oriented pseudocode for every hardware module") — it is written in real
  SystemVerilog idiom and is structurally faithful to the Python model,
  but has not been run through a linter/simulator/synthesiser. Treat it
  as an architecture-accurate starting point for an actual RTL
  implementation, not a drop-in IP block.
- **Modes 0-2's action policy is a non-contextual bandit** (one value per
  action, no state input at all) — a real, load-bearing simplification
  discussed in `docs/03_FIXED_POINT_AND_LEARNING.md` and directly visible
  in the ablation results (feature ablation cannot and does not change
  what those modes do). Only Mode 3+'s linear Q(state, action) policy is
  state-conditioned.
- **The ablation study's "more features can converge slower under a fixed
  training budget" finding is real and reproducible** in this reference
  implementation (see `docs/08_RESULTS.md`), not an artifact hidden or
  explained away — it is a genuine property of fixed-learning-rate linear
  function approximation under a bounded number of online updates, and is
  reported because it is true, not because it flatters the "full" model.
- **The fabric's physical model is illustrative**, tuned to produce
  interesting, physically-plausible dynamics (thermal buildup, workload-
  induced heat concentration, fault-driven degradation) for demonstrating
  the *control* problem — it is not calibrated against any real silicon's
  measured power/thermal characteristics, and was not intended to be.
