# Verification Environment & Benchmark Suite

## Verification (Section 31/32)

`python/tests/`, stdlib `unittest` only (no external test runner needed —
`python3 -m unittest discover -s tests` from `python/`). 62 tests across:

| file | covers |
|---|---|
| `test_fixed_point.py` | conversion round-trip, exact arithmetic against hand-computed results, saturation-not-wraparound, MAC-accumulator non-clipping, Q8.8/Q16.16/Q24.8 resolution & range ordering |
| `test_feature_engine.py` | ring-buffer mean/variance/delta against hand-computed values, ring eviction, the min-divisor regression test |
| `test_predictor_and_learning.py` | `OutputModel.predict()` against hand-computed dot products, multi-output fan-out, `WeightUpdater`'s error-threshold / update-interval gates, weight saturation |
| `test_reward_and_actions.py` | `RewardEngine.compute()` against a hand-computed value, all four `ActionSelector` strategies, every `ConstraintEngine.check()` violation category, `trip_action()`'s actual-vs-candidate distinction |
| `test_fsm_and_memory.py` | FSM state-order traversal, per-state handler dispatch, timeout-forces-reset, `LearningMemory`'s circular overwrite |
| `test_integration.py` | every mode runs end-to-end without error, hard limits are never violated on the *applied* configuration, reward stays bounded, throughput doesn't collapse, Mode 4 keeps PEs active, **bit-exact determinism** from a fixed seed |

Bit-accurate simulation (Section 32): the Python model and the RTL are
required to agree on the same fixed-point *mathematics* (same saturate/
truncate/round rules), not merely produce similar-looking floats — that is
what `fixed_clip`/`fixed_mul`/`fixed_div` and their `fixed_point_ops.sv`
counterparts are written to guarantee term-for-term. There is no numerical
tolerance between them for the arithmetic primitives themselves; where a
tolerance *would* legitimately apply is between two different fixed-point
FORMATS (Q8.8 vs Q16.16), which is exactly what `run_precision_comparison.py`
quantifies.

## Benchmark suite (Sections 28-30)

All scripts live in `python/benchmarks/`, write CSV + hand-rolled
dependency-free SVG charts to `python/results/`, and run entirely on
synthetic (no external dataset) workload/fault traces from
`fabric.py::WorkloadGenerator`.

| script | Section | what it measures |
|---|---|---|
| `run_convergence.py` | 29 | reward / throughput / efficiency / prediction-error / policy-instability over time, for Modes 0-3, same seed/workload |
| `run_ablation.py` | 30 | no-learning vs. linear-learning vs. {no-thermal, no-power, no-workload}-feature Mode-3 vs. full Mode-3, steady-state reward/throughput/power/temp/prediction-MSE |
| `run_precision_comparison.py` | 21/32 | Q8.8/Q16.16/Q24.8 MAC-pipeline accuracy vs. float64, and closed-loop outcome sensitivity to format choice |
| `run_synthesis_estimate.py` | 25/26 | register/MAC/LUT/memory/clock/power heuristic estimate across all 5 complexity modes x 3 fixed-point formats |
| `run_mode4_demo.py` | 16/26 | short Mode-4 (per-PE distributed agents) demonstration run |

Run the whole suite:

```
cd python
python3 -m unittest discover -s tests
cd benchmarks
python3 run_convergence.py
python3 run_ablation.py
python3 run_precision_comparison.py
python3 run_synthesis_estimate.py
python3 run_mode4_demo.py
```

or `bash python/scripts/run_all.sh` to do all of the above in one shot.
See `docs/08_RESULTS.md` for the actual numbers and charts from a
reference run, and the honest caveats attached to a couple of the more
surprising ones.
