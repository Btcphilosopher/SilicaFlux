// =============================================================================
//  sync_fifo.sv  ·  Parameterised Synchronous FIFO
//
//  Single-clock-domain FIFO using a power-of-2 depth and a (n+1)-bit pointer
//  scheme to unambiguously distinguish full from empty without a comparator.
//
//  Parameters
//  ──────────
//  WIDTH          Data width in bits.
//  DEPTH          Storage depth — MUST be a power of 2.
//  AFULL_THRESH   Almost-full asserts when count ≥ (DEPTH - AFULL_THRESH).
//  AEMPTY_THRESH  Almost-empty asserts when count ≤ AEMPTY_THRESH.
//  FWFT           1 → First-Word Fall-Through (output valid without pop).
//                 0 → Standard mode (rdata valid one cycle after pop).
//
//  Latency model
//  ─────────────
//  Push latency : zero  — data written to memory combinatorially, registered
//                          on the rising edge; wr_ptr increments at that edge.
//  Pop latency  : 1 clk (standard) / 0 clk (FWFT) for rdata to be valid.
// =============================================================================

module sync_fifo #(
  parameter int WIDTH         = 32,
  parameter int DEPTH         = 16,
  parameter int AFULL_THRESH  = 2,
  parameter int AEMPTY_THRESH = 2,
  parameter bit FWFT          = 1'b0
) (
  input  logic             clk,
  input  logic             rst_n,
  // ── Write interface ──────────────────────────────────────────────────────
  input  logic             push,
  input  logic [WIDTH-1:0] wdata,
  // ── Read interface ───────────────────────────────────────────────────────
  input  logic             pop,
  output logic [WIDTH-1:0] rdata,
  // ── Status flags ─────────────────────────────────────────────────────────
  output logic             full,
  output logic             empty,
  output logic             almost_full,
  output logic             almost_empty,
  output logic             overflow,
  output logic             underflow,
  output logic [$clog2(DEPTH):0] count
);

  // ---------------------------------------------------------------------------
  // Local parameters
  // ---------------------------------------------------------------------------
  localparam int ADDR_W = $clog2(DEPTH);
  localparam int PTR_W  = ADDR_W + 1;   // extra MSB for full/empty discrimination

  // ---------------------------------------------------------------------------
  // Storage and pointers
  // ---------------------------------------------------------------------------
  logic [WIDTH-1:0]  mem [0:DEPTH-1];
  logic [PTR_W-1:0]  wr_ptr, rd_ptr;

  // ---------------------------------------------------------------------------
  // Combinatorial status flags
  // ---------------------------------------------------------------------------
  assign full         = (wr_ptr[PTR_W-1] != rd_ptr[PTR_W-1]) &&
                        (wr_ptr[ADDR_W-1:0] == rd_ptr[ADDR_W-1:0]);
  assign empty        = (wr_ptr == rd_ptr);
  assign count        = wr_ptr - rd_ptr;
  assign almost_full  = (count >= PTR_W'(DEPTH - AFULL_THRESH));
  assign almost_empty = (count <= PTR_W'(AEMPTY_THRESH));

  // ---------------------------------------------------------------------------
  // Write logic
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wr_ptr   <= '0;
      overflow <= 1'b0;
    end else begin
      if (push && !full) begin
        mem[wr_ptr[ADDR_W-1:0]] <= wdata;
        wr_ptr                  <= wr_ptr + 1'b1;
        overflow                <= 1'b0;
      end else if (push && full) begin
        overflow <= 1'b1;        // sticky; cleared on next successful push
      end
    end
  end

  // ---------------------------------------------------------------------------
  // Read logic — FWFT vs. standard
  // ---------------------------------------------------------------------------
  // Intermediate flop used only in standard mode
  logic [WIDTH-1:0] rdata_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) rdata_q <= '0;
    else if (pop && !empty)
      rdata_q <= mem[rd_ptr[ADDR_W-1:0]];
  end

  // Read-pointer and underflow
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_ptr    <= '0;
      underflow <= 1'b0;
    end else begin
      if (pop && !empty) begin
        rd_ptr    <= rd_ptr + 1'b1;
        underflow <= 1'b0;
      end else if (pop && empty) begin
        underflow <= 1'b1;
      end
    end
  end

  // Output mux: FWFT reads directly from RAM; standard reads the registered copy
  assign rdata = FWFT ? mem[rd_ptr[ADDR_W-1:0]] : rdata_q;

  // ---------------------------------------------------------------------------
  // Initialisation
  // ---------------------------------------------------------------------------
  initial begin
    wr_ptr    = '0;
    rd_ptr    = '0;
    overflow  = 1'b0;
    underflow = 1'b0;
    rdata_q   = '0;
    for (int i = 0; i < DEPTH; i++) mem[i] = '0;
  end

  // ---------------------------------------------------------------------------
  // Assertions
  // ---------------------------------------------------------------------------
  // synthesis translate_off
  initial begin
    assert ((DEPTH & (DEPTH-1)) == 0 && DEPTH >= 2)
      else $fatal(1, "[sync_fifo] DEPTH must be a power-of-2 >= 2 (got %0d)", DEPTH);
    assert (AFULL_THRESH  > 0 && AFULL_THRESH  < DEPTH)
      else $fatal(1, "[sync_fifo] AFULL_THRESH  out of range");
    assert (AEMPTY_THRESH > 0 && AEMPTY_THRESH < DEPTH)
      else $fatal(1, "[sync_fifo] AEMPTY_THRESH out of range");
  end

  property p_overflow_sticky;
    @(posedge clk) disable iff (!rst_n)
    (push && full) |-> ##1 overflow;
  endproperty
  assert property (p_overflow_sticky) else
    $error("[sync_fifo] overflow flag not set after push-while-full");

  property p_no_data_loss;
    @(posedge clk) disable iff (!rst_n)
    (push && !full) |=> (count > $past(count, 1));
  endproperty
  assert property (p_no_data_loss) else
    $error("[sync_fifo] count did not increase after successful push");
  // synthesis translate_on

endmodule : sync_fifo
