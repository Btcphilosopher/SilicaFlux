// =============================================================================
//  dp_ram.sv  ·  Parameterised True Dual-Port RAM (Independent Clocks)
//
//  Both ports can simultaneously read and write.  Write-write collision to
//  the same address in the same cycle is implementation-defined (Port A wins
//  in this model); use external arbitration when determinism is required.
//
//  Read-write collision (one port reads while the other writes the same
//  address) produces implementation-defined data on the reading port —
//  do not rely on a particular value without CDC synchronisation.
//
//  Parameters
//  ──────────
//  WIDTH    Data width in bits.
//  DEPTH    Number of addressable words.
//  LATENCY  Read latency in clock cycles per port (≥ 1).
// =============================================================================

module dp_ram #(
  parameter int WIDTH   = 32,
  parameter int DEPTH   = 1024,
  parameter int LATENCY = 1
) (
  // ── Port A ──────────────────────────────────────────────────────────────
  input  logic                     clk_a,
  input  logic                     rst_a_n,
  input  logic                     en_a,
  input  logic                     we_a,
  input  logic [$clog2(DEPTH)-1:0] addr_a,
  input  logic [WIDTH-1:0]         wdata_a,
  output logic [WIDTH-1:0]         rdata_a,
  // ── Port B ──────────────────────────────────────────────────────────────
  input  logic                     clk_b,
  input  logic                     rst_b_n,
  input  logic                     en_b,
  input  logic                     we_b,
  input  logic [$clog2(DEPTH)-1:0] addr_b,
  input  logic [WIDTH-1:0]         wdata_b,
  output logic [WIDTH-1:0]         rdata_b
);

  // ---------------------------------------------------------------------------
  // Shared memory array
  // ---------------------------------------------------------------------------
  (* ram_style = "block" *)
  (* ramstyle  = "M20K"  *)
  logic [WIDTH-1:0] mem [0:DEPTH-1];

  logic [WIDTH-1:0] pipe_a [0:LATENCY-1];
  logic [WIDTH-1:0] pipe_b [0:LATENCY-1];

  initial begin
    for (int i = 0; i < DEPTH;   i++) mem[i]    = '0;
    for (int j = 0; j < LATENCY; j++) pipe_a[j] = '0;
    for (int j = 0; j < LATENCY; j++) pipe_b[j] = '0;
  end

  // ---------------------------------------------------------------------------
  // Port A — write
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_a) begin
    if (en_a && we_a)
      mem[addr_a] <= wdata_a;
  end

  // Port A — read  (write-first: new data forwarded on simultaneous R/W)
  always_ff @(posedge clk_a or negedge rst_a_n) begin
    if (!rst_a_n)    pipe_a[0] <= '0;
    else if (en_a)   pipe_a[0] <= (we_a) ? wdata_a : mem[addr_a];
  end

  // ---------------------------------------------------------------------------
  // Port B — write
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_b) begin
    if (en_b && we_b)
      mem[addr_b] <= wdata_b;
  end

  // Port B — read  (write-first)
  always_ff @(posedge clk_b or negedge rst_b_n) begin
    if (!rst_b_n)    pipe_b[0] <= '0;
    else if (en_b)   pipe_b[0] <= (we_b) ? wdata_b : mem[addr_b];
  end

  // ---------------------------------------------------------------------------
  // Pipeline stages for LATENCY > 1
  // ---------------------------------------------------------------------------
  generate
    for (genvar i = 1; i < LATENCY; i++) begin : g_pipe
      always_ff @(posedge clk_a or negedge rst_a_n) begin
        if (!rst_a_n) pipe_a[i] <= '0;
        else          pipe_a[i] <= pipe_a[i-1];
      end
      always_ff @(posedge clk_b or negedge rst_b_n) begin
        if (!rst_b_n) pipe_b[i] <= '0;
        else          pipe_b[i] <= pipe_b[i-1];
      end
    end
  endgenerate

  assign rdata_a = pipe_a[LATENCY-1];
  assign rdata_b = pipe_b[LATENCY-1];

  // ---------------------------------------------------------------------------
  // Assertions
  // ---------------------------------------------------------------------------
  // synthesis translate_off
  initial begin
    assert (LATENCY >= 1)
      else $fatal(1, "[dp_ram] LATENCY must be >= 1");
    assert (WIDTH > 0 && DEPTH > 1)
      else $fatal(1, "[dp_ram] WIDTH and DEPTH must be > 1");
  end

  // Warn on simultaneous write collision
  property p_wr_collision;
    @(posedge clk_a)
    !(en_a && we_a && en_b && we_b && (addr_a == addr_b));
  endproperty
  assert property (p_wr_collision) else
    $warning("[dp_ram] Write-write collision on addr=%0h — result is A-wins", addr_a);
  // synthesis translate_on

endmodule : dp_ram
