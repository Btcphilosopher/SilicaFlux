// =============================================================================
//  memory_controller.sv  ·  DRAM-Style Memory Controller FSM
//
//  Models a simplified SDRAM controller with full ACTIVATE → CAS → PRECHARGE
//  → REFRESH timing pipeline.  Designed to sit between the cache miss-handling
//  logic and a physical (or behavioural) DRAM macro.
//
//  DRAM timing parameters (all in clock cycles)
//  ─────────────────────────────────────────────
//  tRCD   Row-to-Column Delay  (ACTIVATE → READ/WRITE)
//  tCL    CAS Latency          (CAS command → first data)
//  tWR    Write Recovery       (last write data → PRECHARGE)
//  tRP    Row Precharge        (PRECHARGE → next ACTIVATE)
//  tRFC   Refresh Cycle Time   (AUTO-REFRESH duration)
//  REFRESH_PERIOD  Cycles between consecutive AUTO-REFRESH commands
//
//  FSM state diagram
//  ─────────────────
//  IDLE ──(req)──► ACTIVATE ──(tRCD)──► READ_CAS  ──(tCL)──► READ_DATA  ──► PRECHARGE
//                                     └──────────────────► WRITE_CAS ──────► WRITE_DATA ──► PRECHARGE
//  IDLE ──(refresh_pending)──► REFRESH ──(tRFC)──► IDLE
//  PRECHARGE ──(tRP)──► DONE ──► IDLE
//
//  Interface
//  ─────────
//  The req/resp interface is a simple valid-ready handshake compatible with
//  the cache fill/writeback state machines in this repository.
//  The dram_* outputs follow standard SDRAM command encoding conventions.
// =============================================================================

module memory_controller #(
  parameter int ADDR_WIDTH     = 32,
  parameter int DATA_WIDTH     = 32,
  parameter int BURST_LEN      = 8,      // Words per read/write burst
  parameter int tRCD           = 3,
  parameter int tCL            = 3,
  parameter int tWR            = 2,
  parameter int tRP            = 3,
  parameter int tRFC           = 12,
  parameter int REFRESH_PERIOD = 3200,
  parameter bit PRIORITY_READS = 1'b1    // Reads take priority over pending writes
) (
  input  logic                    clk,
  input  logic                    rst_n,
  // ── Cache / requestor interface ──────────────────────────────────────────
  input  logic                    req_valid,
  input  logic                    req_we,
  input  logic [ADDR_WIDTH-1:0]   req_addr,
  input  logic [DATA_WIDTH-1:0]   req_wdata,
  output logic                    req_ready,       // Controller can accept a new req
  // ── Response to cache ────────────────────────────────────────────────────
  output logic                    resp_valid,
  output logic [DATA_WIDTH-1:0]   resp_rdata,
  output logic [1:0]              resp_code,       // 00=OK, 01=WAIT, 10=ERR
  // ── Physical DRAM interface ───────────────────────────────────────────────
  output logic                    dram_cke,
  output logic                    dram_cs_n,
  output logic                    dram_ras_n,
  output logic                    dram_cas_n,
  output logic                    dram_we_n,
  output logic [ADDR_WIDTH-1:0]   dram_addr,
  output logic [DATA_WIDTH-1:0]   dram_wdata,
  input  logic [DATA_WIDTH-1:0]   dram_rdata,
  input  logic                    dram_valid,      // Read data valid from DRAM
  // ── Debug / monitoring outputs ───────────────────────────────────────────
  output logic [3:0]              fsm_state,
  output logic [31:0]             total_reads,
  output logic [31:0]             total_writes,
  output logic [31:0]             total_refreshes
);

  // ---------------------------------------------------------------------------
  // Local parameters
  // ---------------------------------------------------------------------------
  localparam int CNT_MAX  = tRCD + tCL + tWR + tRP + 4;  // ceiling for counter
  localparam int CNT_W    = $clog2(CNT_MAX + 1);
  localparam int BURST_W  = $clog2(BURST_LEN + 1);
  localparam int REF_W    = $clog2(REFRESH_PERIOD + 1);

  // ---------------------------------------------------------------------------
  // SDRAM command encoding  {RAS_n, CAS_n, WE_n}
  // ---------------------------------------------------------------------------
  localparam logic [2:0] CMD_NOP        = 3'b111;
  localparam logic [2:0] CMD_ACTIVE     = 3'b011;
  localparam logic [2:0] CMD_READ       = 3'b101;
  localparam logic [2:0] CMD_WRITE      = 3'b100;
  localparam logic [2:0] CMD_PRECHARGE  = 3'b010;
  localparam logic [2:0] CMD_AUTO_REF   = 3'b001;

  // ---------------------------------------------------------------------------
  // FSM encoding
  // ---------------------------------------------------------------------------
  typedef enum logic [3:0] {
    ST_IDLE       = 4'h0,
    ST_ACTIVATE   = 4'h1,
    ST_READ_CAS   = 4'h2,
    ST_READ_DATA  = 4'h3,
    ST_WRITE_CAS  = 4'h4,
    ST_WRITE_DATA = 4'h5,
    ST_PRECHARGE  = 4'h6,
    ST_REFRESH    = 4'h7,
    ST_DONE       = 4'h8,
    ST_ERROR      = 4'hF
  } mc_state_t;

  mc_state_t state, next_state;

  // ---------------------------------------------------------------------------
  // Internal registers
  // ---------------------------------------------------------------------------
  logic [CNT_W-1:0]    timing_cnt;     // countdown for tRCD/tCL/tRP/tRFC
  logic [BURST_W-1:0]  burst_cnt;      // word counter within burst
  logic [REF_W-1:0]    refresh_timer;  // cycles until next refresh required
  logic                refresh_pending;

  // Latched request
  logic                  lat_we;
  logic [ADDR_WIDTH-1:0] lat_addr;
  logic [DATA_WIDTH-1:0] lat_wdata;

  // Command register driven to DRAM pins
  logic [2:0] dram_cmd;
  assign {dram_ras_n, dram_cas_n, dram_we_n} = dram_cmd;

  // ---------------------------------------------------------------------------
  // Refresh watchdog (runs continuously)
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      refresh_timer   <= REF_W'(REFRESH_PERIOD - 1);
      refresh_pending <= 1'b0;
      total_refreshes <= '0;
    end else begin
      if (refresh_timer == '0) begin
        refresh_timer   <= REF_W'(REFRESH_PERIOD - 1);
        refresh_pending <= 1'b1;
      end else begin
        refresh_timer <= refresh_timer - 1'b1;
      end
      // Clear when refresh cycle completes
      if (state == ST_REFRESH && timing_cnt == CNT_W'(1))
        total_refreshes <= total_refreshes + 1;
      if (state == ST_DONE && $past(state) == ST_REFRESH)
        refresh_pending <= 1'b0;
    end
  end

  // ---------------------------------------------------------------------------
  // State register
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) state <= ST_IDLE;
    else        state <= next_state;
  end

  // ---------------------------------------------------------------------------
  // Timing counter: loaded on every state transition
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      timing_cnt <= '0;
    end else begin
      if (state != next_state) begin
        // Pre-load counter for next state
        case (next_state)
          ST_ACTIVATE:   timing_cnt <= CNT_W'(tRCD - 1);
          ST_READ_CAS:   timing_cnt <= CNT_W'(tCL  - 1);
          ST_PRECHARGE:  timing_cnt <= CNT_W'(tRP  - 1);
          ST_REFRESH:    timing_cnt <= CNT_W'(tRFC - 1);
          default:       timing_cnt <= '0;
        endcase
      end else begin
        if (timing_cnt > '0) timing_cnt <= timing_cnt - 1'b1;
      end
    end
  end

  // ---------------------------------------------------------------------------
  // Next-state combinatorial logic
  // ---------------------------------------------------------------------------
  always_comb begin
    next_state = state;
    case (state)
      ST_IDLE: begin
        if (refresh_pending)
          next_state = ST_REFRESH;
        else if (req_valid)
          next_state = ST_ACTIVATE;
      end

      ST_ACTIVATE:   if (timing_cnt == '0)
                       next_state = lat_we ? ST_WRITE_CAS : ST_READ_CAS;

      ST_READ_CAS:   if (timing_cnt == '0) next_state = ST_READ_DATA;

      ST_READ_DATA:  if (burst_cnt == BURST_W'(BURST_LEN-1) && dram_valid)
                       next_state = ST_PRECHARGE;

      ST_WRITE_CAS:  next_state = ST_WRITE_DATA;

      ST_WRITE_DATA: if (burst_cnt == BURST_W'(BURST_LEN-1))
                       next_state = ST_PRECHARGE;

      ST_PRECHARGE:  if (timing_cnt == '0) next_state = ST_DONE;

      ST_REFRESH:    if (timing_cnt == '0) next_state = ST_DONE;

      ST_DONE:       next_state = ST_IDLE;

      ST_ERROR:      next_state = ST_IDLE;

      default:       next_state = ST_IDLE;
    endcase
  end

  // ---------------------------------------------------------------------------
  // Output / datapath logic
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      req_ready     <= 1'b0;
      resp_valid    <= 1'b0;
      resp_rdata    <= '0;
      resp_code     <= 2'b00;
      dram_cke      <= 1'b1;
      dram_cs_n     <= 1'b0;
      dram_cmd      <= CMD_NOP;
      dram_addr     <= '0;
      dram_wdata    <= '0;
      burst_cnt     <= '0;
      lat_we        <= 1'b0;
      lat_addr      <= '0;
      lat_wdata     <= '0;
      total_reads   <= '0;
      total_writes  <= '0;
      fsm_state     <= '0;
    end else begin
      // Defaults
      req_ready  <= 1'b0;
      resp_valid <= 1'b0;
      dram_cmd   <= CMD_NOP;
      dram_cke   <= 1'b1;
      dram_cs_n  <= 1'b0;
      fsm_state  <= 4'(state);

      case (state)
        // --------------------------------------------------------------------
        ST_IDLE: begin
          if (!refresh_pending) begin
            req_ready <= 1'b1;
            if (req_valid) begin
              lat_we    <= req_we;
              lat_addr  <= req_addr;
              lat_wdata <= req_wdata;
            end
          end else begin
            resp_code <= 2'b01;  // WAIT — refresh taking priority
          end
        end

        // --------------------------------------------------------------------
        ST_ACTIVATE: begin
          // Issue ACTIVE command with row address on clock 0
          if (timing_cnt == CNT_W'(tRCD-1)) begin
            dram_cmd  <= CMD_ACTIVE;
            dram_addr <= lat_addr;
          end
        end

        // --------------------------------------------------------------------
        ST_READ_CAS: begin
          if (timing_cnt == CNT_W'(tCL-1)) begin
            dram_cmd  <= CMD_READ;
            dram_addr <= lat_addr;
            burst_cnt <= '0;
            total_reads <= total_reads + 1;
          end
        end

        // --------------------------------------------------------------------
        ST_READ_DATA: begin
          if (dram_valid) begin
            resp_rdata <= dram_rdata;
            resp_valid <= 1'b1;
            resp_code  <= 2'b00;   // OKAY
            if (burst_cnt < BURST_W'(BURST_LEN - 1))
              burst_cnt <= burst_cnt + 1'b1;
            else
              burst_cnt <= '0;
          end
        end

        // --------------------------------------------------------------------
        ST_WRITE_CAS: begin
          dram_cmd  <= CMD_WRITE;
          dram_addr <= lat_addr;
          burst_cnt <= '0;
          total_writes <= total_writes + 1;
        end

        // --------------------------------------------------------------------
        ST_WRITE_DATA: begin
          dram_wdata <= lat_wdata;
          if (burst_cnt < BURST_W'(BURST_LEN - 1))
            burst_cnt <= burst_cnt + 1'b1;
          else begin
            burst_cnt  <= '0;
            resp_valid <= 1'b1;
            resp_code  <= 2'b00;   // OKAY
          end
        end

        // --------------------------------------------------------------------
        ST_PRECHARGE: begin
          if (timing_cnt == CNT_W'(tRP-1)) begin
            dram_cmd      <= CMD_PRECHARGE;
            dram_addr[10] <= 1'b1;  // A10=1: all-banks precharge
          end
        end

        // --------------------------------------------------------------------
        ST_REFRESH: begin
          if (timing_cnt == CNT_W'(tRFC-1)) begin
            dram_cmd <= CMD_AUTO_REF;
          end
        end

        // --------------------------------------------------------------------
        ST_DONE: begin
          req_ready <= 1'b1;  // pulse ready for one cycle
        end

        // --------------------------------------------------------------------
        ST_ERROR: begin
          resp_code <= 2'b10;   // ERROR
          resp_valid <= 1'b1;
        end

      endcase
    end
  end

  // ---------------------------------------------------------------------------
  // Assertions
  // ---------------------------------------------------------------------------
  // synthesis translate_off
  initial begin
    assert (tRCD >= 1 && tCL >= 1 && tRP >= 1 && tRFC >= 1)
      else $fatal(1, "[mc] All timing parameters must be >= 1");
    assert (BURST_LEN >= 1 && BURST_LEN <= 16)
      else $fatal(1, "[mc] BURST_LEN must be in [1,16]");
    assert (REFRESH_PERIOD > tRFC)
      else $fatal(1, "[mc] REFRESH_PERIOD must be > tRFC");
  end

  // Ensure resp_valid is not asserted for more than one consecutive cycle
  // (single-beat response model)
  property p_resp_one_cycle;
    @(posedge clk) disable iff (!rst_n)
    resp_valid |=> !resp_valid;
  endproperty
  assert property (p_resp_one_cycle) else
    $warning("[mc] resp_valid held for more than one cycle");

  // Refresh must complete within REFRESH_PERIOD + tRFC cycles
  property p_refresh_not_starved;
    @(posedge clk) disable iff (!rst_n)
    $rose(refresh_pending) |-> ##[1:(tRFC + 20)] (state == ST_REFRESH);
  endproperty
  assert property (p_refresh_not_starved) else
    $error("[mc] Refresh request starved beyond deadline");
  // synthesis translate_on

endmodule : memory_controller
