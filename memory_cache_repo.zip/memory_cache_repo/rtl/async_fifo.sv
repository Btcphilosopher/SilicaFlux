// =============================================================================
//  async_fifo.sv  ·  Parameterised Asynchronous (Dual-Clock) FIFO
//
//  Architecture: Gray-code pointer synchronisation with a 2-FF synchroniser
//  on each crossing, following Clifford Cummings' seminal methodology.
//
//  Key safety properties
//  ─────────────────────
//  1. Gray-code pointers guarantee only one bit changes per increment, making
//     the 2-FF synchroniser metastability-safe.
//  2. Full is evaluated conservatively on the write side (using a stale read
//     pointer), so the FIFO never overfills.
//  3. Empty is evaluated conservatively on the read side, so underflow is
//     impossible under normal operation.
//
//  Parameters
//  ──────────
//  WIDTH   Data width in bits.
//  DEPTH   FIFO depth — MUST be a power of 2 and ≥ 4.
//
//  Note: rdata is FWFT — valid data appears on rdata without a separate read
//  enable; assert pop to advance the read pointer.
// =============================================================================

module async_fifo #(
  parameter int WIDTH = 32,
  parameter int DEPTH = 16
) (
  // ── Write clock domain ───────────────────────────────────────────────────
  input  logic             wclk,
  input  logic             wrst_n,
  input  logic             push,
  input  logic [WIDTH-1:0] wdata,
  output logic             wfull,
  output logic             walmost_full,
  // ── Read clock domain ────────────────────────────────────────────────────
  input  logic             rclk,
  input  logic             rrst_n,
  input  logic             pop,
  output logic [WIDTH-1:0] rdata,
  output logic             rempty,
  output logic             ralmost_empty
);

  // ---------------------------------------------------------------------------
  // Local parameters
  // ---------------------------------------------------------------------------
  localparam int ADDR_W = $clog2(DEPTH);
  localparam int PTR_W  = ADDR_W + 1;    // one extra bit for full/empty detect

  // ---------------------------------------------------------------------------
  // Shared dual-port RAM
  // ---------------------------------------------------------------------------
  logic [WIDTH-1:0] mem [0:DEPTH-1];

  // ---------------------------------------------------------------------------
  // Binary-to-Gray conversion
  // ---------------------------------------------------------------------------
  function automatic logic [PTR_W-1:0] bin2gray (input logic [PTR_W-1:0] b);
    return b ^ (b >> 1);
  endfunction

  // Gray-to-Binary conversion (for count approximation only)
  function automatic logic [PTR_W-1:0] gray2bin (input logic [PTR_W-1:0] g);
    logic [PTR_W-1:0] b;
    b[PTR_W-1] = g[PTR_W-1];
    for (int i = PTR_W-2; i >= 0; i--)
      b[i] = b[i+1] ^ g[i];
    return b;
  endfunction

  // ---------------------------------------------------------------------------
  // Write-domain pointers
  // ---------------------------------------------------------------------------
  logic [PTR_W-1:0] wptr_bin, wptr_gray;

  always_ff @(posedge wclk or negedge wrst_n) begin
    if (!wrst_n) begin
      wptr_bin  <= '0;
      wptr_gray <= '0;
    end else if (push && !wfull) begin
      mem[wptr_bin[ADDR_W-1:0]] <= wdata;
      wptr_bin  <= wptr_bin + 1'b1;
      wptr_gray <= bin2gray(wptr_bin + 1'b1);
    end
  end

  // ---------------------------------------------------------------------------
  // Read-pointer → write-domain 2-FF synchroniser
  // ---------------------------------------------------------------------------
  logic [PTR_W-1:0] rptr_gray_s0_w, rptr_gray_s1_w;   // s0=first FF, s1=settled

  always_ff @(posedge wclk or negedge wrst_n) begin
    if (!wrst_n) begin
      rptr_gray_s0_w <= '0;
      rptr_gray_s1_w <= '0;
    end else begin
      rptr_gray_s0_w <= rptr_gray;   // rptr_gray defined in read domain below
      rptr_gray_s1_w <= rptr_gray_s0_w;
    end
  end

  // Full flag: the two MSBs differ (write has lapped read), lower bits equal
  // Equivalent to: wptr_gray == {~rptr_sync[PTR_W-1:PTR_W-2], rptr_sync[PTR_W-3:0]}
  assign wfull = (wptr_gray[PTR_W-1] != rptr_gray_s1_w[PTR_W-1]) &&
                 (wptr_gray[PTR_W-2] != rptr_gray_s1_w[PTR_W-2]) &&
                 (wptr_gray[PTR_W-3:0] == rptr_gray_s1_w[PTR_W-3:0]);

  // Approximate count in write domain for almost-full
  logic [PTR_W-1:0] rptr_bin_w;
  always_comb rptr_bin_w = gray2bin(rptr_gray_s1_w);
  assign walmost_full = ((wptr_bin - rptr_bin_w) >= PTR_W'(DEPTH - 2));

  // ---------------------------------------------------------------------------
  // Read-domain pointers
  // ---------------------------------------------------------------------------
  logic [PTR_W-1:0] rptr_bin, rptr_gray;

  // rdata is FWFT — combinatorial read from memory
  assign rdata = mem[rptr_bin[ADDR_W-1:0]];

  always_ff @(posedge rclk or negedge rrst_n) begin
    if (!rrst_n) begin
      rptr_bin  <= '0;
      rptr_gray <= '0;
    end else if (pop && !rempty) begin
      rptr_bin  <= rptr_bin + 1'b1;
      rptr_gray <= bin2gray(rptr_bin + 1'b1);
    end
  end

  // ---------------------------------------------------------------------------
  // Write-pointer → read-domain 2-FF synchroniser
  // ---------------------------------------------------------------------------
  logic [PTR_W-1:0] wptr_gray_s0_r, wptr_gray_s1_r;

  always_ff @(posedge rclk or negedge rrst_n) begin
    if (!rrst_n) begin
      wptr_gray_s0_r <= '0;
      wptr_gray_s1_r <= '0;
    end else begin
      wptr_gray_s0_r <= wptr_gray;
      wptr_gray_s1_r <= wptr_gray_s0_r;
    end
  end

  // Empty: read Gray pointer equals synchronised write Gray pointer
  assign rempty = (rptr_gray == wptr_gray_s1_r);

  // Approximate count in read domain for almost-empty
  logic [PTR_W-1:0] wptr_bin_r;
  always_comb wptr_bin_r = gray2bin(wptr_gray_s1_r);
  assign ralmost_empty = ((wptr_bin_r - rptr_bin) <= PTR_W'(2));

  // ---------------------------------------------------------------------------
  // Assertions
  // ---------------------------------------------------------------------------
  // synthesis translate_off
  initial begin
    assert ((DEPTH & (DEPTH-1)) == 0)
      else $fatal(1, "[async_fifo] DEPTH must be a power-of-2 (got %0d)", DEPTH);
    assert (DEPTH >= 4)
      else $fatal(1, "[async_fifo] DEPTH must be >= 4 for correct Gray-code full detect");
    assert (WIDTH > 0)
      else $fatal(1, "[async_fifo] WIDTH must be > 0");
  end

  // No push while full
  property p_no_push_full;
    @(posedge wclk) disable iff (!wrst_n)
    push && wfull |-> ##1 wfull;  // full stays asserted (conservative model)
  endproperty
  assert property (p_no_push_full) else
    $warning("[async_fifo] push asserted while full — data dropped");

  // No pop while empty
  property p_no_pop_empty;
    @(posedge rclk) disable iff (!rrst_n)
    pop && rempty |-> ##1 rempty;  // empty stays asserted
  endproperty
  assert property (p_no_pop_empty) else
    $warning("[async_fifo] pop asserted while empty — spurious advance");
  // synthesis translate_on

endmodule : async_fifo
