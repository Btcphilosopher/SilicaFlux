// =============================================================================
//  set_assoc_cache.sv  ·  N-Way Set-Associative Cache with LRU Replacement
//
//  Policy   : write-back with dirty bit.
//  Replacement:
//    NUM_WAYS = 1  → direct-mapped (trivial; victim always way 0)
//    NUM_WAYS = 2  → true LRU using 1 bit per set
//    NUM_WAYS = 4  → pseudo-LRU (PLRU) binary tree using 3 bits per set
//
//  PLRU tree layout (4-way):
//  ──────────────────────────
//       [b2]
//      /     \
//   [b1]     [b0]
//   /  \     /  \
//  W0  W1  W2  W3
//
//  Each bit points to the LEAST-recently-used subtree/way.
//  Victim selection:  b2=0 → {b1=0→W0, b1=1→W1}  b2=1 → {b0=0→W2, b0=1→W3}
//  Update on access W:
//    W=0: b2←1, b1←1   W=1: b2←1, b1←0
//    W=2: b2←0, b0←1   W=3: b2←0, b0←0
//
//  Parameters
//  ──────────
//  ADDR_WIDTH   Address bus width.
//  DATA_WIDTH   Data bus width.
//  NUM_SETS     Number of sets (power-of-2).
//  NUM_WAYS     Associativity: 1, 2, or 4.
//  LINE_SIZE    Bytes per cache line (power-of-2, ≥ DATA_WIDTH/8).
// =============================================================================

module set_assoc_cache #(
  parameter int ADDR_WIDTH = 32,
  parameter int DATA_WIDTH = 32,
  parameter int NUM_SETS   = 128,
  parameter int NUM_WAYS   = 4,
  parameter int LINE_SIZE  = 64
) (
  input  logic                      clk,
  input  logic                      rst_n,
  // ── CPU interface ────────────────────────────────────────────────────────
  input  logic                      cpu_req,
  input  logic                      cpu_we,
  input  logic [ADDR_WIDTH-1:0]     cpu_addr,
  input  logic [DATA_WIDTH-1:0]     cpu_wdata,
  output logic [DATA_WIDTH-1:0]     cpu_rdata,
  output logic                      cpu_ack,
  output logic                      cpu_stall,
  // ── Memory (downstream) interface ────────────────────────────────────────
  output logic                      mem_req,
  output logic                      mem_we,
  output logic [ADDR_WIDTH-1:0]     mem_addr,
  output logic [DATA_WIDTH-1:0]     mem_wdata,
  input  logic [DATA_WIDTH-1:0]     mem_rdata,
  input  logic                      mem_ack,
  // ── Performance counters ─────────────────────────────────────────────────
  output logic [31:0]               perf_hits,
  output logic [31:0]               perf_misses,
  output logic [31:0]               perf_writebacks
);

  // ---------------------------------------------------------------------------
  // Derived widths
  // ---------------------------------------------------------------------------
  localparam int BYTES_PER_WORD = DATA_WIDTH / 8;
  localparam int WORDS_PER_LINE = LINE_SIZE / BYTES_PER_WORD;
  localparam int OFFSET_BITS    = $clog2(LINE_SIZE);
  localparam int WORD_BITS      = $clog2(WORDS_PER_LINE);
  localparam int INDEX_BITS     = $clog2(NUM_SETS);
  localparam int TAG_BITS       = ADDR_WIDTH - OFFSET_BITS - INDEX_BITS;
  localparam int WAY_BITS       = (NUM_WAYS > 1) ? $clog2(NUM_WAYS) : 1;
  // LRU state bits per set: 1 for 2-way, 3 for 4-way, 0 for direct-mapped
  localparam int LRU_BITS       = (NUM_WAYS == 4) ? 3 :
                                  (NUM_WAYS == 2) ? 1 : 1;

  // ---------------------------------------------------------------------------
  // Address decomposition (combinatorial, from live cpu_addr)
  // ---------------------------------------------------------------------------
  logic [TAG_BITS-1:0]   req_tag;
  logic [INDEX_BITS-1:0] req_index;
  logic [WORD_BITS-1:0]  req_word;

  assign req_tag   = cpu_addr[ADDR_WIDTH-1      : OFFSET_BITS+INDEX_BITS];
  assign req_index = cpu_addr[OFFSET_BITS+INDEX_BITS-1 : OFFSET_BITS];
  assign req_word  = cpu_addr[OFFSET_BITS-1      : OFFSET_BITS-WORD_BITS];

  // ---------------------------------------------------------------------------
  // Cache storage arrays
  // ---------------------------------------------------------------------------
  logic [TAG_BITS-1:0]   tag_arr   [0:NUM_SETS-1][0:NUM_WAYS-1];
  logic [DATA_WIDTH-1:0] data_arr  [0:NUM_SETS-1][0:NUM_WAYS-1][0:WORDS_PER_LINE-1];
  logic                  valid_arr [0:NUM_SETS-1][0:NUM_WAYS-1];
  logic                  dirty_arr [0:NUM_SETS-1][0:NUM_WAYS-1];
  logic [LRU_BITS-1:0]   lru_arr   [0:NUM_SETS-1];

  // ---------------------------------------------------------------------------
  // Parallel hit detection across all ways
  // ---------------------------------------------------------------------------
  logic [NUM_WAYS-1:0]   way_hit_vec;
  logic [WAY_BITS-1:0]   hit_way;
  logic                  cache_hit;

  generate
    for (genvar w = 0; w < NUM_WAYS; w++) begin : g_hit
      assign way_hit_vec[w] = valid_arr[req_index][w] &&
                              (tag_arr[req_index][w] == req_tag);
    end
  endgenerate

  always_comb begin
    hit_way   = '0;
    cache_hit = 1'b0;
    for (int i = NUM_WAYS-1; i >= 0; i--)
      if (way_hit_vec[i]) begin
        hit_way   = WAY_BITS'(i);
        cache_hit = 1'b1;
      end
  end

  // ---------------------------------------------------------------------------
  // LRU victim selection (combinatorial, from latched index during miss)
  // ---------------------------------------------------------------------------
  logic [WAY_BITS-1:0] victim_way;

  always_comb begin : g_victim
    victim_way = '0;
    if (NUM_WAYS == 1) begin
      victim_way = '0;
    end else if (NUM_WAYS == 2) begin
      // True LRU: lru_arr bit = index of LRU way
      victim_way = WAY_BITS'(lru_arr[req_index][0]);
    end else begin                   // NUM_WAYS == 4  PLRU tree
      if (!lru_arr[req_index][2])    // b2=0 → left subtree is LRU
        victim_way = lru_arr[req_index][1] ? 2'b01 : 2'b00;
      else                           // b2=1 → right subtree is LRU
        victim_way = lru_arr[req_index][0] ? 2'b11 : 2'b10;
    end
  end

  // ---------------------------------------------------------------------------
  // LRU update function
  // ---------------------------------------------------------------------------
  function automatic logic [LRU_BITS-1:0] update_lru (
    input logic [LRU_BITS-1:0] lru,
    input logic [WAY_BITS-1:0] accessed
  );
    logic [LRU_BITS-1:0] nxt;
    nxt = lru;
    if (NUM_WAYS == 2) begin
      nxt[0] = ~accessed[0];   // point to the OTHER way
    end else if (NUM_WAYS == 4) begin
      case (accessed)
        2'b00: begin nxt[2] = 1'b1; nxt[1] = 1'b1; end  // point right, point W1
        2'b01: begin nxt[2] = 1'b1; nxt[1] = 1'b0; end  // point right, point W0
        2'b10: begin nxt[2] = 1'b0; nxt[0] = 1'b1; end  // point left,  point W3
        2'b11: begin nxt[2] = 1'b0; nxt[0] = 1'b0; end  // point left,  point W2
        default: ;
      endcase
    end
    return nxt;
  endfunction

  // ---------------------------------------------------------------------------
  // FSM
  // ---------------------------------------------------------------------------
  typedef enum logic [2:0] {
    S_IDLE      = 3'b000,
    S_HIT       = 3'b001,
    S_WRITEBACK = 3'b010,
    S_FILL      = 3'b011,
    S_RESPOND   = 3'b100
  } state_t;

  state_t state, next_state;

  // Latched request — held stable across multi-cycle miss
  logic [TAG_BITS-1:0]   lat_tag;
  logic [INDEX_BITS-1:0] lat_index;
  logic [WORD_BITS-1:0]  lat_word;
  logic                  lat_we;
  logic [DATA_WIDTH-1:0] lat_wdata;
  logic [WAY_BITS-1:0]   lat_victim;   // victim way chosen at miss time

  // Word counter for burst fill / writeback
  logic [$clog2(WORDS_PER_LINE):0] fill_cnt;
  logic                            fill_done;
  assign fill_done = (fill_cnt == $clog2(WORDS_PER_LINE)'(WORDS_PER_LINE - 1));

  // ---------------------------------------------------------------------------
  // State register
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) state <= S_IDLE;
    else        state <= next_state;
  end

  // ---------------------------------------------------------------------------
  // Next-state logic
  // ---------------------------------------------------------------------------
  always_comb begin
    next_state = state;
    case (state)
      S_IDLE: begin
        if (cpu_req) begin
          if      (cache_hit)                                               next_state = S_HIT;
          else if (valid_arr[req_index][victim_way] &&
                   dirty_arr[req_index][victim_way])                        next_state = S_WRITEBACK;
          else                                                              next_state = S_FILL;
        end
      end
      S_HIT:      next_state = S_IDLE;
      S_WRITEBACK: if (fill_done && mem_ack)                                next_state = S_FILL;
      S_FILL:      if (fill_done && mem_ack)                                next_state = S_RESPOND;
      S_RESPOND:  next_state = S_IDLE;
      default:    next_state = S_IDLE;
    endcase
  end

  // ---------------------------------------------------------------------------
  // Datapath — clocked
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cpu_rdata       <= '0;
      cpu_ack         <= 1'b0;
      cpu_stall       <= 1'b0;
      mem_req         <= 1'b0;
      mem_we          <= 1'b0;
      mem_addr        <= '0;
      mem_wdata       <= '0;
      fill_cnt        <= '0;
      lat_tag         <= '0;
      lat_index       <= '0;
      lat_word        <= '0;
      lat_we          <= 1'b0;
      lat_wdata       <= '0;
      lat_victim      <= '0;
      perf_hits       <= '0;
      perf_misses     <= '0;
      perf_writebacks <= '0;
      for (int s = 0; s < NUM_SETS; s++) begin
        lru_arr[s] <= '0;
        for (int wy = 0; wy < NUM_WAYS; wy++) begin
          valid_arr[s][wy] <= 1'b0;
          dirty_arr[s][wy] <= 1'b0;
          tag_arr[s][wy]   <= '0;
        end
      end
    end else begin
      cpu_ack   <= 1'b0;
      cpu_stall <= 1'b0;
      mem_req   <= 1'b0;

      case (state)

        // --------------------------------------------------------------------
        S_IDLE: begin
          if (cpu_req) begin
            lat_tag    <= req_tag;
            lat_index  <= req_index;
            lat_word   <= req_word;
            lat_we     <= cpu_we;
            lat_wdata  <= cpu_wdata;
            if (!cache_hit) begin
              cpu_stall   <= 1'b1;
              lat_victim  <= victim_way;
              fill_cnt    <= '0;
              perf_misses <= perf_misses + 1;
            end
          end
        end

        // --------------------------------------------------------------------
        S_HIT: begin
          if (!lat_we)
            cpu_rdata <= data_arr[lat_index][hit_way][lat_word];
          else begin
            data_arr[lat_index][hit_way][lat_word] <= lat_wdata;
            dirty_arr[lat_index][hit_way]          <= 1'b1;
          end
          lru_arr[lat_index] <= update_lru(lru_arr[lat_index], hit_way);
          cpu_ack   <= 1'b1;
          perf_hits <= perf_hits + 1;
        end

        // --------------------------------------------------------------------
        S_WRITEBACK: begin
          cpu_stall <= 1'b1;
          mem_req   <= 1'b1;
          mem_we    <= 1'b1;
          mem_addr  <= {tag_arr[lat_index][lat_victim], lat_index,
                        fill_cnt[WORD_BITS-1:0],
                        {(OFFSET_BITS-WORD_BITS){1'b0}}};
          mem_wdata <= data_arr[lat_index][lat_victim][fill_cnt[WORD_BITS-1:0]];
          if (mem_ack) begin
            if (!fill_done)
              fill_cnt <= fill_cnt + 1'b1;
            else begin
              fill_cnt                          <= '0;
              dirty_arr[lat_index][lat_victim]  <= 1'b0;
              perf_writebacks                   <= perf_writebacks + 1;
            end
          end
        end

        // --------------------------------------------------------------------
        S_FILL: begin
          cpu_stall <= 1'b1;
          mem_req   <= 1'b1;
          mem_we    <= 1'b0;
          mem_addr  <= {lat_tag, lat_index,
                        fill_cnt[WORD_BITS-1:0],
                        {(OFFSET_BITS-WORD_BITS){1'b0}}};
          if (mem_ack) begin
            data_arr[lat_index][lat_victim][fill_cnt[WORD_BITS-1:0]] <= mem_rdata;
            if (!fill_done)
              fill_cnt <= fill_cnt + 1'b1;
            else begin
              fill_cnt                         <= '0;
              valid_arr[lat_index][lat_victim] <= 1'b1;
              tag_arr[lat_index][lat_victim]   <= lat_tag;
            end
          end
        end

        // --------------------------------------------------------------------
        S_RESPOND: begin
          if (!lat_we)
            cpu_rdata <= data_arr[lat_index][lat_victim][lat_word];
          else begin
            data_arr[lat_index][lat_victim][lat_word] <= lat_wdata;
            dirty_arr[lat_index][lat_victim]          <= 1'b1;
          end
          lru_arr[lat_index] <= update_lru(lru_arr[lat_index], lat_victim);
          cpu_ack <= 1'b1;
        end

      endcase
    end
  end

  // ---------------------------------------------------------------------------
  // Assertions
  // ---------------------------------------------------------------------------
  // synthesis translate_off
  initial begin
    assert (NUM_WAYS == 1 || NUM_WAYS == 2 || NUM_WAYS == 4)
      else $fatal(1, "[sa_cache] NUM_WAYS must be 1, 2, or 4 (got %0d)", NUM_WAYS);
    assert ((NUM_SETS  & (NUM_SETS -1)) == 0)
      else $fatal(1, "[sa_cache] NUM_SETS  must be power-of-2");
    assert ((LINE_SIZE & (LINE_SIZE-1)) == 0)
      else $fatal(1, "[sa_cache] LINE_SIZE must be power-of-2");
    assert (TAG_BITS > 0)
      else $fatal(1, "[sa_cache] TAG_BITS=0: address too narrow for cache config");
  end

  // At most one way hits at any time
  property p_one_hot_hit;
    @(posedge clk) disable iff (!rst_n)
    cpu_req |-> $onehot0(way_hit_vec);
  endproperty
  assert property (p_one_hot_hit) else
    $error("[sa_cache] Multiple ways report a hit simultaneously — tag array corrupt");

  property p_ack_one_cycle;
    @(posedge clk) disable iff (!rst_n)
    cpu_ack |=> !cpu_ack;
  endproperty
  assert property (p_ack_one_cycle) else
    $error("[sa_cache] cpu_ack held more than one cycle");
  // synthesis translate_on

endmodule : set_assoc_cache
