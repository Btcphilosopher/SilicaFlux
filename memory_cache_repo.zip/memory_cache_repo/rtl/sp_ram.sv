// =============================================================================
//  sp_ram.sv  ·  Parameterised Single-Port Synchronous RAM
//
//  Synthesis-ready behavioural description that infers Block RAM on Xilinx
//  Vivado (XPM or legacy RAMB36) and Intel Quartus (M20K / MLAB).
//
//  Parameters
//  ──────────
//  WIDTH          Data width in bits.
//  DEPTH          Number of addressable words.  Need not be a power of 2,
//                 though power-of-2 is recommended for optimal address decoding.
//  LATENCY        Read latency in clock cycles (≥ 1).  LATENCY=1 gives a
//                 single registered output (standard BRAM mode).  LATENCY>1
//                 adds explicit pipeline stages.
//  RD_WR_POLICY   Behaviour when read and write addresses coincide:
//                   "WRITE_FIRST" – new write data forwarded to read output.
//                   "READ_FIRST"  – old data returned (read-before-write).
//                   "NO_CHANGE"   – output register holds previous value.
//  INIT_FILE      Path to $readmemh init file.  Leave "" to zero-init.
//
//  Port           Dir   Width              Description
//  ─────────────────────────────────────────────────────
//  clk            in    1                  Rising-edge clock
//  rst_n          in    1                  Async active-low reset
//  en             in    1                  Chip enable (clock-gate)
//  we             in    1                  Write enable
//  addr           in    clog2(DEPTH)       Read/write address
//  wdata          in    WIDTH              Write data
//  rdata          out   WIDTH              Read data (after LATENCY cycles)
// =============================================================================

module sp_ram #(
  parameter int    WIDTH        = 32,
  parameter int    DEPTH        = 1024,
  parameter int    LATENCY      = 1,
  parameter string RD_WR_POLICY = "WRITE_FIRST",
  parameter string INIT_FILE    = ""
) (
  input  logic                     clk,
  input  logic                     rst_n,
  input  logic                     en,
  input  logic                     we,
  input  logic [$clog2(DEPTH)-1:0] addr,
  input  logic [WIDTH-1:0]         wdata,
  output logic [WIDTH-1:0]         rdata
);

  // ---------------------------------------------------------------------------
  // Memory array — attribute hints for major tool families
  // ---------------------------------------------------------------------------
  (* ram_style   = "block" *)   // Xilinx Vivado
  (* ramstyle    = "M20K"  *)   // Intel Quartus
  logic [WIDTH-1:0] mem [0:DEPTH-1];

  // Pipeline chain; index 0 is the first registered stage
  logic [WIDTH-1:0] pipe [0:LATENCY-1];

  // ---------------------------------------------------------------------------
  // Initialisation
  // ---------------------------------------------------------------------------
  initial begin
    if (INIT_FILE != "")
      $readmemh(INIT_FILE, mem);
    else
      for (int i = 0; i < DEPTH; i++) mem[i] = '0;
    for (int j = 0; j < LATENCY; j++) pipe[j] = '0;
  end

  // ---------------------------------------------------------------------------
  // Write port
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk) begin
    if (en && we)
      mem[addr] <= wdata;
  end

  // ---------------------------------------------------------------------------
  // Read port — stage 0 (policy-dependent)
  // ---------------------------------------------------------------------------
  generate
    if (RD_WR_POLICY == "WRITE_FIRST") begin : g_wf
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)        pipe[0] <= '0;
        else if (en)       pipe[0] <= (we) ? wdata : mem[addr];
      end
    end else if (RD_WR_POLICY == "READ_FIRST") begin : g_rf
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)        pipe[0] <= '0;
        else if (en)       pipe[0] <= mem[addr];
      end
    end else begin : g_nc // NO_CHANGE
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)             pipe[0] <= '0;
        else if (en && !we)     pipe[0] <= mem[addr];
      end
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // Additional pipeline stages for LATENCY > 1
  // ---------------------------------------------------------------------------
  generate
    for (genvar i = 1; i < LATENCY; i++) begin : g_pipe
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) pipe[i] <= '0;
        else        pipe[i] <= pipe[i-1];
      end
    end
  endgenerate

  assign rdata = pipe[LATENCY-1];

  // ---------------------------------------------------------------------------
  // Parameter assertions  (elaboration-time)
  // ---------------------------------------------------------------------------
  // synthesis translate_off
  initial begin
    assert (LATENCY >= 1)
      else $fatal(1, "[sp_ram] LATENCY must be >= 1");
    assert (WIDTH > 0 && DEPTH > 1)
      else $fatal(1, "[sp_ram] WIDTH must be >0, DEPTH must be >1");
    if ((DEPTH & (DEPTH-1)) != 0)
      $warning("[sp_ram] DEPTH=%0d is not a power-of-2; address decoder may be sub-optimal", DEPTH);
  end

  // RTL assertions (simulation)
  property p_no_x_addr;
    @(posedge clk) disable iff (!rst_n)
    en |-> !$isunknown(addr);
  endproperty
  assert property (p_no_x_addr) else
    $error("[sp_ram] X/Z detected on addr while en=1");
  // synthesis translate_on

endmodule : sp_ram
