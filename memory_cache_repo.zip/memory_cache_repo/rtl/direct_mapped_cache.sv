// =============================================================================
//  direct_mapped_cache.sv  ·  Parameterised Direct-Mapped Cache
//
//  Policy: write-back with dirty-bit.  On a miss the dirty victim line is
//  written back to main memory before the new line is fetched (classic
//  write-back writeback policy).
//
//  Address decomposition (ADDR_WIDTH = 32, byte addressing)
//  ──────────────────────────────────────────────────────────
//  [31 : INDEX_MSB+1]          Tag
//  [INDEX_MSB : OFFSET_MSB+1]  Set index
//  [OFFSET_MSB : 0]            Byte offset within line
//
//  Parameters
//  ──────────
//  ADDR_WIDTH    Address bus width (default 32).
//  DATA_WIDTH    Data bus width (default 32 — one word per beat).
//  CACHE_LINES   Number of cache lines (must be power-of-2).
//  LINE_SIZE     Bytes per cache line (must be power-of-2, ≥ DATA_WIDTH/8).
//  MEM_LATENCY   Unused directly; main-memory latency is modelled through
//                the mem_ack handshake driven by the memory controller.
//
//  Latency model
//  ─────────────
//  Hit  : 1 cycle  (cpu_ack asserted on the cycle after cpu_req)
//  Miss : FSM stalls CPU (cpu_stall) while writeback/fill complete,
//         then asserts cpu_ack for one cycle on S_RESPOND.
// =============================================================================

module direct_mapped_cache #(
  parameter int ADDR_WIDTH  = 32,
  parameter int DATA_WIDTH  = 32,
  parameter int CACHE_LINES = 256,
  parameter int LINE_SIZE   = 64,
  parameter int MEM_LATENCY = 10    // informational; not used in RTL timing
) (
  input  logic                      clk,
  input  logic                      rst_n,
  // ── CPU interface ────────────────────────────────────────────────────────
  input  logic                      cpu_req,
  input  logic                      cpu_we,
  input  logic [ADDR_WIDTH-1:0]     cpu_addr,
  input  logic [DATA_WIDTH-1:0]     cpu_wdata,
  output logic [DATA_WIDTH-1:0]     cpu_rdata,
  output logic                      cpu_ack,
  output logic                      cpu_stall,
  // ── Memory (downstream) interface ────────────────────────────────────────
  output logic                      mem_req,
  output logic                      mem_we,
  output logic [ADDR_WIDTH-1:0]     mem_addr,
  output logic [DATA_WIDTH-1:0]     mem_wdata,
  input  logic [DATA_WIDTH-1:0]     mem_rdata,
  input  logic                      mem_ack,
  // ── Performance counters ─────────────────────────────────────────────────
  output logic [31:0]               perf_hits,
  output logic [31:0]               perf_misses,
  output logic [31:0]               perf_writebacks
);

  // ---------------------------------------------------------------------------
  // Address field widths
  // ---------------------------------------------------------------------------
  localparam int BYTES_PER_WORD  = DATA_WIDTH / 8;
  localparam int WORDS_PER_LINE  = LINE_SIZE / BYTES_PER_WORD;
  localparam int OFFSET_BITS     = $clog2(LINE_SIZE);
  localparam int WORD_BITS       = $clog2(WORDS_PER_LINE);
  localparam int INDEX_BITS      = $clog2(CACHE_LINES);
  localparam int TAG_BITS        = ADDR_WIDTH - OFFSET_BITS - INDEX_BITS;

  // ---------------------------------------------------------------------------
  // Address decomposition from incoming request
  // ---------------------------------------------------------------------------
  logic [TAG_BITS-1:0]    req_tag;
  logic [INDEX_BITS-1:0]  req_index;
  logic [WORD_BITS-1:0]   req_word;

  assign req_tag   = cpu_addr[ADDR_WIDTH-1      : OFFSET_BITS+INDEX_BITS];
  assign req_index = cpu_addr[OFFSET_BITS+INDEX_BITS-1 : OFFSET_BITS];
  assign req_word  = cpu_addr[OFFSET_BITS-1      : OFFSET_BITS-WORD_BITS];

  // ---------------------------------------------------------------------------
  // Cache arrays
  // ---------------------------------------------------------------------------
  logic [TAG_BITS-1:0]   tag_arr   [0:CACHE_LINES-1];
  logic [DATA_WIDTH-1:0] data_arr  [0:CACHE_LINES-1][0:WORDS_PER_LINE-1];
  logic                  valid_arr [0:CACHE_LINES-1];
  logic                  dirty_arr [0:CACHE_LINES-1];

  // ---------------------------------------------------------------------------
  // Combinatorial hit detection
  // ---------------------------------------------------------------------------
  logic cache_hit;
  assign cache_hit = valid_arr[req_index] && (tag_arr[req_index] == req_tag);

  // ---------------------------------------------------------------------------
  // Fill / writeback word counter
  // ---------------------------------------------------------------------------
  logic [$clog2(WORDS_PER_LINE):0] fill_cnt;
  logic                            fill_done;
  assign fill_done = (fill_cnt == $clog2(WORDS_PER_LINE)'(WORDS_PER_LINE - 1));

  // ---------------------------------------------------------------------------
  // FSM state encoding
  // ---------------------------------------------------------------------------
  typedef enum logic [2:0] {
    S_IDLE       = 3'b000,
    S_HIT        = 3'b001,
    S_WRITEBACK  = 3'b010,
    S_FILL       = 3'b011,
    S_RESPOND    = 3'b100
  } state_t;

  state_t state, next_state;

  // Latched request (held across miss cycles)
  logic [ADDR_WIDTH-1:0] lat_addr;
  logic                  lat_we;
  logic [DATA_WIDTH-1:0] lat_wdata;
  logic [TAG_BITS-1:0]   lat_tag;
  logic [INDEX_BITS-1:0] lat_index;
  logic [WORD_BITS-1:0]  lat_word;

  // ---------------------------------------------------------------------------
  // State register
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) state <= S_IDLE;
    else        state <= next_state;
  end

  // ---------------------------------------------------------------------------
  // Next-state combinatorial logic
  // ---------------------------------------------------------------------------
  always_comb begin
    next_state = state;
    case (state)
      S_IDLE: begin
        if (cpu_req) begin
          if      (cache_hit)                                    next_state = S_HIT;
          else if (dirty_arr[req_index] && valid_arr[req_index]) next_state = S_WRITEBACK;
          else                                                   next_state = S_FILL;
        end
      end
      S_HIT:      next_state = S_IDLE;
      S_WRITEBACK: if (fill_done && mem_ack)                     next_state = S_FILL;
      S_FILL:      if (fill_done && mem_ack)                     next_state = S_RESPOND;
      S_RESPOND:  next_state = S_IDLE;
      default:    next_state = S_IDLE;
    endcase
  end

  // ---------------------------------------------------------------------------
  // Datapath
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cpu_rdata      <= '0;
      cpu_ack        <= 1'b0;
      cpu_stall      <= 1'b0;
      mem_req        <= 1'b0;
      mem_we         <= 1'b0;
      mem_addr       <= '0;
      mem_wdata      <= '0;
      fill_cnt       <= '0;
      lat_addr       <= '0;
      lat_we         <= 1'b0;
      lat_wdata      <= '0;
      lat_tag        <= '0;
      lat_index      <= '0;
      lat_word       <= '0;
      perf_hits      <= '0;
      perf_misses    <= '0;
      perf_writebacks<= '0;
      for (int i = 0; i < CACHE_LINES; i++) begin
        valid_arr[i] <= 1'b0;
        dirty_arr[i] <= 1'b0;
        tag_arr[i]   <= '0;
      end
    end else begin
      // Default strobes
      cpu_ack   <= 1'b0;
      cpu_stall <= 1'b0;
      mem_req   <= 1'b0;

      case (state)
        // ----------------------------------------------------------------
        S_IDLE: begin
          if (cpu_req) begin
            // Latch the request for use in miss-handling states
            lat_addr  <= cpu_addr;
            lat_we    <= cpu_we;
            lat_wdata <= cpu_wdata;
            lat_tag   <= req_tag;
            lat_index <= req_index;
            lat_word  <= req_word;
            if (!cache_hit) begin
              cpu_stall    <= 1'b1;
              fill_cnt     <= '0;
              perf_misses  <= perf_misses + 1;
            end
          end
        end

        // ----------------------------------------------------------------
        S_HIT: begin
          if (!lat_we)
            cpu_rdata <= data_arr[lat_index][lat_word];
          else begin
            data_arr[lat_index][lat_word] <= lat_wdata;
            dirty_arr[lat_index]          <= 1'b1;
          end
          cpu_ack   <= 1'b1;
          perf_hits <= perf_hits + 1;
        end

        // ----------------------------------------------------------------
        S_WRITEBACK: begin
          cpu_stall <= 1'b1;
          mem_req   <= 1'b1;
          mem_we    <= 1'b1;
          // Build writeback address from stored tag + latched index
          mem_addr  <= {tag_arr[lat_index], lat_index,
                        fill_cnt[WORD_BITS-1:0],
                        {(OFFSET_BITS-WORD_BITS){1'b0}}};
          mem_wdata <= data_arr[lat_index][fill_cnt[WORD_BITS-1:0]];
          if (mem_ack) begin
            if (!fill_done)
              fill_cnt <= fill_cnt + 1'b1;
            else begin
              fill_cnt                <= '0;
              dirty_arr[lat_index]    <= 1'b0;
              perf_writebacks         <= perf_writebacks + 1;
            end
          end
        end

        // ----------------------------------------------------------------
        S_FILL: begin
          cpu_stall <= 1'b1;
          mem_req   <= 1'b1;
          mem_we    <= 1'b0;
          mem_addr  <= {lat_tag, lat_index,
                        fill_cnt[WORD_BITS-1:0],
                        {(OFFSET_BITS-WORD_BITS){1'b0}}};
          if (mem_ack) begin
            data_arr[lat_index][fill_cnt[WORD_BITS-1:0]] <= mem_rdata;
            if (!fill_done)
              fill_cnt <= fill_cnt + 1'b1;
            else begin
              fill_cnt             <= '0;
              valid_arr[lat_index] <= 1'b1;
              tag_arr[lat_index]   <= lat_tag;
            end
          end
        end

        // ----------------------------------------------------------------
        S_RESPOND: begin
          if (!lat_we)
            cpu_rdata <= data_arr[lat_index][lat_word];
          else begin
            data_arr[lat_index][lat_word] <= lat_wdata;
            dirty_arr[lat_index]          <= 1'b1;
          end
          cpu_ack <= 1'b1;
        end

      endcase
    end
  end

  // ---------------------------------------------------------------------------
  // RTL assertions
  // ---------------------------------------------------------------------------
  // synthesis translate_off
  initial begin
    assert (TAG_BITS > 0)
      else $fatal(1, "[dm_cache] TAG_BITS=0: address too narrow for cache config");
    assert ((CACHE_LINES & (CACHE_LINES-1)) == 0)
      else $fatal(1, "[dm_cache] CACHE_LINES must be power-of-2");
    assert ((LINE_SIZE & (LINE_SIZE-1)) == 0)
      else $fatal(1, "[dm_cache] LINE_SIZE must be power-of-2");
    assert (WORDS_PER_LINE >= 1)
      else $fatal(1, "[dm_cache] LINE_SIZE must be >= DATA_WIDTH/8");
  end

  property p_ack_single_cycle;
    @(posedge clk) disable iff (!rst_n)
    cpu_ack |=> !cpu_ack;
  endproperty
  assert property (p_ack_single_cycle) else
    $error("[dm_cache] cpu_ack held for more than one cycle");

  property p_no_ack_stall_both;
    @(posedge clk) disable iff (!rst_n)
    !(cpu_ack && cpu_stall);
  endproperty
  assert property (p_no_ack_stall_both) else
    $error("[dm_cache] cpu_ack and cpu_stall asserted simultaneously");
  // synthesis translate_on

endmodule : direct_mapped_cache
