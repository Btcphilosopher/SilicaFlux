// =============================================================================
//  mem_pkg.sv  ·  Memory & Cache Subsystem Package
//  Shared enumerations, structs, and constants used across all modules.
// =============================================================================

package mem_pkg;

  // ---------------------------------------------------------------------------
  // Cache line state encoding
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    LINE_INVALID  = 2'b00,
    LINE_VALID    = 2'b01,
    LINE_DIRTY    = 2'b11,
    LINE_RESERVED = 2'b10
  } line_state_t;

  // ---------------------------------------------------------------------------
  // Memory operation types
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    MEM_NOP   = 2'b00,
    MEM_READ  = 2'b01,
    MEM_WRITE = 2'b10,
    MEM_FLUSH = 2'b11
  } mem_op_t;

  // ---------------------------------------------------------------------------
  // Memory controller FSM state encoding
  // ---------------------------------------------------------------------------
  typedef enum logic [3:0] {
    MC_IDLE       = 4'h0,
    MC_ACTIVATE   = 4'h1,
    MC_READ_CAS   = 4'h2,
    MC_READ_DATA  = 4'h3,
    MC_WRITE_CAS  = 4'h4,
    MC_WRITE_DATA = 4'h5,
    MC_PRECHARGE  = 4'h6,
    MC_REFRESH    = 4'h7,
    MC_DONE       = 4'h8,
    MC_ERROR      = 4'hF
  } mc_state_t;

  // ---------------------------------------------------------------------------
  // Bus response codes
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    RESP_OKAY  = 2'b00,
    RESP_WAIT  = 2'b01,
    RESP_ERROR = 2'b10,
    RESP_RETRY = 2'b11
  } resp_code_t;

  // ---------------------------------------------------------------------------
  // Generic memory request structure
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic        valid;
    mem_op_t     op;
    logic [31:0] addr;
    logic [31:0] data;
    logic [3:0]  strobe;   // Byte enables
    logic [3:0]  id;       // Transaction ID for out-of-order tracking
  } mem_req_t;

  // ---------------------------------------------------------------------------
  // Generic memory response structure
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic        valid;
    resp_code_t  code;
    logic [31:0] data;
    logic [3:0]  id;
  } mem_resp_t;

  // ---------------------------------------------------------------------------
  // FIFO status flag bundle
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic full;
    logic empty;
    logic almost_full;
    logic almost_empty;
    logic overflow;
    logic underflow;
  } fifo_flags_t;

  // ---------------------------------------------------------------------------
  // Cache performance counters (instantiate inside a cache module)
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic [31:0] read_hits;
    logic [31:0] read_misses;
    logic [31:0] write_hits;
    logic [31:0] write_misses;
    logic [31:0] writebacks;
    logic [31:0] evictions;
  } cache_perf_t;

endpackage : mem_pkg
