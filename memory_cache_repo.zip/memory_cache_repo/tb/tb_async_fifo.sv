// =============================================================================
//  tb_async_fifo.sv  ·  Testbench: Asynchronous (Dual-Clock) FIFO
//
//  Tests:  1. wclk fast / rclk slow (4:1 ratio) — burst write, slow drain
//          2. wclk slow / rclk fast (1:4 ratio) — slow write, burst read
//          3. Equal clocks — basic fill and drain, ordering check
//          4. Full detection: push stops when wfull asserted
//          5. Empty detection: pop stops when rempty asserted
//          6. Randomised burst: random clk ratios, random burst lengths
//          7. Reset while non-empty: verify clean recovery
// =============================================================================

`timescale 1ns/1ps

module tb_async_fifo;

  localparam int WIDTH = 32;
  localparam int DEPTH = 16;

  // DUT signals
  logic            wclk, rclk;
  logic            wrst_n, rrst_n;
  logic            push, pop;
  logic [WIDTH-1:0] wdata, rdata;
  logic            wfull, walmost_full;
  logic            rempty, ralmost_empty;

  // Clock generation (variable period, driven by parameters)
  real wclk_period = 10.0;   // modifiable per test
  real rclk_period = 10.0;

  initial wclk = 0;
  initial rclk = 0;
  always #(wclk_period/2.0) wclk = ~wclk;
  always #(rclk_period/2.0) rclk = ~rclk;

  async_fifo #(.WIDTH(WIDTH), .DEPTH(DEPTH)) dut (
    .wclk         (wclk),
    .wrst_n       (wrst_n),
    .push         (push),
    .wdata        (wdata),
    .wfull        (wfull),
    .walmost_full (walmost_full),
    .rclk         (rclk),
    .rrst_n       (rrst_n),
    .pop          (pop),
    .rdata        (rdata),
    .rempty       (rempty),
    .ralmost_empty(ralmost_empty)
  );

  // Reference queue (software model — single-threaded bookkeeping)
  logic [WIDTH-1:0] ref_q [$];
  int pass_cnt = 0, fail_cnt = 0;

  // ── Reset both domains ────────────────────────────────────────────────────
  task automatic full_reset();
    push=0; pop=0; wdata=0;
    wrst_n=0; rrst_n=0;
    ref_q = {};
    repeat (8) @(posedge wclk);
    repeat (8) @(posedge rclk);
    wrst_n=1; rrst_n=1;
    repeat (4) @(posedge wclk);
    repeat (4) @(posedge rclk);
  endtask

  // ── Write N words from write-clock domain ─────────────────────────────────
  task automatic burst_write(input int n);
    for (int i = 0; i < n; i++) begin
      @(posedge wclk);
      if (!wfull) begin
        push  = 1;
        wdata = WIDTH'($urandom);
        ref_q.push_back(wdata);
      end else push = 0;
      @(posedge wclk);
      push = 0;
    end
  endtask

  // ── Read and verify N words from read-clock domain ────────────────────────
  task automatic burst_read_check(input int n, input string tag);
    for (int i = 0; i < n; i++) begin
      @(posedge rclk);
      if (!rempty) begin
        // rdata is FWFT — valid before pop; latch then advance
        automatic logic [WIDTH-1:0] exp;
        if (ref_q.size() > 0) begin
          exp = ref_q.pop_front();
          pop = 1;
          @(posedge rclk); pop = 0;
          // Compare on negedge
          @(negedge rclk);
          if (rdata === exp) pass_cnt++;
          else begin
            fail_cnt++;
            $error("[async_fifo][%s] idx=%0d exp=0x%0h got=0x%0h",
                   tag, i, exp, rdata);
          end
        end else begin
          pop = 0;
        end
      end
    end
  endtask

  initial begin
    $display("\n========== async_fifo Testbench ==========");
    full_reset();

    // ── T1: Fast write (2 ns) / slow read (8 ns) ──────────────────────────
    $display("[T1] wclk=500MHz, rclk=125MHz");
    wclk_period = 2.0; rclk_period = 8.0;
    full_reset();
    // Fill half the FIFO quickly
    burst_write(DEPTH/2);
    // Wait for pointers to synchronise (need ~2 rclk periods for 2-FF sync)
    repeat (6) @(posedge rclk);
    burst_read_check(DEPTH/2, "T1");

    // ── T2: Slow write (8 ns) / fast read (2 ns) ──────────────────────────
    $display("[T2] wclk=125MHz, rclk=500MHz");
    wclk_period = 8.0; rclk_period = 2.0;
    full_reset();
    burst_write(DEPTH/2);
    repeat (6) @(posedge rclk);
    burst_read_check(DEPTH/2, "T2");

    // ── T3: Equal clocks, full fill + ordered drain ────────────────────────
    $display("[T3] Equal clocks (100 MHz), fill and drain");
    wclk_period = 10.0; rclk_period = 10.0;
    full_reset();
    burst_write(DEPTH);     // fill completely
    repeat (8) @(posedge rclk);  // allow pointer sync
    // Verify full flag from write side
    @(negedge wclk);
    if (!wfull) begin
      fail_cnt++;
      $error("[T3] wfull not asserted after filling %0d entries", DEPTH);
    end else pass_cnt++;
    burst_read_check(DEPTH, "T3");
    repeat (6) @(posedge rclk);
    @(negedge rclk);
    if (!rempty) begin
      fail_cnt++;
      $error("[T3] rempty not asserted after draining");
    end else pass_cnt++;

    // ── T4: Overflow guard (push while wfull asserted, verify no corruption) 
    $display("[T4] Full protection test");
    wclk_period = 10.0; rclk_period = 10.0;
    full_reset();
    burst_write(DEPTH);     // fill
    repeat (4) @(posedge rclk);
    // Try to push more — should be silently dropped by DUT
    @(posedge wclk); push=1; wdata=32'hDEAD_BEEF; @(posedge wclk); push=0;
    // Drain and verify no corruption
    burst_read_check(DEPTH, "T4");

    // ── T5: Randomised burst stress ────────────────────────────────────────
    $display("[T5] Randomised burst stress (20 rounds)");
    wclk_period = 10.0; rclk_period = 7.0;
    full_reset();
    for (int r = 0; r < 20; r++) begin
      automatic int wr_n = $urandom_range(1, DEPTH/2);
      automatic int rd_n = $urandom_range(1, DEPTH/2);
      burst_write(wr_n);
      repeat (6) @(posedge rclk);
      burst_read_check((rd_n < ref_q.size()) ? rd_n : ref_q.size(), "T5");
    end
    // Drain remainder
    repeat (8) @(posedge rclk);
    burst_read_check(ref_q.size(), "T5_DRAIN");

    // ── T6: Reset mid-operation ────────────────────────────────────────────
    $display("[T6] Reset while non-empty, verify recovery");
    burst_write(DEPTH/2);
    // Assert reset mid-flight
    @(posedge wclk); wrst_n=0; rrst_n=0;
    repeat (6) @(posedge wclk);
    wrst_n=1; rrst_n=1; ref_q={};
    repeat (4) @(posedge rclk);
    @(negedge rclk);
    if (!rempty) begin
      fail_cnt++;
      $error("[T6] rempty not asserted after reset");
    end else pass_cnt++;
    // Write and read fresh data
    burst_write(4);
    repeat (6) @(posedge rclk);
    burst_read_check(4, "T6_POST_RST");

    $display("------------------------------------------");
    $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
    if (fail_cnt == 0) $display(">>> async_fifo: ALL TESTS PASSED <<<");
    else               $display(">>> async_fifo: %0d FAILURES <<<", fail_cnt);
    $display("==========================================\n");
    $finish;
  end

  initial begin
    #50_000_000;
    $fatal(1, "[tb_async_fifo] Simulation timeout");
  end

endmodule : tb_async_fifo
