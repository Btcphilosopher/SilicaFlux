// =============================================================================
//  tb_sp_ram.sv  ·  Testbench: Single-Port RAM
//
//  Tests:  1. Sequential write → sequential read-back
//          2. Random address / data (1000 ops)
//          3. Read-during-write (WRITE_FIRST forwarding)
//          4. Boundary addresses (0 and DEPTH-1)
//          5. Back-to-back write/read same address
// =============================================================================

`timescale 1ns/1ps

module tb_sp_ram;

  // ---------------------------------------------------------------------------
  // Parameters under test
  // ---------------------------------------------------------------------------
  localparam int WIDTH   = 32;
  localparam int DEPTH   = 256;
  localparam int LATENCY = 2;
  localparam int CLK_HALF= 5;  // 100 MHz

  // ---------------------------------------------------------------------------
  // DUT interface signals
  // ---------------------------------------------------------------------------
  logic                     clk, rst_n;
  logic                     en, we;
  logic [$clog2(DEPTH)-1:0] addr;
  logic [WIDTH-1:0]         wdata, rdata;

  // ---------------------------------------------------------------------------
  // DUT instantiation
  // ---------------------------------------------------------------------------
  sp_ram #(
    .WIDTH        (WIDTH),
    .DEPTH        (DEPTH),
    .LATENCY      (LATENCY),
    .RD_WR_POLICY ("WRITE_FIRST")
  ) dut (
    .clk   (clk),
    .rst_n (rst_n),
    .en    (en),
    .we    (we),
    .addr  (addr),
    .wdata (wdata),
    .rdata (rdata)
  );

  // ---------------------------------------------------------------------------
  // Clock
  // ---------------------------------------------------------------------------
  initial clk = 1'b0;
  always  #CLK_HALF clk = ~clk;

  // ---------------------------------------------------------------------------
  // Reference model
  // ---------------------------------------------------------------------------
  logic [WIDTH-1:0] ref_mem [0:DEPTH-1];
  int pass_cnt, fail_cnt;

  // ---------------------------------------------------------------------------
  // Tasks
  // ---------------------------------------------------------------------------
  task automatic reset_dut();
    en = 0; we = 0; addr = 0; wdata = 0;
    rst_n = 0;
    for (int i = 0; i < DEPTH; i++) ref_mem[i] = '0;
    @(posedge clk); @(posedge clk);
    rst_n = 1;
    @(posedge clk);
  endtask

  task automatic write_word(input logic [$clog2(DEPTH)-1:0] a,
                             input logic [WIDTH-1:0]          d);
    @(posedge clk);
    en = 1; we = 1; addr = a; wdata = d;
    ref_mem[a] = d;
    @(posedge clk);
    en = 0; we = 0;
  endtask

  task automatic read_check(input logic [$clog2(DEPTH)-1:0] a,
                             input string                    tag = "");
    logic [WIDTH-1:0] expected;
    expected = ref_mem[a];
    @(posedge clk);
    en = 1; we = 0; addr = a;
    // Wait LATENCY cycles for output to be valid
    repeat (LATENCY) @(posedge clk);
    en = 0;
    @(negedge clk);  // sample after rising edge
    if (rdata === expected) begin
      pass_cnt++;
    end else begin
      fail_cnt++;
      $error("[sp_ram][%s] addr=0x%0h  expected=0x%0h  got=0x%0h",
             tag, a, expected, rdata);
    end
  endtask

  // ---------------------------------------------------------------------------
  // Test sequence
  // ---------------------------------------------------------------------------
  int seed;
  initial begin
    pass_cnt = 0; fail_cnt = 0;
    seed     = 42;
    $display("\n========== sp_ram Testbench ==========");

    // ── Reset ─────────────────────────────────────────────────────────────
    reset_dut();

    // ── Test 1: Sequential write ──────────────────────────────────────────
    $display("[T1] Sequential write, depth=%0d", DEPTH);
    for (int i = 0; i < DEPTH; i++)
      write_word($clog2(DEPTH)'(i), WIDTH'($urandom));

    // ── Test 2: Sequential read-back ──────────────────────────────────────
    $display("[T2] Sequential read-back");
    for (int i = 0; i < DEPTH; i++)
      read_check($clog2(DEPTH)'(i), "SEQ");

    // ── Test 3: Random access pattern (1000 ops) ──────────────────────────
    $display("[T3] Random access (1000 ops)");
    for (int i = 0; i < 1000; i++) begin
      automatic logic [$clog2(DEPTH)-1:0] ra;
      automatic logic [WIDTH-1:0]          rd;
      ra = $clog2(DEPTH)'($urandom_range(0, DEPTH-1));
      if ($urandom_range(0,1)) begin
        rd = WIDTH'($urandom);
        write_word(ra, rd);
      end else begin
        read_check(ra, "RND");
      end
    end

    // ── Test 4: Boundary addresses ────────────────────────────────────────
    $display("[T4] Boundary addresses");
    write_word('0,             32'hDEAD_BEEF);
    write_word($clog2(DEPTH)'(DEPTH-1), 32'hCAFE_F00D);
    read_check('0,             "BND_LOW");
    read_check($clog2(DEPTH)'(DEPTH-1), "BND_HIGH");

    // ── Test 5: Back-to-back write then read same address ─────────────────
    $display("[T5] Back-to-back write/read");
    write_word(8'h10, 32'hA5A5_A5A5);
    read_check(8'h10, "B2B");

    // ── Results ───────────────────────────────────────────────────────────
    $display("----------------------------------------");
    $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
    if (fail_cnt == 0) $display(">>> sp_ram: ALL TESTS PASSED <<<");
    else               $display(">>> sp_ram: %0d FAILURES <<<", fail_cnt);
    $display("========================================\n");
    $finish;
  end

  // Timeout watchdog
  initial begin
    #5_000_000;
    $fatal(1, "[tb_sp_ram] Simulation timeout — possible hang");
  end

endmodule : tb_sp_ram
