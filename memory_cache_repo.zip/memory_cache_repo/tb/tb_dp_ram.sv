// =============================================================================
//  tb_dp_ram.sv  ·  Testbench: True Dual-Port RAM
//
//  Tests:  1. Single-port operation on A only, then B only
//          2. Concurrent writes to different addresses
//          3. Port A write / Port B read (CDC read hazard annotated)
//          4. Different clock frequencies (clk_a 100 MHz, clk_b 75 MHz)
//          5. Randomised concurrent read/write stress (500 pairs)
// =============================================================================

`timescale 1ns/1ps

module tb_dp_ram;

  localparam int WIDTH   = 32;
  localparam int DEPTH   = 256;
  localparam int LATENCY = 1;

  // ── Clocks (different frequencies) ───────────────────────────────────────
  logic clk_a, clk_b, rst_a_n, rst_b_n;
  initial clk_a = 1'b0;
  initial clk_b = 1'b0;
  always #5  clk_a = ~clk_a;   // 100 MHz
  always #6  clk_b = ~clk_b;   //  83 MHz (different period)

  // ── DUT interface ─────────────────────────────────────────────────────────
  logic                     en_a, we_a, en_b, we_b;
  logic [$clog2(DEPTH)-1:0] addr_a, addr_b;
  logic [WIDTH-1:0]         wdata_a, wdata_b;
  logic [WIDTH-1:0]         rdata_a, rdata_b;

  dp_ram #(.WIDTH(WIDTH), .DEPTH(DEPTH), .LATENCY(LATENCY)) dut (
    .clk_a   (clk_a),   .rst_a_n (rst_a_n),
    .en_a    (en_a),    .we_a    (we_a),
    .addr_a  (addr_a),  .wdata_a (wdata_a), .rdata_a (rdata_a),
    .clk_b   (clk_b),   .rst_b_n (rst_b_n),
    .en_b    (en_b),    .we_b    (we_b),
    .addr_b  (addr_b),  .wdata_b (wdata_b), .rdata_b (rdata_b)
  );

  logic [WIDTH-1:0] ref_mem [0:DEPTH-1];
  int pass_cnt = 0, fail_cnt = 0;

  // ── Write through Port A ───────────────────────────────────────────────────
  task automatic write_a(input logic [$clog2(DEPTH)-1:0] a,
                          input logic [WIDTH-1:0]          d);
    @(posedge clk_a);
    en_a = 1; we_a = 1; addr_a = a; wdata_a = d;
    ref_mem[a] = d;
    @(posedge clk_a);
    en_a = 0; we_a = 0;
  endtask

  // ── Write through Port B ───────────────────────────────────────────────────
  task automatic write_b(input logic [$clog2(DEPTH)-1:0] a,
                          input logic [WIDTH-1:0]          d);
    @(posedge clk_b);
    en_b = 1; we_b = 1; addr_b = a; wdata_b = d;
    ref_mem[a] = d;
    @(posedge clk_b);
    en_b = 0; we_b = 0;
  endtask

  // ── Read through Port A and check ─────────────────────────────────────────
  task automatic read_check_a(input logic [$clog2(DEPTH)-1:0] a,
                               input string tag = "");
    logic [WIDTH-1:0] exp;
    exp = ref_mem[a];
    @(posedge clk_a);
    en_a = 1; we_a = 0; addr_a = a;
    repeat (LATENCY) @(posedge clk_a);
    en_a = 0; @(negedge clk_a);
    if (rdata_a === exp) pass_cnt++;
    else begin
      fail_cnt++;
      $error("[dp_ram][A][%s] addr=%0h exp=%0h got=%0h", tag, a, exp, rdata_a);
    end
  endtask

  // ── Read through Port B and check ─────────────────────────────────────────
  task automatic read_check_b(input logic [$clog2(DEPTH)-1:0] a,
                               input string tag = "");
    logic [WIDTH-1:0] exp;
    exp = ref_mem[a];
    @(posedge clk_b);
    en_b = 1; we_b = 0; addr_b = a;
    repeat (LATENCY) @(posedge clk_b);
    en_b = 0; @(negedge clk_b);
    if (rdata_b === exp) pass_cnt++;
    else begin
      fail_cnt++;
      $error("[dp_ram][B][%s] addr=%0h exp=%0h got=%0h", tag, a, exp, rdata_b);
    end
  endtask

  initial begin
    $display("\n========== dp_ram Testbench ==========");
    en_a=0; we_a=0; addr_a=0; wdata_a=0;
    en_b=0; we_b=0; addr_b=0; wdata_b=0;
    for (int i=0; i<DEPTH; i++) ref_mem[i] = '0;
    rst_a_n=0; rst_b_n=0;
    #30; rst_a_n=1; rst_b_n=1; #10;

    // ── T1: Port A only ───────────────────────────────────────────────────
    $display("[T1] Sequential write on Port A");
    for (int i=0; i<DEPTH; i++) write_a($clog2(DEPTH)'(i), WIDTH'($urandom));
    $display("[T1] Read-back through Port A");
    for (int i=0; i<DEPTH; i++) read_check_a($clog2(DEPTH)'(i), "A_SEQ");

    // ── T2: Port B only ───────────────────────────────────────────────────
    $display("[T2] Overwrite even addresses from Port B");
    for (int i=0; i<DEPTH; i+=2) write_b($clog2(DEPTH)'(i), WIDTH'($urandom));
    for (int i=0; i<DEPTH; i+=2) read_check_b($clog2(DEPTH)'(i), "B_EVEN");

    // ── T3: Concurrent write A + write B to different addresses ───────────
    $display("[T3] Concurrent writes to distinct addresses");
    fork
      for (int i=0; i<32; i++) write_a($clog2(DEPTH)'(i*2),   WIDTH'($urandom));
      for (int i=0; i<32; i++) write_b($clog2(DEPTH)'(i*2+1), WIDTH'($urandom));
    join
    // Verify from both ports
    for (int i=0; i<32; i++) begin
      read_check_a($clog2(DEPTH)'(i*2),   "CONC_A");
      read_check_b($clog2(DEPTH)'(i*2+1), "CONC_B");
    end

    // ── T4: Randomised concurrent stress ──────────────────────────────────
    $display("[T4] Randomised concurrent stress (500 pairs)");
    fork
      begin : thread_a
        for (int i=0; i<500; i++) begin
          automatic logic [$clog2(DEPTH)-1:0] ra;
          ra = $clog2(DEPTH)'($urandom_range(0, DEPTH/2-1));
          if ($urandom_range(0,1)) write_a(ra, WIDTH'($urandom));
          else                     read_check_a(ra, "STR_A");
        end
      end
      begin : thread_b
        for (int i=0; i<500; i++) begin
          automatic logic [$clog2(DEPTH)-1:0] rb;
          rb = $clog2(DEPTH)'($urandom_range(DEPTH/2, DEPTH-1));
          if ($urandom_range(0,1)) write_b(rb, WIDTH'($urandom));
          else                     read_check_b(rb, "STR_B");
        end
      end
    join

    $display("----------------------------------------");
    $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
    if (fail_cnt == 0) $display(">>> dp_ram: ALL TESTS PASSED <<<");
    else               $display(">>> dp_ram: %0d FAILURES <<<", fail_cnt);
    $display("========================================\n");
    $finish;
  end

  initial begin
    #10_000_000;
    $fatal(1, "[tb_dp_ram] Simulation timeout");
  end

endmodule : tb_dp_ram
