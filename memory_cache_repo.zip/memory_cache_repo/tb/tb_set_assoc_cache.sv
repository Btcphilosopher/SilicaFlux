// =============================================================================
//  tb_set_assoc_cache.sv  ·  Testbench: N-Way Set-Associative Cache
//
//  Instantiates the 4-way variant by default.
//
//  Tests:
//    1. Cold fill: all ways in one set, verify 4 compulsory misses then hits
//    2. LRU verification: access pattern forces a known eviction, verify
//       that the correct LRU way is replaced
//    3. Way pollution: fill all ways of a set with conflicting data
//    4. Write-back: dirty lines evicted correctly on way replacement
//    5. Multi-set random stress (800 ops) with golden model cross-check
//    6. Performance counter integrity
// =============================================================================

`timescale 1ns/1ps

module tb_set_assoc_cache;

  // ── Parameters ────────────────────────────────────────────────────────────
  localparam int ADDR_WIDTH = 16;
  localparam int DATA_WIDTH = 32;
  localparam int NUM_SETS   = 8;     // deliberately small for exhaustive LRU test
  localparam int NUM_WAYS   = 4;
  localparam int LINE_SIZE  = 8;     // 2 words per line
  localparam int MEM_LATENCY= 4;
  localparam int CLK_HALF   = 5;

  // Address geometry derived
  localparam int BYTES_W   = DATA_WIDTH/8;
  localparam int WORDS_L   = LINE_SIZE/BYTES_W;
  localparam int OFF_BITS  = $clog2(LINE_SIZE);
  localparam int IDX_BITS  = $clog2(NUM_SETS);
  localparam int TAG_BITS  = ADDR_WIDTH - OFF_BITS - IDX_BITS;
  // Stride to reach next tag for same index (= NUM_SETS * LINE_SIZE)
  localparam int TAG_STRIDE = NUM_SETS * LINE_SIZE;

  // ── DUT interface ─────────────────────────────────────────────────────────
  logic                  clk, rst_n;
  logic                  cpu_req, cpu_we;
  logic [ADDR_WIDTH-1:0] cpu_addr;
  logic [DATA_WIDTH-1:0] cpu_wdata, cpu_rdata;
  logic                  cpu_ack, cpu_stall;
  logic                  mem_req, mem_we;
  logic [ADDR_WIDTH-1:0] mem_addr;
  logic [DATA_WIDTH-1:0] mem_wdata, mem_rdata;
  logic                  mem_ack;
  logic [31:0]           perf_hits, perf_misses, perf_writebacks;

  set_assoc_cache #(
    .ADDR_WIDTH (ADDR_WIDTH),
    .DATA_WIDTH (DATA_WIDTH),
    .NUM_SETS   (NUM_SETS),
    .NUM_WAYS   (NUM_WAYS),
    .LINE_SIZE  (LINE_SIZE)
  ) dut (.*);

  initial clk = 0;
  always  #CLK_HALF clk = ~clk;

  // ── Behavioural memory stub (same style as dm_cache TB) ───────────────────
  localparam int MEM_DEPTH = 1 << ADDR_WIDTH;
  logic [DATA_WIDTH-1:0] main_mem [0:MEM_DEPTH/4-1];
  logic [3:0] mem_lat_cnt;

  initial begin
    for (int i = 0; i < MEM_DEPTH/4; i++)
      main_mem[i] = DATA_WIDTH'(32'hA000_0000 | (i * 4));
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mem_ack <= 0; mem_rdata <= 0; mem_lat_cnt <= 0;
    end else begin
      mem_ack <= 0;
      if (mem_req && !mem_ack) begin
        if (mem_lat_cnt == MEM_LATENCY - 1) begin
          mem_lat_cnt <= 0;
          mem_ack     <= 1;
          if (mem_we)
            main_mem[mem_addr[ADDR_WIDTH-1:2]] <= mem_wdata;
          else
            mem_rdata <= main_mem[mem_addr[ADDR_WIDTH-1:2]];
        end else mem_lat_cnt <= mem_lat_cnt + 1;
      end else if (!mem_req) mem_lat_cnt <= 0;
    end
  end

  // Golden model
  logic [DATA_WIDTH-1:0] golden [0:MEM_DEPTH/4-1];
  int pass_cnt = 0, fail_cnt = 0;

  initial begin
    for (int i = 0; i < MEM_DEPTH/4; i++)
      golden[i] = DATA_WIDTH'(32'hA000_0000 | (i * 4));
  end

  // ── CPU transaction tasks ──────────────────────────────────────────────────
  task automatic cpu_read (input  logic [ADDR_WIDTH-1:0] a,
                            output logic [DATA_WIDTH-1:0] d);
    @(posedge clk); cpu_req=1; cpu_we=0; cpu_addr=a;
    @(posedge clk);
    while (!cpu_ack) @(posedge clk);
    d = cpu_rdata; cpu_req=0;
    @(posedge clk);
  endtask

  task automatic cpu_write(input logic [ADDR_WIDTH-1:0] a,
                            input logic [DATA_WIDTH-1:0] d);
    @(posedge clk); cpu_req=1; cpu_we=1; cpu_addr=a; cpu_wdata=d;
    @(posedge clk);
    while (!cpu_ack) @(posedge clk);
    cpu_req=0; cpu_we=0;
    golden[a[ADDR_WIDTH-1:2]] = d;
    @(posedge clk);
  endtask

  task automatic check_read(input logic [ADDR_WIDTH-1:0] a, input string tag);
    logic [DATA_WIDTH-1:0] got, exp;
    exp = golden[a[ADDR_WIDTH-1:2]];
    cpu_read(a, got);
    if (got === exp) pass_cnt++;
    else begin
      fail_cnt++;
      $error("[sa_cache][%s] addr=0x%0h exp=0x%0h got=0x%0h", tag, a, exp, got);
    end
  endtask

  task automatic reset_dut();
    cpu_req=0; cpu_we=0; cpu_addr=0; cpu_wdata=0;
    rst_n=0; @(posedge clk); @(posedge clk); rst_n=1; @(posedge clk);
  endtask

  initial begin
    $display("\n========== set_assoc_cache Testbench (4-way, %0d sets) ==========",
             NUM_SETS);
    reset_dut();

    // ── T1: Cold fill — touch all NUM_WAYS ways in set 0 ──────────────────
    $display("[T1] Cold fill: 4 distinct tags → 4 misses then 4 hits");
    begin
      automatic int pre_miss = perf_misses;
      // 4 addresses mapping to set 0, different tags
      for (int w = 0; w < NUM_WAYS; w++)
        check_read(ADDR_WIDTH'(w * TAG_STRIDE), "COLD");
      @(negedge clk);
      if (perf_misses - pre_miss != NUM_WAYS) begin
        fail_cnt++;
        $error("[T1] Expected %0d misses, got %0d", NUM_WAYS, perf_misses-pre_miss);
      end else pass_cnt++;

      automatic int pre_hits = perf_hits;
      for (int w = 0; w < NUM_WAYS; w++)
        check_read(ADDR_WIDTH'(w * TAG_STRIDE), "WARM");
      @(negedge clk);
      if (perf_hits - pre_hits != NUM_WAYS) begin
        fail_cnt++;
        $error("[T1] Expected %0d hits, got %0d", NUM_WAYS, perf_hits-pre_hits);
      end else pass_cnt++;
    end

    // ── T2: LRU eviction order verification ───────────────────────────────
    $display("[T2] PLRU eviction: access W0,W1,W2,W3; next miss evicts W0 (PLRU)");
    begin
      // Fill all 4 ways in set 1 (addresses = set1_base + w * TAG_STRIDE)
      localparam logic [ADDR_WIDTH-1:0] S1B = ADDR_WIDTH'(LINE_SIZE);  // set 1 base
      // Access in order W0→W1→W2→W3
      for (int w = 0; w < NUM_WAYS; w++)
        check_read(ADDR_WIDTH'(S1B + w * TAG_STRIDE), "LRU_FILL");

      // Now access W1, W2, W3 (skipping W0) → PLRU should select W0 as victim
      check_read(ADDR_WIDTH'(S1B + 1 * TAG_STRIDE), "LRU_ACCESS");
      check_read(ADDR_WIDTH'(S1B + 2 * TAG_STRIDE), "LRU_ACCESS");
      check_read(ADDR_WIDTH'(S1B + 3 * TAG_STRIDE), "LRU_ACCESS");

      // Bring in W4 (a 5th tag) — should evict W0
      automatic int pre_wb = perf_writebacks;
      check_read(ADDR_WIDTH'(S1B + 4 * TAG_STRIDE), "LRU_EVICT");
      // Re-accessing W0 should now cause a miss
      automatic int pre_miss2 = perf_misses;
      check_read(ADDR_WIDTH'(S1B + 0 * TAG_STRIDE), "LRU_W0_REFETCH");
      @(negedge clk);
      if (perf_misses - pre_miss2 == 1) begin
        pass_cnt++;
        $display("     LRU eviction of W0 confirmed ✓");
      end else begin
        fail_cnt++;
        $error("[T2] W0 not evicted by PLRU; expected miss but got hit");
      end
    end

    // ── T3: Write-back (dirty eviction) ────────────────────────────────────
    $display("[T3] Write-back: dirty line eviction");
    begin
      localparam logic [ADDR_WIDTH-1:0] WB_BASE = ADDR_WIDTH'(2 * LINE_SIZE);
      // Fill set 2, make one way dirty
      for (int w = 0; w < NUM_WAYS; w++)
        check_read(ADDR_WIDTH'(WB_BASE + w * TAG_STRIDE), "WB_FILL");
      // Write to W0 → mark dirty
      cpu_write(ADDR_WIDTH'(WB_BASE), 32'hDEAD_CAFE);

      automatic int pre_wb = perf_writebacks;
      // Bring in W4 → eviction of dirty W0 should trigger writeback
      check_read(ADDR_WIDTH'(WB_BASE + 4 * TAG_STRIDE), "WB_TRIGGER");
      @(negedge clk);
      if (perf_writebacks > pre_wb) begin
        pass_cnt++;
        $display("     Dirty writeback confirmed ✓ (total=%0d)", perf_writebacks);
      end else begin
        fail_cnt++;
        $error("[T3] Expected writeback, perf_writebacks unchanged");
      end
      // Verify written-back data visible in main_mem
      check_read(ADDR_WIDTH'(WB_BASE), "WB_VERIFY");
    end

    // ── T4: Randomised multi-set stress ────────────────────────────────────
    $display("[T4] Randomised multi-set stress (800 ops)");
    for (int i = 0; i < 800; i++) begin
      automatic logic [ADDR_WIDTH-1:0] ra;
      automatic logic [DATA_WIDTH-1:0] rd;
      // Use a range that spans multiple sets and forces way conflicts
      ra = ADDR_WIDTH'(($urandom_range(0, NUM_SETS * NUM_WAYS * 2 - 1)) * LINE_SIZE);
      ra = ra & ~ADDR_WIDTH'(BYTES_W-1);  // word-align
      if ($urandom_range(0,1))
        cpu_write(ra, DATA_WIDTH'($urandom));
      else
        check_read(ra, "STRESS");
    end

    $display("──────────────────────────────────────────────────────");
    $display("Final: hits=%0d misses=%0d writebacks=%0d",
             perf_hits, perf_misses, perf_writebacks);
    $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
    if (fail_cnt == 0) $display(">>> set_assoc_cache: ALL TESTS PASSED <<<");
    else               $display(">>> set_assoc_cache: %0d FAILURES <<<", fail_cnt);
    $display("======================================================\n");
    $finish;
  end

  initial begin
    #100_000_000;
    $fatal(1, "[tb_sa_cache] Simulation timeout");
  end

endmodule : tb_set_assoc_cache
