// =============================================================================
//  tb_sync_fifo.sv  ·  Testbench: Synchronous FIFO
//
//  Tests:  1. Fill to full, verify full/almost-full flags
//          2. Drain to empty, verify data ordering (FWFT and standard)
//          3. Overflow: push while full — verify sticky flag
//          4. Underflow: pop while empty — verify sticky flag
//          5. Random push/pop interleaving (1000 ops)
//          6. Back-pressure stress: push faster than pop
//          7. Simultaneous push+pop at same cycle
// =============================================================================

`timescale 1ns/1ps

module tb_sync_fifo;

  localparam int WIDTH         = 32;
  localparam int DEPTH         = 16;
  localparam int AFULL_THRESH  = 2;
  localparam int AEMPTY_THRESH = 2;
  localparam int CLK_HALF      = 5;

  logic            clk, rst_n;
  logic            push, pop;
  logic [WIDTH-1:0] wdata, rdata;
  logic            full, empty, almost_full, almost_empty;
  logic            overflow, underflow;
  logic [$clog2(DEPTH):0] count;

  // ── Standard mode DUT ─────────────────────────────────────────────────────
  sync_fifo #(
    .WIDTH         (WIDTH),
    .DEPTH         (DEPTH),
    .AFULL_THRESH  (AFULL_THRESH),
    .AEMPTY_THRESH (AEMPTY_THRESH),
    .FWFT          (1'b0)
  ) dut (
    .clk          (clk),
    .rst_n        (rst_n),
    .push         (push),
    .wdata        (wdata),
    .pop          (pop),
    .rdata        (rdata),
    .full         (full),
    .empty        (empty),
    .almost_full  (almost_full),
    .almost_empty (almost_empty),
    .overflow     (overflow),
    .underflow    (underflow),
    .count        (count)
  );

  initial clk = 1'b0;
  always  #CLK_HALF clk = ~clk;

  // Reference model (simple queue)
  logic [WIDTH-1:0] ref_q  [$];
  int pass_cnt = 0, fail_cnt = 0;

  task automatic reset_dut();
    push = 0; pop = 0; wdata = 0;
    rst_n = 0; ref_q = {};
    @(posedge clk); @(posedge clk);
    rst_n = 1;
    @(posedge clk);
  endtask

  // Push one word (if not full) and update model
  task automatic do_push(input logic [WIDTH-1:0] d);
    @(posedge clk);
    if (!full) begin
      push = 1; wdata = d;
      ref_q.push_back(d);
    end
    @(posedge clk);
    push = 0;
  endtask

  // Pop one word (standard mode) and check against model
  task automatic do_pop_check(input string tag = "");
    logic [WIDTH-1:0] exp;
    @(posedge clk);
    if (!empty) begin
      pop = 1;
      exp = ref_q.pop_front();
    end
    @(posedge clk);
    pop = 0;
    @(negedge clk);
    if (ref_q.size() >= 0 && exp !== 'x) begin   // data valid after pop cycle
      if (rdata === exp) pass_cnt++;
      else begin
        fail_cnt++;
        $error("[sync_fifo][%s] expected=0x%0h got=0x%0h", tag, exp, rdata);
      end
    end
  endtask

  // Check count matches model queue depth
  task automatic check_count(input string tag);
    @(negedge clk);
    if (count !== ref_q.size()) begin
      fail_cnt++;
      $error("[sync_fifo][%s] count mismatch: hw=%0d sw=%0d", tag, count, ref_q.size());
    end else pass_cnt++;
  endtask

  initial begin
    $display("\n========== sync_fifo Testbench ==========");
    reset_dut();

    // ── T1: Fill to full ──────────────────────────────────────────────────
    $display("[T1] Fill to full");
    for (int i = 0; i < DEPTH; i++) do_push(WIDTH'(i + 32'h100));
    @(negedge clk);
    if (!full) begin
      fail_cnt++;
      $error("[T1] full flag not asserted after filling %0d words", DEPTH);
    end else pass_cnt++;
    if (!almost_full) begin
      fail_cnt++;
      $error("[T1] almost_full not asserted");
    end else pass_cnt++;
    check_count("T1");

    // ── T2: Drain to empty ────────────────────────────────────────────────
    $display("[T2] Drain to empty and verify ordering");
    while (!empty) do_pop_check("T2");
    @(negedge clk);
    if (!empty) begin
      fail_cnt++;
      $error("[T2] empty flag not asserted after draining");
    end else pass_cnt++;
    check_count("T2");

    // ── T3: Overflow ──────────────────────────────────────────────────────
    $display("[T3] Overflow test");
    for (int i = 0; i < DEPTH; i++) do_push(WIDTH'(i));
    // Now push again while full
    @(posedge clk); push = 1; wdata = 32'hDEAD_BEEF; @(posedge clk);
    push = 0;
    @(negedge clk);
    if (!overflow) begin
      fail_cnt++;
      $error("[T3] overflow flag not set");
    end else pass_cnt++;
    // Drain and reset overflow
    while (!empty) do_pop_check("T3_DRAIN");

    // ── T4: Underflow ─────────────────────────────────────────────────────
    $display("[T4] Underflow test");
    @(posedge clk); pop = 1; @(posedge clk); pop = 0;
    @(negedge clk);
    if (!underflow) begin
      fail_cnt++;
      $error("[T4] underflow flag not set");
    end else pass_cnt++;

    // Re-reset
    reset_dut();

    // ── T5: Random push/pop interleaving ──────────────────────────────────
    $display("[T5] Random push/pop (1000 ops)");
    for (int i = 0; i < 1000; i++) begin
      automatic logic [WIDTH-1:0] rd;
      rd = WIDTH'($urandom);
      if ($urandom_range(0,1) && !full)       do_push(rd);
      else if (!$urandom_range(0,1) && !empty) do_pop_check("RND");
      if ((i % 100) == 0) check_count($sformatf("RND_%0d", i));
    end

    // ── T6: Simultaneous push + pop ───────────────────────────────────────
    $display("[T6] Simultaneous push and pop");
    // Pre-fill half
    for (int i = 0; i < DEPTH/2; i++) do_push(WIDTH'(32'hABCD_0000 + i));
    // Do 20 simultaneous push+pop
    for (int i = 0; i < 20; i++) begin
      automatic logic [WIDTH-1:0] exp;
      automatic logic [WIDTH-1:0] new_d;
      new_d = WIDTH'($urandom);
      exp   = ref_q.pop_front();
      ref_q.push_back(new_d);
      @(posedge clk);
      push = 1; pop = 1; wdata = new_d;
      @(posedge clk);
      push = 0; pop = 0;
      @(negedge clk);
      if (rdata === exp) pass_cnt++;
      else begin
        fail_cnt++;
        $error("[T6] simultaneous push/pop exp=%0h got=%0h", exp, rdata);
      end
    end

    $display("------------------------------------------");
    $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
    if (fail_cnt == 0) $display(">>> sync_fifo: ALL TESTS PASSED <<<");
    else               $display(">>> sync_fifo: %0d FAILURES <<<", fail_cnt);
    $display("==========================================\n");
    $finish;
  end

  initial begin
    #5_000_000;
    $fatal(1, "[tb_sync_fifo] Simulation timeout");
  end

endmodule : tb_sync_fifo
