# Memory Architecture & Cache Systems — SystemVerilog Repository

Synthesis-ready RTL library covering the full memory hierarchy from single-port SRAM macros to a DRAM-style controller FSM, with randomised self-checking testbenches for every module.

---

## Repository Layout

```
memory_cache_repo/
├── rtl/
│   ├── mem_pkg.sv               Shared package: enums, structs, typedefs
│   ├── sp_ram.sv                Single-port synchronous RAM
│   ├── dp_ram.sv                True dual-port RAM (independent clocks)
│   ├── sync_fifo.sv             Synchronous FIFO (single clock domain)
│   ├── async_fifo.sv            Asynchronous FIFO (dual clock, Gray-code)
│   ├── direct_mapped_cache.sv   Direct-mapped write-back cache
│   ├── set_assoc_cache.sv       N-way set-associative cache with LRU/PLRU
│   └── memory_controller.sv     DRAM-style FSM controller
├── tb/
│   ├── tb_sp_ram.sv
│   ├── tb_dp_ram.sv
│   ├── tb_sync_fifo.sv
│   ├── tb_async_fifo.sv
│   ├── tb_direct_mapped_cache.sv
│   ├── tb_set_assoc_cache.sv
│   └── tb_memory_controller.sv
├── sim/
│   └── Makefile                 Verilator / VCS / ModelSim targets
└── README.md
```

---

## Module Reference

### `sp_ram` — Single-Port Synchronous RAM

| Parameter | Default | Description |
|-----------|---------|-------------|
| `WIDTH` | 32 | Data width in bits |
| `DEPTH` | 1024 | Word count |
| `LATENCY` | 1 | Read latency (pipeline stages, ≥ 1) |
| `RD_WR_POLICY` | `"WRITE_FIRST"` | `WRITE_FIRST` / `READ_FIRST` / `NO_CHANGE` |
| `INIT_FILE` | `""` | Path to `$readmemh` init file |

**Synthesis**: Infers BRAM on Xilinx (RAMB36) and Intel (M20K) via `(* ram_style = "block" *)` attribute.  
**Latency model**: `LATENCY=1` → 1 registered stage; `LATENCY=N` → N pipeline flip-flop stages.

---

### `dp_ram` — True Dual-Port RAM

| Parameter | Default | Description |
|-----------|---------|-------------|
| `WIDTH` | 32 | Data width |
| `DEPTH` | 1024 | Word count |
| `LATENCY` | 1 | Per-port read latency |

Both ports operate on independent clocks. Write-write collision to the same address in the same cycle is Port-A-wins; external arbitration is recommended for deterministic behaviour.

---

### `sync_fifo` — Synchronous FIFO

| Parameter | Default | Description |
|-----------|---------|-------------|
| `WIDTH` | 32 | Data width |
| `DEPTH` | 16 | Depth (power-of-2) |
| `AFULL_THRESH` | 2 | Almost-full threshold (entries from full) |
| `AEMPTY_THRESH` | 2 | Almost-empty threshold (entries from empty) |
| `FWFT` | `0` | `1` = First-Word Fall-Through |

Uses a `(n+1)`-bit pointer scheme: the extra MSB makes full/empty discrimination unambiguous without a separate flag register.

**Flag table:**

| Flag | Assertion condition |
|------|---------------------|
| `full` | `count == DEPTH` |
| `empty` | `count == 0` |
| `almost_full` | `count ≥ DEPTH − AFULL_THRESH` |
| `almost_empty` | `count ≤ AEMPTY_THRESH` |
| `overflow` | Push attempted while `full` (sticky) |
| `underflow` | Pop attempted while `empty` (sticky) |

---

### `async_fifo` — Asynchronous Dual-Clock FIFO

| Parameter | Default | Description |
|-----------|---------|-------------|
| `WIDTH` | 32 | Data width |
| `DEPTH` | 16 | Depth (power-of-2, ≥ 4) |

Implements the Clifford Cummings Gray-code pointer synchronisation method. Full and empty flags are inherently conservative:

- **Full** evaluated on the write side using a stale (2-cycle old) read pointer — guarantees no overfill.
- **Empty** evaluated on the read side using a stale write pointer — guarantees no underflow.

**CDC safe pointer crossing:**

```
wclk domain                      rclk domain
──────────                        ──────────
wptr_bin ──→ bin2gray ──→ wptr_gray
                                  wptr_gray ──→ FF ──→ FF ──→ wptr_gray_s1_r
                                  empty = (rptr_gray == wptr_gray_s1_r)

rptr_bin ──→ bin2gray ──→ rptr_gray
rptr_gray ──→ FF ──→ FF ──→ rptr_gray_s1_w
wfull = (wptr_gray == {~rptr_s1_w[MSB:MSB-1], rptr_s1_w[MSB-2:0]})
```

---

### `direct_mapped_cache`

| Parameter | Default | Description |
|-----------|---------|-------------|
| `ADDR_WIDTH` | 32 | CPU/memory address width |
| `DATA_WIDTH` | 32 | Data bus width |
| `CACHE_LINES` | 256 | Number of cache lines |
| `LINE_SIZE` | 64 | Bytes per cache line |
| `MEM_LATENCY` | 10 | Informational; latency is via `mem_ack` |

**Address decomposition:**

```
 31          TAG_MSB  INDEX_MSB  OFFSET_MSB  0
 [  TAG  ] [ INDEX ] [  BYTE OFFSET within LINE  ]
```

**FSM:**

```
IDLE → HIT → IDLE
IDLE → WRITEBACK → FILL → RESPOND → IDLE   (dirty miss)
IDLE → FILL → RESPOND → IDLE               (clean miss)
```

**Latency model:**
- Hit: 1 clock cycle (`cpu_ack` on next rising edge after `cpu_req`)
- Miss: `cpu_stall` held high; total cycles = `N_WORDS_PER_LINE × (mem_latency + 1)` + optional writeback

---

### `set_assoc_cache`

| Parameter | Default | Description |
|-----------|---------|-------------|
| `ADDR_WIDTH` | 32 | Address width |
| `DATA_WIDTH` | 32 | Data width |
| `NUM_SETS` | 128 | Number of sets (power-of-2) |
| `NUM_WAYS` | 4 | Associativity: 1, 2, or 4 |
| `LINE_SIZE` | 64 | Bytes per line |

**LRU implementation:**

| `NUM_WAYS` | Algorithm | Bits per set |
|-----------|-----------|-------------|
| 1 | Direct-mapped (trivial) | — |
| 2 | True LRU | 1 |
| 4 | Pseudo-LRU binary tree | 3 |

**PLRU 4-way tree (3 bits `[b2,b1,b0]`):**

```
        b2
       /    \
     b1      b0
    /  \    /  \
   W0  W1  W2  W3

Victim:  b2=0 → {b1=0→W0, b1=1→W1}   b2=1 → {b0=0→W2, b0=1→W3}
Update:  access W0 → b2=1,b1=1    W1 → b2=1,b1=0
         access W2 → b2=0,b0=1    W3 → b2=0,b0=0
```

---

### `memory_controller`

| Parameter | Default | Description |
|-----------|---------|-------------|
| `ADDR_WIDTH` | 32 | Address width |
| `DATA_WIDTH` | 32 | Data width |
| `BURST_LEN` | 8 | Words per burst |
| `tRCD` | 3 | Row activation → CAS (cycles) |
| `tCL` | 3 | CAS latency (cycles) |
| `tWR` | 2 | Write recovery (cycles) |
| `tRP` | 3 | Precharge time (cycles) |
| `tRFC` | 12 | Refresh cycle time (cycles) |
| `REFRESH_PERIOD` | 3200 | Cycles between refreshes |
| `PRIORITY_READS` | 1 | Give reads priority over pending writes |

**SDRAM command encoding `{RAS_n, CAS_n, WE_n}`:**

| Command | Encoding |
|---------|----------|
| NOP | `111` |
| ACTIVE | `011` |
| READ | `101` |
| WRITE | `100` |
| PRECHARGE | `010` |
| AUTO-REFRESH | `001` |

**Full state flow (read):**

```
IDLE →(tRCD)→ ACTIVATE →(tCL)→ READ_CAS → READ_DATA →(tRP)→ PRECHARGE → DONE → IDLE
```

**Refresh pre-emption:** when `refresh_pending` is asserted, any new request is blocked and `resp_code = WAIT`. Refresh is completed in `tRFC` cycles, then normal operation resumes.

---

## Simulation Quick-Start

### Verilator (recommended, open-source)

```bash
cd sim
make sim_all           # full regression
make sim_sp_ram        # individual module
make sim_sa_cache TOOL=verilator
```

### VCS (Synopsys)

```bash
make sim_all TOOL=vcs
```

### ModelSim / Questa (Intel/Siemens)

```bash
make sim_all TOOL=modelsim
```

### Lint only

```bash
make lint   # Verilator lint pass, no simulation
```

---

## Design Conventions

- All synchronous resets are active-low (`rst_n`). Async FIFOs have separate resets per clock domain.
- All flops use `always_ff`; all combinatorial blocks use `always_comb`. No mixed-sensitivity blocks.
- Parameters are validated at elaboration time with `initial assert` blocks inside `// synthesis translate_off` guards.
- SVA properties check protocol invariants: single-cycle ACK, no simultaneous ACK+stall, one-hot hit detection.
- Performance counters (`perf_hits`, `perf_misses`, `perf_writebacks`) are 32-bit saturating counts available on all cache ports.
- The `mem_pkg` package must be compiled first. All modules import it via `import mem_pkg::*` or by reference.

---

## Synthesis Guidelines

| Target | Recommended settings |
|--------|----------------------|
| **Xilinx Vivado** | Use `ram_style = "block"` attribute (already set). Set `LATENCY ≥ 1` to infer RAMB36. |
| **Intel Quartus** | Use `ramstyle = "M20K"`. Dual-clock DP RAM requires `LATENCY ≥ 1`. |
| **ASIC (DC/Genus)** | Replace behavioral RAM with foundry macro. Cache arrays (`tag_arr`, `data_arr`) should be mapped to SRAM compilers. |

For area-critical applications, reduce `LINE_SIZE` and `NUM_WAYS` to shrink the deeply nested `data_arr` array. For timing-critical paths, add a register stage between the hit-detection combinatorial logic and the output mux.
