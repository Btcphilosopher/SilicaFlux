//=============================================================================
// File        : seq_det_1011_mealy.sv
// Project     : FSM Library — Reusable Finite State Machines
// Description : Sequence Detector for pattern "1011" — Mealy FSM.
//
//   Mealy machine: detected output is asserted on the transition arc from
//   S3 when data_in='1'.  This gives ONE FEWER STATE than the Moore version
//   (4 vs 5) and asserts the output in the SAME clock cycle as the final
//   matching bit (not one cycle later as Moore does).
//
//   State diagram (4 states):
//
//           0/0         0/0        1/0      1/1
//   S0 ────────> S0    S1 ──────> S2 ────> S3 ──> S0 or S1
//    └───1/0───> S1    S1 ──1/0─> S1 ─1/0> S3    (output on this arc)
//                      S2 ──0/0─> S0
//                      S3 ──0/0─> S2
//
//   State  Prefix matched
//   ──────────────────────
//   S0     ""     (nothing useful)
//   S1     "1"
//   S2     "10"
//   S3     "101"
//
//   Output is generated combinationally on S3 + data_in='1' arc:
//     detected = (cs == S3) && data_in
//
//   After detection (overlapping): → S1 (the final '1' starts a new match)
//   After detection (non-overlapping): → S0
//
//   Key comparison vs Moore:
//   ┌────────────────┬───────────┬───────────┐
//   │ Property       │   Moore   │   Mealy   │
//   ├────────────────┼───────────┼───────────┤
//   │ States         │     5     │     4     │
//   │ Output latency │  +1 cycle │   0 cycles│
//   │ Glitch risk    │   None    │  Possible │
//   │ Overlapping    │ Param     │ Natural   │
//   └────────────────┴───────────┴───────────┘
//
// Assertions:
//   A1  detected requires cs==S3 AND data_in==1 simultaneously
//   A2  State count: only S0–S3 (no S4)
//   A3  Detected is a combinational function (no registered state needed)
//   A4  Timing: detected in same cycle as final bit (Moore latency comparison)
//=============================================================================

`include "../../rtl/pkg/fsm_pkg.sv"

module seq_det_1011_mealy
  import fsm_pkg::*;
#(
  parameter bit OVERLAPPING = 1'b1  // default overlapping for Mealy
)(
  input  logic clk,
  input  logic rst_n,
  input  logic data_in,
  output logic detected,    // MEALY: combinational, asserted in same cycle as last bit
  output logic [1:0] dbg_state
);

  //===========================================================================
  // State type — 4 states (Binary, 2 bits)
  // Mealy saves one state vs Moore — no dedicated DETECT state needed
  //===========================================================================
  typedef enum logic [1:0] {
    S0 = 2'd0,  // no prefix
    S1 = 2'd1,  // "1"
    S2 = 2'd2,  // "10"
    S3 = 2'd3   // "101"
  } state_t;

  state_t cs, ns;
  assign dbg_state = cs;

  //===========================================================================
  // Sequential
  //===========================================================================
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) cs <= S0;
    else        cs <= ns;

  //===========================================================================
  // Mealy: next-state AND output together
  //===========================================================================
  always_comb begin : mealy_nsl_op
    ns       = S0;
    detected = 1'b0;

    unique case (cs)
      S0: begin
        if (data_in) begin ns = S1; end
        else         begin ns = S0; end
      end

      S1: begin
        if (!data_in) begin ns = S2; end
        else          begin ns = S1; end   // "11": second '1' restarts prefix
      end

      S2: begin
        if (data_in)  begin ns = S3; end
        else          begin ns = S0; end   // "100": no useful prefix
      end

      S3: begin
        if (data_in) begin
          detected = 1'b1;                 // MEALY OUTPUT — asserted HERE, on arc
          ns = OVERLAPPING ? S1 : S0;      // overlapping: recycle final '1'
        end else begin
          ns = S2;                         // "1010": "10" is a valid prefix
        end
      end

      default: ns = S0;
    endcase
  end

  //===========================================================================
  // SVA Assertions
  //===========================================================================
`ifndef SYNTHESIS

  // A1 — MEALY PROPERTY: detected requires cs==S3 AND data_in simultaneously
  A1_mealy_output: assert property (
    @(posedge clk) disable iff (!rst_n)
    detected |-> (cs == S3 && data_in == 1'b1)
  ) else $error("[SEQ_MEALY] A1: Mealy output asserted incorrectly");

  // A2 — Converse: S3 + data_in=1 MUST assert detected
  A2_mealy_completeness: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == S3 && data_in == 1'b1) |-> detected
  ) else $error("[SEQ_MEALY] A2: Mealy output not asserted on S3+1");

  // A3 — No spurious detections from other states
  A3_no_s0_detect: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == S0 || cs == S1 || cs == S2) |-> !detected
  ) else $error("[SEQ_MEALY] A3: Spurious detection in non-S3 state");

  // A4 — S3 only entered from S2 on data_in=1
  A4_s3_from_s2: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == S3) |-> ($past(cs) == S2 && $past(data_in) == 1'b1)
  ) else $error("[SEQ_MEALY] A4: S3 entered illegally");

  // A5 — Overlapping: after detection, next state is S1 (recycles '1')
  generate
    if (OVERLAPPING) begin : g_ol
      A5_overlap_s1: assert property (
        @(posedge clk) disable iff (!rst_n)
        (cs == S3 && data_in) |=> (cs == S1)
      ) else $error("[SEQ_MEALY] A5: Overlapping: expected S1 after detect");
    end
  endgenerate

  // A6 — No unknown state
  A6_no_x: assert property (
    @(posedge clk) disable iff (!rst_n)
    !$isunknown(cs)
  ) else $error("[SEQ_MEALY] A6: Unknown state");

  // A7 — detected is never X (critical for downstream logic)
  A7_detected_known: assert property (
    @(posedge clk) disable iff (!rst_n)
    !$isunknown(detected)
  ) else $error("[SEQ_MEALY] A7: detected output is X");

  // Coverage
  COV_detect:          cover property (@(posedge clk) detected);
  COV_back_to_back:    cover property (@(posedge clk) detected ##4 detected);
  COV_s2_to_s0:        cover property (@(posedge clk) cs==S2 && !data_in ##1 cs==S0);
  COV_s3_to_s2:        cover property (@(posedge clk) cs==S3 && !data_in ##1 cs==S2);

`endif

endmodule : seq_det_1011_mealy
