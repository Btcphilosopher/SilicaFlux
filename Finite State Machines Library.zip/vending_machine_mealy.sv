//=============================================================================
// File        : vending_machine_mealy.sv
// Project     : FSM Library — Reusable Finite State Machines
// Description : Vending Machine Controller — Mealy FSM.
//
//   Same functionality as the Moore version but outputs are generated
//   on TRANSITION ARCS (state × input → output), not from states alone.
//
//   Key Mealy advantages demonstrated here:
//     • dispense_out is asserted on the arc that crosses the ITEM_COST
//       threshold, removing the need for a separate DISPENSING state
//     • State count drops from 7 (Moore) to 4 (Mealy):
//         IDLE, ACCEPTING, CHANGE_OUT, REFUND
//     • Combinational outputs mean 1-cycle faster response
//
//   Key Mealy tradeoff:
//     • Outputs can glitch when inputs change mid-cycle
//     • Register downstream if glitch-free outputs required
//
// State-output table (Mealy arcs):
//
//  From state   Input            Output           Next state
//  ----------  ---------------  ---------------  ----------
//  IDLE        coin (< cost)    —                ACCEPTING
//  IDLE        coin (= cost)    dispense         IDLE
//  IDLE        coin (> cost)    dispense         CHANGE_OUT
//  ACCEPTING   coin (total<)    —                ACCEPTING
//  ACCEPTING   coin (total=)    dispense         IDLE
//  ACCEPTING   coin (total>)    dispense         CHANGE_OUT
//  ACCEPTING   cancel           change_out (×N)  REFUND
//  CHANGE_OUT  change_ack       change_out       IDLE (if done)
//  REFUND      change_ack       change_out       IDLE (if done)
//=============================================================================

`include "../../rtl/pkg/fsm_pkg.sv"

module vending_machine_mealy
  import fsm_pkg::*;
#(
  parameter int ITEM_COST  = 60,
  parameter int MAX_CHANGE = 110,
  parameter int TOTAL_W    = 8
)(
  input  logic         clk,
  input  logic         rst_n,
  input  coin_e        coin_in,
  input  logic         cancel,
  input  logic         change_ack,
  output logic         dispense_out,  // MEALY: asserted on threshold-crossing arc
  output logic         change_out,    // MEALY: asserted during change/refund arcs
  output logic [7:0]   change_amount,
  output logic         ready,
  output logic [1:0]   dbg_state
);

  //===========================================================================
  // Mealy: 4 states vs 7 in Moore version
  //===========================================================================
  typedef enum logic [1:0] {
    ST_IDLE       = 2'd0,
    ST_ACCEPTING  = 2'd1,
    ST_CHANGE_OUT = 2'd2,
    ST_REFUND     = 2'd3
  } state_t;

  state_t cs, ns;

  logic [TOTAL_W-1:0] coin_total_q, coin_total_d;
  logic [TOTAL_W-1:0] change_q,     change_d;

  logic [TOTAL_W-1:0] coin_value;
  logic               coin_inserted;

  always_comb begin
    unique case (coin_in)
      COIN_10P: coin_value = TOTAL_W'(10);
      COIN_20P: coin_value = TOTAL_W'(20);
      COIN_50P: coin_value = TOTAL_W'(50);
      default:  coin_value = '0;
    endcase
  end

  assign coin_inserted = (coin_in != NO_COIN);
  assign dbg_state     = cs;
  assign change_amount = change_q;

  //===========================================================================
  // Sequential
  //===========================================================================
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cs           <= ST_IDLE;
      coin_total_q <= '0;
      change_q     <= '0;
    end else begin
      cs           <= ns;
      coin_total_q <= coin_total_d;
      change_q     <= change_d;
    end
  end

  //===========================================================================
  // Mealy combinational block: next-state + outputs together
  // Outputs are asserted on the transition arc, not from a dedicated state
  //===========================================================================
  always_comb begin : mealy_nsl_op
    // Defaults: no output, hold state and data
    ns           = cs;
    coin_total_d = coin_total_q;
    change_d     = change_q;
    dispense_out = 1'b0;
    change_out   = 1'b0;
    ready        = 1'b0;

    unique case (cs)

      // -----------------------------------------------------------------------
      ST_IDLE: begin
        ready = 1'b1;
        if (coin_inserted) begin
          coin_total_d = coin_value;
          if (coin_value > TOTAL_W'(ITEM_COST)) begin
            // Mealy: dispense asserted RIGHT HERE on the arc, no DISPENSING state
            dispense_out = 1'b1;
            change_d     = coin_value - TOTAL_W'(ITEM_COST);
            coin_total_d = '0;
            ns           = ST_CHANGE_OUT;
          end else if (coin_value == TOTAL_W'(ITEM_COST)) begin
            dispense_out = 1'b1;  // arc output
            coin_total_d = '0;
            ns           = ST_IDLE;
          end else begin
            ns = ST_ACCEPTING;
          end
        end
      end

      // -----------------------------------------------------------------------
      ST_ACCEPTING: begin
        ready = 1'b1;
        if (cancel) begin
          change_d = coin_total_q;
          ns       = ST_REFUND;
        end else if (coin_inserted) begin
          coin_total_d = coin_total_q + coin_value;
          if (coin_total_d > TOTAL_W'(ITEM_COST)) begin
            dispense_out = 1'b1;  // Mealy arc output: dispense when threshold crossed
            change_d     = coin_total_d - TOTAL_W'(ITEM_COST);
            coin_total_d = '0;
            ns           = ST_CHANGE_OUT;
          end else if (coin_total_d == TOTAL_W'(ITEM_COST)) begin
            dispense_out = 1'b1;  // exact payment arc
            coin_total_d = '0;
            ns           = ST_IDLE;
          end
          // else stay in ACCEPTING, accumulate more coins
        end
      end

      // -----------------------------------------------------------------------
      ST_CHANGE_OUT: begin
        if (change_ack) begin
          change_out = 1'b1;   // Mealy: output on ack arc
          if (change_q <= TOTAL_W'(10)) begin
            change_d = '0;
            ns       = ST_IDLE;
          end else begin
            change_d = change_q - TOTAL_W'(10);
          end
        end
      end

      // -----------------------------------------------------------------------
      ST_REFUND: begin
        if (change_ack) begin
          change_out = 1'b1;
          if (change_q <= TOTAL_W'(10)) begin
            change_d = '0;
            ns       = ST_IDLE;
          end else begin
            change_d = change_q - TOTAL_W'(10);
          end
        end
      end

      default: ns = ST_IDLE;
    endcase
  end

  //===========================================================================
  // SVA Assertions
  //===========================================================================
`ifndef SYNTHESIS

  // A1 — Mealy property: dispense is only generated during IDLE or ACCEPTING
  //      on the coin-insertion arc (not from any dedicated state)
  A1_dispense_arc: assert property (
    @(posedge clk) disable iff (!rst_n)
    dispense_out |-> (cs == ST_IDLE || cs == ST_ACCEPTING)
  ) else $error("[VM_MEALY] A1: dispense_out from unexpected state %0d", cs);

  // A2 — dispense requires a coin to be inserted in the same cycle
  A2_dispense_needs_coin: assert property (
    @(posedge clk) disable iff (!rst_n)
    dispense_out |-> coin_inserted
  ) else $error("[VM_MEALY] A2: dispense without coin input");

  // A3 — change_out only in CHANGE_OUT or REFUND states
  A3_change_state: assert property (
    @(posedge clk) disable iff (!rst_n)
    change_out |-> (cs == ST_CHANGE_OUT || cs == ST_REFUND)
  ) else $error("[VM_MEALY] A3: change_out outside change states");

  // A4 — Mealy vs Moore equivalence: dispense must fire within same cycle
  //      as the threshold crossing (not one cycle later as Moore would)
  A4_mealy_latency: assert property (
    @(posedge clk) disable iff (!rst_n)
    (coin_inserted && (coin_total_q + coin_value >= TOTAL_W'(ITEM_COST))
     && (cs == ST_IDLE || cs == ST_ACCEPTING))
    |-> dispense_out
  ) else $error("[VM_MEALY] A4: Mealy dispense latency violated");

  // A5 — coin_total returns to zero after dispensing
  A5_total_cleared: assert property (
    @(posedge clk) disable iff (!rst_n)
    dispense_out |=> (coin_total_q == '0)
  ) else $error("[VM_MEALY] A5: coin_total not cleared after dispense");

  // A6 — State unknown check
  A6_no_x: assert property (
    @(posedge clk) disable iff (!rst_n)
    !$isunknown(cs)
  ) else $error("[VM_MEALY] A6: Unknown state");

  COV_dispense_idle:     cover property (@(posedge clk) dispense_out && cs==ST_IDLE);
  COV_dispense_accept:   cover property (@(posedge clk) dispense_out && cs==ST_ACCEPTING);
  COV_change_returned:   cover property (@(posedge clk) cs==ST_CHANGE_OUT [*2]);
  COV_cancel_mid_insert: cover property (@(posedge clk) cs==ST_ACCEPTING && cancel);

`endif

endmodule : vending_machine_mealy
