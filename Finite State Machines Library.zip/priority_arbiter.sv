//=============================================================================
// File        : priority_arbiter.sv
// Project     : FSM Library — Reusable Finite State Machines
// Description : Priority Arbiter FSM — with anti-starvation masked round-robin.
//
//   Pure fixed-priority arbitration can starve low-priority requesters.
//   This implementation uses a two-pass masked scheme:
//     Pass 1: Apply fixed priority only to requesters ABOVE last_grant
//             (promotes fairness while respecting priority within a window).
//     Pass 2: If Pass 1 finds nothing, fall back to full fixed priority.
//
//   Priority order: REQ[0] > REQ[1] > REQ[2] > REQ[3]  (0 = highest)
//
//   Handshake: grant is held until ack is received from the grantee.
//   This is a common bus-arbitration pattern.
//
//   States:
//     ST_IDLE     – no pending grants
//     ST_GRANT    – grant issued, waiting for ack
//     ST_RELEASE  – ack received, release bus for one cycle
//
//   Outputs:
//     gnt[3:0]   – one-hot grant
//     gnt_valid  – grant is active
//
// Assertions:
//   A1  gnt is one-hot when gnt_valid
//   A2  No grant without matching request
//   A3  Grant held until ack received
//   A4  No simultaneous gnt and ST_IDLE
//   A5  After ack, release for at least one cycle before re-grant
//   A6  Lower-priority never granted when higher-priority requesting
//       (unless higher-priority was most recently granted — anti-starvation)
//=============================================================================

`include "../../rtl/pkg/fsm_pkg.sv"

module priority_arbiter
  import fsm_pkg::*;
#(
  parameter int NUM_REQ = 4   // number of requesters (max 8)
)(
  input  logic                clk,
  input  logic                rst_n,
  input  logic [NUM_REQ-1:0]  req,       // requests (level)
  input  logic                ack,       // grantee acknowledges and releases bus
  output logic [NUM_REQ-1:0]  gnt,       // one-hot grant
  output logic                gnt_valid  // grant is active
);

  //===========================================================================
  // State type
  //===========================================================================
  typedef enum logic [1:0] {
    ST_IDLE    = 2'b00,
    ST_GRANT   = 2'b01,
    ST_RELEASE = 2'b10
  } state_t;

  state_t cs, ns;

  logic [NUM_REQ-1:0] gnt_q, gnt_d;   // registered grant
  logic [2:0]         last_q, last_d; // last granted requester

  //===========================================================================
  // Priority encode: find highest-priority requester in masked window
  // mask_above: only look at requesters with index > last_q (anti-starvation)
  //===========================================================================
  function automatic logic [NUM_REQ-1:0] priority_encode(
    input logic [NUM_REQ-1:0] r,
    input logic [2:0]         above  // mask: only indices > above
  );
    logic [NUM_REQ-1:0] masked;
    logic [NUM_REQ-1:0] result;
    // Build mask: allow all requesters with index > above
    masked = '0;
    for (int i = 0; i < NUM_REQ; i++)
      if (3'(i) > above) masked[i] = r[i];

    // First pass: priority within masked window
    result = '0;
    for (int i = 0; i < NUM_REQ; i++) begin
      if (masked[i]) begin result = NUM_REQ'(1) << i; break; end
    end

    // Second pass: if masked found nothing, use full priority
    if (result == '0) begin
      for (int i = 0; i < NUM_REQ; i++) begin
        if (r[i]) begin result = NUM_REQ'(1) << i; break; end
      end
    end

    return result;
  endfunction

  // Index of the set bit in a one-hot vector
  function automatic logic [2:0] onehot_to_idx(input logic [NUM_REQ-1:0] oh);
    for (int i = 0; i < NUM_REQ; i++)
      if (oh[i]) return 3'(i);
    return 3'(NUM_REQ);
  endfunction

  //===========================================================================
  // Sequential
  //===========================================================================
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cs     <= ST_IDLE;
      gnt_q  <= '0;
      last_q <= '0;
    end else begin
      cs     <= ns;
      gnt_q  <= gnt_d;
      last_q <= last_d;
    end
  end

  //===========================================================================
  // Next-state logic
  //===========================================================================
  always_comb begin : nsl
    ns     = cs;
    gnt_d  = gnt_q;
    last_d = last_q;

    unique case (cs)

      ST_IDLE: begin
        gnt_d = '0;
        if (|req) begin
          // Anti-starvation priority encode
          gnt_d  = priority_encode(req, last_q);
          last_d = onehot_to_idx(gnt_d);
          if (|gnt_d) ns = ST_GRANT;
        end
      end

      ST_GRANT: begin
        // Hold grant until ack received
        if (ack) begin
          gnt_d = '0;
          ns    = ST_RELEASE;
        end else if (!req[onehot_to_idx(gnt_q)]) begin
          // Grantee retracted request without ack — auto-release (timeout guard)
          gnt_d = '0;
          ns    = ST_RELEASE;
        end
      end

      ST_RELEASE: begin
        // One-cycle bus release before re-arbitration
        ns = ST_IDLE;
      end

      default: ns = ST_IDLE;

    endcase
  end

  //===========================================================================
  // Output logic — Moore
  //===========================================================================
  always_comb begin : op
    gnt       = '0;
    gnt_valid = 1'b0;

    unique case (cs)
      ST_IDLE:    /* no grant */ ;
      ST_GRANT:   begin gnt = gnt_q; gnt_valid = |gnt_q; end
      ST_RELEASE: /* bus released */ ;
      default:    /* no grant */ ;
    endcase
  end

  //===========================================================================
  // SVA Assertions
  //===========================================================================
`ifndef SYNTHESIS

  // A1 — gnt always zero or one-hot
  A1_onehot: assert property (
    @(posedge clk) disable iff (!rst_n)
    (gnt == '0) || is_one_hot(16'(gnt))
  ) else $fatal(2, "[PRI_ARB] A1: Multiple grants: gnt=%0b", gnt);

  // A2 — No grant without matching request
  genvar gi;
  generate
    for (gi = 0; gi < NUM_REQ; gi++) begin : g_no_phantom
      assert property (
        @(posedge clk) disable iff (!rst_n)
        gnt[gi] |-> req[gi]
      ) else $error("[PRI_ARB] A2: Grant to requester %0d with no request", gi);
    end
  endgenerate

  // A3 — Grant held until ack (or request retraction)
  A3_hold_until_ack: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == ST_GRANT && !ack && req[onehot_to_idx(gnt_q)]) |=> (cs == ST_GRANT)
  ) else $error("[PRI_ARB] A3: Grant released before ack");

  // A4 — No grant active in IDLE state
  A4_idle_no_grant: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == ST_IDLE) |-> (gnt == '0)
  ) else $error("[PRI_ARB] A4: Grant active in IDLE state");

  // A5 — After ack (RELEASE state), no grant for one cycle
  A5_release_gap: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == ST_RELEASE) |-> (gnt == '0)
  ) else $error("[PRI_ARB] A5: Grant active during RELEASE");

  // A6 — Priority: when only req[0] asserted, gnt[0] must follow
  A6_highest_priority: assert property (
    @(posedge clk) disable iff (!rst_n)
    (req == 4'b0001 && cs == ST_IDLE) |=> gnt[0]
  ) else $error("[PRI_ARB] A6: Highest priority requester not served");

  // A7 — gnt_valid iff cs==ST_GRANT
  A7_valid_in_grant: assert property (
    @(posedge clk) disable iff (!rst_n)
    gnt_valid |-> (cs == ST_GRANT)
  ) else $error("[PRI_ARB] A7: gnt_valid outside ST_GRANT");

  // A8 — After RELEASE, return to IDLE
  A8_release_to_idle: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == ST_RELEASE) |=> (cs == ST_IDLE)
  ) else $error("[PRI_ARB] A8: RELEASE did not return to IDLE");

  // A9 — No unknown state
  A9_no_x: assert property (
    @(posedge clk) disable iff (!rst_n)
    !$isunknown(cs)
  ) else $error("[PRI_ARB] A9: Unknown state");

  // Coverage: all requesters granted
  COV_gnt0: cover property (@(posedge clk) gnt[0] && ack);
  COV_gnt1: cover property (@(posedge clk) gnt[1] && ack);
  COV_gnt2: cover property (@(posedge clk) gnt[2] && ack);
  COV_gnt3: cover property (@(posedge clk) gnt[3] && ack);
  COV_contention: cover property (@(posedge clk) req == 4'hF && cs==ST_IDLE);
  COV_starvation_avoid: cover property (
    @(posedge clk) gnt[3] && ack  // lowest priority eventually wins
  );

`endif

endmodule : priority_arbiter
