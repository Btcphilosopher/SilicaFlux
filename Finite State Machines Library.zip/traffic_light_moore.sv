//=============================================================================
// File        : traffic_light_moore.sv
// Project     : FSM Library — Reusable Finite State Machines
// Description : Traffic Light Controller — Moore FSM, Binary Encoding.
//
//   Moore machine: outputs are a function of CURRENT STATE only.
//   UK sequence:   RED → RED+AMBER → GREEN → AMBER → RED
//   Extensions:    Pedestrian crossing request (latched, served at RED).
//                  Emergency vehicle override (hold RED).
//
// State encoding: Binary — 3 bits for 6 states
//   ST_RED       = 3'd0
//   ST_RED_AMBER = 3'd1
//   ST_GREEN     = 3'd2
//   ST_AMBER     = 3'd3
//   ST_PED_RED   = 3'd4  (hold red + pedestrian walk)
//   ST_EMERGENCY = 3'd5  (emergency: stay red, ignore timer)
//
// Assertions (SVA):
//   A1  No unknown state after reset
//   A2  Red ∧ Green simultaneously forbidden (safety critical)
//   A3  Walk signal only in PED_RED state
//   A4  RED → RED_AMBER (legal sequence)
//   A5  AMBER → RED or PED_RED only
//   A6  Emergency forces EMERGENCY within one clock
//   A7  All outputs known (no X/Z propagation)
//=============================================================================

`include "../../rtl/pkg/fsm_pkg.sv"

module traffic_light_moore
  import fsm_pkg::*;
#(
  parameter int TIMER_W      = 8,   // phase-counter bit width
  parameter int RED_CYCLES   = 100, // cycles in RED
  parameter int RA_CYCLES    = 8,   // cycles in RED+AMBER
  parameter int GREEN_CYCLES = 80,  // cycles in GREEN
  parameter int AMBER_CYCLES = 25,  // cycles in AMBER
  parameter int PED_CYCLES   = 60   // cycles in PED_RED (pedestrian walk)
)(
  input  logic clk,
  input  logic rst_n,
  input  logic pedestrian_req,  // pedestrian crossing request (level)
  input  logic emergency,       // emergency vehicle present (level)
  output logic red,
  output logic amber,
  output logic green,
  output logic ped_walk,        // pedestrian walk signal (active during PED_RED)
  output logic [2:0] dbg_state  // debug probe: numeric state
);

  //===========================================================================
  // State type — BINARY ENCODING (2-3 bits)
  //===========================================================================
  typedef enum logic [2:0] {
    ST_RED       = 3'd0,
    ST_RED_AMBER = 3'd1,
    ST_GREEN     = 3'd2,
    ST_AMBER     = 3'd3,
    ST_PED_RED   = 3'd4,
    ST_EMERGENCY = 3'd5
  } state_t;

  state_t cs, ns;

  //===========================================================================
  // Phase timer and pedestrian latch
  //===========================================================================
  logic [TIMER_W-1:0] timer_q, timer_d;
  logic               ped_q,   ped_d;
  logic               timer_zero;

  assign timer_zero = (timer_q == '0);
  assign dbg_state  = cs;

  //===========================================================================
  // Sequential block: state, timer, pedestrian latch
  //===========================================================================
  always_ff @(posedge clk or negedge rst_n) begin : seq
    if (!rst_n) begin
      cs      <= ST_RED;
      timer_q <= TIMER_W'(RED_CYCLES);
      ped_q   <= 1'b0;
    end else begin
      cs      <= ns;
      timer_q <= timer_d;
      ped_q   <= ped_d;
    end
  end

  //===========================================================================
  // Combinational block: next-state and timer
  //===========================================================================
  always_comb begin : nsl
    // Defaults: hold state, count down, latch pedestrian
    ns      = cs;
    timer_d = (timer_zero) ? timer_q : (timer_q - 1'b1);
    ped_d   = ped_q | pedestrian_req;

    // Emergency overrides everything → force EMERGENCY state
    if (emergency && cs != ST_EMERGENCY) begin
      ns      = ST_EMERGENCY;
      timer_d = TIMER_W'(RED_CYCLES);

    end else begin
      unique case (cs)

        ST_RED: begin
          if (timer_zero) begin
            ns      = ST_RED_AMBER;
            timer_d = TIMER_W'(RA_CYCLES);
          end
        end

        ST_RED_AMBER: begin
          if (timer_zero) begin
            ns      = ST_GREEN;
            timer_d = TIMER_W'(GREEN_CYCLES);
          end
        end

        ST_GREEN: begin
          if (timer_zero) begin
            ns      = ST_AMBER;
            timer_d = TIMER_W'(AMBER_CYCLES);
          end
        end

        ST_AMBER: begin
          if (timer_zero) begin
            // If pedestrian was requested, serve crossing before next GREEN
            if (ped_q) begin
              ns      = ST_PED_RED;
              timer_d = TIMER_W'(PED_CYCLES);
              ped_d   = 1'b0;  // clear latch once served
            end else begin
              ns      = ST_RED;
              timer_d = TIMER_W'(RED_CYCLES);
            end
          end
        end

        ST_PED_RED: begin
          ped_d = 1'b0;  // keep cleared during walk phase
          if (timer_zero) begin
            ns      = ST_RED_AMBER;
            timer_d = TIMER_W'(RA_CYCLES);
          end
        end

        ST_EMERGENCY: begin
          timer_d = TIMER_W'(RED_CYCLES);  // hold at RED, refresh timer
          if (!emergency) begin
            ns      = ST_RED;
            timer_d = TIMER_W'(RED_CYCLES);
          end
        end

        default: begin  // unreachable in normal operation
          ns      = ST_RED;
          timer_d = TIMER_W'(RED_CYCLES);
        end

      endcase
    end
  end

  //===========================================================================
  // Output logic — MOORE: depends only on cs
  //===========================================================================
  always_comb begin : op
    red      = 1'b0;
    amber    = 1'b0;
    green    = 1'b0;
    ped_walk = 1'b0;

    unique case (cs)
      ST_RED:        red   = 1'b1;
      ST_RED_AMBER:  begin red = 1'b1; amber = 1'b1; end
      ST_GREEN:      green = 1'b1;
      ST_AMBER:      amber = 1'b1;
      ST_PED_RED:    begin red = 1'b1; ped_walk = 1'b1; end
      ST_EMERGENCY:  red   = 1'b1;
      default:       red   = 1'b1;  // fail-safe: show red
    endcase
  end

  //===========================================================================
  // Formal-style SVA Assertions
  // pragma translate_off
  //===========================================================================
`ifndef SYNTHESIS

  // A1 — State register is never X or Z after reset
  A1_no_x_state: assert property (
    @(posedge clk) disable iff (!rst_n)
    !$isunknown(cs)
  ) else $error("[TL_MOORE] A1: Unknown state value cs=%0b", cs);

  // A2 — SAFETY CRITICAL: Red and Green must never be simultaneously active
  A2_no_red_green: assert property (
    @(posedge clk) disable iff (!rst_n)
    !(red && green)
  ) else $fatal(2, "[TL_MOORE] A2: SAFETY FAULT – Red and Green simultaneously active!");

  // A3 — Walk signal is asserted only in PED_RED state (Moore property)
  A3_walk_in_ped_red: assert property (
    @(posedge clk) disable iff (!rst_n)
    ped_walk |-> (cs == ST_PED_RED)
  ) else $error("[TL_MOORE] A3: Walk signal active outside PED_RED state");

  // A4 — RED only transitions to RED_AMBER (not directly to GREEN/AMBER)
  A4_red_to_ra_only: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == ST_RED && timer_zero && !emergency) |=> (cs == ST_RED_AMBER)
  ) else $error("[TL_MOORE] A4: RED did not transition to RED_AMBER");

  // A5 — AMBER transitions only to RED or PED_RED
  A5_amber_exit: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == ST_AMBER && timer_zero && !emergency) |=>
    (cs == ST_RED || cs == ST_PED_RED)
  ) else $error("[TL_MOORE] A5: AMBER illegal transition");

  // A6 — Emergency asserted forces EMERGENCY state within one clock
  A6_emergency_immediate: assert property (
    @(posedge clk) disable iff (!rst_n)
    ($rose(emergency) && cs != ST_EMERGENCY) |=> (cs == ST_EMERGENCY)
  ) else $error("[TL_MOORE] A6: Emergency did not force EMERGENCY state");

  // A7 — All lamp outputs must be known (no X/Z on safety outputs)
  A7_outputs_known: assert property (
    @(posedge clk) disable iff (!rst_n)
    !$isunknown({red, amber, green, ped_walk})
  ) else $error("[TL_MOORE] A7: Unknown output value on lamp signals");

  // A8 — Green must precede amber in normal sequence (no amber without green)
  A8_green_precedes_amber: assert property (
    @(posedge clk) disable iff (!rst_n)
    ($rose(amber) && !red) |-> $past(green, 1)
  ) else $error("[TL_MOORE] A8: Amber asserted without prior Green");

  // Coverage goals
  COV_normal_cycle: cover property (
    @(posedge clk)
    cs == ST_RED ##[1:200] cs == ST_RED_AMBER
    ##[1:10]  cs == ST_GREEN
    ##[1:100] cs == ST_AMBER
    ##[1:30]  cs == ST_RED
  );

  COV_ped_crossing: cover property (
    @(posedge clk) pedestrian_req && cs == ST_GREEN
    ##[1:120] cs == ST_PED_RED
  );

  COV_emergency_preempt: cover property (
    @(posedge clk) emergency && cs == ST_GREEN
    ##[1:2] cs == ST_EMERGENCY
    ##[1:20] cs == ST_RED
  );

`endif
  //===========================================================================
  // pragma translate_on
  //===========================================================================

endmodule : traffic_light_moore
