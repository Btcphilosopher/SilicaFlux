//=============================================================================
// File        : fsm_pkg.sv
// Project     : FSM Library — Reusable Finite State Machines
// Description : Shared package: types, encoding enums, utility functions.
// Standard    : IEEE 1800-2017 (SystemVerilog)
//=============================================================================

`ifndef FSM_PKG_SV
`define FSM_PKG_SV

package fsm_pkg;

  //===========================================================================
  // Encoding selection (use as a parameter to instantiate different encodings)
  //===========================================================================
  // BINARY  : log2(N) bits — compact area, slower decode mux
  // ONE_HOT : N bits — one bit per state, fastest decode, larger flop count
  // GRAY    : log2(N) bits — adjacent states differ by exactly 1 bit,
  //           reduces glitch energy and metastability in async crossings
  //===========================================================================
  typedef enum int unsigned {
    ENC_BINARY  = 0,
    ENC_ONE_HOT = 1,
    ENC_GRAY    = 2
  } encoding_e;

  //===========================================================================
  // Vending machine coin denominations
  //===========================================================================
  typedef enum logic [1:0] {
    NO_COIN  = 2'b00,
    COIN_10P = 2'b01,
    COIN_20P = 2'b10,
    COIN_50P = 2'b11
  } coin_e;

  //===========================================================================
  // Elevator direction
  //===========================================================================
  typedef enum logic [1:0] {
    DIR_NONE = 2'b00,
    DIR_UP   = 2'b01,
    DIR_DOWN = 2'b10
  } direction_e;

  //===========================================================================
  // Arbitration bus
  //===========================================================================
  parameter int NUM_REQ = 4;

  //===========================================================================
  // Gray code utilities
  //===========================================================================

  // Binary → Gray: XOR each bit with the one above it
  function automatic logic [7:0] bin_to_gray(input logic [7:0] b);
    return b ^ (b >> 1);
  endfunction

  // Gray → Binary: propagate XOR cascade from MSB down
  function automatic logic [7:0] gray_to_bin(input logic [7:0] g);
    logic [7:0] b;
    b[7] = g[7];
    for (int i = 6; i >= 0; i--)
      b[i] = b[i+1] ^ g[i];
    return b;
  endfunction

  //===========================================================================
  // One-hot validity check
  // Returns 1'b1 iff exactly one bit is asserted in vec
  //===========================================================================
  function automatic logic is_one_hot(input logic [15:0] vec);
    return (|vec) && !(|(vec & (vec - 16'd1)));
  endfunction

  //===========================================================================
  // Population count (number of asserted bits)
  //===========================================================================
  function automatic int unsigned popcount(input logic [15:0] vec);
    int unsigned cnt = 0;
    for (int i = 0; i < 16; i++)
      if (vec[i]) cnt++;
    return cnt;
  endfunction

  //===========================================================================
  // Priority encode: returns index of least-significant set bit
  //===========================================================================
  function automatic logic [3:0] priority_enc(input logic [15:0] vec);
    for (int i = 0; i < 16; i++)
      if (vec[i]) return 4'(i);
    return 4'hF;  // no bit set
  endfunction

endpackage : fsm_pkg

`endif // FSM_PKG_SV
