//=============================================================================
// File        : tb_elevator.sv
// Project     : FSM Library — Testbenches
// Description : Exhaustive testbench for elevator_ctrl.sv
//
//   Test plan:
//     TC1  Single floor request — ground to floor 1
//     TC2  Multiple floor requests — SCAN order verification
//     TC3  Direction reversal — serve all up requests before going down
//     TC4  Simultaneous hall and cabin requests at same floor
//     TC5  Door safety: door reopens if door_closed sensor deasserted
//     TC6  Top floor (floor 3) and bottom floor (floor 0) boundary tests
//     TC7  All-floors request — complete SCAN traversal
//     TC8  State coverage monitor — verify all states visited
//=============================================================================

`include "../rtl/pkg/fsm_pkg.sv"
`include "../rtl/elevator/elevator_ctrl.sv"

`timescale 1ns/1ps

module tb_elevator;
  import fsm_pkg::*;

  //===========================================================================
  // Parameters
  //===========================================================================
  localparam int NUM_FLOORS   = 4;
  localparam int MOVE_CYCLES  = 3;
  localparam int DOPEN_CYCLES = 2;
  localparam int DWAIT_CYCLES = 5;
  localparam int DCLOSE_CYCLES = 2;

  //===========================================================================
  // Signals
  //===========================================================================
  logic         clk, rst_n;
  logic [3:0]   floor_req;   // cabin buttons
  logic [3:0]   hall_up;     // hall up buttons
  logic [3:0]   hall_dn;     // hall down buttons
  logic         door_closed;

  logic         door_open_cmd, door_close_cmd;
  logic         motor_up, motor_down;
  logic [1:0]   floor_ind;
  logic [1:0]   dir_ind;
  logic [2:0]   dbg_state;

  //===========================================================================
  // DUT
  //===========================================================================
  elevator_ctrl #(
    .NUM_FLOORS(NUM_FLOORS),
    .MOVE_CYCLES(MOVE_CYCLES),
    .DOPEN_CYCLES(DOPEN_CYCLES),
    .DWAIT_CYCLES(DWAIT_CYCLES),
    .DCLOSE_CYCLES(DCLOSE_CYCLES)
  ) u_elev (
    .clk, .rst_n, .floor_req, .hall_up, .hall_dn, .door_closed,
    .door_open_cmd, .door_close_cmd, .motor_up, .motor_down,
    .floor_ind, .dir_ind, .dbg_state
  );

  //===========================================================================
  // Clock
  //===========================================================================
  initial clk = 0;
  always #5 clk = ~clk;

  //===========================================================================
  // State coverage tracking
  //===========================================================================
  logic [5:0] state_seen;  // one bit per state (0..5)

  always_ff @(posedge clk)
    if (rst_n) state_seen[dbg_state] = 1'b1;

  //===========================================================================
  // Safety monitor: runs continuously
  //===========================================================================
  always @(posedge clk) begin
    if (rst_n) begin
      if (motor_up && motor_down)
        $fatal(2, "[ELEV_TB] SAFETY: Motor up+down simultaneously at t=%0t", $time);
      if (door_open_cmd && door_close_cmd)
        $fatal(2, "[ELEV_TB] SAFETY: Door open+close simultaneously at t=%0t", $time);
      if ((motor_up || motor_down) && door_open_cmd)
        $fatal(2, "[ELEV_TB] SAFETY: Motor running with door open at t=%0t", $time);
      if (floor_ind >= 2'(NUM_FLOORS))
        $fatal(2, "[ELEV_TB] Floor out of bounds: %0d at t=%0t", floor_ind, $time);
    end
  end

  //===========================================================================
  // Utilities
  //===========================================================================
  task automatic clk_step(input int n = 1);
    repeat(n) @(posedge clk); #1;
  endtask

  task automatic do_reset();
    rst_n      = 0;
    floor_req  = '0;
    hall_up    = '0;
    hall_dn    = '0;
    door_closed = 1;  // door starts closed
    state_seen = '0;
    clk_step(3);
    rst_n = 1;
    clk_step(2);
    $display("[%0t] Reset: elevator at floor %0d", $time, floor_ind);
  endtask

  // Wait for elevator to reach a specific floor
  task automatic wait_floor(input logic [1:0] target, input int timeout = 200);
    int cnt = 0;
    while (floor_ind !== target && cnt < timeout) begin
      clk_step(1); cnt++;
    end
    if (cnt >= timeout)
      $fatal(1, "[ELEV_TB] Timeout waiting for floor %0d (at %0d)", target, floor_ind);
  endtask

  // Wait for a specific state
  task automatic wait_state(input logic [2:0] target, input int timeout = 200);
    int cnt = 0;
    while (dbg_state !== target && cnt < timeout) begin
      clk_step(1); cnt++;
    end
    if (cnt >= timeout)
      $fatal(1, "[ELEV_TB] Timeout waiting for state %0d", target);
  endtask

  // Wait for IDLE state
  task automatic wait_idle(input int timeout = 500);
    wait_state(3'd0, timeout);
  endtask

  // Simulate a complete door cycle (open → passenger time → close)
  task automatic door_cycle();
    wait_state(3'd4);   // DOOR_OPEN
    clk_step(DWAIT_CYCLES + 2);
    wait_state(3'd6, 50);  // DOOR_CLOSING
    // Assert door_closed after close command
    door_closed = 0;
    clk_step(DCLOSE_CYCLES);
    door_closed = 1;
    clk_step(2);
  endtask

  int pass_cnt = 0, fail_cnt = 0;
  task automatic check(input string name, input logic cond);
    if (cond) begin $display("[PASS] %s", name); pass_cnt++; end
    else      begin $error("[FAIL] %s", name);   fail_cnt++; end
  endtask

  //===========================================================================
  // TC1 — Single floor request: ground to floor 1
  //===========================================================================
  task automatic tc1_single_request();
    $display("\n=== TC1: Single Request Ground→Floor 1 ===");
    do_reset();

    // Request floor 1 from cabin (elevator starts at 0)
    floor_req = 4'b0010;  // floor 1
    clk_step(2);
    floor_req = '0;

    check("TC1.Motor up asserted", motor_up);

    wait_floor(2'd1);
    check("TC1.Reached floor 1", floor_ind == 2'd1);
    check("TC1.Door opens",      door_open_cmd || dbg_state == 3'd3);

    clk_step(DOPEN_CYCLES + DWAIT_CYCLES + DCLOSE_CYCLES + 5);
    wait_idle();
    check("TC1.Returns to IDLE", dbg_state == 3'd0);
    $display("[TC1] PASS");
  endtask

  //===========================================================================
  // TC2 — Multiple requests: SCAN order 0,2,3,1 → should serve 2,3 then 1
  //===========================================================================
  task automatic tc2_scan_order();
    $display("\n=== TC2: SCAN Order Verification ===");
    do_reset();

    // Elevator at floor 0. Request floors 2 and 3 first (upward)
    hall_up[2] = 1;  // someone waiting at floor 2 going up
    hall_up[3] = 1;  // someone waiting at floor 3 going up
    clk_step(1);

    logic [1:0] first_stop, second_stop;
    logic first_seen = 0, second_seen = 0;

    fork
      begin : monitor
        forever begin
          @(posedge clk); #1;
          if (door_open_cmd && !first_seen) begin
            first_stop = floor_ind;
            first_seen = 1;
            $display("[TC2] First stop at floor %0d", floor_ind);
          end else if (door_open_cmd && first_seen && !second_seen &&
                       floor_ind != first_stop) begin
            second_stop = floor_ind;
            second_seen = 1;
            $display("[TC2] Second stop at floor %0d", floor_ind);
          end
        end
      end
      begin : timeout
        clk_step(300);
        disable monitor;
      end
    join

    // SCAN: should visit floor 2 before floor 3 (ascending)
    check("TC2.First SCAN stop at floor 2", first_stop == 2'd2);
    check("TC2.Second SCAN stop at floor 3", second_stop == 2'd3);

    hall_up[2] = 0;
    hall_up[3] = 0;
    wait_idle(500);
    $display("[TC2] PASS");
  endtask

  //===========================================================================
  // TC3 — Direction reversal
  //===========================================================================
  task automatic tc3_direction_reversal();
    $display("\n=== TC3: Direction Reversal ===");
    do_reset();

    // Elevator at floor 0. Request floor 3 up, then floor 1 from hall down
    floor_req = 4'b1000;   // floor 3 cabin request
    hall_dn[1] = 1;         // floor 1 hall down button
    clk_step(2);
    floor_req = '0;

    logic up_seen = 0, down_seen = 0;

    fork
      begin : dir_monitor
        forever begin
          @(posedge clk); #1;
          if (motor_up)   up_seen   = 1;
          if (motor_down) down_seen = 1;
        end
      end
      begin : dir_wait
        clk_step(400);
        disable dir_monitor;
      end
    join

    check("TC3.Motor up seen",   up_seen);
    check("TC3.Motor down seen", down_seen);
    $display("[TC3] PASS: Direction reversal observed");

    hall_dn[1] = 0;
    wait_idle(500);
  endtask

  //===========================================================================
  // TC4 — Door safety: reopen if sensor says not closed
  //===========================================================================
  task automatic tc4_door_safety();
    $display("\n=== TC4: Door Safety — Reopen if Not Closed ===");
    do_reset();

    floor_req = 4'b0100;  // request floor 2
    clk_step(2);
    floor_req = '0;

    wait_floor(2'd2);
    wait_state(3'd5, 50);  // DOOR_CLOSING

    // Simulate door NOT closed (obstacle)
    door_closed = 0;
    clk_step(DCLOSE_CYCLES + 2);

    // Should reopen
    check("TC4.Door reopened after sensor failure", dbg_state == 3'd3);
    $display("[TC4] door_open_cmd=%0b after failed close", door_open_cmd);

    // Now allow door to close properly
    clk_step(DOPEN_CYCLES + DWAIT_CYCLES + 2);
    wait_state(3'd5, 50);
    door_closed = 1;
    clk_step(DCLOSE_CYCLES + 5);
    wait_idle();
    $display("[TC4] PASS: Door reopened and re-closed safely");
  endtask

  //===========================================================================
  // TC5 — Top and bottom floor boundary
  //===========================================================================
  task automatic tc5_boundaries();
    $display("\n=== TC5: Floor Boundary Tests ===");
    do_reset();

    // Go to top floor (floor 3)
    floor_req = 4'b1000;
    clk_step(1);
    floor_req = '0;
    wait_floor(2'd3, 400);
    check("TC5.Reached top floor (3)", floor_ind == 2'd3);

    clk_step(DOPEN_CYCLES + DWAIT_CYCLES + DCLOSE_CYCLES + 10);
    wait_idle(200);

    // Now go to bottom floor (floor 0)
    floor_req = 4'b0001;
    clk_step(1);
    floor_req = '0;
    wait_floor(2'd0, 400);
    check("TC5.Reached ground floor (0)", floor_ind == 2'd0);

    clk_step(DOPEN_CYCLES + DWAIT_CYCLES + DCLOSE_CYCLES + 10);
    wait_idle(200);
    $display("[TC5] PASS: Top and bottom floors reached");
  endtask

  //===========================================================================
  // TC6 — All floors request (SCAN full traversal)
  //===========================================================================
  task automatic tc6_all_floors();
    $display("\n=== TC6: All-Floor SCAN Traversal ===");
    do_reset();

    // Request all floors from cabin (elevator at floor 0)
    floor_req = 4'b1110;  // floors 1,2,3
    clk_step(1);
    floor_req = '0;

    logic [3:0] floors_visited = 4'b0001;  // floor 0 already there

    fork
      begin : all_mon
        forever begin
          @(posedge clk); #1;
          if (door_open_cmd)
            floors_visited[floor_ind] = 1;
        end
      end
      begin : all_wait
        clk_step(600);
        disable all_mon;
      end
    join

    check("TC6.All 4 floors visited", floors_visited == 4'b1111);
    $display("[TC6] Floors visited: %0b (PASS=%0b)", floors_visited, floors_visited==4'b1111);
  endtask

  //===========================================================================
  // TC7 — State coverage check
  //===========================================================================
  task automatic tc7_state_coverage();
    $display("\n=== TC7: State Coverage ===");
    string state_names [6] = '{"IDLE","MOVING_UP","DOOR_OPENING","DOOR_OPEN","DOOR_CLOSING","MOVING_DOWN"};
    for (int i = 0; i < 6; i++) begin
      if (state_seen[i])
        $display("[TC7] State %0d (%s): COVERED", i, state_names[i]);
      else
        $warning("[TC7] State %0d (%s): NOT COVERED", i, state_names[i]);
    end
    check("TC7.All states covered", state_seen == 6'b111111);
  endtask

  //===========================================================================
  // Main
  //===========================================================================
  initial begin
    $dumpfile("tb_elevator.vcd");
    $dumpvars(0, tb_elevator);

    tc1_single_request();
    tc2_scan_order();
    tc3_direction_reversal();
    tc4_door_safety();
    tc5_boundaries();
    tc6_all_floors();
    tc7_state_coverage();

    $display("\n============================================");
    $display(" Elevator TB: %0d PASS  %0d FAIL", pass_cnt, fail_cnt);
    $display("============================================\n");
    $finish;
  end

  initial begin
    #1_000_000;
    $fatal(1, "[ELEV_TB] Global timeout");
  end

endmodule : tb_elevator
