//=============================================================================
// File        : elevator_ctrl.sv
// Project     : FSM Library — Reusable Finite State Machines
// Description : Elevator Control System — SCAN-based scheduling FSM.
//
//   4-floor elevator (floors 0–3). Implements a simplified SCAN algorithm:
//   – Serve all requests in the current direction before reversing.
//   – Pickup any request at the current floor before continuing.
//
//   Inputs:
//     floor_req[3:0]  – cabin call buttons (passenger inside presses floor)
//     hall_up[3:0]    – hall call up buttons  (floor N → going up)
//     hall_dn[3:0]    – hall call down buttons (floor N → going down)
//     door_closed     – door-closed sensor (physical feedback)
//
//   Outputs:
//     door_open_cmd   – command to open door
//     door_close_cmd  – command to close door
//     motor_up        – drive motor upward
//     motor_down      – drive motor downward
//     floor_ind[1:0]  – current floor indicator
//     dir_ind[1:0]    – current direction indicator
//
//   States:
//     IDLE          – stationary, no requests
//     MOVING_UP     – travelling upward, checking for stops
//     MOVING_DOWN   – travelling downward, checking for stops
//     DOOR_OPENING  – door motor commanded open
//     DOOR_OPEN     – door open, passengers loading/unloading
//     DOOR_CLOSING  – door motor commanded closed
//
//   Assertions:
//     A1  Motor up and motor down never simultaneously active (safety)
//     A2  Door commands mutually exclusive
//     A3  Door open only in DOOR_OPENING or DOOR_OPEN states
//     A4  Motor commands only in MOVING states
//     A5  Floor never exceeds NUM_FLOORS-1
//     A6  Requests cleared when floor served
//     A7  No stuck states (liveness: eventually reaches IDLE or MOVING)
//=============================================================================

`include "../../rtl/pkg/fsm_pkg.sv"

module elevator_ctrl
  import fsm_pkg::*;
#(
  parameter int NUM_FLOORS   = 4,
  parameter int FLOOR_W      = $clog2(NUM_FLOORS),  // 2 bits
  parameter int MOVE_CYCLES  = 10,   // cycles to travel one floor
  parameter int DOPEN_CYCLES = 5,    // cycles for door to open
  parameter int DWAIT_CYCLES = 30,   // cycles door stays open
  parameter int DCLOSE_CYCLES = 5,   // cycles for door to close
  parameter int TIMER_W      = 8
)(
  input  logic                  clk,
  input  logic                  rst_n,
  input  logic [NUM_FLOORS-1:0] floor_req,    // cabin buttons
  input  logic [NUM_FLOORS-1:0] hall_up,      // hall up calls
  input  logic [NUM_FLOORS-1:0] hall_dn,      // hall down calls
  input  logic                  door_closed,  // door-closed sensor
  output logic                  door_open_cmd,
  output logic                  door_close_cmd,
  output logic                  motor_up,
  output logic                  motor_down,
  output logic [FLOOR_W-1:0]    floor_ind,
  output logic [1:0]            dir_ind,
  output logic [2:0]            dbg_state
);

  //===========================================================================
  // State type (Gray encoded for low-glitch state bus)
  //===========================================================================
  typedef enum logic [2:0] {
    ST_IDLE         = 3'b000,  // Gray 0
    ST_MOVING_UP    = 3'b001,  // Gray 1
    ST_DOOR_OPENING = 3'b011,  // Gray 3
    ST_DOOR_OPEN    = 3'b010,  // Gray 2
    ST_DOOR_CLOSING = 3'b110,  // Gray 6
    ST_MOVING_DOWN  = 3'b111   // Gray 7
  } state_t;

  state_t cs, ns;

  //===========================================================================
  // Datapath registers
  //===========================================================================
  logic [FLOOR_W-1:0]    floor_q, floor_d;       // current floor
  direction_e            dir_q,   dir_d;          // current direction
  logic [TIMER_W-1:0]    timer_q, timer_d;        // general-purpose timer
  logic [NUM_FLOORS-1:0] requests_q, requests_d;  // union of all pending requests
  logic                  timer_zero;

  assign timer_zero = (timer_q == '0);
  assign dbg_state  = cs;
  assign floor_ind  = floor_q;
  assign dir_ind    = dir_q;

  //===========================================================================
  // Request management: combine floor_req, hall_up, hall_dn
  //===========================================================================
  always_comb begin
    // Merge all pending calls; individual bits cleared when floor is served
    requests_d = requests_q | floor_req | hall_up | hall_dn;
  end

  //===========================================================================
  // SCAN helper functions
  //===========================================================================

  // Is there any request above current floor?
  function automatic logic requests_above(
    input logic [NUM_FLOORS-1:0] reqs,
    input logic [FLOOR_W-1:0]    cur
  );
    for (int i = 0; i < NUM_FLOORS; i++)
      if (i > int'(cur) && reqs[i]) return 1'b1;
    return 1'b0;
  endfunction

  // Is there any request below current floor?
  function automatic logic requests_below(
    input logic [NUM_FLOORS-1:0] reqs,
    input logic [FLOOR_W-1:0]    cur
  );
    for (int i = 0; i < NUM_FLOORS; i++)
      if (i < int'(cur) && reqs[i]) return 1'b1;
    return 1'b0;
  endfunction

  //===========================================================================
  // Sequential
  //===========================================================================
  always_ff @(posedge clk or negedge rst_n) begin : seq
    if (!rst_n) begin
      cs         <= ST_IDLE;
      floor_q    <= '0;
      dir_q      <= DIR_NONE;
      timer_q    <= '0;
      requests_q <= '0;
    end else begin
      cs         <= ns;
      floor_q    <= floor_d;
      dir_q      <= dir_d;
      timer_q    <= timer_d;
      requests_q <= requests_d;
    end
  end

  //===========================================================================
  // Next-state logic
  //===========================================================================
  always_comb begin : nsl
    ns      = cs;
    floor_d = floor_q;
    dir_d   = dir_q;
    timer_d = timer_zero ? '0 : (timer_q - 1'b1);

    unique case (cs)

      // -----------------------------------------------------------------------
      ST_IDLE: begin
        dir_d = DIR_NONE;
        if (requests_q[floor_q]) begin
          // Request at current floor — open door immediately
          timer_d = TIMER_W'(DOPEN_CYCLES);
          ns      = ST_DOOR_OPENING;
        end else if (requests_above(requests_q, floor_q)) begin
          timer_d = TIMER_W'(MOVE_CYCLES);
          dir_d   = DIR_UP;
          ns      = ST_MOVING_UP;
        end else if (requests_below(requests_q, floor_q)) begin
          timer_d = TIMER_W'(MOVE_CYCLES);
          dir_d   = DIR_DOWN;
          ns      = ST_MOVING_DOWN;
        end
        // else stay IDLE
      end

      // -----------------------------------------------------------------------
      ST_MOVING_UP: begin
        if (timer_zero) begin
          // Arrived at next floor above
          floor_d = floor_q + 1'b1;
          if (requests_q[floor_q + 1'b1]) begin
            // SCAN: stop here
            timer_d = TIMER_W'(DOPEN_CYCLES);
            ns      = ST_DOOR_OPENING;
          end else if (floor_q + 1'b1 < FLOOR_W'(NUM_FLOORS-1)
                       && requests_above(requests_q, floor_q + 1'b1)) begin
            // Continue up
            timer_d = TIMER_W'(MOVE_CYCLES);
          end else if (requests_below(requests_q, floor_q + 1'b1)) begin
            // No more above, reverse
            dir_d   = DIR_DOWN;
            timer_d = TIMER_W'(MOVE_CYCLES);
            ns      = ST_MOVING_DOWN;
          end else begin
            ns = ST_IDLE;
          end
        end
      end

      // -----------------------------------------------------------------------
      ST_MOVING_DOWN: begin
        if (timer_zero) begin
          floor_d = floor_q - 1'b1;
          if (requests_q[floor_q - 1'b1]) begin
            timer_d = TIMER_W'(DOPEN_CYCLES);
            ns      = ST_DOOR_OPENING;
          end else if (floor_q - 1'b1 > '0
                       && requests_below(requests_q, floor_q - 1'b1)) begin
            timer_d = TIMER_W'(MOVE_CYCLES);
          end else if (requests_above(requests_q, floor_q - 1'b1)) begin
            dir_d   = DIR_UP;
            timer_d = TIMER_W'(MOVE_CYCLES);
            ns      = ST_MOVING_UP;
          end else begin
            ns = ST_IDLE;
          end
        end
      end

      // -----------------------------------------------------------------------
      ST_DOOR_OPENING: begin
        if (timer_zero) begin
          timer_d = TIMER_W'(DWAIT_CYCLES);
          ns      = ST_DOOR_OPEN;
        end
      end

      // -----------------------------------------------------------------------
      ST_DOOR_OPEN: begin
        // Clear request for current floor
        if (timer_zero) begin
          timer_d = TIMER_W'(DCLOSE_CYCLES);
          ns      = ST_DOOR_CLOSING;
        end
      end

      // -----------------------------------------------------------------------
      ST_DOOR_CLOSING: begin
        if (timer_zero && door_closed) begin
          // Door confirmed closed — decide next move
          if (requests_above(requests_q, floor_q) && dir_q != DIR_DOWN) begin
            dir_d   = DIR_UP;
            timer_d = TIMER_W'(MOVE_CYCLES);
            ns      = ST_MOVING_UP;
          end else if (requests_below(requests_q, floor_q)) begin
            dir_d   = DIR_DOWN;
            timer_d = TIMER_W'(MOVE_CYCLES);
            ns      = ST_MOVING_DOWN;
          end else begin
            ns = ST_IDLE;
          end
        end else if (timer_zero && !door_closed) begin
          // Door sensor says not closed yet — reopen for safety
          timer_d = TIMER_W'(DOPEN_CYCLES);
          ns      = ST_DOOR_OPENING;
        end
      end

      default: ns = ST_IDLE;
    endcase

    // Clear the current-floor request once door opens
    if (cs == ST_DOOR_OPENING || cs == ST_DOOR_OPEN)
      requests_d[floor_q] = 1'b0;
  end

  //===========================================================================
  // Output logic — Moore
  //===========================================================================
  always_comb begin : op
    door_open_cmd  = 1'b0;
    door_close_cmd = 1'b0;
    motor_up       = 1'b0;
    motor_down     = 1'b0;

    unique case (cs)
      ST_IDLE:         /* nothing */ ;
      ST_MOVING_UP:    motor_up       = 1'b1;
      ST_MOVING_DOWN:  motor_down     = 1'b1;
      ST_DOOR_OPENING: door_open_cmd  = 1'b1;
      ST_DOOR_OPEN:    door_open_cmd  = 1'b1;
      ST_DOOR_CLOSING: door_close_cmd = 1'b1;
      default:         /* nothing */ ;
    endcase
  end

  //===========================================================================
  // SVA Assertions
  //===========================================================================
`ifndef SYNTHESIS

  // A1 — SAFETY: motor up and down never simultaneously commanded
  A1_no_motor_conflict: assert property (
    @(posedge clk) disable iff (!rst_n)
    !(motor_up && motor_down)
  ) else $fatal(2, "[ELEV] A1: SAFETY – Motor up and down simultaneously!");

  // A2 — Door commands mutually exclusive
  A2_door_exclusive: assert property (
    @(posedge clk) disable iff (!rst_n)
    !(door_open_cmd && door_close_cmd)
  ) else $fatal(2, "[ELEV] A2: SAFETY – Door open and close commanded together!");

  // A3 — Door commands only in door states
  A3_door_state: assert property (
    @(posedge clk) disable iff (!rst_n)
    door_open_cmd |-> (cs == ST_DOOR_OPENING || cs == ST_DOOR_OPEN)
  ) else $error("[ELEV] A3: Door open command outside door state");

  // A4 — Motor up only in MOVING_UP
  A4_motor_state: assert property (
    @(posedge clk) disable iff (!rst_n)
    motor_up |-> (cs == ST_MOVING_UP)
  ) else $error("[ELEV] A4: Motor up outside MOVING_UP state");

  // A5 — Floor indicator never exceeds NUM_FLOORS-1
  A5_floor_bounds: assert property (
    @(posedge clk) disable iff (!rst_n)
    floor_q < FLOOR_W'(NUM_FLOORS)
  ) else $fatal(2, "[ELEV] A5: Floor out of bounds: %0d", floor_q);

  // A6 — Moving up never decrements floor
  A6_up_monotone: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == ST_MOVING_UP && $changed(floor_q)) |-> (floor_q > $past(floor_q))
  ) else $error("[ELEV] A6: Floor decreased while moving up");

  // A7 — Moving down never increments floor
  A7_down_monotone: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == ST_MOVING_DOWN && $changed(floor_q)) |-> (floor_q < $past(floor_q))
  ) else $error("[ELEV] A7: Floor increased while moving down");

  // A8 — Door must not open while motor is running
  A8_no_move_while_open: assert property (
    @(posedge clk) disable iff (!rst_n)
    door_open_cmd |-> !(motor_up || motor_down)
  ) else $fatal(2, "[ELEV] A8: SAFETY – Door opening while motor running!");

  // Coverage
  COV_top_floor:       cover property (@(posedge clk) floor_q == FLOOR_W'(NUM_FLOORS-1));
  COV_ground_floor:    cover property (@(posedge clk) floor_q == '0);
  COV_full_ascent:     cover property (@(posedge clk) floor_q=='0 ##[1:200] floor_q==FLOOR_W'(NUM_FLOORS-1));
  COV_direction_rev:   cover property (@(posedge clk) cs==ST_MOVING_UP ##[1:$] cs==ST_MOVING_DOWN);
  COV_all_states:      cover property (@(posedge clk) cs==ST_IDLE ##[1:$] cs==ST_MOVING_UP
                                       ##[1:$] cs==ST_DOOR_OPENING ##[1:$] cs==ST_DOOR_OPEN
                                       ##[1:$] cs==ST_DOOR_CLOSING ##[1:$] cs==ST_IDLE);

`endif

endmodule : elevator_ctrl
