//=============================================================================
// File        : round_robin_arbiter.sv
// Project     : FSM Library — Reusable Finite State Machines
// Description : Round-Robin Arbiter — Token FSM, 4 requesters.
//
//   Implements fair arbitration across NUM_REQ requesters.
//   Each grant is held for HOLD_CYCLES before rotating to the next requester.
//   If the current grantee deasserts its request, the arbiter advances.
//
//   Token FSM:
//     IDLE      – no requests, token at last_grant
//     GRANT_N   – grant is issued to requester N
//     (HOLD_N)  – implicit within GRANT_N via a hold counter
//
//   Round-robin schedule: if requesters 0,1,2,3 all assert simultaneously,
//   grants cycle as 0→1→2→3→0→... in strict rotation.
//
//   Interface:
//     req[N]     – request from requester N (level signal)
//     gnt[N]     – grant to requester N (one-hot, valid for HOLD_CYCLES)
//     gnt_valid  – at least one grant is active
//
//   Parameters:
//     NUM_REQ    – number of requesters (default 4, max 8)
//     HOLD_CYCLES – minimum grant hold (0 = release as soon as req deasserts)
//
// Assertions:
//   A1  gnt is always one-hot when gnt_valid=1
//   A2  gnt only asserted if corresponding req is asserted
//   A3  Round-robin order preserved (no grant jumping ahead)
//   A4  Fairness: each requester gets a grant within NUM_REQ cycles
//       of another requester's grant (bounded starvation)
//   A5  No simultaneous grants
//=============================================================================

`include "../../rtl/pkg/fsm_pkg.sv"

module round_robin_arbiter
  import fsm_pkg::*;
#(
  parameter int NUM_REQ    = 4,
  parameter int HOLD_CYCLES = 3,
  parameter int HOLD_W     = $clog2(HOLD_CYCLES + 1)
)(
  input  logic                clk,
  input  logic                rst_n,
  input  logic [NUM_REQ-1:0]  req,       // request signals (level)
  output logic [NUM_REQ-1:0]  gnt,       // grant signals (one-hot or zero)
  output logic                gnt_valid  // at least one grant active
);

  localparam int STATE_W = $clog2(NUM_REQ + 1);

  //===========================================================================
  // State: IDLE=0, GRANT_0=1, GRANT_1=2, ..., GRANT_N=N+1
  //===========================================================================
  typedef enum logic [2:0] {
    ST_IDLE    = 3'd0,
    ST_GRANT_0 = 3'd1,
    ST_GRANT_1 = 3'd2,
    ST_GRANT_2 = 3'd3,
    ST_GRANT_3 = 3'd4
  } state_t;

  state_t cs, ns;

  logic [HOLD_W-1:0]   hold_q, hold_d;   // hold counter
  logic [2:0]          last_q, last_d;   // last granted requester index

  //===========================================================================
  // Helper: next requester in round-robin order starting after 'from'
  // Returns NUM_REQ if no request found
  //===========================================================================
  function automatic logic [2:0] next_req(
    input logic [NUM_REQ-1:0] r,
    input logic [2:0]         from
  );
    for (int i = 1; i <= NUM_REQ; i++) begin
      logic [2:0] idx;
      idx = (3'(from) + 3'(i)) % 3'(NUM_REQ);
      if (r[idx]) return idx;
    end
    return 3'(NUM_REQ);  // sentinel: no request
  endfunction

  //===========================================================================
  // Sequential
  //===========================================================================
  always_ff @(posedge clk or negedge rst_n) begin : seq
    if (!rst_n) begin
      cs     <= ST_IDLE;
      hold_q <= '0;
      last_q <= '0;
    end else begin
      cs     <= ns;
      hold_q <= hold_d;
      last_q <= last_d;
    end
  end

  //===========================================================================
  // Next-state logic
  //===========================================================================
  always_comb begin : nsl
    ns     = cs;
    hold_d = hold_q;
    last_d = last_q;

    unique case (cs)

      ST_IDLE: begin
        hold_d = '0;
        if (|req) begin
          // Find first requester starting from (last_q + 1)
          logic [2:0] nxt;
          nxt = next_req(req, last_q);
          if (nxt < 3'(NUM_REQ)) begin
            ns     = state_t'(nxt + 3'd1);
            last_d = nxt;
            hold_d = HOLD_W'(HOLD_CYCLES);
          end
        end
      end

      ST_GRANT_0, ST_GRANT_1, ST_GRANT_2, ST_GRANT_3: begin
        logic [2:0] cur_gnt;
        cur_gnt = 3'(cs) - 3'd1;  // which requester we're serving

        if (hold_q > '0) begin
          hold_d = hold_q - 1'b1;
        end else begin
          // Hold expired or request deasserted — advance
          if (!req[cur_gnt] || hold_q == '0) begin
            logic [2:0] nxt;
            nxt = next_req(req, cur_gnt);
            if (nxt < 3'(NUM_REQ) && req != '0) begin
              ns     = state_t'(nxt + 3'd1);
              last_d = nxt;
              hold_d = HOLD_W'(HOLD_CYCLES);
            end else begin
              ns = ST_IDLE;
            end
          end
        end
      end

      default: ns = ST_IDLE;
    endcase
  end

  //===========================================================================
  // Output logic — Moore
  //===========================================================================
  always_comb begin : op
    gnt       = '0;
    gnt_valid = 1'b0;

    unique case (cs)
      ST_IDLE:    /* no grant */ ;
      ST_GRANT_0: begin gnt[0] = 1'b1; gnt_valid = 1'b1; end
      ST_GRANT_1: begin gnt[1] = 1'b1; gnt_valid = 1'b1; end
      ST_GRANT_2: begin gnt[2] = 1'b1; gnt_valid = 1'b1; end
      ST_GRANT_3: begin gnt[3] = 1'b1; gnt_valid = 1'b1; end
      default:    /* no grant */ ;
    endcase
  end

  //===========================================================================
  // SVA Assertions
  //===========================================================================
`ifndef SYNTHESIS

  // A1 — gnt is zero or one-hot (never two grants simultaneously)
  A1_gnt_onehot: assert property (
    @(posedge clk) disable iff (!rst_n)
    (gnt == '0) || is_one_hot(16'(gnt))
  ) else $fatal(2, "[RR_ARB] A1: Multiple grants simultaneously: gnt=%0b", gnt);

  // A2 — Grant only if corresponding request is active
  genvar gi;
  generate
    for (gi = 0; gi < NUM_REQ; gi++) begin : g_req_check
      assert property (
        @(posedge clk) disable iff (!rst_n)
        gnt[gi] |-> req[gi]
      ) else $error("[RR_ARB] A2: Grant to requester %0d without request", gi);
    end
  endgenerate

  // A3 — No grant when no requests
  A3_no_phantom_grant: assert property (
    @(posedge clk) disable iff (!rst_n)
    (req == '0) |=> (gnt == '0)
  ) else $error("[RR_ARB] A3: Grant persisted after all requests deasserted");

  // A4 — Round-robin order: GRANT_0 followed eventually by GRANT_1 (if req[1])
  A4_rr_order_0_to_1: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == ST_GRANT_0 && req[1]) |-> ##[1:2*NUM_REQ+1] gnt[1]
  ) else $error("[RR_ARB] A4: Requester 1 starved after req[0] grant");

  // A5 — gnt_valid iff gnt != 0
  A5_valid_gnt: assert property (
    @(posedge clk) disable iff (!rst_n)
    gnt_valid == (|gnt)
  ) else $error("[RR_ARB] A5: gnt_valid inconsistent with gnt");

  // A6 — No unknown state
  A6_no_x: assert property (
    @(posedge clk) disable iff (!rst_n)
    !$isunknown(cs)
  ) else $error("[RR_ARB] A6: Unknown state");

  // A7 — Grant valid state: if in GRANT_N, gnt[N] must be 1
  A7_grant_state_output: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == ST_GRANT_0) |-> gnt[0]
  ) else $error("[RR_ARB] A7: GRANT_0 state without gnt[0]");

  // Coverage: all four requesters get grants
  COV_gnt0: cover property (@(posedge clk) gnt[0]);
  COV_gnt1: cover property (@(posedge clk) gnt[1]);
  COV_gnt2: cover property (@(posedge clk) gnt[2]);
  COV_gnt3: cover property (@(posedge clk) gnt[3]);
  COV_all_req: cover property (@(posedge clk) req == 4'hF);  // all requesting
  COV_rr_full_cycle: cover property (
    @(posedge clk)
    cs==ST_GRANT_0 ##[1:20] cs==ST_GRANT_1
    ##[1:20] cs==ST_GRANT_2 ##[1:20] cs==ST_GRANT_3
    ##[1:20] cs==ST_GRANT_0
  );

`endif

endmodule : round_robin_arbiter
