//=============================================================================
// File        : vending_machine_moore.sv
// Project     : FSM Library — Reusable Finite State Machines
// Description : Vending Machine Controller — Moore FSM.
//
//   Accepts 10p, 20p, and 50p coins. Item costs 60p.
//   Returns change if overpaid. Cancel button refunds all coins.
//
//   Moore machine: outputs (dispense, return_coin, change_amount) are
//   driven purely by the current state.
//
//   Coin accumulation is handled by a DATAPATH counter (coin_total_q)
//   controlled by FSM. This separates control (FSM) from data (counter),
//   a clean design pattern.
//
//   States:
//     IDLE        – waiting for first coin
//     ACCEPTING   – coins being inserted, total < ITEM_COST
//     EXACT       – total == ITEM_COST, ready to dispense
//     OVERPAID    – total > ITEM_COST, dispense and prepare change
//     DISPENSING  – item released (one-cycle pulse)
//     CHANGE_OUT  – returning change coin-by-coin
//     REFUND      – cancel pressed, returning all coins
//
//   Assertions:
//     A1  dispense_out only in DISPENSING
//     A2  change_out only in CHANGE_OUT
//     A3  coin_total never exceeds max overpay (170p: 50+50+50+20)
//     A4  dispense follows EXACT or OVERPAID state
//     A5  idle state reached after DISPENSING+CHANGE_OUT sequence
//     A6  cancel/refund only from IDLE or ACCEPTING
//=============================================================================

`include "../../rtl/pkg/fsm_pkg.sv"

module vending_machine_moore
  import fsm_pkg::*;
#(
  parameter int ITEM_COST   = 60,   // pence
  parameter int MAX_CHANGE  = 110,  // max change = 50+50+10 = 110p
  parameter int TOTAL_W     = 8     // coin total counter width
)(
  input  logic         clk,
  input  logic         rst_n,
  input  coin_e        coin_in,     // coin inserted this cycle (NO_COIN if none)
  input  logic         cancel,      // refund all coins
  input  logic         change_ack,  // pulsed when change coin dispensed
  output logic         dispense_out, // item dispensed (one clock pulse)
  output logic         change_out,   // change coin dispensed (one clock pulse)
  output logic [7:0]   change_amount, // how many pence still owed as change
  output logic         ready,         // accepting coins
  output logic         fault,         // illegal state reached
  output logic [2:0]   dbg_state
);

  //===========================================================================
  // State type
  //===========================================================================
  typedef enum logic [2:0] {
    ST_IDLE       = 3'd0,
    ST_ACCEPTING  = 3'd1,
    ST_EXACT      = 3'd2,
    ST_OVERPAID   = 3'd3,
    ST_DISPENSING = 3'd4,
    ST_CHANGE_OUT = 3'd5,
    ST_REFUND     = 3'd6
  } state_t;

  state_t cs, ns;

  //===========================================================================
  // Datapath registers
  //===========================================================================
  logic [TOTAL_W-1:0] coin_total_q, coin_total_d;  // running total
  logic [TOTAL_W-1:0] change_q,     change_d;       // change still to return

  // Coin value decode
  logic [TOTAL_W-1:0] coin_value;
  always_comb begin
    unique case (coin_in)
      COIN_10P: coin_value = TOTAL_W'(10);
      COIN_20P: coin_value = TOTAL_W'(20);
      COIN_50P: coin_value = TOTAL_W'(50);
      default:  coin_value = '0;
    endcase
  end

  logic coin_inserted;
  assign coin_inserted = (coin_in != NO_COIN);
  assign dbg_state     = cs;
  assign change_amount = change_q;

  //===========================================================================
  // Sequential
  //===========================================================================
  always_ff @(posedge clk or negedge rst_n) begin : seq
    if (!rst_n) begin
      cs           <= ST_IDLE;
      coin_total_q <= '0;
      change_q     <= '0;
    end else begin
      cs           <= ns;
      coin_total_q <= coin_total_d;
      change_q     <= change_d;
    end
  end

  //===========================================================================
  // Combinational: next-state and datapath control
  //===========================================================================
  always_comb begin : nsl
    ns           = cs;
    coin_total_d = coin_total_q;
    change_d     = change_q;

    unique case (cs)

      ST_IDLE: begin
        if (coin_inserted) begin
          coin_total_d = coin_value;
          if (coin_value == TOTAL_W'(ITEM_COST))
            ns = ST_EXACT;
          else if (coin_value > TOTAL_W'(ITEM_COST))
            ns = ST_OVERPAID;
          else
            ns = ST_ACCEPTING;
        end
      end

      ST_ACCEPTING: begin
        if (cancel) begin
          ns = ST_REFUND;
        end else if (coin_inserted) begin
          coin_total_d = coin_total_q + coin_value;
          if (coin_total_d == TOTAL_W'(ITEM_COST))
            ns = ST_EXACT;
          else if (coin_total_d > TOTAL_W'(ITEM_COST))
            ns = ST_OVERPAID;
          // else stay in ACCEPTING
        end
      end

      ST_EXACT: begin
        change_d = '0;
        ns       = ST_DISPENSING;
      end

      ST_OVERPAID: begin
        change_d = coin_total_q - TOTAL_W'(ITEM_COST);
        ns       = ST_DISPENSING;
      end

      ST_DISPENSING: begin
        coin_total_d = '0;
        if (change_q > '0)
          ns = ST_CHANGE_OUT;
        else
          ns = ST_IDLE;
      end

      ST_CHANGE_OUT: begin
        // Each change_ack pulse represents one coin returned
        // Simplification: return 10p coins one at a time
        if (change_ack) begin
          change_d = change_q - TOTAL_W'(10);  // return 10p
          if (change_q <= TOTAL_W'(10))
            ns = ST_IDLE;
        end
      end

      ST_REFUND: begin
        // Return coins: one cycle per 10p, simplified
        if (change_ack) begin
          if (coin_total_q >= TOTAL_W'(10))
            coin_total_d = coin_total_q - TOTAL_W'(10);
          else begin
            coin_total_d = '0;
            ns = ST_IDLE;
          end
        end
      end

      default: ns = ST_IDLE;

    endcase
  end

  //===========================================================================
  // Output logic — MOORE: functions of cs only
  //===========================================================================
  always_comb begin : op
    dispense_out = 1'b0;
    change_out   = 1'b0;
    ready        = 1'b0;
    fault        = 1'b0;

    unique case (cs)
      ST_IDLE:       ready        = 1'b1;
      ST_ACCEPTING:  ready        = 1'b1;
      ST_EXACT:      /* transitional — no direct output */ ;
      ST_OVERPAID:   /* transitional — no direct output */ ;
      ST_DISPENSING: dispense_out = 1'b1;
      ST_CHANGE_OUT: change_out   = 1'b1;
      ST_REFUND:     change_out   = 1'b1;   // re-use change_out for refund
      default:       fault        = 1'b1;   // unreachable
    endcase
  end

  //===========================================================================
  // SVA Assertions
  //===========================================================================
`ifndef SYNTHESIS

  // A1 — dispense_out only in DISPENSING state
  A1_dispense_state: assert property (
    @(posedge clk) disable iff (!rst_n)
    dispense_out |-> (cs == ST_DISPENSING)
  ) else $error("[VM_MOORE] A1: dispense_out outside DISPENSING");

  // A2 — change_out only in CHANGE_OUT or REFUND
  A2_change_state: assert property (
    @(posedge clk) disable iff (!rst_n)
    change_out |-> (cs == ST_CHANGE_OUT || cs == ST_REFUND)
  ) else $error("[VM_MOORE] A2: change_out outside change states");

  // A3 — coin_total never exceeds maximum possible overpay
  A3_max_total: assert property (
    @(posedge clk) disable iff (!rst_n)
    coin_total_q <= TOTAL_W'(ITEM_COST + MAX_CHANGE)
  ) else $error("[VM_MOORE] A3: coin_total overflow: %0d", coin_total_q);

  // A4 — dispensing is always preceded by EXACT or OVERPAID
  A4_dispense_precondition: assert property (
    @(posedge clk) disable iff (!rst_n)
    $rose(dispense_out) |-> ($past(cs,1) == ST_EXACT || $past(cs,1) == ST_OVERPAID)
  ) else $error("[VM_MOORE] A4: DISPENSING entered illegally");

  // A5 — after DISPENSING (with no change), return to IDLE within 2 cycles
  A5_idle_after_exact: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == ST_DISPENSING && change_q == '0) |=> ##[0:1] (cs == ST_IDLE)
  ) else $error("[VM_MOORE] A5: Did not return to IDLE after exact payment");

  // A6 — fault output never asserted in correct operation
  A6_no_fault: assert property (
    @(posedge clk) disable iff (!rst_n)
    !fault
  ) else $fatal(1, "[VM_MOORE] A6: Fault state reached — unreachable state entered");

  // A7 — no state unknown
  A7_no_x: assert property (
    @(posedge clk) disable iff (!rst_n)
    !$isunknown(cs)
  ) else $error("[VM_MOORE] A7: Unknown state");

  // Coverage: all paths
  COV_exact_pay:    cover property (@(posedge clk) $rose(dispense_out) && change_q=='0);
  COV_overpay:      cover property (@(posedge clk) $rose(dispense_out) && change_q>'0);
  COV_cancel:       cover property (@(posedge clk) cs == ST_REFUND);
  COV_50p_direct:   cover property (@(posedge clk) coin_in==COIN_50P && $past(cs)==ST_IDLE);
  COV_multi_coins:  cover property (@(posedge clk) cs==ST_ACCEPTING [*3]);

`endif

endmodule : vending_machine_moore
