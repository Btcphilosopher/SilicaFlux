//=============================================================================
// File        : seq_det_generic.sv
// Project     : FSM Library — Reusable Finite State Machines
// Description : Parameterized Sequence Detector — KMP FSM approach.
//
//   Detects an arbitrary N-bit pattern in a serial bitstream.
//   Uses the Knuth-Morris-Pratt (KMP) failure function to compute optimal
//   state-transition fall-back values at elaboration time.
//
//   KMP avoids rescanning previously-matched characters.  For hardware:
//     • Each state = number of pattern bits matched so far (0..N)
//     • Failure function f[i] = length of longest proper suffix of
//       pattern[0..i-1] that is also a prefix.
//     • Precomputed as a localparams array (unrolled generate loop).
//
//   Parameters:
//     SEQ_LEN     – pattern length in bits (2–8)
//     PATTERN     – the bit pattern to detect (MSB = first received)
//     OVERLAPPING – allow overlapping matches
//
//   Example patterns:
//     4'b1011  – the worked example in Moore/Mealy files
//     4'b1010  – demonstrates non-trivial failure function (f[3]=2)
//     6'b101101 – longer pattern with internal repetition
//
//   Moore implementation (detected is a registered state output).
//
// Assertions:
//   A1  detected only in state SEQ_LEN
//   A2  Every transition uses a valid next state (0..SEQ_LEN)
//   A3  State bounded to [0, SEQ_LEN]
//=============================================================================

`include "../../rtl/pkg/fsm_pkg.sv"

module seq_det_generic
  import fsm_pkg::*;
#(
  parameter  int           SEQ_LEN     = 4,
  parameter  logic [7:0]   PATTERN     = 8'b1011_0000,  // MSB-first, pad unused LSBs
  parameter  bit           OVERLAPPING = 1'b1
)(
  input  logic clk,
  input  logic rst_n,
  input  logic data_in,
  output logic detected,
  output logic [$clog2(SEQ_LEN+1)-1:0] dbg_state
);

  // ──────────────────────────────────────────────────────────────────────
  // State register: integer state in range [0, SEQ_LEN]
  // State = number of pattern bits matched so far.
  // ──────────────────────────────────────────────────────────────────────
  localparam int STATE_W = $clog2(SEQ_LEN + 2);  // enough bits

  logic [STATE_W-1:0] cs, ns;
  assign dbg_state = cs[$clog2(SEQ_LEN+1)-1:0];

  // ──────────────────────────────────────────────────────────────────────
  // KMP failure function: computed at elaboration via initial block
  // fail[i] = longest proper prefix of pattern[0..i-1] that is a suffix
  // ──────────────────────────────────────────────────────────────────────
  logic [STATE_W-1:0] fail [SEQ_LEN];  // fail[0..SEQ_LEN-1]

  // Helper: pattern bit at position i (MSB = bit received first = bit 7)
  function automatic logic pat_bit(input int i);
    return PATTERN[7 - i];
  endfunction

  // Build failure function at time-zero (synthesis: tool unrolls)
  integer f_k;
  initial begin
    fail[0] = '0;
    f_k = 0;
    for (int i = 1; i < SEQ_LEN; i++) begin
      while (f_k > 0 && pat_bit(f_k) != pat_bit(i))
        f_k = int'(fail[f_k - 1]);
      if (pat_bit(f_k) == pat_bit(i))
        f_k++;
      fail[i] = STATE_W'(f_k);
    end
    // Debug: print failure function
    $display("[SEQ_GEN] Pattern=%0b, SEQ_LEN=%0d", PATTERN[7:8-SEQ_LEN], SEQ_LEN);
    for (int i = 0; i < SEQ_LEN; i++)
      $display("[SEQ_GEN]   fail[%0d] = %0d", i, fail[i]);
  end

  // ──────────────────────────────────────────────────────────────────────
  // Sequential
  // ──────────────────────────────────────────────────────────────────────
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) cs <= '0;
    else        cs <= ns;

  // ──────────────────────────────────────────────────────────────────────
  // Next-state logic using KMP transitions
  // ──────────────────────────────────────────────────────────────────────
  always_comb begin : kmp_nsl
    // After full match (DETECT state): overlapping uses fail[SEQ_LEN-1] as
    // the resume point; non-overlapping resets to 0.
    logic [STATE_W-1:0] resume;
    resume = OVERLAPPING ? fail[SEQ_LEN-1] : '0;

    if (cs == STATE_W'(SEQ_LEN)) begin
      // Currently in detect state — start fresh or overlapping resume
      if (pat_bit(int'(resume)) == data_in)
        ns = resume + 1'b1;
      else
        ns = '0;
    end else begin
      // KMP: find longest prefix that is a suffix of matched + data_in
      logic [STATE_W-1:0] k;
      k = cs;
      while (k > '0 && pat_bit(int'(k)) != data_in)
        k = fail[int'(k) - 1];
      if (pat_bit(int'(k)) == data_in)
        ns = k + 1'b1;
      else
        ns = '0;
    end
  end

  // Moore output
  assign detected = (cs == STATE_W'(SEQ_LEN));

  //===========================================================================
  // SVA Assertions
  //===========================================================================
`ifndef SYNTHESIS

  // A1 — detected only when state == SEQ_LEN
  A1_detect_state: assert property (
    @(posedge clk) disable iff (!rst_n)
    detected |-> (cs == STATE_W'(SEQ_LEN))
  ) else $error("[SEQ_GEN] A1: detected outside SEQ_LEN state");

  // A2 — State bounded within valid range
  A2_state_bounds: assert property (
    @(posedge clk) disable iff (!rst_n)
    cs <= STATE_W'(SEQ_LEN)
  ) else $error("[SEQ_GEN] A2: State out of bounds: %0d", cs);

  // A3 — No unknown state
  A3_no_x: assert property (
    @(posedge clk) disable iff (!rst_n)
    !$isunknown(cs)
  ) else $error("[SEQ_GEN] A3: Unknown state");

  // Coverage
  COV_detect: cover property (@(posedge clk) detected);
  COV_two_det: cover property (@(posedge clk) detected ##[SEQ_LEN:$] detected);

`endif

endmodule : seq_det_generic


//=============================================================================
// Additional sequence detectors demonstrating different patterns
//=============================================================================

// ──────────────────────────────────────────────────────────────────────────
// Detector: "1010" overlapping
// Failure function: f[] = [0, 0, 1, 2]
// Pattern has internal repetition → non-trivial failure function
// S0─1→S1─0→S2─1→S3─0→DETECT
//                 S3─1→S1   (not S0: "1010_1" has prefix "1")
// ──────────────────────────────────────────────────────────────────────────
module seq_det_1010
  import fsm_pkg::*;
(
  input  logic clk, rst_n, data_in,
  output logic detected,
  output logic [2:0] dbg_state
);
  typedef enum logic [2:0] {
    S0=3'd0, S1=3'd1, S2=3'd2, S3=3'd3, S4=3'd4
  } state_t;

  state_t cs, ns;
  assign dbg_state = cs;
  assign detected  = (cs == S4);

  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) cs <= S0;
    else        cs <= ns;

  always_comb begin
    unique case (cs)
      S0: ns = data_in ? S1 : S0;
      S1: ns = data_in ? S1 : S2;     // "11" → S1
      S2: ns = data_in ? S3 : S0;
      S3: ns = data_in ? S1 : S4;     // "1011" → S4; stay consistent with KMP fail
      S4: ns = data_in ? S1 : S2;     // overlapping: "1010_0" → S2 (prefix "10")
      default: ns = S0;
    endcase
  end

`ifndef SYNTHESIS
  A_det: assert property (@(posedge clk) disable iff (!rst_n) detected |-> (cs==S4));
  A_s4: assert property (@(posedge clk) disable iff (!rst_n)
    cs==S4 |-> ($past(cs)==S3 && !$past(data_in)));
`endif
endmodule

// ──────────────────────────────────────────────────────────────────────────
// Detector: "110" — simple 3-bit Moore detector
// ──────────────────────────────────────────────────────────────────────────
module seq_det_110
  import fsm_pkg::*;
(
  input  logic clk, rst_n, data_in,
  output logic detected,
  output logic [1:0] dbg_state
);
  typedef enum logic [1:0] {S0=2'd0, S1=2'd1, S2=2'd2, S3=2'd3} state_t;
  state_t cs, ns;

  assign dbg_state = cs;
  assign detected  = (cs == S3);

  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) cs <= S0;
    else        cs <= ns;

  always_comb begin
    unique case (cs)
      S0: ns = data_in ? S1 : S0;
      S1: ns = data_in ? S2 : S0;
      S2: ns = data_in ? S2 : S3;  // "110": third bit is 0
      S3: ns = data_in ? S1 : S0;  // after detect
      default: ns = S0;
    endcase
  end
endmodule
