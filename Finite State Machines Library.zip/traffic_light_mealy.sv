//=============================================================================
// File        : traffic_light_mealy.sv
// Project     : FSM Library — Reusable Finite State Machines
// Description : Traffic Light Controller — Mealy FSM, One-Hot Encoding.
//
//   Mealy machine: outputs are a function of CURRENT STATE + CURRENT INPUTS.
//   Key differences from the Moore version:
//     • ped_walk is generated combinationally from (GREEN state ∧ ped_req)
//       — no extra request latch needed, response is one cycle faster
//     • The "green-cut-short" output is asserted on the arc, not in a state
//     • One fewer state (no ST_PED_RED: walk is a direct Mealy output)
//
//   Tradeoff: Mealy outputs can GLITCH when inputs change asynchronously.
//   Mitigation: register Mealy outputs downstream if glitch-free outputs
//   are required (add one cycle of pipeline latency).
//
// State encoding: ONE-HOT — 5 bits, one set per state
//   (* fsm_encoding = "one_hot" *) synthesis hint shown in typedef comments.
//
//   ST_RED       = 5'b00001
//   ST_RED_AMBER = 5'b00010
//   ST_GREEN     = 5'b00100
//   ST_AMBER     = 5'b01000
//   ST_EMERGENCY = 5'b10000
//
// Assertions:
//   A1  One-hot validity (exactly one bit set)
//   A2  Red ∧ Green forbidden (safety)
//   A3  Walk only assertable from GREEN state
//   A4  Emergency forces EMERGENCY within one clock
//   A5  Valid one-hot encoding preserved across transitions
//=============================================================================

`include "../../rtl/pkg/fsm_pkg.sv"

module traffic_light_mealy
  import fsm_pkg::*;
#(
  parameter int TIMER_W      = 8,
  parameter int RED_CYCLES   = 100,
  parameter int RA_CYCLES    = 8,
  parameter int GREEN_CYCLES = 80,
  parameter int AMBER_CYCLES = 25
)(
  input  logic clk,
  input  logic rst_n,
  input  logic pedestrian_req,   // pedestrian request — drives Mealy walk output
  input  logic emergency,
  output logic red,
  output logic amber,
  output logic green,
  output logic ped_walk,         // MEALY output: walk = GREEN ∧ ped_req
  output logic [4:0] dbg_state
);

  //===========================================================================
  // State type — ONE-HOT ENCODING (5 bits)
  // Synthesis attribute hint: (* fsm_encoding = "one_hot" *)
  //===========================================================================
  typedef enum logic [4:0] {
    ST_RED       = 5'b00001,  // one-hot bit 0
    ST_RED_AMBER = 5'b00010,  // one-hot bit 1
    ST_GREEN     = 5'b00100,  // one-hot bit 2
    ST_AMBER     = 5'b01000,  // one-hot bit 3
    ST_EMERGENCY = 5'b10000   // one-hot bit 4
  } state_t;

  (* fsm_encoding = "one_hot" *)
  state_t cs, ns;

  logic [TIMER_W-1:0] timer_q, timer_d;
  logic               timer_zero;

  assign timer_zero = (timer_q == '0);
  assign dbg_state  = cs;

  //===========================================================================
  // Sequential
  //===========================================================================
  always_ff @(posedge clk or negedge rst_n) begin : seq
    if (!rst_n) begin
      cs      <= ST_RED;
      timer_q <= TIMER_W'(RED_CYCLES);
    end else begin
      cs      <= ns;
      timer_q <= timer_d;
    end
  end

  //===========================================================================
  // Combinational: next-state, timer, AND Mealy outputs in one block
  // Mealy outputs (ped_walk) are assigned here alongside state transitions
  //===========================================================================
  always_comb begin : nsl_and_mealy_op
    // Defaults
    ns        = cs;
    timer_d   = timer_zero ? timer_q : (timer_q - 1'b1);
    // Mealy outputs — driven combinationally
    red       = 1'b0;
    amber     = 1'b0;
    green     = 1'b0;
    ped_walk  = 1'b0;

    // Base output from current state (Mealy still assigns most outputs from state)
    unique case (cs)
      ST_RED:        red   = 1'b1;
      ST_RED_AMBER:  begin red = 1'b1; amber = 1'b1; end
      ST_GREEN:      green = 1'b1;
      ST_AMBER:      amber = 1'b1;
      ST_EMERGENCY:  red   = 1'b1;
      default:       red   = 1'b1;
    endcase

    // True Mealy output: walk depends on BOTH state AND input
    // No latch required — one cycle faster response than Moore version
    ped_walk = (cs == ST_GREEN) && pedestrian_req;

    // Emergency override
    if (emergency && cs != ST_EMERGENCY) begin
      ns      = ST_EMERGENCY;
      timer_d = TIMER_W'(RED_CYCLES);
      red     = 1'b1;
      amber   = 1'b0;
      green   = 1'b0;

    end else begin
      unique case (cs)

        ST_RED: begin
          if (timer_zero) begin
            ns      = ST_RED_AMBER;
            timer_d = TIMER_W'(RA_CYCLES);
          end
        end

        ST_RED_AMBER: begin
          if (timer_zero) begin
            ns      = ST_GREEN;
            timer_d = TIMER_W'(GREEN_CYCLES);
          end
        end

        ST_GREEN: begin
          // Mealy: if pedestrian is requesting, cut green phase short
          // (after minimum 20 cycles) — output changes on input change, no latch
          if (timer_zero || (pedestrian_req && timer_q < TIMER_W'(20))) begin
            ns      = ST_AMBER;
            timer_d = TIMER_W'(AMBER_CYCLES);
            green   = 1'b0;  // de-assert on the transitioning arc
            amber   = 1'b1;  // Mealy output: amber asserted on transition arc
          end
        end

        ST_AMBER: begin
          if (timer_zero) begin
            ns      = ST_RED;
            timer_d = TIMER_W'(RED_CYCLES);
          end
        end

        ST_EMERGENCY: begin
          timer_d = TIMER_W'(RED_CYCLES);
          if (!emergency) begin
            ns      = ST_RED;
            timer_d = TIMER_W'(RED_CYCLES);
          end
        end

        default: begin
          ns      = ST_RED;
          timer_d = TIMER_W'(RED_CYCLES);
        end

      endcase
    end
  end

  //===========================================================================
  // SVA Assertions
  //===========================================================================
`ifndef SYNTHESIS

  // A1 — One-hot validity: exactly one state bit asserted at all times
  A1_one_hot: assert property (
    @(posedge clk) disable iff (!rst_n)
    is_one_hot(16'(cs))
  ) else $error("[TL_MEALY] A1: State is not one-hot: cs=%0b", cs);

  // A2 — SAFETY: Red and Green never simultaneously active
  A2_no_rg: assert property (
    @(posedge clk) disable iff (!rst_n)
    !(red && green)
  ) else $fatal(2, "[TL_MEALY] A2: SAFETY FAULT – Red and Green simultaneously active!");

  // A3 — Walk only assertable when in GREEN state (Mealy: also requires ped_req)
  A3_walk_requires_green: assert property (
    @(posedge clk) disable iff (!rst_n)
    ped_walk |-> (cs == ST_GREEN)
  ) else $error("[TL_MEALY] A3: Mealy walk output outside GREEN state");

  // A4 — Emergency forces EMERGENCY within one clock
  A4_emergency: assert property (
    @(posedge clk) disable iff (!rst_n)
    ($rose(emergency) && cs != ST_EMERGENCY) |=> (cs == ST_EMERGENCY)
  ) else $error("[TL_MEALY] A4: Emergency did not force EMERGENCY state");

  // A5 — One-hot preserved after every transition
  A5_onehot_preserved: assert property (
    @(posedge clk) disable iff (!rst_n)
    ##1 is_one_hot(16'(cs))
  ) else $error("[TL_MEALY] A5: One-hot broken after transition");

  // A6 — Outputs known (no X/Z)
  A6_outputs_known: assert property (
    @(posedge clk) disable iff (!rst_n)
    !$isunknown({red, amber, green})
  ) else $error("[TL_MEALY] A6: Unknown output");

  // Coverage: Mealy walk asserted (requires ped_req during GREEN)
  COV_mealy_walk: cover property (
    @(posedge clk) cs == ST_GREEN && pedestrian_req && ped_walk
  );

  COV_full_sequence: cover property (
    @(posedge clk)
    cs == ST_RED ##[1:200] cs == ST_RED_AMBER ##[1:10]
    cs == ST_GREEN ##[1:100] cs == ST_AMBER ##[1:30] cs == ST_RED
  );

`endif

endmodule : traffic_light_mealy
