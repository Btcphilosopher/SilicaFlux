//=============================================================================
// File        : traffic_light_encodings.sv
// Project     : FSM Library
// Description : Side-by-side comparison of Binary, Gray, and One-hot
//               encoding strategies for the same 4-state traffic light.
//               Instantiated by testbench to verify all three produce
//               identical functional behaviour with different bit patterns.
//
//   Encoding summary for 4 traffic-light states:
//
//   State        Binary   Gray    One-hot
//   ----------  -------  ------  ---------
//   RED          2'b00   2'b00   4'b0001
//   RED_AMBER    2'b01   2'b01   4'b0010
//   GREEN        2'b10   2'b11   4'b0100
//   AMBER        2'b11   2'b10   4'b1000
//
//   Gray advantage: RED↔RED_AMBER and GREEN↔AMBER transitions differ by
//   only 1 bit, eliminating simultaneous multi-bit glitches between
//   physically adjacent states.
//=============================================================================

`include "../../rtl/pkg/fsm_pkg.sv"

//-----------------------------------------------------------------------------
// Sub-module: 4-state traffic light core (logic independent of encoding)
// Encoding injected by the wrapper via state typedef
//-----------------------------------------------------------------------------

// ──────────────────────────────────────────────────────────────────────────────
// BINARY ENCODING
// ──────────────────────────────────────────────────────────────────────────────
module tl_binary
  import fsm_pkg::*;
#(parameter int TIMER_W = 8,
  parameter int RED_CYC = 50, parameter int RA_CYC = 6,
  parameter int GRN_CYC = 40, parameter int AMB_CYC = 20)
(
  input  logic clk, rst_n, ped_req, emergency,
  output logic red, amber, green, ped_walk,
  output logic [1:0] raw_state  // expose raw bits for observation
);
  typedef enum logic [1:0] {    // BINARY: values 0–3
    ST_RED       = 2'b00,
    ST_RED_AMBER = 2'b01,
    ST_GREEN     = 2'b10,
    ST_AMBER     = 2'b11
  } state_t;

  state_t             cs, ns;
  logic [TIMER_W-1:0] t_q, t_d;
  logic               ped_q, ped_d;
  logic               tz;

  assign tz        = (t_q == '0);
  assign raw_state = cs;

  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin cs <= ST_RED; t_q <= TIMER_W'(RED_CYC); ped_q <= 0; end
    else        begin cs <= ns;     t_q <= t_d;                ped_q <= ped_d; end

  always_comb begin
    ns    = cs;  t_d = tz ? t_q : t_q - 1'b1;  ped_d = ped_q | ped_req;
    if (emergency) begin ns = ST_RED; t_d = TIMER_W'(RED_CYC); end
    else unique case (cs)
      ST_RED:       if (tz) begin ns = ST_RED_AMBER; t_d = TIMER_W'(RA_CYC);  end
      ST_RED_AMBER: if (tz) begin ns = ST_GREEN;     t_d = TIMER_W'(GRN_CYC); end
      ST_GREEN:     if (tz || ped_q) begin ns = ST_AMBER; t_d = TIMER_W'(AMB_CYC); end
      ST_AMBER:     if (tz) begin ns = ST_RED; t_d = TIMER_W'(RED_CYC); ped_d = 0; end
      default:      ns = ST_RED;
    endcase
  end

  always_comb begin
    {red,amber,green,ped_walk} = '0;
    unique case (cs)
      ST_RED:       red   = 1;
      ST_RED_AMBER: begin red = 1; amber = 1; end
      ST_GREEN:     begin green = 1; ped_walk = ped_q; end
      ST_AMBER:     amber = 1;
      default:      red = 1;
    endcase
  end
endmodule

// ──────────────────────────────────────────────────────────────────────────────
// GRAY ENCODING
// ──────────────────────────────────────────────────────────────────────────────
module tl_gray
  import fsm_pkg::*;
#(parameter int TIMER_W = 8,
  parameter int RED_CYC = 50, parameter int RA_CYC = 6,
  parameter int GRN_CYC = 40, parameter int AMB_CYC = 20)
(
  input  logic clk, rst_n, ped_req, emergency,
  output logic red, amber, green, ped_walk,
  output logic [1:0] raw_state
);
  // Gray code: adjacent traffic states differ by exactly 1 bit
  // RED(00) ↔ RED_AMBER(01): differ in bit 0     ✓
  // RED_AMBER(01) ↔ GREEN(11): differ in bit 1   ✓
  // GREEN(11) ↔ AMBER(10): differ in bit 0       ✓
  // AMBER(10) → RED(00): differs by 2 bits       ✗ (wrap-around breaks Gray)
  typedef enum logic [1:0] {
    ST_RED       = 2'b00,  // Gray 0
    ST_RED_AMBER = 2'b01,  // Gray 1
    ST_GREEN     = 2'b11,  // Gray 3
    ST_AMBER     = 2'b10   // Gray 2
  } state_t;

  state_t             cs, ns;
  logic [TIMER_W-1:0] t_q, t_d;
  logic               ped_q, ped_d;
  logic               tz;

  assign tz        = (t_q == '0);
  assign raw_state = cs;

  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin cs <= ST_RED; t_q <= TIMER_W'(RED_CYC); ped_q <= 0; end
    else        begin cs <= ns;     t_q <= t_d;                ped_q <= ped_d; end

  always_comb begin
    ns    = cs;  t_d = tz ? t_q : t_q - 1'b1;  ped_d = ped_q | ped_req;
    if (emergency) begin ns = ST_RED; t_d = TIMER_W'(RED_CYC); end
    else unique case (cs)
      ST_RED:       if (tz) begin ns = ST_RED_AMBER; t_d = TIMER_W'(RA_CYC);  end
      ST_RED_AMBER: if (tz) begin ns = ST_GREEN;     t_d = TIMER_W'(GRN_CYC); end
      ST_GREEN:     if (tz || ped_q) begin ns = ST_AMBER; t_d = TIMER_W'(AMB_CYC); end
      ST_AMBER:     if (tz) begin ns = ST_RED; t_d = TIMER_W'(RED_CYC); ped_d = 0; end
      default:      ns = ST_RED;
    endcase
  end

  always_comb begin
    {red,amber,green,ped_walk} = '0;
    unique case (cs)
      ST_RED:       red   = 1;
      ST_RED_AMBER: begin red = 1; amber = 1; end
      ST_GREEN:     begin green = 1; ped_walk = ped_q; end
      ST_AMBER:     amber = 1;
      default:      red = 1;
    endcase
  end
endmodule

// ──────────────────────────────────────────────────────────────────────────────
// ONE-HOT ENCODING
// ──────────────────────────────────────────────────────────────────────────────
module tl_onehot
  import fsm_pkg::*;
#(parameter int TIMER_W = 8,
  parameter int RED_CYC = 50, parameter int RA_CYC = 6,
  parameter int GRN_CYC = 40, parameter int AMB_CYC = 20)
(
  input  logic clk, rst_n, ped_req, emergency,
  output logic red, amber, green, ped_walk,
  output logic [3:0] raw_state
);
  // One-hot: exactly one bit set per state. State decode = direct bit test.
  // No decoder mux required: red = state[0], amber = state[1]|state[0], etc.
  typedef enum logic [3:0] {
    ST_RED       = 4'b0001,
    ST_RED_AMBER = 4'b0010,
    ST_GREEN     = 4'b0100,
    ST_AMBER     = 4'b1000
  } state_t;

  (* fsm_encoding = "one_hot" *)
  state_t             cs, ns;
  logic [TIMER_W-1:0] t_q, t_d;
  logic               ped_q, ped_d;
  logic               tz;

  assign tz        = (t_q == '0);
  assign raw_state = cs;

  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin cs <= ST_RED; t_q <= TIMER_W'(RED_CYC); ped_q <= 0; end
    else        begin cs <= ns;     t_q <= t_d;                ped_q <= ped_d; end

  always_comb begin
    ns    = cs;  t_d = tz ? t_q : t_q - 1'b1;  ped_d = ped_q | ped_req;
    if (emergency) begin ns = ST_RED; t_d = TIMER_W'(RED_CYC); end
    else unique case (cs)
      ST_RED:       if (tz) begin ns = ST_RED_AMBER; t_d = TIMER_W'(RA_CYC);  end
      ST_RED_AMBER: if (tz) begin ns = ST_GREEN;     t_d = TIMER_W'(GRN_CYC); end
      ST_GREEN:     if (tz || ped_q) begin ns = ST_AMBER; t_d = TIMER_W'(AMB_CYC); end
      ST_AMBER:     if (tz) begin ns = ST_RED; t_d = TIMER_W'(RED_CYC); ped_d = 0; end
      default:      ns = ST_RED;
    endcase
  end

  // One-hot output decode: direct bit assignments (no mux/case needed)
  assign red      = cs[0] | cs[1];          // RED or RED_AMBER
  assign amber    = cs[1] | cs[3];          // RED_AMBER or AMBER
  assign green    = cs[2];                  // GREEN only
  assign ped_walk = cs[2] & ped_q;          // green && latched request

`ifndef SYNTHESIS
  // One-hot validity assertion
  A_onehot: assert property (
    @(posedge clk) disable iff (!rst_n)
    is_one_hot(16'(cs))
  ) else $error("[TL_ONEHOT] One-hot violated: cs=%0b", cs);
`endif

endmodule

// ──────────────────────────────────────────────────────────────────────────────
// ENCODING COMPARISON WRAPPER
// Instantiates all three variants; testbench can verify equivalence
// ──────────────────────────────────────────────────────────────────────────────
module traffic_light_encodings
  import fsm_pkg::*;
#(parameter int TIMER_W = 8,
  parameter int RED_CYC = 50, parameter int RA_CYC = 6,
  parameter int GRN_CYC = 40, parameter int AMB_CYC = 20)
(
  input  logic clk, rst_n, ped_req, emergency,
  // Binary outputs
  output logic bin_red, bin_amber, bin_green, bin_ped_walk,
  output logic [1:0] bin_raw,
  // Gray outputs
  output logic gray_red, gray_amber, gray_green, gray_ped_walk,
  output logic [1:0] gray_raw,
  // One-hot outputs
  output logic oh_red, oh_amber, oh_green, oh_ped_walk,
  output logic [3:0] oh_raw
);

  tl_binary #(TIMER_W, RED_CYC, RA_CYC, GRN_CYC, AMB_CYC) u_bin (
    .clk, .rst_n, .ped_req, .emergency,
    .red(bin_red), .amber(bin_amber), .green(bin_green),
    .ped_walk(bin_ped_walk), .raw_state(bin_raw)
  );

  tl_gray #(TIMER_W, RED_CYC, RA_CYC, GRN_CYC, AMB_CYC) u_gray (
    .clk, .rst_n, .ped_req, .emergency,
    .red(gray_red), .amber(gray_amber), .green(gray_green),
    .ped_walk(gray_ped_walk), .raw_state(gray_raw)
  );

  tl_onehot #(TIMER_W, RED_CYC, RA_CYC, GRN_CYC, AMB_CYC) u_oh (
    .clk, .rst_n, .ped_req, .emergency,
    .red(oh_red), .amber(oh_amber), .green(oh_green),
    .ped_walk(oh_ped_walk), .raw_state(oh_raw)
  );

`ifndef SYNTHESIS
  // Cross-encoding equivalence check: all three must produce identical outputs
  EQ_red: assert property (
    @(posedge clk) disable iff (!rst_n)
    (bin_red == gray_red) && (bin_red == oh_red)
  ) else $error("[TL_ENC] Red output divergence between encodings");

  EQ_green: assert property (
    @(posedge clk) disable iff (!rst_n)
    (bin_green == gray_green) && (bin_green == oh_green)
  ) else $error("[TL_ENC] Green output divergence between encodings");

  // Cover: Gray state bits exhibit single-bit transitions (main Gray property)
  COV_gray_single_bit: cover property (
    @(posedge clk) $countones(gray_raw ^ $past(gray_raw)) == 1
  );
`endif

endmodule : traffic_light_encodings
