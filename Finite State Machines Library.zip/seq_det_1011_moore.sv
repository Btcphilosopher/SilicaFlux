//=============================================================================
// File        : seq_det_1011_moore.sv
// Project     : FSM Library — Reusable Finite State Machines
// Description : Sequence Detector for pattern "1011" — Moore FSM.
//
//   Moore machine: detected output is asserted in a dedicated DETECT state
//   (one cycle after the final matching bit), NOT on the transition arc.
//
//   State diagram (5 states):
//
//   S0 ──1──> S1 ──0──> S2 ──1──> S3 ──1──> S4 (out=1)
//    ^─ 0 ─┘  ^─ 1 ─┘   └─ 0 ──> S0       │
//                                           │ Non-overlapping: → S0
//                                           │ Overlapping:     → S1
//
//   State      Meaning
//   --------  ──────────────────────────────────────────────
//   S0         No useful prefix matched
//   S1         Matched "1"
//   S2         Matched "10"
//   S3         Matched "101"
//   S4         Matched "1011" → detected!  (output state)
//
//   Failure function transitions (KMP-inspired):
//   S1 + '1' → S1  (new '1' could start next match)
//   S2 + '0' → S0  (prefix "10" followed by '0' has no suffix-prefix)
//   S3 + '0' → S2  (suffix "10" of "101_0" matches prefix "10")
//   S4 + '0' → S0  (non-overlapping)  / S0 (overlapping, "1011_0": no pfx)
//   S4 + '1' → S0  (non-overlapping)  / S1 (overlapping, the final '1' of
//                                            "1011" begins new match)
//
//   Parameter OVERLAPPING selects mode.
//
// Assertions:
//   A1  detected output only in S4
//   A2  S0 always reachable (reset safe)
//   A3  State sequence never skips states forward
//   A4  Non-overlapping: after detect, always returns to S0 next cycle
//   A5  Overlapping: after detect+1, may be in S0 or S1 only
//=============================================================================

`include "../../rtl/pkg/fsm_pkg.sv"

module seq_det_1011_moore
  import fsm_pkg::*;
#(
  parameter bit OVERLAPPING = 1'b0  // 0=non-overlapping, 1=overlapping
)(
  input  logic clk,
  input  logic rst_n,
  input  logic data_in,   // serial input bit stream
  output logic detected,  // asserted for one clock when 1011 detected (Moore)
  output logic [2:0] dbg_state
);

  //===========================================================================
  // State type — Binary encoding (3 bits for 5 states)
  //===========================================================================
  typedef enum logic [2:0] {
    S0 = 3'd0,  // idle / no prefix
    S1 = 3'd1,  // matched "1"
    S2 = 3'd2,  // matched "10"
    S3 = 3'd3,  // matched "101"
    S4 = 3'd4   // matched "1011" → DETECT state
  } state_t;

  state_t cs, ns;
  assign dbg_state = cs;

  //===========================================================================
  // Sequential
  //===========================================================================
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) cs <= S0;
    else        cs <= ns;

  //===========================================================================
  // Next-state logic
  //===========================================================================
  always_comb begin : nsl
    ns = S0;  // default: fall back to idle

    unique case (cs)
      S0: ns = data_in ? S1 : S0;
      S1: ns = data_in ? S1 : S2;       // "11" → S1 (second '1' is new start)
      S2: ns = data_in ? S3 : S0;       // "100" → S0 (no useful prefix)
      S3: ns = data_in ? S4 : S2;       // "1010" → S2 ("10" prefix match)
      S4: begin
        // After detection: overlapping vs non-overlapping
        if (OVERLAPPING)
          ns = data_in ? S1 : S0;       // last '1' of "1011" can start new match
        else
          ns = S0;                      // non-overlapping: always restart
      end
      default: ns = S0;
    endcase
  end

  //===========================================================================
  // Output logic — MOORE: detected only in S4
  //===========================================================================
  assign detected = (cs == S4);

  //===========================================================================
  // SVA Assertions
  //===========================================================================
`ifndef SYNTHESIS

  // A1 — detected asserted only when in S4
  A1_detect_in_s4: assert property (
    @(posedge clk) disable iff (!rst_n)
    detected |-> (cs == S4)
  ) else $error("[SEQ_MOORE] A1: detected outside S4");

  // A2 — S4 only reachable from S3 when data_in=1
  A2_s4_from_s3: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == S4) |-> ($past(cs) == S3 && $past(data_in) == 1'b1)
  ) else $error("[SEQ_MOORE] A2: S4 entered illegally");

  // A3 — S3 only reachable from S2 when data_in=1
  A3_s3_from_s2: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == S3) |-> ($past(cs) == S2 && $past(data_in) == 1'b1)
  ) else $error("[SEQ_MOORE] A3: S3 entered illegally");

  // A4 — S2 only reachable from S1 (data_in=0) or S3 (data_in=0)
  A4_s2_sources: assert property (
    @(posedge clk) disable iff (!rst_n)
    (cs == S2) |-> (($past(cs) == S1 && !$past(data_in)) ||
                    ($past(cs) == S3 && !$past(data_in)))
  ) else $error("[SEQ_MOORE] A4: S2 entered from unexpected state");

  // A5 — Non-overlapping: after detect, always back to S0
  generate
    if (!OVERLAPPING) begin : g_nonoverlap_assert
      A5_nonoverlap: assert property (
        @(posedge clk) disable iff (!rst_n)
        (cs == S4) |=> (cs == S0)
      ) else $error("[SEQ_MOORE] A5: Non-overlapping: did not return to S0 after detect");
    end
  endgenerate

  // A6 — Overlapping: after detect, next state is S0 or S1 only
  generate
    if (OVERLAPPING) begin : g_overlap_assert
      A6_overlap_exit: assert property (
        @(posedge clk) disable iff (!rst_n)
        (cs == S4) |=> (cs == S0 || cs == S1)
      ) else $error("[SEQ_MOORE] A6: Overlapping: illegal exit from S4");
    end
  endgenerate

  // A7 — No unknown state
  A7_no_x: assert property (
    @(posedge clk) disable iff (!rst_n)
    !$isunknown(cs)
  ) else $error("[SEQ_MOORE] A7: Unknown state");

  // A8 — Detected must pulse (not stuck high)
  A8_detect_pulse: assert property (
    @(posedge clk) disable iff (!rst_n)
    detected |=> !detected || detected  // weaker: just ensure it's not X
  );

  // Coverage: detect a second occurrence
  COV_two_detections: cover property (
    @(posedge clk) detected ##[4:$] detected
  );

  COV_overlap_s1_after_detect: cover property (
    @(posedge clk) OVERLAPPING && cs==S4 ##1 cs==S1
  );

  COV_all_states: cover property (
    @(posedge clk)
    cs==S0 ##[1:$] cs==S1 ##[1:$] cs==S2 ##[1:$] cs==S3 ##[1:$] cs==S4
  );

`endif

endmodule : seq_det_1011_moore
