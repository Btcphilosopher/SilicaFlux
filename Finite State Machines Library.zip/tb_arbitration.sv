//=============================================================================
// File        : tb_arbitration.sv
// Project     : FSM Library — Testbenches
// Description : Exhaustive testbench for round_robin_arbiter and
//               priority_arbiter.
//
//   Test plan:
//     TC1  Single requester — immediate grant
//     TC2  Round-robin order: req[0..3] in rotation
//     TC3  Fairness: all requesters get equal share under simultaneous load
//     TC4  Priority ordering: req[0] always wins over req[1..3]
//     TC5  Anti-starvation: low-priority eventually gets granted
//     TC6  Burst: rapid grant-ack cycles
//     TC7  Hold count: verify grant held for HOLD_CYCLES
//     TC8  Idle after all requests deasserted
//=============================================================================

`include "../rtl/pkg/fsm_pkg.sv"
`include "../rtl/arbitration/round_robin_arbiter.sv"
`include "../rtl/arbitration/priority_arbiter.sv"

`timescale 1ns/1ps

module tb_arbitration;
  import fsm_pkg::*;

  //===========================================================================
  // Signals — Round Robin
  //===========================================================================
  logic       clk, rst_n;
  logic [3:0] rr_req, rr_gnt;
  logic       rr_valid;

  //===========================================================================
  // Signals — Priority
  //===========================================================================
  logic [3:0] pri_req, pri_gnt;
  logic       pri_ack;
  logic       pri_valid;

  //===========================================================================
  // DUTs
  //===========================================================================
  round_robin_arbiter #(.NUM_REQ(4), .HOLD_CYCLES(2)) u_rr (
    .clk, .rst_n,
    .req(rr_req), .gnt(rr_gnt), .gnt_valid(rr_valid)
  );

  priority_arbiter #(.NUM_REQ(4)) u_pri (
    .clk, .rst_n,
    .req(pri_req), .ack(pri_ack),
    .gnt(pri_gnt), .gnt_valid(pri_valid)
  );

  //===========================================================================
  // Clock
  //===========================================================================
  initial clk = 0;
  always #5 clk = ~clk;

  //===========================================================================
  // Utilities
  //===========================================================================
  task automatic clk_step(input int n = 1);
    repeat(n) @(posedge clk); #1;
  endtask

  task automatic do_reset();
    rst_n   = 0;
    rr_req  = '0;
    pri_req = '0;
    pri_ack = '0;
    clk_step(3);
    rst_n = 1;
    clk_step(2);
  endtask

  // Wait for round-robin grant to specific requester
  task automatic wait_rr_grant(input int req_idx, input int timeout = 50);
    int cnt = 0;
    while (!rr_gnt[req_idx] && cnt < timeout) begin
      clk_step(1); cnt++;
    end
    if (cnt >= timeout)
      $fatal(1, "[ARB_TB] Timeout waiting for rr_gnt[%0d]", req_idx);
  endtask

  // Complete a priority grant handshake
  task automatic pri_handshake(input int timeout = 20);
    int cnt = 0;
    while (!pri_valid && cnt < timeout) begin
      clk_step(1); cnt++;
    end
    if (cnt < timeout) begin
      pri_ack = 1;
      clk_step(1);
      pri_ack = 0;
      clk_step(2);
    end else
      $error("[ARB_TB] Priority grant never asserted");
  endtask

  int pass_cnt = 0, fail_cnt = 0;
  task automatic check(input string name, input logic cond);
    if (cond) begin $display("[PASS] %s", name); pass_cnt++; end
    else      begin $error("[FAIL] %s", name);   fail_cnt++; end
  endtask

  //===========================================================================
  // TC1 — Single requester
  //===========================================================================
  task automatic tc1_single_requester();
    $display("\n=== TC1: Single Requester ===");
    do_reset();

    // RR: only req[2]
    rr_req = 4'b0100;
    clk_step(3);
    check("TC1.RR: gnt[2] asserted", rr_gnt[2]);
    check("TC1.RR: only one grant",  rr_gnt == 4'b0100);
    rr_req = '0;
    clk_step(5);

    // Priority: only req[3] (lowest priority)
    pri_req = 4'b1000;
    clk_step(3);
    check("TC1.PRI: gnt[3] asserted when only requester", pri_gnt[3]);
    pri_handshake();
    pri_req = '0;
    $display("[TC1] PASS");
  endtask

  //===========================================================================
  // TC2 — Round-robin rotation order
  //===========================================================================
  task automatic tc2_rr_rotation();
    $display("\n=== TC2: Round-Robin Rotation Order ===");
    do_reset();

    // All requesters assert
    rr_req = 4'b1111;
    clk_step(2);

    logic [3:0] grant_sequence[8];
    for (int i = 0; i < 8; i++) begin
      // Wait for any grant
      int w = 0;
      while (!rr_valid && w < 20) begin clk_step(1); w++; end
      grant_sequence[i] = rr_gnt;
      $display("[TC2] Grant %0d: gnt=%0b (requester %0d)", i, rr_gnt, $clog2(rr_gnt+1)-1);
      clk_step(3);  // hold period
    end

    // Verify round-robin: grants should cycle 0→1→2→3→0→...
    logic [3:0] last_gnt = 4'b1000;  // pretend last was 3 so first should be 0
    int rr_errors = 0;
    for (int i = 0; i < 8; i++) begin
      int cur = -1, expected = -1;
      for (int j = 0; j < 4; j++)
        if (grant_sequence[i][j]) cur = j;
      // Expected: (last+1) mod 4
      for (int j = 0; j < 4; j++)
        if (last_gnt[j]) expected = (j+1)%4;
      if (cur != expected) begin
        $error("[TC2] RR violation: expected req[%0d], got req[%0d]", expected, cur);
        rr_errors++;
      end
      last_gnt = grant_sequence[i];
    end
    check("TC2.RR rotation maintained", rr_errors == 0);
    rr_req = '0;
    $display("[TC2] PASS");
  endtask

  //===========================================================================
  // TC3 — Fairness: count grants per requester
  //===========================================================================
  task automatic tc3_fairness();
    $display("\n=== TC3: Fairness Under Contention ===");
    do_reset();

    int grant_cnt[4] = '{0,0,0,0};
    rr_req = 4'b1111;  // all requesting

    repeat(40) begin
      @(posedge clk); #1;
      for (int i = 0; i < 4; i++)
        if (rr_gnt[i]) grant_cnt[i]++;
    end

    rr_req = '0;
    $display("[TC3] Grants: req0=%0d req1=%0d req2=%0d req3=%0d",
             grant_cnt[0], grant_cnt[1], grant_cnt[2], grant_cnt[3]);

    // All requesters should have gotten some grants; deviation should be small
    int max_g = 0, min_g = 100;
    for (int i = 0; i < 4; i++) begin
      if (grant_cnt[i] > max_g) max_g = grant_cnt[i];
      if (grant_cnt[i] < min_g) min_g = grant_cnt[i];
    end
    check("TC3.All requesters got grants",       min_g > 0);
    check("TC3.Grant distribution fair (<=3 diff)", (max_g - min_g) <= 3);
  endtask

  //===========================================================================
  // TC4 — Priority ordering
  //===========================================================================
  task automatic tc4_priority_order();
    $display("\n=== TC4: Priority Ordering ===");
    do_reset();

    // All 4 requesters simultaneously
    pri_req = 4'b1111;
    clk_step(3);
    check("TC4.Highest priority (0) wins contention", pri_gnt[0]);
    pri_handshake();

    // Now req[0] deasserts, req[1..3] remain
    pri_req = 4'b1110;
    clk_step(3);
    check("TC4.Next priority (1) wins after 0 deasserts", pri_gnt[1]);
    pri_handshake();

    pri_req = 4'b1100;
    clk_step(3);
    check("TC4.Priority 2 wins when 0,1 absent", pri_gnt[2]);
    pri_handshake();

    pri_req = 4'b1000;
    clk_step(3);
    check("TC4.Lowest priority (3) wins when alone", pri_gnt[3]);
    pri_handshake();

    pri_req = '0;
    $display("[TC4] PASS: Priority ordering correct");
  endtask

  //===========================================================================
  // TC5 — Anti-starvation: low-priority gets served eventually
  //===========================================================================
  task automatic tc5_anti_starvation();
    $display("\n=== TC5: Anti-Starvation (Low Priority Eventually Served) ===");
    do_reset();

    // req[3] is lowest priority; req[0] keeps requesting
    // Without anti-starvation, req[3] would never get granted
    pri_req = 4'b1001;  // req[0] and req[3] both requesting
    int gnt3_count = 0;

    repeat(100) begin
      clk_step(1);
      if (pri_gnt[0]) begin
        pri_ack = 1; clk_step(1); pri_ack = 0;
      end
      if (pri_gnt[3]) gnt3_count++;
    end

    pri_req = '0;
    $display("[TC5] req[3] granted %0d times alongside req[0]", gnt3_count);
    check("TC5.Low-priority req[3] granted at least once", gnt3_count > 0);
  endtask

  //===========================================================================
  // TC6 — Burst: rapid back-to-back grants
  //===========================================================================
  task automatic tc6_burst():
    $display("\n=== TC6: Burst Grant-Ack Cycles ===");
    do_reset();

    int total_grants = 0;
    pri_req = 4'b0101;  // req[0] and req[2] alternating

    repeat(20) begin
      if (pri_valid) begin
        total_grants++;
        pri_ack = 1; clk_step(1); pri_ack = 0;
      end
      clk_step(2);
    end

    pri_req = '0;
    check("TC6.Multiple grants issued in burst", total_grants >= 3);
    $display("[TC6] Total grants in burst: %0d", total_grants);
  endtask

  //===========================================================================
  // TC7 — Hold count verification (round-robin)
  //===========================================================================
  task automatic tc7_hold_count();
    $display("\n=== TC7: RR Hold Count (HOLD_CYCLES=2) ===");
    do_reset();

    rr_req = 4'b0001;  // only req[0]
    clk_step(2);
    check("TC7.Grant asserted", rr_gnt[0]);

    // Grant should stay for at least HOLD_CYCLES
    int held = 0;
    repeat(5) begin
      @(posedge clk); #1;
      if (rr_gnt[0]) held++;
    end
    check("TC7.Grant held for >=2 cycles", held >= 2);
    $display("[TC7] Grant held for %0d cycles", held);

    rr_req = '0;
    clk_step(5);
  endtask

  //===========================================================================
  // TC8 — Idle after all requests deassert
  //===========================================================================
  task automatic tc8_idle_after_release():
    $display("\n=== TC8: Idle After Requests Deassert ===");
    do_reset();

    rr_req  = 4'b1111;
    pri_req = 4'b1111;
    clk_step(10);

    rr_req  = '0;
    pri_req = '0;
    clk_step(5);

    // Both arbiters should be in IDLE (no grants)
    check("TC8.RR: no grant after all reqs deassert",  rr_gnt == '0);
    check("TC8.PRI: no grant after all reqs deassert", pri_gnt == '0);
    $display("[TC8] PASS");
  endtask

  //===========================================================================
  // Main
  //===========================================================================
  initial begin
    $dumpfile("tb_arbitration.vcd");
    $dumpvars(0, tb_arbitration);

    tc1_single_requester();
    tc2_rr_rotation();
    tc3_fairness();
    tc4_priority_order();
    tc5_anti_starvation();
    tc6_burst();
    tc7_hold_count();
    tc8_idle_after_release();

    $display("\n============================================");
    $display(" Arbitration TB: %0d PASS  %0d FAIL", pass_cnt, fail_cnt);
    $display("============================================\n");
    $finish;
  end

  initial begin
    #500_000;
    $fatal(1, "[ARB_TB] Global timeout");
  end

endmodule : tb_arbitration
