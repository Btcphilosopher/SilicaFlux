# FSM Library — Reusable Finite State Machines in SystemVerilog

A production-grade repository of parameterised, formally-annotated finite state machines covering traffic control, vending, elevator scheduling, sequence detection, and bus arbitration. Every module ships with Moore **and** Mealy implementations, three state-encoding strategies, concurrent SVA assertions, and exhaustive testbenches.

---

## Repository Structure

```
fsm_library/
├── rtl/
│   ├── pkg/
│   │   └── fsm_pkg.sv                   # Shared types, enums, utility functions
│   ├── traffic_light/
│   │   ├── traffic_light_moore.sv        # Moore FSM — binary encoding
│   │   ├── traffic_light_mealy.sv        # Mealy FSM — one-hot encoding
│   │   └── traffic_light_encodings.sv    # Binary / Gray / One-hot comparison wrapper
│   ├── vending_machine/
│   │   ├── vending_machine_moore.sv      # Moore FSM — 60p item, 10/20/50p coins
│   │   └── vending_machine_mealy.sv      # Mealy FSM — output on transition arc
│   ├── elevator/
│   │   └── elevator_ctrl.sv              # SCAN-algorithm elevator, Gray encoding
│   ├── sequence_detector/
│   │   ├── seq_det_1011_moore.sv         # "1011" detector — Moore, 5 states
│   │   ├── seq_det_1011_mealy.sv         # "1011" detector — Mealy, 4 states
│   │   └── seq_det_generic.sv            # KMP-FSM, parameterised pattern + 1010/110
│   └── arbitration/
│       ├── round_robin_arbiter.sv        # Token FSM, 4 requesters, configurable hold
│       └── priority_arbiter.sv           # Fixed-priority + anti-starvation mask
├── tb/
│   ├── tb_traffic_light.sv               # TC1–TC7: reset, sequence, ped, emergency
│   ├── tb_vending_machine.sv             # TC1–TC8: exact pay, overpay, cancel, timing
│   ├── tb_elevator.sv                    # TC1–TC7: SCAN order, door safety, bounds
│   ├── tb_sequence_detectors.sv          # TC1–TC7: latency, overlap, exhaustive
│   └── tb_arbitration.sv                 # TC1–TC8: fairness, priority, starvation
├── Makefile                              # VCS / ModelSim / Icarus / Verilator targets
└── README.md
```

---

## Quick Start

```bash
# Lint all RTL (requires Verilator)
make verilator_lint

# Simulate with Icarus Verilog (open-source)
make icarus_all

# Simulate with VCS + coverage
make vcs_all

# Open a waveform
make icarus_tl && make wave_tl
```

---

## Design Principles

### 1. Three-Process FSM Template

Every module uses the canonical three-process split, which is the safest and most synthesis-portable structure for registered FSMs:

```
Process 1 — Sequential (always_ff):
  Registers: state, timer, datapath registers
  Triggered: posedge clk, negedge rst_n (async active-low reset)

Process 2 — Combinational next-state (always_comb):
  Inputs:   current state, primary inputs
  Outputs:  next state, next datapath values

Process 3 — Combinational outputs (always_comb):
  Moore: outputs = f(state)
  Mealy: outputs = f(state, inputs)  ← combined with Process 2
```

Keeping Process 3 separate from Process 2 for Moore machines makes the output decode visible to synthesis as a dedicated cone, enabling better timing optimisation.

### 2. State Encoding Strategies

| Strategy | Bits (N states) | Decode speed | Glitch risk | Best for |
|----------|----------------|--------------|-------------|----------|
| Binary   | ⌈log₂N⌉       | Slow (mux)   | High        | Area-constrained ASIC |
| One-hot  | N              | Fast (1 FF)  | Low         | FPGA (abundant FFs)   |
| Gray     | ⌈log₂N⌉       | Medium       | Minimal     | CDC crossings, low EMI |

**Binary** is declared with natural integer values in the typedef enum.  
**One-hot** uses explicit power-of-two values and a `(* fsm_encoding = "one_hot" *)` attribute.  
**Gray** uses values where adjacent states differ by exactly one bit. The AMBER→RED wrap-around in a 4-state traffic light breaks strict Gray ordering — this is documented in-line as an expected property violation.

The `traffic_light_encodings.sv` wrapper instantiates all three variants in parallel. A cross-encoding equivalence assertion fires if any functional divergence occurs:

```systemverilog
EQ_red: assert property (
    @(posedge clk) disable iff (!rst_n)
    (bin_red == gray_red) && (bin_red == oh_red)
) else $error("Red output divergence between encodings");
```

### 3. Moore vs Mealy — When to Use Which

**Moore machine** (outputs from state register):
- Outputs are glitch-free (registered state drives them)
- One extra state required for each distinct output combination
- Output latency: one clock cycle after the triggering input
- Used by: `traffic_light_moore`, `vending_machine_moore`, `elevator_ctrl`, `seq_det_1011_moore`, `round_robin_arbiter`, `priority_arbiter`

**Mealy machine** (outputs from state × input):
- Fewer states (demonstrated: 7→4 for vending machine, 5→4 for sequence detector)
- Responds in the **same clock cycle** as the triggering input
- Combinational output path can glitch; add output register if required
- Used by: `traffic_light_mealy`, `vending_machine_mealy`, `seq_det_1011_mealy`

**Concrete latency difference** (from `tb_vending_machine.sv TC7`):

```
Clock edge N:   10p coin inserted (total reaches 60p threshold)
  Mealy output: dispense_out = 1  ← combinational, SAME cycle
  Moore output: dispense_out = 0  ← still transitioning
Clock edge N+1:
  Moore output: dispense_out = 1  ← registered, ONE CYCLE LATER
```

---

## Module Reference

### Traffic Light — `traffic_light_moore.sv`

UK sequence: **RED → RED+AMBER → GREEN → AMBER → RED**

| Port | Direction | Description |
|------|-----------|-------------|
| `pedestrian_req` | input | Latched crossing request |
| `emergency` | input | Holds RED until deasserted |
| `red/amber/green` | output | Lamp drivers |
| `ped_walk` | output | Pedestrian walk signal (Moore: PED_RED state only) |

**State machine:**

```
        ┌──────────┐  timer  ┌───────────┐  timer  ┌───────┐  timer  ┌───────┐
rst ──> │   RED    ├────────>│ RED_AMBER ├────────>│ GREEN ├────────>│ AMBER │
        └──────────┘         └───────────┘         └───┬───┘         └───┬───┘
              ^                                     ped_req              │ timer
              │                                         │                │
              │                               ┌─────────┘         ped_q │
              │  !fault                       ▼                         │
              │                          ┌─────────┐                    │
              └──────────────────────────│ PED_RED │<───────────────────┘
                                         └─────────┘
        emergency ──────────────> EMERGENCY (hold RED)
```

**Safety assertions:**  
`A2_no_red_green` is marked `$fatal(2,...)` — simulation aborts immediately if RED and GREEN are simultaneously active, making it impossible to miss a safety violation.

---

### Vending Machine — `vending_machine_moore.sv` / `vending_machine_mealy.sv`

Accepts 10p, 20p, 50p coins. Item costs 60p. Returns change as 10p coins via `change_ack` handshake.

**Moore state graph (7 states):**

```
IDLE ──coin──> ACCEPTING ──threshold──> EXACT ──> DISPENSING ──> IDLE
                  │                  │                │
                  │ cancel           └──> OVERPAID    └──> CHANGE_OUT ──> IDLE
                  ▼
               REFUND ──> IDLE
```

**Mealy state graph (4 states — fewer by removing EXACT, OVERPAID, DISPENSING):**

```
IDLE ──coin(=cost)/dispense──> IDLE
IDLE ──coin(>cost)/dispense──> CHANGE_OUT
IDLE ──coin(<cost)──> ACCEPTING
ACCEPTING ──coin(=)/dispense──> IDLE
ACCEPTING ──coin(>)/dispense──> CHANGE_OUT
ACCEPTING ──cancel──> REFUND
```

---

### Elevator — `elevator_ctrl.sv`

4-floor SCAN (LOOK) algorithm. Serves all requests in the current direction before reversing.

**State machine (Gray encoded):**

```
            ┌────────────────────────────────┐
            │              IDLE              │
            └───────┬─────────────┬──────────┘
          req_above │             │ req_below
                    ▼             ▼
              MOVING_UP    MOVING_DOWN
                    │             │
               at floor       at floor
                    └──────┬──────┘
                           ▼
                     DOOR_OPENING
                           │ timer
                           ▼
                       DOOR_OPEN
                           │ timer
                           ▼
                     DOOR_CLOSING ──!door_closed──> DOOR_OPENING (safety reopen)
                           │ door_closed
                           ▼
                     (MOVING / IDLE)
```

**Door safety reopen** (TC4): if the `door_closed` sensor does not assert within `DCLOSE_CYCLES` of issuing `door_close_cmd`, the FSM returns to `DOOR_OPENING`. This prevents a closing door crushing an obstacle.

---

### Sequence Detectors

#### 1011 — Moore vs Mealy state comparison

```
Pattern: 1 0 1 1

Moore (5 states):              Mealy (4 states):
S0 ─1─> S1 ─0─> S2            S0 ─1─> S1 ─0─> S2
S2 ─1─> S3 ─1─> S4(det)       S2 ─1─> S3 ─1/det─> S0 or S1
S3 ─0─> S2  (KMP fallback)     S3 ─0─> S2  (same KMP fallback)
S1 ─1─> S1  (self-loop)        S1 ─1─> S1  (self-loop)
```

Mealy eliminates S4 by asserting `detected` on the **arc** from S3 rather than in a dedicated output state. The output is combinational — if a glitch-free `detected` signal is required downstream, register it with a single `always_ff`.

#### Generic Detector — KMP Failure Function

`seq_det_generic` computes the Knuth-Morris-Pratt failure function at elaboration via an `initial` block, building state-transition fall-back values for any pattern up to 8 bits:

```
f[0] = 0  (no proper prefix-suffix)
f[i] = length of longest proper prefix of pattern[0..i-1] that is a suffix
```

For `1011`: `f[] = {0, 0, 0, 1}` — after a failed match at position 3, fall back to state 1 (have matched the "1" prefix).  
For `1010`: `f[] = {0, 0, 1, 2}` — richer fall-back enables immediate continuation of overlapping matches.

---

### Arbiters

#### Round-Robin — `round_robin_arbiter.sv`

Token FSM with configurable `HOLD_CYCLES`. After the hold expires or the grantee deasserts its request, the token advances to the next requester in modular order. Under all-requesting load, grants rotate as: `0 → 1 → 2 → 3 → 0 → ...`

**Fairness bound**: any requester is served within `NUM_REQ × (HOLD_CYCLES + 1)` cycles of any other requester's grant.

#### Priority — `priority_arbiter.sv`

Two-pass masked priority encoder with grant-ack handshake:

- **Pass 1**: apply fixed priority only to requesters with index > `last_grant` (anti-starvation window)
- **Pass 2**: if Pass 1 finds nothing, fall back to full fixed priority

This ensures that a perpetually-requesting `req[0]` cannot permanently starve `req[3]`, because after granting index 0, the mask shifts to consider indices 1–3 first in the next arbitration.

---

## Assertion Strategy

Every module contains concurrent SVA properties guarded by `` `ifndef SYNTHESIS `` to ensure zero synthesis overhead. Properties are categorised:

| Category | Example | Severity |
|----------|---------|----------|
| Safety-critical | `red && green` simultaneous | `$fatal(2, ...)` — simulation kills |
| Functional | Walk signal outside GREEN | `$error(...)` — logged, continues |
| Liveness/sequence | Correct state transitions | `$error(...)` — logged, continues |
| Output quality | No X/Z on outputs | `$error(...)` |
| Coverage | All states/arcs visited | `cover property (...)` |

**Implication operators used:**
```systemverilog
A |->  B   // overlapping: if A at cycle N, then B at cycle N
A |=> B    // non-overlapping: if A at cycle N, then B at cycle N+1
##[1:$]    // 1 or more cycles later (liveness)
$rose(x)   // x transitioned 0→1
$fell(x)   // x transitioned 1→0
$past(x,N) // value of x N cycles ago
disable iff (!rst_n)  // suspend assertion during reset
```

---

## Synthesis Notes

### Tool-Specific FSM Encoding Directives

```systemverilog
// Xilinx Vivado
(* fsm_encoding = "one_hot" *) state_t cs;
(* fsm_encoding = "gray"    *) state_t cs;

// Synopsys Design Compiler
// synopsys enum_encoding "one-hot"
typedef enum logic [3:0] { ... } state_t; // synopsys enum_encoding "one-hot"

// Cadence Genus / RC
// pragma attribute state_t hls_fsm_state_encoding one_hot
```

### Recommended Constraints

For the traffic-light timer counter, set a multicycle path if the timer is not in the critical timing path:

```tcl
# SDC: relax timing on phase timer (non-critical, updates every 100s of cycles)
set_multicycle_path -setup 2 -from [get_cells timer_q_reg*] -to [get_cells timer_q_reg*]
```

---

## Verification Closure Checklist

- [ ] All `assert property` checks pass with zero failures
- [ ] All `cover property` goals hit (reported by simulator)
- [ ] State coverage: every state visited in each testbench
- [ ] Transition coverage: every arc exercised
- [ ] Output toggle coverage: all output bits toggled 0→1 and 1→0
- [ ] Safety assertions (`$fatal`) never triggered
- [ ] Formal proof (JasperGold / SymbiYosys): all properties proven unbounded for sequence detectors and arbiters

---

## Extensions and Customisation

| Module | Key Parameters | Notes |
|--------|---------------|-------|
| `traffic_light_moore` | `RED_CYCLES`, `GREEN_CYCLES`, `PED_CYCLES` | Adjust for real-time clocking |
| `vending_machine_moore` | `ITEM_COST`, `MAX_CHANGE` | Support other currencies by changing coin enum |
| `elevator_ctrl` | `NUM_FLOORS`, `MOVE_CYCLES` | Scale to 8/16 floors; add overload sensor |
| `seq_det_generic` | `SEQ_LEN`, `PATTERN`, `OVERLAPPING` | Up to 8-bit pattern; extend PATTERN to 16 bits for longer matches |
| `round_robin_arbiter` | `NUM_REQ`, `HOLD_CYCLES` | Tested to 8 requesters |
| `priority_arbiter` | `NUM_REQ` | Add `PREEMPT` parameter for non-blocking high-priority override |

---

## References

1. Cummings, C.E. — *Synthesisable Finite State Machine Design Techniques Using the New SystemVerilog 3.0 Enhancements* (SNUG 2003)
2. IEEE 1800-2017 — SystemVerilog Language Reference Manual
3. Knuth, Morris, Pratt — *Fast Pattern Matching in Strings* (SIAM J. Comput., 1977)
4. Clifford Wolf — *SymbiYosys Formal Verification Flow* (https://symbiyosys.readthedocs.io)
5. Synopsys — *VCS Functional Verification User Guide*
