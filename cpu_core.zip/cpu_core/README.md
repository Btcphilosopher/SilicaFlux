# RV32I 5-Stage Pipelined CPU Core

Production-quality SystemVerilog implementation of a 5-stage pipelined
RISC-V RV32I processor with full hazard handling and bypass networks.

---

## Architecture

```
 ┌──────┐   ┌──────┐   ┌──────┐   ┌──────┐   ┌──────┐
 │  IF  │──▶│  ID  │──▶│  EX  │──▶│ MEM  │──▶│  WB  │
 └──────┘   └──────┘   └──────┘   └──────┘   └──────┘
     ▲          │          │          │          │
     │   hazard_unit        forwarding_unit       │
     └──────────┴──────────┴──────────┴──────────┘
```

### Stage summary

| Stage | Work done |
|-------|-----------|
| IF  | PC → IMEM → IF/ID register |
| ID  | Decode instruction; read register file (write-through); generate immediates; produce all control signals |
| EX  | Forwarding muxes; ALU; branch comparator; jump-target computation |
| MEM | DMEM read/write with byte-enable; address = ALU result |
| WB  | Write-back mux (ALU / mem-data / PC+4); register-file write |

---

## Hazard handling

### Load-use hazard (1-cycle stall)
```
LW  x1, 0(x2)          ← in EX   (id_ex_q.mem_read=1)
ADD x3, x1, x4         ← in ID   (uses x1)
```
Hazard unit asserts `pc_stall`, `if_id_stall`, `id_ex_bubble`.
The load result is available in MEM/WB one cycle later and forwarded correctly.

### Control hazards (2-cycle flush)
Branch and jump outcomes are resolved at the **end of the EX stage**.
Two wrong-path instructions (in IF and ID) are squashed by flushing IF/ID
and ID/EX registers.

### Data hazards — full bypass network
| Gap | Forward path | Selector |
|-----|-------------|----------|
| 1 instruction | EX/MEM.alu_result → EX ALU input | `forward_a/b = 2'b10` |
| 2 instructions | MEM/WB.write_data → EX ALU input | `forward_a/b = 2'b01` |
| 3 instructions | Register file write-through | handled in RF |

---

## Supported ISA (RV32I subset)

| Format | Instructions |
|--------|-------------|
| R | ADD SUB AND OR XOR SLT SLTU SLL SRL SRA |
| I | ADDI ANDI ORI XORI SLTI SLTIU SLLI SRLI SRAI |
| I-Load | LB LH LW LBU LHU |
| S | SB SH SW |
| B | BEQ BNE BLT BGE BLTU BGEU |
| U | LUI AUIPC |
| J | JAL JALR |

---

## File structure

```
cpu_core/
├── rtl/
│   ├── cpu_pkg.sv           Package: types, opcodes, pipeline-register structs
│   ├── alu.sv               32-bit combinational ALU (11 operations)
│   ├── register_file.sv     32×32 RF, write-through forwarding, dbg port
│   ├── hazard_unit.sv       Load-use stall + control-hazard flush
│   ├── forward_unit.sv      EX/MEM and MEM/WB forwarding selects
│   ├── cpu_core.sv          Top pipeline (all 5 stages + submodule instances)
│   ├── instr_mem.sv         Combinational-read ROM (initialised BRAM model)
│   ├── data_mem.sv          Byte-enable write + registered read (1-cycle)
│   └── cpu_top.sv           Integration: core + IMEM + DMEM
├── tb/
│   ├── tb_cpu_top.sv        Directed + randomised test suite
│   ├── cpu_scoreboard.sv    Architectural reference model; checks every commit
│   └── instr_gen.sv         Constrained-random instruction stream (unused port
│                            workaround: generation inlined directly in TB)
└── sim/
    └── Makefile             Icarus Verilog, Questa, VCS targets
```

---

## Commit bus (scoreboard interface)

`cpu_core` exposes a commit bus so the testbench scoreboard can check every
retiring instruction without back-door register-file access:

| Signal | Description |
|--------|-------------|
| `commit_valid` | Instruction retiring this cycle |
| `commit_pc`    | PC of retiring instruction |
| `commit_instr` | Instruction word (carried through pipeline) |
| `commit_rd`    | Destination register index |
| `commit_wdata` | Value written to register file |
| `commit_we`    | Register-file write enable (filtered: 0 for x0) |

---

## Simulation

### Icarus Verilog (installed)
```bash
cd sim
make sim          # compile + run
make wave         # open cpu_waves.vcd in GTKWave
```

### Questa / ModelSim
```bash
cd sim
make questa
```

### VCS
```bash
cd sim
make vcs
```

---

## Test results

```
Directed test  : TB PASS=27 FAIL=0   SB PASS=36 FAIL=0
Random test    : SB PASS=55 FAIL=0   (63 random instructions + scoreboard check)
FINAL          : ALL TESTS PASSED
```

### Directed test coverage

| Section | Checks | What is verified |
|---------|--------|-----------------|
| A | 7  | ADDI, ADD, SUB, AND, OR, XOR + EX→EX forwarding |
| B | 3  | Back-to-back same-source forwarding |
| C | 6  | LW, SW, load-use hazard, MEM forwarding |
| D | 4  | SLLI, SRLI, SRAI (arithmetic on -1) |
| E | 2  | SLT (signed), SLTU (unsigned) |
| F | 2  | LUI, AUIPC |
| G | 2  | BLT loop (3 iterations, branch flush) |
| H | 1  | JAL forward jump, link register |
| I | 1  | JALR jump, link register |

### Randomised test
63 constrained-random instructions covering R-type, ADDI, ANDI/ORI, LW, SW,
SLLI. Every committing instruction that writes a register is checked by the
scoreboard against the reference model. Seed=42 for reproducibility.

---

## Synthesis notes

- No vendor primitives; targets Xilinx, Intel, Lattice, ASIC flows
- `instr_mem` models combinational-read ROM; replace with inferred BRAM for FPGA
- `data_mem` uses synchronous read (1-cycle latency); maps directly to FPGA BRAM
- `// synthesis translate_off/on` guards around all simulation-only code
- Assertion blocks inside cpu_core are guarded and stripped by synthesis tools
