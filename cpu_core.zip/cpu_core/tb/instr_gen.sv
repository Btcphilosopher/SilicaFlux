`timescale 1ns/1ps
// =============================================================================
// instr_gen.sv  –  Random RV32I instruction stream generator
// Fills prog[0..NUM_INSTRS] with:
//   [0]          preamble: ADDI x1, x0, DMEM_BASE  (establishes memory base)
//   [1..N-1]     constrained-random instructions
//   [N]          halt: JAL x0, 0
// =============================================================================
module instr_gen #(
    parameter int NUM_INSTRS = 64,
    parameter int DMEM_BASE  = 32'h200,
    parameter int POOL_WORDS = 16
) (
    output logic [31:0] prog [0:NUM_INSTRS]
);
    // ---- Encoding helpers ---------------------------------------------------
    function automatic logic [31:0] mk_R(
        input [6:0] f7, input [4:0] rs2, rs1, rd, input [2:0] f3);
        mk_R = {f7, rs2, rs1, f3, rd, 7'b0110011};
    endfunction
    function automatic logic [31:0] mk_I(
        input [11:0] imm, input [4:0] rs1, rd, input [2:0] f3, input [6:0] op);
        mk_I = {imm, rs1, f3, rd, op};
    endfunction
    function automatic logic [31:0] mk_S(
        input [11:0] imm, input [4:0] rs2, rs1, input [2:0] f3);
        mk_S = {imm[11:5], rs2, rs1, f3, imm[4:0], 7'b0100011};
    endfunction

    // ---- Generation ---------------------------------------------------------
    integer seed_var;
    integer itype, op_sel;
    logic [4:0] rd, rs1, rs2;
    logic [11:0] imm12;
    logic [4:0]  shamt;
    logic [11:0] off12;

    initial begin
        // Initialise every element to NOP first (prevents X propagation)
        for (int k = 0; k <= NUM_INSTRS; k++)
            prog[k] = 32'h00000013;

        // Seed the RNG
        seed_var = 42;
        void'($urandom(seed_var));

        // Index 0: preamble – establish x1 = DMEM_BASE
        prog[0] = mk_I(12'(DMEM_BASE), 5'd0, 5'd1, 3'b000, 7'b0010011);

        // Indices 1 .. NUM_INSTRS-1 : random instructions
        for (int i = 1; i < NUM_INSTRS; i++) begin
            itype  = int'($urandom_range(0, 5));
            rd     = 5'($urandom_range(1, 15));   // x1-x15
            rs1    = 5'($urandom_range(1, 15));
            rs2    = 5'($urandom_range(1, 15));
            imm12  = 12'($urandom_range(0, 63));
            shamt  = 5'($urandom_range(1, 15));
            off12  = 12'($urandom_range(0, POOL_WORDS-1) * 4);  // word-aligned

            case (itype)
                0: begin  // R-type ALU
                    op_sel = int'($urandom_range(0, 7));
                    case (op_sel)
                        0: prog[i] = mk_R(7'h00,rs2,rs1,rd,3'b000); // ADD
                        1: prog[i] = mk_R(7'h20,rs2,rs1,rd,3'b000); // SUB
                        2: prog[i] = mk_R(7'h00,rs2,rs1,rd,3'b111); // AND
                        3: prog[i] = mk_R(7'h00,rs2,rs1,rd,3'b110); // OR
                        4: prog[i] = mk_R(7'h00,rs2,rs1,rd,3'b100); // XOR
                        5: prog[i] = mk_R(7'h00,rs2,rs1,rd,3'b010); // SLT
                        6: prog[i] = mk_R(7'h00,rs2,rs1,rd,3'b001); // SLL
                        7: prog[i] = mk_R(7'h00,rs2,rs1,rd,3'b101); // SRL
                        default: prog[i] = 32'h00000013;
                    endcase
                end
                1: prog[i] = mk_I(imm12, rs1, rd, 3'b000, 7'b0010011); // ADDI
                2: begin  // ANDI or ORI
                    if ($urandom & 1)
                        prog[i] = mk_I(imm12, rs1, rd, 3'b111, 7'b0010011); // ANDI
                    else
                        prog[i] = mk_I(imm12, rs1, rd, 3'b110, 7'b0010011); // ORI
                end
                3: prog[i] = mk_I(off12, 5'd1, rd, 3'b010, 7'b0000011);  // LW x1-based
                4: prog[i] = mk_S(off12, rs2, 5'd1, 3'b010);              // SW x1-based
                default: begin  // SLLI / NOP
                    if ($urandom & 1)
                        prog[i] = {7'b0000000, shamt, rs1, 3'b001, rd, 7'b0010011}; // SLLI
                    else
                        prog[i] = 32'h00000013; // NOP
                end
            endcase
        end

        // Index NUM_INSTRS: halt
        prog[NUM_INSTRS] = 32'h0000006F; // JAL x0, 0
    end
endmodule
