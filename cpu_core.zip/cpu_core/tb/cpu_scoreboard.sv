`timescale 1ns/1ps
// =============================================================================
// cpu_scoreboard.sv  –  Architectural Correctness Checker
//
// Uses the commit_instr bus (instruction word carried through pipeline to WB)
// rather than reading IMEM externally, avoiding iverilog unpacked-array port
// propagation issues entirely.
// =============================================================================
import cpu_pkg::*;

module cpu_scoreboard #(
    parameter int IMEM_DEPTH = 1024,
    parameter int DMEM_DEPTH = 1024
) (
    input  logic        clk,
    input  logic        rst_n,
    input  logic        commit_valid,
    input  logic [31:0] commit_pc,
    input  logic [31:0] commit_instr,   // instruction word at WB stage
    input  logic [4:0]  commit_rd,
    input  logic [31:0] commit_wdata,
    input  logic        commit_we,
    // Data memory: still read via hierarchical access from TB wrapper
    input  logic [7:0]  dmem_bytes [DMEM_DEPTH*4],
    output int          checks_pass,
    output int          checks_fail
);
    logic [31:0] shadow_regs [32];

    initial begin
        for (int i = 0; i < 32; i++) shadow_regs[i] = 32'b0;
        checks_pass = 0;
        checks_fail = 0;
    end

    // Clear shadow on CPU reset
    always_ff @(negedge rst_n) begin
        for (int i = 0; i < 32; i++) shadow_regs[i] = 32'b0;
    end

    function automatic logic [31:0] get_r(input logic [4:0] r);
        get_r = (r == 5'b0) ? 32'b0 : shadow_regs[r];
    endfunction

    // -------------------------------------------------------------------------
    // Reference model – all local vars declared at top (iverilog requirement)
    // -------------------------------------------------------------------------
    task automatic ref_exec(
        input  logic [31:0] instr,
        input  logic [31:0] pc,
        output logic        exp_we,
        output logic [4:0]  exp_rd,
        output logic [31:0] exp_wd
    );
        logic [6:0]  opc;
        logic [4:0]  rd, rs1, rs2;
        logic [2:0]  f3;
        logic [6:0]  f7;
        logic [31:0] A, B, imm, res;
        logic [31:0] addr, raw;
        logic [63:0] A64;
        logic [31:0] tmp32;
        logic signed [31:0] As, Bs;

        opc = instr[6:0];   rd  = instr[11:7];
        f3  = instr[14:12]; rs1 = instr[19:15];
        rs2 = instr[24:20]; f7  = instr[31:25];
        A   = get_r(rs1);   B   = get_r(rs2);
        As  = A;            Bs  = B;
        A64 = {{32{A[31]}}, A};

        exp_we = 1'b0; exp_rd = rd; exp_wd = 32'b0; res = 32'b0;

        case (opc)
            OP_R: begin
                exp_we = (rd != 5'b0);
                case ({f7[5], f3})
                    4'b0000: res = A + B;
                    4'b1000: res = A - B;
                    4'b0001: res = A << B[4:0];
                    4'b0010: res = {31'b0, As < Bs};
                    4'b0011: res = {31'b0, A < B};
                    4'b0100: res = A ^ B;
                    4'b0101: res = A >> B[4:0];
                    4'b1101: begin
                        A64 = {{32{A[31]}}, A};
                        tmp32 = (A64 >> {27'b0, B[4:0]});
                        res = tmp32;
                    end
                    4'b0110: res = A | B;
                    4'b0111: res = A & B;
                    default: res = 32'b0;
                endcase
                exp_wd = res;
            end

            OP_I_ALU: begin
                exp_we = (rd != 5'b0);
                imm = {{20{instr[31]}}, instr[31:20]};
                A64 = {{32{A[31]}}, A};
                As  = A;
                Bs  = imm;
                case (f3)
                    3'b000: res = A + imm;
                    3'b010: res = {31'b0, As < Bs};
                    3'b011: res = {31'b0, A < imm};
                    3'b100: res = A ^ imm;
                    3'b110: res = A | imm;
                    3'b111: res = A & imm;
                    3'b001: res = A << imm[4:0];
                    3'b101: begin
                        if (f7[5]) begin
                            A64   = {{32{A[31]}}, A};
                            tmp32 = (A64 >> {27'b0, imm[4:0]});
                            res   = tmp32;
                        end else begin
                            res = A >> imm[4:0];
                        end
                    end
                    default: res = 32'b0;
                endcase
                exp_wd = res;
            end

            OP_LOAD: begin
                exp_we = (rd != 5'b0);
                imm  = {{20{instr[31]}}, instr[31:20]};
                addr = A + imm;
                raw  = {dmem_bytes[{addr[31:2],2'b11}],
                        dmem_bytes[{addr[31:2],2'b10}],
                        dmem_bytes[{addr[31:2],2'b01}],
                        dmem_bytes[{addr[31:2],2'b00}]};
                case (f3)
                    3'b000: exp_wd = {{24{raw[7]}},  raw[7:0]};
                    3'b001: exp_wd = {{16{raw[15]}}, raw[15:0]};
                    3'b010: exp_wd = raw;
                    3'b100: exp_wd = {24'b0, raw[7:0]};
                    3'b101: exp_wd = {16'b0, raw[15:0]};
                    default: exp_wd = raw;
                endcase
            end

            OP_JAL:   begin exp_we = (rd != 5'b0); exp_wd = pc + 32'd4; end
            OP_JALR:  begin exp_we = (rd != 5'b0); exp_wd = pc + 32'd4; end
            OP_LUI:   begin exp_we = (rd != 5'b0); exp_wd = {instr[31:12], 12'b0}; end
            OP_AUIPC: begin exp_we = (rd != 5'b0); exp_wd = pc + {instr[31:12], 12'b0}; end
            default:  exp_we = 1'b0;
        endcase

        if (exp_we && rd != 5'b0) shadow_regs[rd] = exp_wd;
    endtask

    // -------------------------------------------------------------------------
    // Monitor: check every committed instruction
    // -------------------------------------------------------------------------
    always_ff @(posedge clk) begin
        if (rst_n && commit_valid) begin
            logic        exp_we;
            logic [4:0]  exp_rd;
            logic [31:0] exp_wd;

            ref_exec(commit_instr, commit_pc, exp_we, exp_rd, exp_wd);

            if (exp_we) begin
                if (commit_we !== exp_we ||
                    commit_rd !== exp_rd ||
                    commit_wdata !== exp_wd) begin
                    $error("[SB FAIL] PC=%08h instr=%08h  exp: x%0d=%08h  got: we=%b x%0d=%08h",
                        commit_pc, commit_instr,
                        exp_rd, exp_wd,
                        commit_we, commit_rd, commit_wdata);
                    checks_fail++;
                end else begin
                    checks_pass++;
                end
            end
        end
    end
endmodule
