`timescale 1ns/1ps
// =============================================================================
// tb_cpu_top.sv  –  RV32I 5-Stage Pipeline Testbench
//
// Test 1: Directed programme (hand-crafted hazard/forwarding coverage)
// Test 2: Constrained-random stream via instr_gen
// Scoreboard: cpu_scoreboard checks every commit
// =============================================================================
import cpu_pkg::*;

module tb_cpu_top;

    // =========================================================================
    // Clock / reset
    // =========================================================================
    localparam int CLK_HALF = 5;

    logic clk, rst_n;
    initial clk = 0;
    always #CLK_HALF clk = ~clk;

    // =========================================================================
    // DUT
    // =========================================================================
    localparam int IMEM_D = 1024;
    localparam int DMEM_D = 1024;

    logic        commit_valid;
    logic [31:0] commit_pc;
    logic [31:0] commit_instr;
    logic [4:0]  commit_rd;
    logic [31:0] commit_wdata;
    logic        commit_we;
    logic [31:0] dbg_rf [32];

    cpu_top #(.IMEM_DEPTH(IMEM_D), .DMEM_DEPTH(DMEM_D)) dut (
        .clk(clk), .rst_n(rst_n),
        .commit_valid(commit_valid), .commit_pc(commit_pc),
        .commit_instr(commit_instr), .commit_rd(commit_rd),
        .commit_wdata(commit_wdata), .commit_we(commit_we),
        .dbg_rf(dbg_rf)
    );

    // =========================================================================
    // Scoreboard
    // =========================================================================
    int sb_pass, sb_fail;

    cpu_scoreboard #(.IMEM_DEPTH(IMEM_D), .DMEM_DEPTH(DMEM_D)) u_sb (
        .clk(clk), .rst_n(rst_n),
        .commit_valid (commit_valid),
        .commit_pc    (commit_pc),
        .commit_instr (commit_instr),
        .commit_rd    (commit_rd),
        .commit_wdata (commit_wdata),
        .commit_we    (commit_we),
        .dmem_bytes   (dut.u_dmem.mem),
        .checks_pass  (sb_pass),
        .checks_fail  (sb_fail)
    );

    // =========================================================================
    // Random programme buffer (filled by gen_random_prog task)
    // =========================================================================
    localparam int RAND_N    = 63;
    localparam int DMEM_BASE = 32'h200;
    logic [31:0] rprog [0:RAND_N];

    // =========================================================================
    // Instruction encoding helpers
    // =========================================================================
    function automatic logic [31:0] fR(
        input [6:0] f7,[4:0] rs2,rs1,rd,[2:0] f3);
        fR={f7,rs2,rs1,f3,rd,7'b0110011}; endfunction
    function automatic logic [31:0] fI(
        input [11:0] imm,[4:0] rs1,rd,[2:0] f3,[6:0] op);
        fI={imm,rs1,f3,rd,op}; endfunction
    function automatic logic [31:0] fS(
        input [11:0] imm,[4:0] rs2,rs1,[2:0] f3);
        fS={imm[11:5],rs2,rs1,f3,imm[4:0],7'b0100011}; endfunction
    function automatic logic [31:0] fB(
        input signed [12:0] off,[4:0] rs2,rs1,[2:0] f3);
        logic [12:0] o; o=off;
        fB={o[12],o[10:5],rs2,rs1,f3,o[4:1],o[11],7'b1100011}; endfunction
    function automatic logic [31:0] fJ(
        input signed [20:0] off,[4:0] rd);
        logic [20:0] o; o=off;
        fJ={o[20],o[10:1],o[11],o[19:12],rd,7'b1101111}; endfunction
    function automatic logic [31:0] fU(
        input [19:0] hi,[4:0] rd,[6:0] op);
        fU={hi,rd,op}; endfunction

    // =========================================================================
    // Random programme generator (task avoids iverilog unpacked-array port bug)
    // =========================================================================
    function automatic logic [31:0] mk_R2(
        input [6:0] f7, input [4:0] rs2,rs1,rd, input [2:0] f3);
        mk_R2 = {f7,rs2,rs1,f3,rd,7'b0110011}; endfunction
    function automatic logic [31:0] mk_I2(
        input [11:0] imm, input [4:0] rs1,rd, input [2:0] f3, input [6:0] op);
        mk_I2 = {imm,rs1,f3,rd,op}; endfunction
    function automatic logic [31:0] mk_S2(
        input [11:0] imm, input [4:0] rs2,rs1, input [2:0] f3);
        mk_S2 = {imm[11:5],rs2,rs1,f3,imm[4:0],7'b0100011}; endfunction


    // =========================================================================
    // Halt detection: JAL x0,0 loops same PC forever; require 3 consecutive
    // hits to avoid false-positive from BLT back-branch (which alternates PCs)
    // =========================================================================
    logic        halt_seen;
    logic [31:0] prev_commit_pc;
    int          same_pc_cnt;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            halt_seen      <= 0;
            prev_commit_pc <= 32'hDEAD_BEEF;
            same_pc_cnt    <= 0;
        end else if (commit_valid) begin
            if (commit_pc == prev_commit_pc) begin
                same_pc_cnt <= same_pc_cnt + 1;
                if (same_pc_cnt >= 2) halt_seen <= 1'b1;
            end else begin
                same_pc_cnt    <= 0;
            end
            prev_commit_pc <= commit_pc;
        end
    end

    // =========================================================================
    // Helpers
    // =========================================================================
    int tb_pass, tb_fail;

    task automatic do_reset(input int n);
        rst_n = 0;
        repeat(n) @(posedge clk);
        @(negedge clk); rst_n = 1;
    endtask

    task automatic wait_halt(input int limit);
        int t; t = 0;
        while (!halt_seen && t < limit) begin
            @(posedge clk); t++;
        end
        if (t >= limit) begin
            $error("[TB] Timeout after %0d cycles", limit);
            tb_fail++;
        end
    endtask

    task automatic check_reg(input int n, input logic [31:0] exp, input string lbl);
        logic [31:0] actual;
        // Direct hierarchical reference bypasses iverilog unpacked-array port propagation issue
        actual = (n == 0) ? 32'b0 : dut.u_core.u_rf.regs[n];
        if (actual !== exp) begin
            $error("[FAIL] %s: x%0d = 0x%08h, expected 0x%08h",lbl,n,actual,exp);
            tb_fail++;
        end else tb_pass++;
    endtask

    // =========================================================================
    // ── DIRECTED TEST PROGRAMME ───────────────────────────────────────────────
    // Sections:
    //  A  Basic arithmetic + consecutive EX→EX forwarding
    //  B  Back-to-back same-reg forwarding
    //  C  Store/load + load-use hazard
    //  D  Shift operations
    //  E  SLT / SLTU
    //  F  LUI / AUIPC
    //  G  Branch loop (BLT)
    //  H  JAL (forward jump, skip one instruction)
    //  I  JALR
    // =========================================================================
    task automatic load_directed();
        int i;
        for (i = 0; i < IMEM_D; i++) dut.u_imem.mem[i] = 32'h00000013; // fill NOPs
        i = 0;

        // ── A: basic arithmetic + EX→EX forwarding ──────────────────────────
        dut.u_imem.mem[i++] = fI(12'd10, 5'd0, 5'd1, 3'b000, 7'b0010011); // ADDI x1,x0,10
        dut.u_imem.mem[i++] = fI(12'd20, 5'd0, 5'd2, 3'b000, 7'b0010011); // ADDI x2,x0,20
        dut.u_imem.mem[i++] = fR(7'h00,5'd2,5'd1,5'd3,3'b000); // ADD  x3=x1+x2=30
        dut.u_imem.mem[i++] = fR(7'h20,5'd1,5'd2,5'd4,3'b000); // SUB  x4=x2-x1=10
        dut.u_imem.mem[i++] = fR(7'h00,5'd4,5'd3,5'd5,3'b111); // AND  x5=x3&x4=10
        dut.u_imem.mem[i++] = fR(7'h00,5'd4,5'd3,5'd6,3'b110); // OR   x6=x3|x4=30
        dut.u_imem.mem[i++] = fR(7'h00,5'd4,5'd3,5'd7,3'b100); // XOR  x7=x3^x4=20

        // ── B: back-to-back same-source forwarding ───────────────────────────
        dut.u_imem.mem[i++] = fR(7'h00,5'd3,5'd3,5'd8, 3'b000); // ADD x8 =30+30=60
        dut.u_imem.mem[i++] = fR(7'h00,5'd4,5'd8,5'd9, 3'b000); // ADD x9 =60+10=70
        dut.u_imem.mem[i++] = fR(7'h00,5'd8,5'd9,5'd10,3'b000); // ADD x10=70+60=130

        // ── C: store/load + load-use hazard ─────────────────────────────────
        dut.u_imem.mem[i++] = fI(12'h400,5'd0,5'd11,3'b000,7'b0010011); // ADDI x11=0x400
        dut.u_imem.mem[i++] = fS(12'd0,5'd3,5'd11,3'b010);              // SW x3→mem[0x400]
        dut.u_imem.mem[i++] = fI(12'd0,5'd11,5'd12,3'b010,7'b0000011);  // LW x12←mem[0x400]
        dut.u_imem.mem[i++] = 32'h00000013;                              // NOP (no hazard)
        dut.u_imem.mem[i++] = fR(7'h00,5'd1,5'd12,5'd13,3'b000);        // ADD x13=x12+x1=40
        dut.u_imem.mem[i++] = fS(12'd4,5'd1,5'd11,3'b010);              // SW x1→mem[0x404]
        dut.u_imem.mem[i++] = fI(12'd4,5'd11,5'd14,3'b010,7'b0000011);  // LW x14←mem[0x404]
        dut.u_imem.mem[i++] = fR(7'h00,5'd2,5'd14,5'd15,3'b000);        // ADD x15=x14+x2 (LOAD-USE)

        // ── D: shifts ────────────────────────────────────────────────────────
        dut.u_imem.mem[i++] = fI(12'd1,  5'd0,5'd16,3'b000,7'b0010011); // ADDI x16=1
        dut.u_imem.mem[i++] = fI({7'b0000000,5'd4}, 5'd16,5'd17,3'b001,7'b0010011); // SLLI x17=16
        dut.u_imem.mem[i++] = fI({7'b0000000,5'd2}, 5'd17,5'd18,3'b101,7'b0010011); // SRLI x18=4
        dut.u_imem.mem[i++] = fI({7'b0100000,5'd1}, 5'd17,5'd19,3'b101,7'b0010011); // SRAI x19=8
        dut.u_imem.mem[i++] = fI(12'hFFF,5'd0,5'd20,3'b000,7'b0010011); // ADDI x20=-1
        dut.u_imem.mem[i++] = fI({7'b0100000,5'd4}, 5'd20,5'd21,3'b101,7'b0010011); // SRAI x21=-1

        // ── E: SLT / SLTU ────────────────────────────────────────────────────
        dut.u_imem.mem[i++] = fI(12'hFFF,5'd0,5'd22,3'b000,7'b0010011); // ADDI x22=-1
        dut.u_imem.mem[i++] = fI(12'd1,  5'd0,5'd23,3'b000,7'b0010011); // ADDI x23=1
        dut.u_imem.mem[i++] = fR(7'h00,5'd23,5'd22,5'd24,3'b010);       // SLT  x24=1 (-1<1)
        dut.u_imem.mem[i++] = fR(7'h00,5'd23,5'd22,5'd25,3'b011);       // SLTU x25=0

        // ── F: LUI / AUIPC ───────────────────────────────────────────────────
        dut.u_imem.mem[i++] = fU(20'h00001,5'd26,7'b0110111); // LUI  x26=0x1000
        dut.u_imem.mem[i++] = fU(20'h00000,5'd27,7'b0010111); // AUIPC x27=PC+0

        // ── G: branch loop (BLT, count 0→3) ──────────────────────────────────
        dut.u_imem.mem[i++] = fI(12'd0,5'd0,5'd28,3'b000,7'b0010011); // ADDI x28=0
        dut.u_imem.mem[i++] = fI(12'd3,5'd0,5'd29,3'b000,7'b0010011); // ADDI x29=3
        // loop_start at word i
        dut.u_imem.mem[i++] = fI(12'd1,5'd28,5'd28,3'b000,7'b0010011); // ADDI x28++
        dut.u_imem.mem[i++] = fB(-13'sd4, 5'd29,5'd28,3'b100); // BLT x28,x29,-4

        // ── H: JAL forward (+8 = skip 1 instruction) ─────────────────────────
        dut.u_imem.mem[i++] = fJ(21'sd8,5'd30);                           // JAL x30,+8
        dut.u_imem.mem[i++] = fI(12'd99,5'd0,5'd31,3'b000,7'b0010011);   // ADDI x31=99 SKIP
        dut.u_imem.mem[i++] = fI(12'd42,5'd0,5'd2, 3'b000,7'b0010011);   // ADDI x2=42

        // ── I: JALR (+16 from x30=0x8C skips to 0x9C past x31=99) ─────────────
        // JAL left x30=PC_JAL+4=0x8C. JALR target=(0x8C+16)&~1=0x9C → ADDI x3,x0,77
        dut.u_imem.mem[i++] = fI(12'd16,5'd30,5'd30,3'b000,7'b1100111);  // JALR x30,x30,16
        dut.u_imem.mem[i++] = fI(12'd99,5'd0,5'd31,3'b000,7'b0010011);   // ADDI x31=99 SKIP
        dut.u_imem.mem[i++] = fI(12'd77,5'd0,5'd3, 3'b000,7'b0010011);   // ADDI x3=77

        // ── HALT ──────────────────────────────────────────────────────────────
        dut.u_imem.mem[i++] = 32'h0000006F; // JAL x0, 0
        $display("[TB] Directed prog: %0d words", i);
    endtask

    // =========================================================================
    // ── SIMULATION ENTRY ──────────────────────────────────────────────────────
    // =========================================================================
    initial begin
        tb_pass = 0; tb_fail = 0;

        $dumpfile("cpu_waves.vcd");
        $dumpvars(0, tb_cpu_top);

        $display("============================================================");
        $display("  RV32I 5-Stage Pipeline – Test Suite");
        $display("============================================================");

        // ---- TEST 1: DIRECTED -----------------------------------------------
        $display("\n--- Directed Test ---");
        rst_n = 0;
        repeat(5) @(posedge clk);
        load_directed();
        @(negedge clk); rst_n = 1;
        wait_halt(3000);
        repeat(10) @(posedge clk);

        // ---- Verify architectural state -------------------------------------
        // Section A
        check_reg( 1, 32'd10,        "A: x1");
        check_reg( 4, 32'd10,        "A: x4=SUB");
        check_reg( 5, 32'd10,        "A: x5=AND");
        check_reg( 6, 32'd30,        "A: x6=OR");
        check_reg( 7, 32'd20,        "A: x7=XOR");
        // Section B
        check_reg( 8, 32'd60,        "B: x8");
        check_reg( 9, 32'd70,        "B: x9");
        check_reg(10, 32'd130,       "B: x10");
        // Section C
        check_reg(11, 32'h400,       "C: x11=base");
        check_reg(12, 32'd30,        "C: x12=load");
        check_reg(13, 32'd40,        "C: x13=40");
        check_reg(14, 32'd10,        "C: x14=load-use-src");
        check_reg(15, 32'd30,        "C: x15=load-use(10+20=30)");
        // Section D
        check_reg(16, 32'd1,         "D: x16");
        check_reg(17, 32'd16,        "D: x17=SLLI");
        check_reg(18, 32'd4,         "D: x18=SRLI");
        check_reg(19, 32'd8,         "D: x19=SRAI");
        check_reg(20, 32'hFFFFFFFF,  "D: x20=-1");
        check_reg(21, 32'hFFFFFFFF,  "D: x21=SRAI(-1)");
        // Section E
        check_reg(24, 32'd1,         "E: x24=SLT");
        check_reg(25, 32'd0,         "E: x25=SLTU");
        // Section F
        check_reg(26, 32'h00001000,  "F: x26=LUI");
        // Section G
        check_reg(28, 32'd3,         "G: x28=loop result");
        check_reg(29, 32'd3,         "G: x29=limit");
        // Section H/I  (x2 and x3 overwritten by JAL/JALR targets)
        check_reg( 2, 32'd42,        "H: x2 after JAL skip");
        check_reg( 3, 32'd77,        "I: x3 after JALR skip");
        check_reg(31, 32'd0,         "H/I: x31 not written (skipped)");

        $display("\n[Directed] TB: PASS=%0d FAIL=%0d  SB: PASS=%0d FAIL=%0d",
                 tb_pass, tb_fail, sb_pass, sb_fail);

        // ---- TEST 2: RANDOM -------------------------------------------------
        $display("\n--- Randomised Test ---");
        begin : rand_block
            // iverilog: declare all vars before first procedural statement
            int rpass_pre;
            int rfail_pre;
            int rand_cycles;
            rpass_pre   = sb_pass;
            rfail_pre   = sb_fail;
            rand_cycles = 0;

            // Generate random programme: write directly into IMEM (bypasses
            // iverilog unpacked-array task/port limitation entirely)
            begin
                integer itype_r, op_r;
                logic [4:0] rd_r, rs1_r, rs2_r, sh_r;
                logic [11:0] imm_r, off_r;
                integer sv_r;
                sv_r = 42; void'($urandom(sv_r));
                // Preamble: x1 = DMEM_BASE
                dut.u_imem.mem[0] = mk_I2(12'(DMEM_BASE),5'd0,5'd1,3'b000,7'b0010011);
                for (int ri = 1; ri < RAND_N; ri++) begin
                    itype_r = int'($urandom_range(0,5));
                    rd_r    = 5'($urandom_range(2,15));  // protect x1 (DMEM base)
                    rs1_r   = 5'($urandom_range(1,15));
                    rs2_r   = 5'($urandom_range(1,15));
                    imm_r   = 12'($urandom_range(0,63));
                    sh_r    = 5'($urandom_range(1,15));
                    off_r   = 12'($urandom_range(0,15)*4);
                    case (itype_r)
                        0: begin
                            op_r = int'($urandom_range(0,7));
                            case (op_r)
                                0: dut.u_imem.mem[ri]=mk_R2(7'h00,rs2_r,rs1_r,rd_r,3'b000);
                                1: dut.u_imem.mem[ri]=mk_R2(7'h20,rs2_r,rs1_r,rd_r,3'b000);
                                2: dut.u_imem.mem[ri]=mk_R2(7'h00,rs2_r,rs1_r,rd_r,3'b111);
                                3: dut.u_imem.mem[ri]=mk_R2(7'h00,rs2_r,rs1_r,rd_r,3'b110);
                                4: dut.u_imem.mem[ri]=mk_R2(7'h00,rs2_r,rs1_r,rd_r,3'b100);
                                5: dut.u_imem.mem[ri]=mk_R2(7'h00,rs2_r,rs1_r,rd_r,3'b010);
                                6: dut.u_imem.mem[ri]=mk_R2(7'h00,rs2_r,rs1_r,rd_r,3'b001);
                                7: dut.u_imem.mem[ri]=mk_R2(7'h00,rs2_r,rs1_r,rd_r,3'b101);
                                default: dut.u_imem.mem[ri]=32'h00000013;
                            endcase
                        end
                        1: dut.u_imem.mem[ri]=mk_I2(imm_r,rs1_r,rd_r,3'b000,7'b0010011);
                        2: dut.u_imem.mem[ri]=($urandom&1) ?
                               mk_I2(imm_r,rs1_r,rd_r,3'b111,7'b0010011):
                               mk_I2(imm_r,rs1_r,rd_r,3'b110,7'b0010011);
                        3: dut.u_imem.mem[ri]=mk_I2(off_r,5'd0,rd_r,3'b010,7'b0000011); // LW x0-based
                        4: dut.u_imem.mem[ri]=mk_S2(off_r,rs2_r,5'd0,3'b010); // SW x0-based
                        default: dut.u_imem.mem[ri]={7'b0000000,sh_r,rs1_r,3'b001,rd_r,7'b0010011};
                    endcase
                end
                dut.u_imem.mem[RAND_N] = 32'h0000006F; // halt
                for (int k = RAND_N+1; k < IMEM_D; k++)
                    dut.u_imem.mem[k] = 32'h0000006F;
            end

            // Verify
            $display("[RNG] IMEM[0]=%08h IMEM[1]=%08h IMEM[%0d]=%08h",
                     dut.u_imem.mem[0], dut.u_imem.mem[1],
                     RAND_N, dut.u_imem.mem[RAND_N]);

            // Hard-reset: ensures halt_seen clears (negedge rst_n fires always_ff)
            rst_n = 0;
            @(posedge clk);          // one posedge during reset clears halt_seen
            @(posedge clk);
            @(posedge clk);
            @(posedge clk);
            @(posedge clk);
            @(negedge clk);
            rst_n = 1;
            @(posedge clk);          // one more so pipeline starts cleanly
            $display("[RNG] halt_seen=%0b at start of random run", halt_seen);

            // Run until halt or timeout
            while (!halt_seen && rand_cycles < 8000) begin
                @(posedge clk);
                rand_cycles++;
            end
            if (rand_cycles >= 8000) begin
                $error("[TB] Random test timeout");
                tb_fail++;
            end
            repeat(10) @(posedge clk);

            $display("[Random] cycles=%0d  SB delta: PASS=%0d FAIL=%0d",
                     rand_cycles, sb_pass - rpass_pre, sb_fail - rfail_pre);
        end

        // ---- Summary --------------------------------------------------------
        $display("\n============================================================");
        $display("FINAL: TB=%0d/%0d  SB=%0d/%0d  (pass/fail)",
                 tb_pass, tb_fail, sb_pass, sb_fail);
        if (tb_fail == 0 && sb_fail == 0)
            $display("ALL TESTS PASSED");
        else
            $display("*** FAILURES DETECTED ***");
        $display("============================================================");
        $finish;
    end

    // Watchdog
    initial begin #5_000_000; $error("GLOBAL TIMEOUT"); $finish; end

    // Commit monitor
    always_ff @(posedge clk)
        if (rst_n && commit_valid && commit_we)
            $display("[WB] PC=%08h x%02d <- %08h", commit_pc, commit_rd, commit_wdata);

    // Immediate assertions on commit bus
    always @(posedge clk) begin
        if (rst_n) begin
            if (commit_valid && commit_pc[1:0] !== 2'b00)
                $error("ASSERT: misaligned commit PC %08h", commit_pc);
            if (commit_we && commit_rd == 5'b0)
                $error("ASSERT: commit write to x0");
        end
    end

endmodule
