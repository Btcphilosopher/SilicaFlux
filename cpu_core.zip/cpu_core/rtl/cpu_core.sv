`timescale 1ns/1ps
// =============================================================================
// cpu_core.sv  –  RV32I 5-Stage Pipelined Processor Core
// Stages     : IF → ID → EX → MEM → WB
// Hazards    : load-use (1-cycle stall) + control hazards (2-cycle flush)
// Forwarding : EX/MEM→EX, MEM/WB→EX, RF write-through for WB→ID
// =============================================================================
import cpu_pkg::*;

module cpu_core (
    input  logic        clk,
    input  logic        rst_n,
    // Instruction memory (combinational read)
    output logic [31:0] imem_addr,
    input  logic [31:0] imem_rdata,
    // Data memory (byte-enable write, registered read)
    output logic [31:0] dmem_addr,
    output logic [31:0] dmem_wdata,
    output logic [3:0]  dmem_be,
    output logic        dmem_we,
    output logic        dmem_re,
    input  logic [31:0] dmem_rdata,
    // Commit/debug bus
    output logic        commit_valid,
    output logic [31:0] commit_pc,
    output logic [31:0] commit_instr,
    output logic [4:0]  commit_rd,
    output logic [31:0] commit_wdata,
    output logic        commit_we,
    output logic [31:0] dbg_rf [32]
);

    // =========================================================================
    // Pipeline registers
    // =========================================================================
    if_id_reg_t  if_id_q, if_id_d;
    id_ex_reg_t  id_ex_q, id_ex_d;
    ex_mem_reg_t ex_mem_q, ex_mem_d;
    mem_wb_reg_t mem_wb_q;

    // PC and carry-through PC for commit bus
    logic [31:0] pc_q, pc_d;
    logic [31:0] ex_mem_pc_q, mem_wb_pc_q;

    // Hazard / flush
    logic pc_stall, if_id_stall, if_id_flush, id_ex_bubble, id_ex_flush;
    // Forwarding selects
    logic [1:0] forward_a, forward_b;

    // =========================================================================
    // ── IF STAGE ─────────────────────────────────────────────────────────────
    // =========================================================================
    assign imem_addr  = pc_q;
    assign if_id_d.pc    = pc_q;
    assign if_id_d.instr = imem_rdata;
    assign if_id_d.valid = 1'b1;

    // =========================================================================
    // ── ID STAGE – DECODE / REGISTER READ ───────────────────────────────────
    // =========================================================================
    logic [6:0] id_opcode;
    logic [4:0] id_rd, id_rs1, id_rs2;
    logic [2:0] id_funct3;
    logic [6:0] id_funct7;

    assign id_opcode = if_id_q.instr[6:0];
    assign id_rd     = if_id_q.instr[11:7];
    assign id_funct3 = if_id_q.instr[14:12];
    assign id_rs1    = if_id_q.instr[19:15];
    assign id_rs2    = if_id_q.instr[24:20];
    assign id_funct7 = if_id_q.instr[31:25];

    logic [31:0] imm_i, imm_s, imm_b, imm_u, imm_j;
    assign imm_i = {{20{if_id_q.instr[31]}}, if_id_q.instr[31:20]};
    assign imm_s = {{20{if_id_q.instr[31]}}, if_id_q.instr[31:25], if_id_q.instr[11:7]};
    assign imm_b = {{19{if_id_q.instr[31]}}, if_id_q.instr[31], if_id_q.instr[7],
                    if_id_q.instr[30:25], if_id_q.instr[11:8], 1'b0};
    assign imm_u = {if_id_q.instr[31:12], 12'b0};
    assign imm_j = {{11{if_id_q.instr[31]}}, if_id_q.instr[31], if_id_q.instr[19:12],
                    if_id_q.instr[20], if_id_q.instr[30:21], 1'b0};

    logic [31:0] rf_rd1, rf_rd2;
    logic [31:0] wb_wdata;
    logic        wb_we;

    // ---- Control unit -------------------------------------------------------
    always_comb begin : ctrl_decode
        id_ex_d             = '0;
        id_ex_d.pc          = if_id_q.pc;
        id_ex_d.pc_plus4    = if_id_q.pc + 32'd4;
        id_ex_d.rs1         = id_rs1;
        id_ex_d.rs2         = id_rs2;
        id_ex_d.rd          = id_rd;
        id_ex_d.funct3      = id_funct3;
        id_ex_d.rs1_data    = rf_rd1;
        id_ex_d.rs2_data    = rf_rd2;
        id_ex_d.valid       = if_id_q.valid;

        case (id_opcode)
            OP_R: begin
                id_ex_d.reg_write = 1'b1;
                id_ex_d.wb_sel    = WB_ALU;
                case ({id_funct7[5], id_funct3})
                    4'b0000: id_ex_d.alu_op = ALU_ADD;
                    4'b1000: id_ex_d.alu_op = ALU_SUB;
                    4'b0001: id_ex_d.alu_op = ALU_SLL;
                    4'b0010: id_ex_d.alu_op = ALU_SLT;
                    4'b0011: id_ex_d.alu_op = ALU_SLTU;
                    4'b0100: id_ex_d.alu_op = ALU_XOR;
                    4'b0101: id_ex_d.alu_op = ALU_SRL;
                    4'b1101: id_ex_d.alu_op = ALU_SRA;
                    4'b0110: id_ex_d.alu_op = ALU_OR;
                    4'b0111: id_ex_d.alu_op = ALU_AND;
                    default: id_ex_d.alu_op = ALU_ADD;
                endcase
            end
            OP_I_ALU: begin
                id_ex_d.reg_write = 1'b1;
                id_ex_d.alu_b_src = 1'b1;
                id_ex_d.imm       = imm_i;
                id_ex_d.wb_sel    = WB_ALU;
                case (id_funct3)
                    3'b000: id_ex_d.alu_op = ALU_ADD;
                    3'b010: id_ex_d.alu_op = ALU_SLT;
                    3'b011: id_ex_d.alu_op = ALU_SLTU;
                    3'b100: id_ex_d.alu_op = ALU_XOR;
                    3'b110: id_ex_d.alu_op = ALU_OR;
                    3'b111: id_ex_d.alu_op = ALU_AND;
                    3'b001: id_ex_d.alu_op = ALU_SLL;
                    3'b101: id_ex_d.alu_op = id_funct7[5] ? ALU_SRA : ALU_SRL;
                    default: id_ex_d.alu_op = ALU_ADD;
                endcase
            end
            OP_LOAD: begin
                id_ex_d.reg_write = 1'b1;
                id_ex_d.alu_b_src = 1'b1;
                id_ex_d.imm       = imm_i;
                id_ex_d.alu_op    = ALU_ADD;
                id_ex_d.mem_read  = 1'b1;
                id_ex_d.wb_sel    = WB_MEM;
            end
            OP_STORE: begin
                id_ex_d.alu_b_src = 1'b1;
                id_ex_d.imm       = imm_s;
                id_ex_d.alu_op    = ALU_ADD;
                id_ex_d.mem_write = 1'b1;
            end
            OP_BRANCH: begin
                id_ex_d.imm    = imm_b;
                id_ex_d.branch = 1'b1;
            end
            OP_JAL: begin
                id_ex_d.reg_write = 1'b1;
                id_ex_d.alu_a_src = 1'b1;   // PC
                id_ex_d.alu_b_src = 1'b1;   // imm_j
                id_ex_d.imm       = imm_j;
                id_ex_d.alu_op    = ALU_ADD;
                id_ex_d.wb_sel    = WB_PC4;
                id_ex_d.jump      = 1'b1;
            end
            OP_JALR: begin
                id_ex_d.reg_write = 1'b1;
                id_ex_d.alu_b_src = 1'b1;
                id_ex_d.imm       = imm_i;
                id_ex_d.alu_op    = ALU_ADD;
                id_ex_d.wb_sel    = WB_PC4;
                id_ex_d.jump      = 1'b1;
                id_ex_d.is_jalr   = 1'b1;
            end
            OP_LUI: begin
                id_ex_d.reg_write = 1'b1;
                id_ex_d.alu_b_src = 1'b1;
                id_ex_d.imm       = imm_u;
                id_ex_d.alu_op    = ALU_COPY_B;
                id_ex_d.wb_sel    = WB_ALU;
            end
            OP_AUIPC: begin
                id_ex_d.reg_write = 1'b1;
                id_ex_d.alu_a_src = 1'b1;   // PC
                id_ex_d.alu_b_src = 1'b1;
                id_ex_d.imm       = imm_u;
                id_ex_d.alu_op    = ALU_ADD;
                id_ex_d.wb_sel    = WB_ALU;
            end
            default: ;   // NOP/FENCE/SYSTEM – all zeros already
        endcase
    end

    // =========================================================================
    // ── EX STAGE ─────────────────────────────────────────────────────────────
    // =========================================================================
    logic [31:0] fwd_rs1, fwd_rs2;
    logic [31:0] wb_result_fwd;

    // WB forward data: select among ALU result, load data, PC+4
    always_comb begin : wb_fwd_sel
        case (mem_wb_q.wb_sel)
            WB_MEM : wb_result_fwd = dmem_rdata;
            WB_PC4 : wb_result_fwd = mem_wb_q.pc_plus4;
            default: wb_result_fwd = mem_wb_q.alu_result;
        endcase
    end

    always_comb begin : fwd_mux_a
        case (forward_a)
            2'b10  : fwd_rs1 = ex_mem_q.alu_result;
            2'b01  : fwd_rs1 = wb_result_fwd;
            default: fwd_rs1 = id_ex_q.rs1_data;
        endcase
    end

    always_comb begin : fwd_mux_b
        case (forward_b)
            2'b10  : fwd_rs2 = ex_mem_q.alu_result;
            2'b01  : fwd_rs2 = wb_result_fwd;
            default: fwd_rs2 = id_ex_q.rs2_data;
        endcase
    end

    logic [31:0] alu_a, alu_b, alu_result;
    logic        alu_zero;
    assign alu_a = id_ex_q.alu_a_src ? id_ex_q.pc  : fwd_rs1;
    assign alu_b = id_ex_q.alu_b_src ? id_ex_q.imm : fwd_rs2;

    // Branch comparator (dedicated; does not use ALU)
    logic branch_taken;
    always_comb begin : branch_cmp
        branch_taken = 1'b0;
        if (id_ex_q.branch && id_ex_q.valid) begin
            case (id_ex_q.funct3)
                3'b000: branch_taken = (fwd_rs1 == fwd_rs2);
                3'b001: branch_taken = (fwd_rs1 != fwd_rs2);
                3'b100: branch_taken = ($signed(fwd_rs1) <  $signed(fwd_rs2));
                3'b101: branch_taken = ($signed(fwd_rs1) >= $signed(fwd_rs2));
                3'b110: branch_taken = (fwd_rs1 <  fwd_rs2);
                3'b111: branch_taken = (fwd_rs1 >= fwd_rs2);
                default: branch_taken = 1'b0;
            endcase
        end
    end

    logic [31:0] branch_target, jump_target;
    assign branch_target = id_ex_q.pc + id_ex_q.imm;
    // JAL: alu_result = PC + imm_j; JALR: alu_result = rs1+imm, mask bit-0
    assign jump_target = id_ex_q.is_jalr ? {alu_result[31:1], 1'b0} : alu_result;

    logic jump_ex;
    assign jump_ex = id_ex_q.jump && id_ex_q.valid;

    // EX/MEM combinational
    always_comb begin : ex_mem_stage
        ex_mem_d.pc_plus4   = id_ex_q.pc_plus4;
        ex_mem_d.alu_result = alu_result;
        ex_mem_d.rs2_data   = fwd_rs2;     // forwarded store data
        ex_mem_d.rd         = id_ex_q.rd;
        ex_mem_d.mem_read   = id_ex_q.mem_read;
        ex_mem_d.mem_write  = id_ex_q.mem_write;
        ex_mem_d.reg_write  = id_ex_q.reg_write;
        ex_mem_d.wb_sel     = id_ex_q.wb_sel;
        ex_mem_d.funct3     = id_ex_q.funct3;
        ex_mem_d.valid      = id_ex_q.valid;
    end

    // =========================================================================
    // ── MEM STAGE ────────────────────────────────────────────────────────────
    // =========================================================================
    logic [31:0] store_data;
    logic [3:0]  byte_en;

    always_comb begin : store_align
        case (ex_mem_q.funct3)
            3'b000: begin   // SB
                store_data = {4{ex_mem_q.rs2_data[7:0]}};
                byte_en    = 4'b0001 << ex_mem_q.alu_result[1:0];
            end
            3'b001: begin   // SH
                store_data = {2{ex_mem_q.rs2_data[15:0]}};
                byte_en    = ex_mem_q.alu_result[1] ? 4'b1100 : 4'b0011;
            end
            default: begin  // SW
                store_data = ex_mem_q.rs2_data;
                byte_en    = 4'b1111;
            end
        endcase
    end

    assign dmem_addr  = ex_mem_q.alu_result;
    assign dmem_wdata = store_data;
    assign dmem_be    = byte_en;
    assign dmem_we    = ex_mem_q.mem_write & ex_mem_q.valid;
    assign dmem_re    = ex_mem_q.mem_read  & ex_mem_q.valid;

    // =========================================================================
    // ── WB STAGE ─────────────────────────────────────────────────────────────
    // =========================================================================
    logic [31:0] load_data;
    always_comb begin : load_sign_ext
        case (mem_wb_q.funct3)
            3'b000: load_data = {{24{dmem_rdata[7]}},  dmem_rdata[7:0]};
            3'b001: load_data = {{16{dmem_rdata[15]}}, dmem_rdata[15:0]};
            3'b010: load_data = dmem_rdata;
            3'b100: load_data = {24'b0, dmem_rdata[7:0]};
            3'b101: load_data = {16'b0, dmem_rdata[15:0]};
            default: load_data = dmem_rdata;
        endcase
    end

    always_comb begin : wb_mux
        case (mem_wb_q.wb_sel)
            WB_MEM : wb_wdata = load_data;
            WB_PC4 : wb_wdata = mem_wb_q.pc_plus4;
            default: wb_wdata = mem_wb_q.alu_result;
        endcase
    end

    // wb_we: only assert when destination is not x0
    assign wb_we        = mem_wb_q.reg_write & mem_wb_q.valid & (|mem_wb_q.rd);
    assign commit_valid  = mem_wb_q.valid;
    assign commit_pc     = mem_wb_pc_q;
    assign commit_instr  = mem_wb_q.instr_w;   // instruction word for scoreboard
    assign commit_rd     = mem_wb_q.rd;
    assign commit_wdata  = wb_wdata;
    assign commit_we     = wb_we;

    // =========================================================================
    // ── PC NEXT-STATE ─────────────────────────────────────────────────────────
    // =========================================================================
    always_comb begin : pc_next
        if      (branch_taken) pc_d = branch_target;
        else if (jump_ex)      pc_d = jump_target;
        else if (pc_stall)     pc_d = pc_q;
        else                   pc_d = pc_q + 32'd4;
    end

    // =========================================================================
    // ── PIPELINE REGISTERS (clocked) ─────────────────────────────────────────
    // =========================================================================
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) pc_q <= 32'b0;
        else        pc_q <= pc_d;
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n || if_id_flush)
            if_id_q <= '0;
        else if (!if_id_stall)
            if_id_q <= if_id_d;
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n || id_ex_flush || id_ex_bubble)
            id_ex_q <= '0;
        else
            id_ex_q <= id_ex_d;
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) ex_mem_q <= '0;
        else        ex_mem_q <= ex_mem_d;
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mem_wb_q      <= '0;
            ex_mem_pc_q   <= '0;
            mem_wb_pc_q   <= '0;
        end else begin
            mem_wb_q.pc_plus4   <= ex_mem_q.pc_plus4;
            mem_wb_q.alu_result <= ex_mem_q.alu_result;
            mem_wb_q.instr_w    <= ex_mem_instr_q;   // instruction carried to WB
            mem_wb_q.rd         <= ex_mem_q.rd;
            mem_wb_q.reg_write  <= ex_mem_q.reg_write;
            mem_wb_q.wb_sel     <= ex_mem_q.wb_sel;
            mem_wb_q.funct3     <= ex_mem_q.funct3;
            mem_wb_q.valid      <= ex_mem_q.valid;
            // Carry PC through for commit bus
            ex_mem_pc_q         <= id_ex_q.pc;
            mem_wb_pc_q         <= ex_mem_pc_q;
        end
    end

    // Carry instruction word through EX/MEM → MEM/WB
    logic [31:0] id_ex_instr_q, ex_mem_instr_q;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            id_ex_instr_q  <= '0;
            ex_mem_instr_q <= '0;
        end else begin
            id_ex_instr_q  <= id_ex_bubble || id_ex_flush ? 32'h0000_0013
                                                          : if_id_q.instr;
            ex_mem_instr_q <= id_ex_instr_q;
        end
    end

    // =========================================================================
    // ── SUBMODULES ────────────────────────────────────────────────────────────
    // =========================================================================
    alu u_alu (
        .a(alu_a), .b(alu_b), .op(id_ex_q.alu_op),
        .result(alu_result), .zero(alu_zero)
    );

    register_file u_rf (
        .clk(clk), .rst_n(rst_n),
        .rs1(id_rs1), .rs2(id_rs2), .rd1(rf_rd1), .rd2(rf_rd2),
        .rd(mem_wb_q.rd), .wd(wb_wdata), .we(wb_we),
        .dbg_rf(dbg_rf)
    );

    hazard_unit u_haz (
        .id_ex_mem_read(id_ex_q.mem_read),
        .id_ex_rd      (id_ex_q.rd),
        .if_id_rs1     (id_rs1),
        .if_id_rs2     (id_rs2),
        .branch_taken  (branch_taken),
        .jump_ex       (jump_ex),
        .pc_stall      (pc_stall),
        .if_id_stall   (if_id_stall),
        .if_id_flush   (if_id_flush),
        .id_ex_bubble  (id_ex_bubble),
        .id_ex_flush   (id_ex_flush)
    );

    forward_unit u_fwd (
        .id_ex_rs1       (id_ex_q.rs1),
        .id_ex_rs2       (id_ex_q.rs2),
        .ex_mem_rd       (ex_mem_q.rd),
        .ex_mem_reg_write(ex_mem_q.reg_write),
        .mem_wb_rd       (mem_wb_q.rd),
        .mem_wb_reg_write(mem_wb_q.reg_write),
        .forward_a       (forward_a),
        .forward_b       (forward_b)
    );

    // =========================================================================
    // ── PIPELINE ASSERTIONS (immediate; fire on posedge clk) ─────────────────
    // =========================================================================
    always @(posedge clk) begin
        if (rst_n) begin
            // x0 must always be zero
            if (dbg_rf[0] !== 32'b0)
                $error("ASSERT: x0 != 0, value=%0h", dbg_rf[0]);

            // Forward select consistency
            if (forward_a == 2'b10 && !(ex_mem_q.reg_write && ex_mem_q.rd != 5'b0))
                $error("ASSERT: forward_a=EX/MEM but ex_mem has no valid reg write");
            if (forward_b == 2'b10 && !(ex_mem_q.reg_write && ex_mem_q.rd != 5'b0))
                $error("ASSERT: forward_b=EX/MEM but ex_mem has no valid reg write");

            // PC must be word-aligned
            if (pc_q[1:0] !== 2'b00)
                $error("ASSERT: PC misaligned = %08h", pc_q);
        end
    end

    // Load-use bubble: sampled one cycle after hazard detection
    logic prev_load_use;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) prev_load_use <= 1'b0;
        else prev_load_use <= (id_ex_q.mem_read && id_ex_q.valid
                               && id_ex_q.rd != 5'b0
                               && (id_ex_q.rd == id_rs1 || id_ex_q.rd == id_rs2));
    end
    always @(posedge clk) begin
        if (rst_n && prev_load_use) begin
            if (id_ex_q.valid !== 1'b0)
                $error("ASSERT: load-use hazard not stalled correctly");
        end
    end

endmodule
