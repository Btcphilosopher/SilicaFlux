`timescale 1ns/1ps
// =============================================================================
// alu.sv  –  32-bit Arithmetic/Logic Unit (pure combinational)
// Supports: ADD SUB AND OR XOR SLT SLTU SLL SRL SRA COPY_B
// =============================================================================
import cpu_pkg::*;

module alu (
    input  logic [31:0] a,
    input  logic [31:0] b,
    input  alu_op_e     op,
    output logic [31:0] result,
    output logic        zero    // result == 0 (unused internally; exposed for debug)
);
    always_comb begin : alu_compute
        unique case (op)
            ALU_ADD   : result = a + b;
            ALU_SUB   : result = a - b;
            ALU_AND   : result = a & b;
            ALU_OR    : result = a | b;
            ALU_XOR   : result = a ^ b;
            ALU_SLT   : result = {31'b0, $signed(a) < $signed(b)};
            ALU_SLTU  : result = {31'b0, a < b};
            ALU_SLL   : result = a << b[4:0];
            ALU_SRL   : result = a >> b[4:0];
            ALU_SRA   : result = $signed(a) >>> b[4:0];
            ALU_COPY_B: result = b;
            default   : result = 32'b0;
        endcase
    end

    assign zero = (result == 32'b0);
endmodule
