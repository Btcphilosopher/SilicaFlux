`timescale 1ns/1ps
// =============================================================================
// instr_mem.sv  –  Instruction Memory (ROM / initialised SRAM)
// Combinational read for pipeline compatibility.
// For FPGA: replace with inferred BRAM + 1-cycle registered IF stage.
// =============================================================================
module instr_mem #(
    parameter int DEPTH     = 1024,           // number of 32-bit words
    parameter     INIT_FILE = ""              // optional hex file
) (
    input  logic [31:0] addr,                 // byte address (word-aligned)
    output logic [31:0] rdata
);
    logic [31:0] mem [DEPTH];

    initial begin
        for (int i = 0; i < DEPTH; i++) mem[i] = 32'h00000013; // NOP
        if (INIT_FILE != "") $readmemh(INIT_FILE, mem);
    end

    // Combinational read (word-aligned; lower 2 bits ignored)
    assign rdata = (addr[31:2] < DEPTH) ? mem[addr[31:2]] : 32'h00000013;
endmodule
