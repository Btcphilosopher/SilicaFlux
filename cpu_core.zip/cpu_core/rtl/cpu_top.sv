`timescale 1ns/1ps
// =============================================================================
// cpu_top.sv  –  Top-level: CPU core + instruction memory + data memory
// =============================================================================
import cpu_pkg::*;

module cpu_top #(
    parameter int  IMEM_DEPTH = 1024,
    parameter int  DMEM_DEPTH = 1024,
    parameter      IMEM_INIT  = ""
) (
    input  logic        clk,
    input  logic        rst_n,

    // Commit / debug bus (exposed for testbench)
    output logic        commit_valid,
    output logic [31:0] commit_pc,
    output logic [31:0] commit_instr,
    output logic [4:0]  commit_rd,
    output logic [31:0] commit_wdata,
    output logic        commit_we,
    output logic [31:0] dbg_rf [32]
);
    // ---- Memory interfaces --------------------------------------------------
    logic [31:0] imem_addr, imem_rdata;
    logic [31:0] dmem_addr, dmem_wdata, dmem_rdata;
    logic [3:0]  dmem_be;
    logic        dmem_we, dmem_re;

    // ---- Submodule instantiation --------------------------------------------
    cpu_core u_core (
        .clk          (clk),
        .rst_n        (rst_n),
        .imem_addr    (imem_addr),
        .imem_rdata   (imem_rdata),
        .dmem_addr    (dmem_addr),
        .dmem_wdata   (dmem_wdata),
        .dmem_be      (dmem_be),
        .dmem_we      (dmem_we),
        .dmem_re      (dmem_re),
        .dmem_rdata   (dmem_rdata),
        .commit_valid (commit_valid),
        .commit_pc    (commit_pc),
        .commit_instr (commit_instr),
        .commit_rd    (commit_rd),
        .commit_wdata (commit_wdata),
        .commit_we    (commit_we),
        .dbg_rf       (dbg_rf)
    );

    instr_mem #(.DEPTH(IMEM_DEPTH), .INIT_FILE(IMEM_INIT)) u_imem (
        .addr  (imem_addr),
        .rdata (imem_rdata)
    );

    data_mem #(.DEPTH(DMEM_DEPTH)) u_dmem (
        .clk   (clk),
        .addr  (dmem_addr),
        .wdata (dmem_wdata),
        .be    (dmem_be),
        .we    (dmem_we),
        .re    (dmem_re),
        .rdata (dmem_rdata)
    );
endmodule
