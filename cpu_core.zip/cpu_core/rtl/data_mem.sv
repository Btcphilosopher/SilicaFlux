`timescale 1ns/1ps
// =============================================================================
// data_mem.sv  –  Data Memory with byte-enable write and registered read
//
// Write : synchronous, byte-granular (be[i] enables byte i)
// Read  : synchronous registered output – 1-cycle latency fits the MEM→WB gap
// =============================================================================
module data_mem #(
    parameter int DEPTH = 1024            // number of 32-bit words
) (
    input  logic        clk,
    input  logic [31:0] addr,            // byte address (word-aligned)
    input  logic [31:0] wdata,
    input  logic [3:0]  be,              // byte enable for writes
    input  logic        we,
    input  logic        re,
    output logic [31:0] rdata            // registered read data (1-cycle latency)
);
    logic [7:0] mem [DEPTH*4];           // byte-addressable storage

    initial begin
        for (int i = 0; i < DEPTH*4; i++) mem[i] = 8'b0;
    end

    // Synchronous byte-enable write
    always_ff @(posedge clk) begin
        if (we) begin
            if (be[0]) mem[{addr[31:2], 2'b00}] <= wdata[7:0];
            if (be[1]) mem[{addr[31:2], 2'b01}] <= wdata[15:8];
            if (be[2]) mem[{addr[31:2], 2'b10}] <= wdata[23:16];
            if (be[3]) mem[{addr[31:2], 2'b11}] <= wdata[31:24];
        end
    end

    // Synchronous registered read (1-cycle latency)
    always_ff @(posedge clk) begin
        if (re) begin
            rdata <= { mem[{addr[31:2], 2'b11}],
                       mem[{addr[31:2], 2'b10}],
                       mem[{addr[31:2], 2'b01}],
                       mem[{addr[31:2], 2'b00}] };
        end else begin
            rdata <= 32'b0;
        end
    end
endmodule
