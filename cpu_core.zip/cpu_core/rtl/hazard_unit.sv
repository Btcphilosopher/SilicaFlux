`timescale 1ns/1ps
// =============================================================================
// hazard_unit.sv  –  Hazard Detection Unit
//
// Detects two hazard classes and drives stall / flush control:
//
// 1. LOAD-USE hazard
//    LW is in EX (ID/EX.mem_read=1) and the very next instruction (in ID)
//    reads the same destination register.
//    Action: stall PC + IF/ID; inject one bubble into ID/EX.
//
// 2. CONTROL hazard (branch taken / unconditional jump)
//    Branch or jump resolved at end of EX stage (2 cycle penalty).
//    Action: flush IF/ID and ID/EX (squash 2 instructions on wrong path).
//
// Priority: flush overrides stall (a branch can follow a load).
// =============================================================================
module hazard_unit (
    // From ID/EX (instruction currently in EX stage)
    input  logic       id_ex_mem_read,   // EX stage is a load
    input  logic [4:0] id_ex_rd,         // EX destination register

    // Decoded rs1/rs2 of instruction currently in ID stage
    input  logic [4:0] if_id_rs1,
    input  logic [4:0] if_id_rs2,

    // Branch/jump resolution from EX stage
    input  logic       branch_taken,     // branch condition true
    input  logic       jump_ex,          // unconditional jump in EX

    // Stall / flush outputs
    output logic       pc_stall,         // hold PC register
    output logic       if_id_stall,      // hold IF/ID register
    output logic       if_id_flush,      // clear IF/ID  → NOP bubble
    output logic       id_ex_bubble,     // insert NOP into ID/EX (load-use)
    output logic       id_ex_flush       // clear ID/EX  → NOP bubble (control)
);
    logic load_use;

    // Load-use: load in EX, dependent instruction in ID
    assign load_use = id_ex_mem_read
                    && id_ex_rd != 5'b0
                    && (id_ex_rd == if_id_rs1 || id_ex_rd == if_id_rs2);

    logic ctrl_flush;
    assign ctrl_flush = branch_taken | jump_ex;

    // Flush takes priority over stall
    assign pc_stall    =  load_use & ~ctrl_flush;
    assign if_id_stall =  load_use & ~ctrl_flush;
    assign id_ex_bubble=  load_use & ~ctrl_flush;   // bubble from stall
    assign if_id_flush =  ctrl_flush;
    assign id_ex_flush =  ctrl_flush;               // squash wrong-path decode
endmodule
