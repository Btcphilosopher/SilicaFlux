`timescale 1ns/1ps
// =============================================================================
// cpu_pkg  –  Shared types, opcodes, and pipeline-register structs (RV32I)
// =============================================================================
package cpu_pkg;

localparam logic [6:0]
    OP_R      = 7'b0110011,
    OP_I_ALU  = 7'b0010011,
    OP_LOAD   = 7'b0000011,
    OP_STORE  = 7'b0100011,
    OP_BRANCH = 7'b1100011,
    OP_JAL    = 7'b1101111,
    OP_JALR   = 7'b1100111,
    OP_LUI    = 7'b0110111,
    OP_AUIPC  = 7'b0010111,
    OP_FENCE  = 7'b0001111,
    OP_SYSTEM = 7'b1110011;

typedef enum logic [3:0] {
    ALU_ADD    = 4'd0,
    ALU_SUB    = 4'd1,
    ALU_AND    = 4'd2,
    ALU_OR     = 4'd3,
    ALU_XOR    = 4'd4,
    ALU_SLT    = 4'd5,
    ALU_SLTU   = 4'd6,
    ALU_SLL    = 4'd7,
    ALU_SRL    = 4'd8,
    ALU_SRA    = 4'd9,
    ALU_COPY_B = 4'd10
} alu_op_e;

typedef enum logic [1:0] {
    WB_ALU = 2'b00,
    WB_MEM = 2'b01,
    WB_PC4 = 2'b10
} wb_sel_e;

typedef struct packed {
    logic [31:0] pc;
    logic [31:0] instr;
    logic        valid;
} if_id_reg_t;

typedef struct packed {
    logic [31:0] pc;
    logic [31:0] pc_plus4;
    logic [31:0] rs1_data;
    logic [31:0] rs2_data;
    logic [31:0] imm;
    logic [4:0]  rs1;
    logic [4:0]  rs2;
    logic [4:0]  rd;
    alu_op_e     alu_op;
    logic        alu_a_src;
    logic        alu_b_src;
    logic        mem_read;
    logic        mem_write;
    logic        reg_write;
    wb_sel_e     wb_sel;
    logic        branch;
    logic        jump;
    logic        is_jalr;
    logic [2:0]  funct3;
    logic        valid;
} id_ex_reg_t;

typedef struct packed {
    logic [31:0] pc_plus4;
    logic [31:0] alu_result;
    logic [31:0] rs2_data;
    logic [4:0]  rd;
    logic        mem_read;
    logic        mem_write;
    logic        reg_write;
    wb_sel_e     wb_sel;
    logic [2:0]  funct3;
    logic        valid;
} ex_mem_reg_t;

typedef struct packed {
    logic [31:0] pc_plus4;
    logic [31:0] alu_result;
    logic [31:0] instr_w;   // instruction word carried for commit bus
    logic [4:0]  rd;
    logic        reg_write;
    wb_sel_e     wb_sel;
    logic [2:0]  funct3;
    logic        valid;
} mem_wb_reg_t;

endpackage : cpu_pkg
