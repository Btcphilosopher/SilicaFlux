`timescale 1ns/1ps
// =============================================================================
// forward_unit.sv  –  Operand Forwarding Unit
//
// Computes forward_a / forward_b selects for the EX-stage ALU muxes:
//   2'b00 = use ID/EX register value  (no hazard, or handled by RF write-through)
//   2'b01 = forward from MEM/WB       (2-instruction gap: ALU or load result)
//   2'b10 = forward from EX/MEM       (1-instruction gap: ALU result only)
//
// Priority: EX/MEM (more recent) > MEM/WB > register file.
//
// Note: register file write-through handles the 3-instruction gap
// (WB writes while ID reads → no forwarding needed here).
// =============================================================================
module forward_unit (
    // ID/EX register – indices of the operands needed in EX
    input  logic [4:0] id_ex_rs1,
    input  logic [4:0] id_ex_rs2,

    // EX/MEM register – result of instruction one stage ahead
    input  logic [4:0] ex_mem_rd,
    input  logic       ex_mem_reg_write,

    // MEM/WB register – result of instruction two stages ahead
    input  logic [4:0] mem_wb_rd,
    input  logic       mem_wb_reg_write,

    output logic [1:0] forward_a,
    output logic [1:0] forward_b
);
    // RS1 forwarding
    always_comb begin
        if (ex_mem_reg_write && ex_mem_rd != 5'b0 && ex_mem_rd == id_ex_rs1)
            forward_a = 2'b10;                 // EX/MEM → EX
        else if (mem_wb_reg_write && mem_wb_rd != 5'b0 && mem_wb_rd == id_ex_rs1)
            forward_a = 2'b01;                 // MEM/WB → EX
        else
            forward_a = 2'b00;                 // no forward
    end

    // RS2 forwarding
    always_comb begin
        if (ex_mem_reg_write && ex_mem_rd != 5'b0 && ex_mem_rd == id_ex_rs2)
            forward_b = 2'b10;
        else if (mem_wb_reg_write && mem_wb_rd != 5'b0 && mem_wb_rd == id_ex_rs2)
            forward_b = 2'b01;
        else
            forward_b = 2'b00;
    end
endmodule
