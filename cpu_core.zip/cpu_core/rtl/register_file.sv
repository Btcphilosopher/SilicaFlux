`timescale 1ns/1ps
// =============================================================================
// register_file.sv  –  32×32 register file
//
// • x0 hardwired to 0 (write to x0 is silently discarded)
// • Write: synchronous on posedge clk
// • Read : combinational with same-cycle write-through forwarding
//          (handles the WB-writes-while-ID-reads case without extra hazard logic)
// • dbg_rf: exposes all 32 registers for scoreboard / waveform inspection
// =============================================================================
module register_file (
    input  logic        clk,
    input  logic        rst_n,
    // Read ports
    input  logic [4:0]  rs1,
    input  logic [4:0]  rs2,
    output logic [31:0] rd1,
    output logic [31:0] rd2,
    // Write port
    input  logic [4:0]  rd,
    input  logic [31:0] wd,
    input  logic        we,
    // Debug
    output logic [31:0] dbg_rf [32]
);
    logic [31:0] regs [32];

    // Synchronous write; x0 is never written
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (int i = 0; i < 32; i++) regs[i] <= 32'b0;
        end else if (we && rd != 5'b0) begin
            regs[rd] <= wd;
        end
    end

    // Combinational read with write-through forwarding on same-cycle WB write
    assign rd1 = (rs1 == 5'b0)                          ? 32'b0 :
                 (we && rd == rs1 && rd != 5'b0)        ? wd    :
                                                           regs[rs1];

    assign rd2 = (rs2 == 5'b0)                          ? 32'b0 :
                 (we && rd == rs2 && rd != 5'b0)        ? wd    :
                                                           regs[rs2];

    // Debug output – explicit per-element assign avoids iverilog unpacked-array assign bug
    genvar gi;
    generate
        for (gi = 0; gi < 32; gi++) begin : gen_dbg
            assign dbg_rf[gi] = regs[gi];
        end
    endgenerate
endmodule
