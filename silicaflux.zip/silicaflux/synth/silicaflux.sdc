# =============================================================================
# SilicaFlux — Synopsys Design Constraints (SDC)
# synth/silicaflux.sdc
#
# Applies to both Vivado and Quartus flows.
# Primary target: 100 MHz (10ns period) on 7-series / Cyclone V
# =============================================================================

# ---------------------------------------------------------------------------
# Primary Clocks
# ---------------------------------------------------------------------------

# Main system clock — 100 MHz
create_clock -name clk \
             -period 10.000 \
             -waveform {0 5} \
             [get_ports clk]

# ---------------------------------------------------------------------------
# Generated Clocks (if MMCM/PLL used for 100 MHz from 12/50 MHz crystal)
# Uncomment and adjust for your FPGA board
# ---------------------------------------------------------------------------
# create_generated_clock -name clk_100 \
#     -source [get_ports clk] \
#     -multiply_by 8 -divide_by 1 \
#     [get_pins u_pll/CLKOUT0]

# ---------------------------------------------------------------------------
# Clock Groups (no timing relationship between async domains)
# ---------------------------------------------------------------------------
# set_clock_groups -asynchronous \
#     -group [get_clocks clk] \
#     -group [get_clocks phy_rx_clk]

# ---------------------------------------------------------------------------
# Input / Output Delays
# ---------------------------------------------------------------------------

# External inputs: assume 2 ns hold + 2 ns setup margin relative to clk
set_input_delay  -clock clk -max 2.0  [get_ports {rst_n imem_wr_* tile_phy_rx_*}]
set_input_delay  -clock clk -min 0.0  [get_ports {rst_n imem_wr_* tile_phy_rx_*}]

# Outputs: allow 2 ns of output delay budget
set_output_delay -clock clk -max 2.0  [get_ports {halt tile_phy_tx_* tile_phy_rx_credit debug_*}]
set_output_delay -clock clk -min 0.0  [get_ports {halt tile_phy_tx_* tile_phy_rx_credit debug_*}]

# ---------------------------------------------------------------------------
# False Paths
# ---------------------------------------------------------------------------

# Asynchronous reset — registered in design, so false path for setup/hold
set_false_path -from [get_ports rst_n]

# Tile interface synchroniser chain — deliberate metastability chain
# Set false path on the first FF input of each 2-FF synchroniser
set_false_path -to [get_cells -hierarchical \
    -filter {NAME =~ *u_tif*phy_rx_valid_s1*}]
set_false_path -to [get_cells -hierarchical \
    -filter {NAME =~ *u_tif*phy_rx_data_s1*}]

# ---------------------------------------------------------------------------
# Multicycle Paths
# ---------------------------------------------------------------------------

# Tensor unit MAC: 4×4 matrix compute is intentionally sequential.
# Inner loop is not time-critical as it runs back-to-back.
# No multicycle constraints needed — single-cycle FSM states.

# IMEM write port (debug/load path): only active during reset hold.
# Apply 2-cycle multicycle for program load path.
set_multicycle_path -setup 2 \
    -from [get_ports imem_wr_data] \
    -to   [get_cells -hierarchical -filter {NAME =~ *u_fetch*imem*}]

set_multicycle_path -hold 1 \
    -from [get_ports imem_wr_data] \
    -to   [get_cells -hierarchical -filter {NAME =~ *u_fetch*imem*}]

# ---------------------------------------------------------------------------
# Clock Uncertainty (FPGA jitter models)
# ---------------------------------------------------------------------------
set_clock_uncertainty -setup 0.200 [get_clocks clk]
set_clock_uncertainty -hold  0.100 [get_clocks clk]

# ---------------------------------------------------------------------------
# Timing Exceptions for Simulation-Only Paths
# ---------------------------------------------------------------------------
# (None in production RTL — all constructs are synthesisable)
