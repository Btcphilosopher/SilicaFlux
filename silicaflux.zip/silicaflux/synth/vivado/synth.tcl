# =============================================================================
# SilicaFlux — Xilinx Vivado Synthesis Script
# synth/vivado/synth.tcl
#
# Target: Digilent Arty A7-100T (xc7a100tcsg324-1)
#         or Zynq Z7020 (xc7z020clg484-1) for SoC integration
#
# Usage (from Vivado Tcl console or batch):
#   vivado -mode batch -source synth.tcl
#
# Outputs:
#   build/silicaflux.bit    — bitstream
#   build/silicaflux.dcp    — design checkpoint
#   build/utilisation.rpt   — resource usage report
#   build/timing.rpt        — timing summary
# =============================================================================

set PROJ_NAME    "silicaflux"
set TOP_MODULE   "silicaflux_top"
set PART         "xc7a100tcsg324-1"
set BUILD_DIR    "[pwd]/build"
set RTL_DIR      "[pwd]/../../rtl"

# ---------------------------------------------------------------------------
# Create project
# ---------------------------------------------------------------------------
file mkdir $BUILD_DIR

create_project $PROJ_NAME $BUILD_DIR/$PROJ_NAME -part $PART -force

# ---------------------------------------------------------------------------
# Add RTL sources
# ---------------------------------------------------------------------------
set rtl_files [list \
    $RTL_DIR/silicaflux_pkg.sv     \
    $RTL_DIR/alu.sv                \
    $RTL_DIR/forwarding_unit.sv    \
    $RTL_DIR/fetch_unit.sv         \
    $RTL_DIR/decoder.sv            \
    $RTL_DIR/register_bank.sv      \
    $RTL_DIR/vector_engine.sv      \
    $RTL_DIR/tensor_unit.sv        \
    $RTL_DIR/memory_controller.sv  \
    $RTL_DIR/control_core.sv       \
    $RTL_DIR/scheduler.sv          \
    $RTL_DIR/compute_tile.sv       \
    $RTL_DIR/noc_interconnect.sv   \
    $RTL_DIR/tile_interface.sv     \
    $RTL_DIR/silicaflux_top.sv     \
]

add_files -fileset [get_filesets sources_1] $rtl_files
set_property file_type SystemVerilog [get_files *.sv]
set_property top $TOP_MODULE [get_filesets sources_1]

# ---------------------------------------------------------------------------
# Add constraints
# ---------------------------------------------------------------------------
add_files -fileset [get_filesets constrs_1] "[pwd]/silicaflux_arty.xdc"

# ---------------------------------------------------------------------------
# Synthesis settings
# ---------------------------------------------------------------------------
# Use Out-of-Context synthesis for modules being used as IP
set_property strategy Flow_PerfOptimized_high [get_runs synth_1]
set_property -name {STEPS.SYNTH_DESIGN.ARGS.MORE OPTIONS} \
    -value {-mode out_of_context} \
    -objects [get_runs synth_1]

# Target clock frequency: 100 MHz
set_property STEPS.SYNTH_DESIGN.ARGS.FLATTEN_HIERARCHY rebuilt \
    [get_runs synth_1]

# ---------------------------------------------------------------------------
# Run synthesis
# ---------------------------------------------------------------------------
puts "INFO: Starting synthesis..."
reset_run synth_1
launch_runs synth_1 -jobs 4
wait_on_run synth_1

if {[get_property PROGRESS [get_runs synth_1]] != "100%"} {
    error "ERROR: Synthesis failed"
}

# ---------------------------------------------------------------------------
# Run implementation
# ---------------------------------------------------------------------------
puts "INFO: Starting implementation..."
set_property strategy Performance_ExplorePostRoutePhysOpt \
    [get_runs impl_1]
launch_runs impl_1 -to_step route_design -jobs 4
wait_on_run impl_1

# ---------------------------------------------------------------------------
# Generate reports
# ---------------------------------------------------------------------------
open_run impl_1
report_utilization   -file $BUILD_DIR/utilisation.rpt
report_timing_summary -file $BUILD_DIR/timing.rpt -max_paths 50
report_clock_interaction -file $BUILD_DIR/clk_interaction.rpt
report_drc           -file $BUILD_DIR/drc.rpt

puts ""
puts "============================================"
puts "  Utilisation Summary"
puts "============================================"
report_utilization

# ---------------------------------------------------------------------------
# Generate bitstream
# ---------------------------------------------------------------------------
launch_runs impl_1 -to_step write_bitstream -jobs 4
wait_on_run impl_1

puts ""
puts "============================================"
puts "  Build complete."
puts "  Bitstream: $BUILD_DIR/$PROJ_NAME/${PROJ_NAME}.runs/impl_1/${TOP_MODULE}.bit"
puts "============================================"
