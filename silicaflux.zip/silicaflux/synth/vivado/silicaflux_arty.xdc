# =============================================================================
# SilicaFlux — Arty A7-100T Pin Constraints
# silicaflux_arty.xdc
#
# Board: Digilent Arty A7-100T
# FPGA:  Xilinx Artix-7 xc7a100tcsg324-1
#
# Assigned I/O:
#   clk               → E3  (12 MHz onboard crystal)
#   rst_n             → C2  (BTN0)
#   imem_wr_en        → D9  (SW0)
#   halt              → H5  (LED0)
#   tile_phy_tx_valid → J5  (LED1)
#   debug pins        → PMOD JA
# =============================================================================

# ---------------------------------------------------------------------------
# Primary Clock — 100 MHz (use MMCM to derive from 12 MHz crystal)
# ---------------------------------------------------------------------------
create_clock -period 10.000 -name clk -waveform {0.000 5.000} [get_ports clk]

# ---------------------------------------------------------------------------
# I/O Assignments — Arty A7
# ---------------------------------------------------------------------------

# System clock (12 MHz crystal on Arty — MMCM generates 100 MHz)
set_property PACKAGE_PIN E3        [get_ports clk]
set_property IOSTANDARD  LVCMOS33  [get_ports clk]

# Reset (active low, BTN0)
set_property PACKAGE_PIN C2        [get_ports rst_n]
set_property IOSTANDARD  LVCMOS33  [get_ports rst_n]

# IMEM write enable (SW0 — used during program load phase)
set_property PACKAGE_PIN A8        [get_ports imem_wr_en]
set_property IOSTANDARD  LVCMOS33  [get_ports imem_wr_en]

# Status LEDs
set_property PACKAGE_PIN H5        [get_ports halt]
set_property IOSTANDARD  LVCMOS33  [get_ports halt]

set_property PACKAGE_PIN J5        [get_ports tile_phy_tx_valid]
set_property IOSTANDARD  LVCMOS33  [get_ports tile_phy_tx_valid]

# Chiplet link — PMOD JA (tile_phy_tx_data[7:0])
set_property PACKAGE_PIN G13       [get_ports {tile_phy_tx_data[0]}]
set_property PACKAGE_PIN B11       [get_ports {tile_phy_tx_data[1]}]
set_property PACKAGE_PIN A11       [get_ports {tile_phy_tx_data[2]}]
set_property PACKAGE_PIN D12       [get_ports {tile_phy_tx_data[3]}]
set_property PACKAGE_PIN D13       [get_ports {tile_phy_tx_data[4]}]
set_property PACKAGE_PIN B18       [get_ports {tile_phy_tx_data[5]}]
set_property PACKAGE_PIN A18       [get_ports {tile_phy_tx_data[6]}]
set_property PACKAGE_PIN K16       [get_ports {tile_phy_tx_data[7]}]
set_property IOSTANDARD  LVCMOS33  [get_ports {tile_phy_tx_data[*]}]

# Chiplet link — PMOD JB (tile_phy_rx_data[7:0])
set_property PACKAGE_PIN E15       [get_ports {tile_phy_rx_data[0]}]
set_property PACKAGE_PIN E16       [get_ports {tile_phy_rx_data[1]}]
set_property PACKAGE_PIN D15       [get_ports {tile_phy_rx_data[2]}]
set_property PACKAGE_PIN C15       [get_ports {tile_phy_rx_data[3]}]
set_property PACKAGE_PIN J17       [get_ports {tile_phy_rx_data[4]}]
set_property PACKAGE_PIN J18       [get_ports {tile_phy_rx_data[5]}]
set_property PACKAGE_PIN K15       [get_ports {tile_phy_rx_data[6]}]
set_property PACKAGE_PIN J15       [get_ports {tile_phy_rx_data[7]}]
set_property IOSTANDARD  LVCMOS33  [get_ports {tile_phy_rx_data[*]}]

set_property PACKAGE_PIN H16       [get_ports tile_phy_rx_valid]
set_property IOSTANDARD  LVCMOS33  [get_ports tile_phy_rx_valid]

set_property PACKAGE_PIN H15       [get_ports tile_phy_tx_credit]
set_property IOSTANDARD  LVCMOS33  [get_ports tile_phy_tx_credit]

set_property PACKAGE_PIN J16       [get_ports tile_phy_rx_credit]
set_property IOSTANDARD  LVCMOS33  [get_ports tile_phy_rx_credit]

# ---------------------------------------------------------------------------
# Timing Constraints
# ---------------------------------------------------------------------------

# Input delay (external setup relative to clk)
set_input_delay -clock clk -max 2.0 [get_ports {rst_n imem_wr_en tile_phy_rx_*}]
set_input_delay -clock clk -min 0.5 [get_ports {rst_n imem_wr_en tile_phy_rx_*}]

# Output delay
set_output_delay -clock clk -max 2.0 [get_ports {halt tile_phy_tx_*}]
set_output_delay -clock clk -min 0.5 [get_ports {halt tile_phy_tx_*}]

# ---------------------------------------------------------------------------
# False Paths
# ---------------------------------------------------------------------------

# Asynchronous reset is false path for timing (registered in design)
set_false_path -from [get_ports rst_n]

# Chiplet RX retimer synchroniser — standard multi-cycle synchroniser
# The two-FF chain in tile_interface is intended as a synchroniser
set_false_path -to [get_cells -hierarchical -filter {NAME =~ *phy_rx_valid_s1*}]

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
set_property CFGBVS VCCO           [current_design]
set_property CONFIG_VOLTAGE 3.3    [current_design]

# Bitstream compression
set_property BITSTREAM.GENERAL.COMPRESS TRUE [current_design]
