# =============================================================================
# SilicaFlux — Intel Quartus Prime Synthesis Script
# synth/quartus/synth.tcl
#
# Target: DE10-Nano (Cyclone V SX 5CSXFC6D6F31C6N)
#         Includes HPS (ARM Cortex-A9) — useful for host-accelerator testing.
#
# Usage:
#   quartus_sh -t synth.tcl
# =============================================================================

package require ::quartus::project
package require ::quartus::flow

set TOP_MODULE "silicaflux_top"
set PROJ_NAME  "silicaflux"
set PART       "5CSXFC6D6F31C6N"
set RTL_DIR    "../../rtl"
set BUILD_DIR  "build"

file mkdir $BUILD_DIR

# ---------------------------------------------------------------------------
# Create project
# ---------------------------------------------------------------------------
project_new $PROJ_NAME -revision $PROJ_NAME -overwrite

set_global_assignment -name FAMILY             "Cyclone V"
set_global_assignment -name DEVICE              $PART
set_global_assignment -name TOP_LEVEL_ENTITY    $TOP_MODULE
set_global_assignment -name PROJECT_OUTPUT_DIRECTORY $BUILD_DIR

# ---------------------------------------------------------------------------
# RTL Sources
# ---------------------------------------------------------------------------
foreach f [list \
    $RTL_DIR/silicaflux_pkg.sv     \
    $RTL_DIR/alu.sv                \
    $RTL_DIR/forwarding_unit.sv    \
    $RTL_DIR/fetch_unit.sv         \
    $RTL_DIR/decoder.sv            \
    $RTL_DIR/register_bank.sv      \
    $RTL_DIR/vector_engine.sv      \
    $RTL_DIR/tensor_unit.sv        \
    $RTL_DIR/memory_controller.sv  \
    $RTL_DIR/control_core.sv       \
    $RTL_DIR/scheduler.sv          \
    $RTL_DIR/compute_tile.sv       \
    $RTL_DIR/noc_interconnect.sv   \
    $RTL_DIR/tile_interface.sv     \
    $RTL_DIR/silicaflux_top.sv     \
] {
    set_global_assignment -name SYSTEMVERILOG_FILE $f
}

# ---------------------------------------------------------------------------
# Timing Constraints
# ---------------------------------------------------------------------------
set_global_assignment -name SDC_FILE silicaflux.sdc

# ---------------------------------------------------------------------------
# Synthesis Settings
# ---------------------------------------------------------------------------
set_global_assignment -name SYNTHESIS_EFFORT           AUTO
set_global_assignment -name ROUTER_EFFORT_MULTIPLIER   1.5
set_global_assignment -name SEED                       1
set_global_assignment -name ALLOW_REGISTER_RETIMING    ON
set_global_assignment -name OPTIMIZE_HOLD_TIMING       "ALL PATHS"
set_global_assignment -name OPTIMIZE_MULTI_CORNER_TIMING ON

# BRAM configuration for scratchpad SRAM inference
set_global_assignment -name AUTO_RAM_RECOGNITION       ON
set_global_assignment -name AUTO_SHIFT_REGISTER_RECOGNITION ON

# ---------------------------------------------------------------------------
# Pin Assignments (DE10-Nano)
# ---------------------------------------------------------------------------
set_location_assignment PIN_V11  -to clk          ;# 50 MHz oscillator
set_location_assignment PIN_AH17 -to rst_n         ;# KEY0
set_location_assignment PIN_W15  -to halt          ;# LED0
set_location_assignment PIN_AA24 -to tile_phy_tx_valid ;# LED1

# PMOD GPIO (GPIO0 pins)
set_location_assignment PIN_AH23 -to {tile_phy_tx_data[0]}
set_location_assignment PIN_AE19 -to {tile_phy_tx_data[1]}
set_location_assignment PIN_AG23 -to {tile_phy_tx_data[2]}
set_location_assignment PIN_AE20 -to {tile_phy_tx_data[3]}
set_location_assignment PIN_AF22 -to {tile_phy_tx_data[4]}
set_location_assignment PIN_AH22 -to {tile_phy_tx_data[5]}
set_location_assignment PIN_AG20 -to {tile_phy_tx_data[6]}
set_location_assignment PIN_AH21 -to {tile_phy_tx_data[7]}

set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to clk
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to rst_n
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to halt
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" \
    -to {tile_phy_tx_data[*]}

# ---------------------------------------------------------------------------
# Run Full Flow
# ---------------------------------------------------------------------------
execute_flow -compile

# Reports
execute_module -tool STA \
    -args "--report_script silicaflux.tcl --do_report_timing"

project_close

puts ""
puts "============================================"
puts "  Quartus synthesis complete."
puts "  SOF: $BUILD_DIR/$PROJ_NAME.sof"
puts "============================================"
