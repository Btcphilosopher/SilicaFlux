# SilicaFlux ISA Reference
## Version 1.0 — Fixed-Width 32-bit Encoding

---

## 1. Overview

SilicaFlux uses a fixed-width 32-bit instruction encoding with four distinct
formats. Instructions target either the scalar control pipeline or are
dispatched to the dataflow scheduler for tile execution.

**Design Principles:**
- All instructions are exactly 32 bits
- Opcode occupies bits [31:27] (5 bits = 32 possible opcodes)
- Format is fully determined by opcode (no ambiguity)
- Immediate values are sign-extended at the use site
- r0 is hardwired to zero; writes are silently discarded

---

## 2. Register File

### Scalar Registers
| Name      | Index | Description                          |
|-----------|-------|--------------------------------------|
| r0        | 0     | Hardwired zero (writes discarded)    |
| r1–r30    | 1–30  | General-purpose scalar (32-bit)      |
| r31       | 31    | Link register (JMP return address)   |

### Vector Registers
| Name  | Index | Description                          |
|-------|-------|--------------------------------------|
| v0–v15 | 0–15 | Vector registers (128-bit, 4×32-bit) |

---

## 3. Instruction Formats

### R-Format (Register)
```
 31        27 26      22 21      17 16      12 11        0
 ┌──────────┬──────────┬──────────┬──────────┬────────────┐
 │  opcode  │    rd    │   rs1    │   rs2    │    func    │
 │  [5 bit] │  [5 bit] │  [5 bit] │  [5 bit] │  [12 bit]  │
 └──────────┴──────────┴──────────┴──────────┴────────────┘
```
Used by: ADD, SUB, MUL

### I-Format (Immediate)
```
 31        27 26      22 21      17 16                   0
 ┌──────────┬──────────┬──────────┬──────────────────────┐
 │  opcode  │    rd    │   rs1    │      imm17           │
 │  [5 bit] │  [5 bit] │  [5 bit] │      [17 bit]        │
 └──────────┴──────────┴──────────┴──────────────────────┘
```
Used by: LOAD, STORE, MOV, BEQ, BNE, JMP

### D-Format (Dataflow)
```
 31        27 26    24 23      19 18      14 13           0
 ┌──────────┬─────────┬──────────┬──────────┬────────────┐
 │  opcode  │ tile_id │  reg     │  length  │   addr14   │
 │  [5 bit] │  [3 bit]│  [5 bit] │  [5 bit] │  [14 bit]  │
 └──────────┴─────────┴──────────┴──────────┴────────────┘
```
Used by: DFLOAD, DFSTORE, DFMAP, DFEXEC, DFSYNC

### V-Format (Vector)
```
 31        27 26      23 22      19 18      15 14   8 7   0
 ┌──────────┬──────────┬──────────┬──────────┬──────┬─────┐
 │  opcode  │   vrd    │  vrs1    │  vrs2    │  rsv │ func│
 │  [5 bit] │  [4 bit] │  [4 bit] │  [4 bit] │ [7b] │[8b] │
 └──────────┴──────────┴──────────┴──────────┴──────┴─────┘
```
Used by: VADD, VMUL, VSUB, DOT, MATMUL, REDUCE, BROADCAST, VLOAD, VSTORE

---

## 4. Opcode Table

| Opcode  | Hex  | Format | Mnemonic  | Operation                              |
|---------|------|--------|-----------|----------------------------------------|
| 00000   | 0x00 | R      | NOP       | No operation                           |
| 00001   | 0x01 | R      | ADD       | rd = rs1 + rs2                         |
| 00010   | 0x02 | R      | SUB       | rd = rs1 − rs2                         |
| 00011   | 0x03 | R      | MUL       | rd = rs1 × rs2 [31:0]                  |
| 00100   | 0x04 | I      | LOAD      | rd = MEM[rs1 + sext(imm17)]            |
| 00101   | 0x05 | I      | STORE     | MEM[rs1 + sext(imm17)] = rs2           |
| 00110   | 0x06 | I      | MOV       | rd = sext(imm17)                       |
| 00111   | 0x07 | I      | BEQ       | if rs1==rs2: PC += sext(imm17)         |
| 01000   | 0x08 | I      | BNE       | if rs1!=rs2: PC += sext(imm17)         |
| 01001   | 0x09 | I      | JMP       | PC = rs1 + sext(imm17)                 |
| 01010   | 0x0A | D      | DFLOAD    | Burst load from SRAM → tile reg buffer |
| 01011   | 0x0B | D      | DFSTORE   | Burst store from tile → SRAM           |
| 01100   | 0x0C | D      | DFMAP     | Map scalar rs1 to tile lane            |
| 01101   | 0x0D | D      | DFEXEC    | Trigger compute kernel on tile         |
| 01110   | 0x0E | D      | DFSYNC    | Barrier: stall until all tiles idle    |
| 01111   | 0x0F | V      | VADD      | vrd[i] = vrs1[i] + vrs2[i]            |
| 10000   | 0x10 | V      | VMUL      | vrd[i] = vrs1[i] × vrs2[i]            |
| 10001   | 0x11 | V      | VSUB      | vrd[i] = vrs1[i] − vrs2[i]            |
| 10010   | 0x12 | V      | DOT       | rd = Σ(vrs1[i] × vrs2[i])             |
| 10011   | 0x13 | V      | MATMUL    | 4×4 matrix multiply (uses local bufs) |
| 10100   | 0x14 | V      | REDUCE    | rd = reduce_op(vrs1) [func[1:0]=op]   |
| 10101   | 0x15 | V      | BROADCAST | vrd = {rs1, rs1, rs1, rs1}             |
| 10110   | 0x16 | V      | VLOAD     | vrd = MEM[rs1 + sext(imm)], 128-bit   |
| 10111   | 0x17 | V      | VSTORE    | MEM[rs1 + sext(imm)] = vrs1, 128-bit  |
| 11111   | 0x1F | —      | HALT      | Stop execution                         |

### REDUCE Function Codes (func[1:0])
| Code | Operation   |
|------|-------------|
| 00   | SUM         |
| 01   | MIN (signed)|
| 10   | MAX (signed)|
| 11   | AND (bitwise)|

---

## 5. Execution Model

### Pipeline Stages

```
  IF → ID → IS → EX → MEM → WB
```

| Stage | Name     | Description                                       |
|-------|----------|---------------------------------------------------|
| IF    | Fetch    | PC increment, instruction SRAM read               |
| ID    | Decode   | Format detect, register file read, immediate ext  |
| IS    | Issue    | Operand forward, hazard check, dispatch to sched  |
| EX    | Execute  | Scalar ALU, branch resolve, DF token dispatch     |
| MEM   | Memory   | LOAD/STORE to scratchpad SRAM                     |
| WB    | Writeback| Register file write; scheduler WB for tile results|

### Hazard Handling
- **RAW (Load-Use):** 1-cycle interlock stall inserted automatically
- **Control Hazards:** 1-cycle flush on taken branch/jump
- **Structural Hazards:** Scheduler back-pressure via `sync_stall`

### Dataflow Execution
1. Scalar pipeline dispatches DF/vector instructions to the Scheduler
2. Scheduler assigns work tokens to free tiles
3. Tile executes asynchronously (vector engine or tensor unit)
4. Completion token returned; scalar results written back via scheduler
5. `DFSYNC` stalls scalar pipeline until all tiles are idle

---

## 6. Assembly Examples

### Example 1: Scalar Loop (sum 1..10)
```asm
        MOV  r1, #0        ; r1 = accumulator = 0
        MOV  r2, #1        ; r2 = loop variable
        MOV  r3, #10       ; r3 = limit
loop:   ADD  r1, r1, r2    ; r1 += r2
        ADD  r2, r2, r1    ; r2++ (using ADD r2,r2,#1 — simplified)
        BNE  r2, r3, loop  ; loop until r2 == 10+1
        HALT
```

### Example 2: Vector Dot Product
```asm
        ; v0 = [1.0, 2.0, 3.0, 4.0]  (pre-loaded via DFLOAD)
        ; v1 = [4.0, 3.0, 2.0, 1.0]
        DOT  r5, v0, v1    ; r5 = 1*4 + 2*3 + 3*2 + 4*1 = 20
        HALT
```

### Example 3: Tile Parallel Vector Ops
```asm
        DFLOAD   tile=0, reg=v0, addr=0x000, len=4   ; Load 4 words → tile 0
        DFLOAD   tile=1, reg=v0, addr=0x010, len=4   ; Load 4 words → tile 1
        DFLOAD   tile=2, reg=v0, addr=0x020, len=4   ; Load 4 words → tile 2
        DFLOAD   tile=3, reg=v0, addr=0x030, len=4   ; Load 4 words → tile 3
        DFEXEC   tile=0, kernel=VADD                 ; All tiles execute VADD
        DFEXEC   tile=1, kernel=VADD
        DFEXEC   tile=2, kernel=VADD
        DFEXEC   tile=3, kernel=VADD
        DFSYNC                                       ; Wait for all tiles
        DFSTORE  tile=0, reg=v1, addr=0x100, len=4  ; Write results back
        HALT
```

### Example 4: 4×4 Matrix Multiply
```asm
        ; Matrix A rows pre-loaded into v0–v3 of tile 0
        ; Matrix B columns pre-loaded into v4–v7 of tile 0
        DFEXEC   tile=0, kernel=MATMUL    ; Execute 4x4 MATMUL
        DFSYNC                            ; Wait for completion (~20 cycles)
        DFSTORE  tile=0, reg=result, addr=0x200, len=16
        HALT
```

---

## 7. Memory Map (Per-Tile Scratchpad)

```
Address     Size     Description
0x0000      256×4B   Scratchpad SRAM (word-addressed, 1KB per tile)
0x0000–     Input data buffers
0x0100–     Output result buffers
0x0200–     Workspace / accumulator area
```

---

## 8. NoC Topology

```
  Tile[0,0] ──── Tile[0,1]
     │                │
  Tile[1,0] ──── Tile[1,1]
```

- XY deterministic routing (deadlock-free)
- 32-bit flit payload
- Valid/ready flow control per link
- Chiplet extension via `tile_interface` serialiser (8/16/32-bit physical link)

---

## 9. Chiplet Scalability

The `tile_interface` module serialises NoC flits over a narrow physical link
for inter-die communication. Each SilicaFlux die exposes:
- N boundary router ports (one per mesh edge)
- Each serialised to a configurable LINK_WIDTH (8/16/32-bit)
- 2-FF retimer synchroniser on RX path for timing closure

Multiple dies are connected by wiring matching `tile_phy_tx_*` / `tile_phy_rx_*`
ports, forming a larger multi-die mesh using the same XY routing algorithm.

---

*SilicaFlux Architecture — © 2025. RTL version 1.0.*
