// =============================================================================
// SilicaFlux — Vector Engine Testbench
// tb_vector_engine.sv
//
// Validates all vector operations of the SilicaFlux vector_engine module:
//   - VADD: per-lane addition
//   - VSUB: per-lane subtraction
//   - VMUL: per-lane multiplication
//   - DOT:  inner product (sum of products)
//   - REDUCE SUM: tree reduction to scalar
//   - REDUCE MAX: maximum value
//   - BROADCAST: scalar fill to all lanes
// =============================================================================

`timescale 1ns/1ps
`include "silicaflux_pkg.sv"

module tb_vector_engine;
  import silicaflux_pkg::*;

  // DUT parameters
  localparam int LANES = 4;
  localparam int VW    = LANES * XLEN; // 128 bits

  // DUT signals
  logic               clk;
  logic               rst_n;
  logic               issue_valid;
  logic [4:0]         opcode;
  logic [7:0]         func;
  logic [VW-1:0]      vop_a;
  logic [VW-1:0]      vop_b;
  logic [XLEN-1:0]    scalar_in;
  logic               result_valid;
  logic [VW-1:0]      vresult;
  logic [XLEN-1:0]    scalar_result;
  logic               is_scalar_result;

  // DUT
  vector_engine #(.LANES(LANES)) dut (
    .clk             (clk),
    .rst_n           (rst_n),
    .issue_valid     (issue_valid),
    .opcode          (opcode),
    .func            (func),
    .vop_a           (vop_a),
    .vop_b           (vop_b),
    .scalar_in       (scalar_in),
    .result_valid    (result_valid),
    .vresult         (vresult),
    .scalar_result   (scalar_result),
    .is_scalar_result(is_scalar_result)
  );

  // Clock
  initial clk = 0;
  always #5 clk = ~clk;

  // Test counters
  int pass_cnt = 0, fail_cnt = 0;

  // Helper: pack 4 x 32-bit values into vector word
  function automatic logic [VW-1:0] pack4;
    input logic [XLEN-1:0] a0, a1, a2, a3;
    pack4 = {a3, a2, a1, a0};
  endfunction

  // Helper: extract lane N
  function automatic logic [XLEN-1:0] lane;
    input logic [VW-1:0] v;
    input int            n;
    lane = v[n*XLEN +: XLEN];
  endfunction

  // Check task
  task automatic chk_vector;
    input string        name;
    input logic [VW-1:0] got;
    input logic [VW-1:0] expected;
    begin
      if (got === expected) begin
        $display("[PASS] %s: [%08X %08X %08X %08X]", name,
                  lane(got,3), lane(got,2), lane(got,1), lane(got,0));
        pass_cnt++;
      end else begin
        $display("[FAIL] %s:", name);
        $display("       got:      [%08X %08X %08X %08X]",
                  lane(got,3), lane(got,2), lane(got,1), lane(got,0));
        $display("       expected: [%08X %08X %08X %08X]",
                  lane(expected,3), lane(expected,2),
                  lane(expected,1), lane(expected,0));
        fail_cnt++;
      end
    end
  endtask

  task automatic chk_scalar;
    input string        name;
    input logic [XLEN-1:0] got;
    input logic [XLEN-1:0] expected;
    begin
      if (got === expected) begin
        $display("[PASS] %s: 0x%08X", name, got);
        pass_cnt++;
      end else begin
        $display("[FAIL] %s: got=0x%08X expected=0x%08X", name, got, expected);
        fail_cnt++;
      end
    end
  endtask

  // Issue one operation and wait for result
  task automatic issue_op;
    input logic [4:0]    op;
    input logic [VW-1:0] va, vb;
    input logic [XLEN-1:0] sc;
    input logic [7:0]    fn;
    begin
      @(negedge clk);
      issue_valid = 1;
      opcode      = op;
      vop_a       = va;
      vop_b       = vb;
      scalar_in   = sc;
      func        = fn;
      @(negedge clk);
      issue_valid = 0;
      // Wait for result_valid (2-cycle pipeline)
      @(posedge clk); // cycle 1
      @(posedge clk); // cycle 2 — result_valid should be high
      @(negedge clk);
    end
  endtask

  // ===========================================================================
  // Test Suite
  // ===========================================================================
  initial begin
    $dumpfile("vec_engine.vcd");
    $dumpvars(0, tb_vector_engine);

    issue_valid = 0;
    opcode      = '0;
    func        = '0;
    vop_a       = '0;
    vop_b       = '0;
    scalar_in   = '0;

    // Reset
    rst_n = 0;
    repeat(4) @(posedge clk);
    @(negedge clk);
    rst_n = 1;
    repeat(2) @(posedge clk);

    // -----------------------------------------------------------------
    // TEST: VADD
    // A = [1, 2, 3, 4]  B = [10, 20, 30, 40]
    // Expected: [11, 22, 33, 44]
    // -----------------------------------------------------------------
    $display("\n--- VADD ---");
    issue_op(OP_VADD,
             pack4(32'd1,  32'd2,  32'd3,  32'd4),
             pack4(32'd10, 32'd20, 32'd30, 32'd40),
             '0, '0);
    chk_vector("VADD", vresult,
               pack4(32'd11, 32'd22, 32'd33, 32'd44));

    // -----------------------------------------------------------------
    // TEST: VSUB
    // A = [100, 200, 300, 400]  B = [1, 2, 3, 4]
    // Expected: [99, 198, 297, 396]
    // -----------------------------------------------------------------
    $display("\n--- VSUB ---");
    issue_op(OP_VSUB,
             pack4(32'd100, 32'd200, 32'd300, 32'd400),
             pack4(32'd1,   32'd2,   32'd3,   32'd4),
             '0, '0);
    chk_vector("VSUB", vresult,
               pack4(32'd99, 32'd198, 32'd297, 32'd396));

    // -----------------------------------------------------------------
    // TEST: VMUL
    // A = [2, 3, 4, 5]  B = [10, 10, 10, 10]
    // Expected: [20, 30, 40, 50]
    // -----------------------------------------------------------------
    $display("\n--- VMUL ---");
    issue_op(OP_VMUL,
             pack4(32'd2,  32'd3,  32'd4,  32'd5),
             pack4(32'd10, 32'd10, 32'd10, 32'd10),
             '0, '0);
    chk_vector("VMUL", vresult,
               pack4(32'd20, 32'd30, 32'd40, 32'd50));

    // -----------------------------------------------------------------
    // TEST: DOT product
    // A = [1, 2, 3, 4]  B = [1, 2, 3, 4]
    // Expected: 1*1 + 2*2 + 3*3 + 4*4 = 1+4+9+16 = 30
    // -----------------------------------------------------------------
    $display("\n--- DOT ---");
    issue_op(OP_DOT,
             pack4(32'd1, 32'd2, 32'd3, 32'd4),
             pack4(32'd1, 32'd2, 32'd3, 32'd4),
             '0, 8'b00 /*REDUCE_SUM*/);
    chk_scalar("DOT", scalar_result, 32'd30);

    // -----------------------------------------------------------------
    // TEST: REDUCE SUM
    // A = [10, 20, 30, 40]  → sum = 100
    // -----------------------------------------------------------------
    $display("\n--- REDUCE SUM ---");
    issue_op(OP_REDUCE,
             pack4(32'd10, 32'd20, 32'd30, 32'd40),
             '0, '0, 8'b00 /*REDUCE_SUM*/);
    chk_scalar("REDUCE_SUM", scalar_result, 32'd100);

    // -----------------------------------------------------------------
    // TEST: REDUCE MAX
    // A = [5, 99, 3, 47]  → max = 99
    // -----------------------------------------------------------------
    $display("\n--- REDUCE MAX ---");
    issue_op(OP_REDUCE,
             pack4(32'd5, 32'd99, 32'd3, 32'd47),
             '0, '0, 8'b10 /*REDUCE_MAX*/);
    chk_scalar("REDUCE_MAX", scalar_result, 32'd99);

    // -----------------------------------------------------------------
    // TEST: BROADCAST
    // scalar_in = 42  → [42, 42, 42, 42]
    // -----------------------------------------------------------------
    $display("\n--- BROADCAST ---");
    issue_op(OP_BCAST,
             '0, '0, 32'd42, '0);
    chk_vector("BROADCAST", vresult,
               pack4(32'd42, 32'd42, 32'd42, 32'd42));

    // -----------------------------------------------------------------
    $display("\n=============================");
    $display("  Vector Engine TB Summary");
    $display("  PASS: %0d  FAIL: %0d", pass_cnt, fail_cnt);
    $display("=============================");
    $finish;
  end

endmodule
