// SilicaFlux — NoC Interconnect Testbench (flat port variant)
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"
module tb_noc_interconnect;
  import silicaflux_pkg::*;
  logic clk=0, rst_n;
  noc_flit_t inject_flit[0:NOC_ROWS-1][0:NOC_COLS-1];
  logic      inject_valid[0:NOC_ROWS-1][0:NOC_COLS-1];
  logic      inject_ready[0:NOC_ROWS-1][0:NOC_COLS-1];
  noc_flit_t eject_flit  [0:NOC_ROWS-1][0:NOC_COLS-1];
  logic      eject_valid [0:NOC_ROWS-1][0:NOC_COLS-1];
  logic      eject_ready [0:NOC_ROWS-1][0:NOC_COLS-1];
  logic [NOC_WIDTH-1:0] eject_data[0:NOC_ROWS-1][0:NOC_COLS-1];
  // Flat ports (iverilog can read these from submodule)
  logic [3:0] inj_ready_flat, ej_valid_flat;
  logic [NOC_WIDTH-1:0] ej_data_flat_0,ej_data_flat_1,ej_data_flat_2,ej_data_flat_3;

  noc_interconnect dut(.clk(clk),.rst_n(rst_n),
    .inject_flit(inject_flit),.inject_valid(inject_valid),.inject_ready(inject_ready),
    .eject_flit(eject_flit),.eject_valid(eject_valid),.eject_ready(eject_ready),
    .eject_data(eject_data),
    .inject_ready_flat(inj_ready_flat),
    .eject_valid_flat(ej_valid_flat),
    .ej_data_flat_0(ej_data_flat_0),
    .ej_data_flat_1(ej_data_flat_1),
    .ej_data_flat_2(ej_data_flat_2),
    .ej_data_flat_3(ej_data_flat_3));

  always #5 clk=~clk;
  // Accept all ejected flits
  always_comb for(int r=0;r<NOC_ROWS;r++) for(int c=0;c<NOC_COLS;c++) eject_ready[r][c]=1'b1;

  int pass_cnt=0, fail_cnt=0;

  task chk32; input string n; input logic [31:0] g,e;
    if(g===e) begin $display("[PASS] %s=0x%08X",n,g); pass_cnt++; end
    else begin $display("[FAIL] %s got=0x%08X exp=0x%08X",n,g,e); fail_cnt++; end
  endtask

  // Helper: flat index from (row,col)
  function automatic int flat; input int r,c; flat=r*NOC_COLS+c; endfunction

  task send_and_check;
    input string name;
    input logic [1:0] sr,sc,dr,dc;
    input logic [31:0] payload;
    input int max_w;
    noc_flit_t f; logic got; integer i;
    int di;
    begin
      di = flat(dr,dc);
      f='0; f.flit_type=FLIT_SINGLE; f.src_row=sr; f.src_col=sc;
      f.dst_row=dr; f.dst_col=dc; f.data=payload; f.valid=1'b1;
      @(negedge clk);
      // Assign flit and valid using explicit case
      case({sr,sc})
        4'b0000: inject_flit[0][0]=f;
        4'b0001: inject_flit[0][1]=f;
        4'b0100: inject_flit[1][0]=f;
        default: inject_flit[1][1]=f;
      endcase
      case({sr,sc})
        4'b0000: inject_valid[0][0]=1'b1;
        4'b0001: inject_valid[0][1]=1'b1;
        4'b0100: inject_valid[1][0]=1'b1;
        default: inject_valid[1][1]=1'b1;
      endcase
      @(negedge clk);
      case({sr,sc})
        4'b0000: inject_valid[0][0]=1'b0;
        4'b0001: inject_valid[0][1]=1'b0;
        4'b0100: inject_valid[1][0]=1'b0;
        default: inject_valid[1][1]=1'b0;
      endcase
      // Wait using flat port
      got=0;
      begin:wej for(i=0;i<max_w;i++) begin
        @(posedge clk);
        if(ej_valid_flat[di]) begin got=1; disable wej; end
      end end
      if(!got) begin $display("[FAIL] %s not delivered",name); fail_cnt++; end
      else begin
        logic [NOC_WIDTH-1:0] got_data;
        case(di)
          0: got_data = ej_data_flat_0;
          1: got_data = ej_data_flat_1;
          2: got_data = ej_data_flat_2;
          default: got_data = ej_data_flat_3;
        endcase
        chk32(name, got_data, payload);
      end
    end
  endtask

  initial begin
    $dumpfile("noc_interconnect.vcd"); $dumpvars(0,tb_noc_interconnect);
    inject_flit[0][0]='0; inject_flit[0][1]='0;
    inject_flit[1][0]='0; inject_flit[1][1]='0;
    inject_valid[0][0]=0; inject_valid[0][1]=0;
    inject_valid[1][0]=0; inject_valid[1][1]=0;
    rst_n=0; repeat(4)@(posedge clk); @(negedge clk); rst_n=1;

    $display("\n--- TEST 1: Local [0][0]->[0][0] ---");
    send_and_check("LOCAL_00",  2'd0,2'd0, 2'd0,2'd0, 32'hDEADBEEF, 20);
    $display("\n--- TEST 2: East hop [0][0]->[0][1] ---");
    send_and_check("EAST_HOP",  2'd0,2'd0, 2'd0,2'd1, 32'h11223344, 20);
    $display("\n--- TEST 3: South hop [0][0]->[1][0] ---");
    send_and_check("SOUTH_HOP", 2'd0,2'd0, 2'd1,2'd0, 32'hAABBCCDD, 20);
    $display("\n--- TEST 4: Diagonal [0][0]->[1][1] ---");
    send_and_check("DIAG_01_11",2'd0,2'd0, 2'd1,2'd1, 32'hCAFEBABE, 30);
    $display("\n--- TEST 5: Reverse [1][1]->[0][0] ---");
    send_and_check("DIAG_11_00",2'd1,2'd1, 2'd0,2'd0, 32'h12345678, 30);
    $display("\n--- TEST 6: Cross [0][1]->[1][0] ---");
    send_and_check("CROSS_01_10",2'd0,2'd1,2'd1,2'd0, 32'hFACEB00C, 30);

    $display("\n============================");
    $display("  NoC TB Summary");
    $display("  PASS: %0d  FAIL: %0d", pass_cnt, fail_cnt);
    $display("============================");
    $finish;
  end
  initial begin #500000; $display("[TIMEOUT]"); $finish; end
endmodule
