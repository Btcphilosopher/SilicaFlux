// SilicaFlux — Compute Tile Testbench (iverilog-safe, flat status ports)
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"
module tb_compute_tile;
  import silicaflux_pkg::*;
  localparam int LANES=4;
  logic clk=0, rst_n;
  // Flat token fields (scheduler->tile interface)
  logic [4:0]  tok_opcode='0;
  logic [2:0]  tok_tile_id='0;
  logic [4:0]  tok_src_reg='0, tok_dst_reg='0;
  logic [3:0]  tok_vsrc_reg='0, tok_vdst_reg='0;
  logic [13:0] tok_mem_addr='0;
  logic [4:0]  tok_length='0;
  logic [7:0]  tok_func='0;
  logic        token_valid=0, token_ready;
  logic [XLEN-1:0] scalar_data_in='0;
  logic [VLEN-1:0] vector_data_in='0, vector_data_in_b='0;
  logic            tile_done, tile_error;
  logic [XLEN-1:0] tile_result_scalar;
  logic [VLEN-1:0] tile_result_vector;
  noc_flit_t noc_flit_out;
  logic noc_flit_valid, noc_flit_ready=1;
  noc_flit_t noc_flit_in='0;
  logic noc_flit_in_valid=0, noc_flit_in_ready;

  compute_tile #(.TILE_ID(0),.LANES(LANES)) dut(
    .clk(clk),.rst_n(rst_n),
    .tok_opcode(tok_opcode),.tok_tile_id(tok_tile_id),
    .tok_src_reg(tok_src_reg),.tok_dst_reg(tok_dst_reg),
    .tok_vsrc_reg(tok_vsrc_reg),.tok_vdst_reg(tok_vdst_reg),
    .tok_mem_addr(tok_mem_addr),.tok_length(tok_length),.tok_func(tok_func),
    .token_valid(token_valid),.token_ready(token_ready),
    .scalar_data_in(scalar_data_in),
    .vector_data_in(vector_data_in),.vector_data_in_b(vector_data_in_b),
    .tile_done(tile_done),.tile_error(tile_error),
    .tile_result_scalar(tile_result_scalar),.tile_result_vector(tile_result_vector),
    .noc_flit_out(noc_flit_out),.noc_flit_valid(noc_flit_valid),.noc_flit_ready(noc_flit_ready),
    .noc_flit_in(noc_flit_in),.noc_flit_in_valid(noc_flit_in_valid),
    .noc_flit_in_ready(noc_flit_in_ready));

  always #5 clk=~clk;
  int pass_cnt=0, fail_cnt=0;

  function automatic logic [4*XLEN-1:0] pk;
    input logic [XLEN-1:0] a,b,c,d; pk={d,c,b,a}; endfunction
  function automatic logic [XLEN-1:0] ln;
    input logic [VLEN-1:0] v; input int n;
    case(n) 0:ln=v[0+:32]; 1:ln=v[32+:32]; 2:ln=v[64+:32]; default:ln=v[96+:32]; endcase
  endfunction

  task chk32; input string n; input logic [31:0] g,e;
    if(g===e) begin $display("[PASS] %-28s = %0d",n,g); pass_cnt++; end
    else begin $display("[FAIL] %-28s got=%0d exp=%0d",n,g,e); fail_cnt++; end
  endtask

  task issue; input df_token_t tok; input logic [31:0] sc;
              input logic [VLEN-1:0] va,vb; input int mw;
    integer i; begin
      begin:wtr for(i=0;i<20;i++) begin @(posedge clk); if(token_ready) disable wtr; end end
      @(negedge clk);
      // Drive flat token fields
      tok_opcode=tok.opcode; tok_tile_id=tok.tile_id[2:0];
      tok_src_reg=tok.src_reg; tok_dst_reg=tok.dst_reg;
      tok_vsrc_reg=tok.vsrc_reg; tok_vdst_reg=tok.vdst_reg;
      tok_mem_addr=tok.mem_addr; tok_length=tok.length; tok_func=tok.func;
      token_valid=1; scalar_data_in=sc; vector_data_in=va; vector_data_in_b=vb;
      @(negedge clk); token_valid=0;
      begin:wdone for(i=0;i<mw;i++) begin @(posedge clk); if(tile_done) disable wdone; end end
      @(negedge clk);
    end
  endtask

  function automatic df_token_t mk; input logic [4:0] op; input logic [7:0] fn;
    mk='0; mk.opcode=op; mk.func=fn; mk.tile_id=0; mk.valid=1; endfunction

  initial begin
    $dumpfile("compute_tile.vcd"); $dumpvars(0,tb_compute_tile);
    rst_n=0; repeat(4)@(posedge clk); @(negedge clk); rst_n=1;

    $display("\n--- TEST 1: VADD [1,2,3,4]+[10,20,30,40] ---");
    issue(mk(OP_VADD,0),'0, pk(1,2,3,4), pk(10,20,30,40), 20);
    chk32("lane0_vadd", ln(tile_result_vector,0), 32'd11);
    chk32("lane1_vadd", ln(tile_result_vector,1), 32'd22);
    chk32("lane2_vadd", ln(tile_result_vector,2), 32'd33);
    chk32("lane3_vadd", ln(tile_result_vector,3), 32'd44);

    $display("\n--- TEST 2: DOT [1,2,3,4].[1,2,3,4]=30 ---");
    issue(mk(OP_DOT,8'h00),'0, pk(1,2,3,4), pk(1,2,3,4), 20);
    chk32("dot_result", tile_result_scalar, 32'd30);

    $display("\n--- TEST 3: REDUCE MAX max(5,99,3,47)=99 ---");
    issue(mk(OP_REDUCE,8'h02),'0, pk(5,99,3,47),'0, 20);
    chk32("reduce_max", tile_result_scalar, 32'd99);

    $display("\n--- TEST 4: BROADCAST 42->[42,42,42,42] ---");
    issue(mk(OP_BCAST,0),32'd42,'0,'0, 20);
    chk32("bcast_lane0", ln(tile_result_vector,0), 32'd42);
    chk32("bcast_lane3", ln(tile_result_vector,3), 32'd42);

    $display("\n--- TEST 5: VMUL [2,3,4,5]*[3,4,5,6] ---");
    issue(mk(OP_VMUL,0),'0, pk(2,3,4,5), pk(3,4,5,6), 20);
    chk32("vmul_lane0", ln(tile_result_vector,0), 32'd6);
    chk32("vmul_lane1", ln(tile_result_vector,1), 32'd12);
    chk32("vmul_lane2", ln(tile_result_vector,2), 32'd20);
    chk32("vmul_lane3", ln(tile_result_vector,3), 32'd30);

    $display("\n--- TEST 6: VSUB [100,200,300,400]-[1,2,3,4] ---");
    issue(mk(OP_VSUB,0),'0, pk(100,200,300,400), pk(1,2,3,4), 20);
    chk32("vsub_lane0", ln(tile_result_vector,0), 32'd99);
    chk32("vsub_lane3", ln(tile_result_vector,3), 32'd396);

    $display("\n--- TEST 7: REDUCE SUM sum(10,20,30,40)=100 ---");
    issue(mk(OP_REDUCE,8'h00),'0, pk(10,20,30,40),'0, 20);
    chk32("reduce_sum", tile_result_scalar, 32'd100);

    $display("\n============================");
    $display("  Compute Tile TB Summary");
    $display("  PASS: %0d  FAIL: %0d", pass_cnt, fail_cnt);
    $display("============================");
    $finish;
  end
  initial begin #200000; $display("[TIMEOUT]"); $finish; end
endmodule
