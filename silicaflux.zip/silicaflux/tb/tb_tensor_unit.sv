// SilicaFlux — Tensor Unit Testbench (iverilog-safe, explicit field access)
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"
module tb_tensor_unit;
  import silicaflux_pkg::*;
  logic clk=0, rst_n, start=0, done, busy;
  logic [4*XLEN-1:0] mat_a_row0,mat_a_row1,mat_a_row2,mat_a_row3;
  logic [4*XLEN-1:0] mat_b_col0,mat_b_col1,mat_b_col2,mat_b_col3;
  logic [4*XLEN-1:0] result_row0,result_row1,result_row2,result_row3;

  tensor_unit dut(.clk(clk),.rst_n(rst_n),.start(start),
    .mat_a_row0(mat_a_row0),.mat_a_row1(mat_a_row1),
    .mat_a_row2(mat_a_row2),.mat_a_row3(mat_a_row3),
    .mat_b_col0(mat_b_col0),.mat_b_col1(mat_b_col1),
    .mat_b_col2(mat_b_col2),.mat_b_col3(mat_b_col3),
    .done(done),.busy(busy),
    .result_row0(result_row0),.result_row1(result_row1),
    .result_row2(result_row2),.result_row3(result_row3));

  always #5 clk=~clk;
  int pass_cnt=0, fail_cnt=0;

  task chk; input string n; input logic [31:0] g,e;
    if(g===e) begin $display("[PASS] %s=%0d",n,g); pass_cnt++; end
    else begin $display("[FAIL] %s got=%0d exp=%0d",n,g,e); fail_cnt++; end
  endtask

  // Pack 4 x 32-bit into row: element 0 at [31:0]
  function automatic logic [4*XLEN-1:0] pk;
    input logic [XLEN-1:0] a,b,c,d; pk={d,c,b,a}; endfunction

  // Extract column N using explicit case (no variable part-select)
  function automatic logic [XLEN-1:0] col;
    input logic [4*XLEN-1:0] r; input int n;
    case(n) 0:col=r[ 0+:32]; 1:col=r[32+:32]; 2:col=r[64+:32]; default:col=r[96+:32]; endcase
  endfunction

  task do_matmul; input int max_cyc;
    integer i; begin
      @(negedge clk); start=1; @(negedge clk); start=0;
      begin:wdone for(i=0;i<max_cyc;i++) begin @(posedge clk); if(done) disable wdone; end end
      @(negedge clk);
    end
  endtask

  initial begin
    $dumpfile("tensor_unit.vcd"); $dumpvars(0,tb_tensor_unit);
    rst_n=0; repeat(4)@(posedge clk); @(negedge clk); rst_n=1;

    // === TEST 1: A*Identity = A ===
    $display("\n--- TEST 1: A * Identity ---");
    mat_a_row0=pk(1,2,3,4);   mat_a_row1=pk(5,6,7,8);
    mat_a_row2=pk(9,10,11,12); mat_a_row3=pk(13,14,15,16);
    mat_b_col0=pk(1,0,0,0); mat_b_col1=pk(0,1,0,0);
    mat_b_col2=pk(0,0,1,0); mat_b_col3=pk(0,0,0,1);
    do_matmul(120);
    chk("C[0][0]",col(result_row0,0),32'd1);
    chk("C[0][1]",col(result_row0,1),32'd2);
    chk("C[0][2]",col(result_row0,2),32'd3);
    chk("C[0][3]",col(result_row0,3),32'd4);
    chk("C[1][0]",col(result_row1,0),32'd5);
    chk("C[1][1]",col(result_row1,1),32'd6);
    chk("C[2][2]",col(result_row2,2),32'd11);
    chk("C[3][3]",col(result_row3,3),32'd16);

    // === TEST 2: Diagonal * All-Ones ===
    $display("\n--- TEST 2: Diagonal x All-Ones ---");
    mat_a_row0=pk(1,0,0,0); mat_a_row1=pk(0,2,0,0);
    mat_a_row2=pk(0,0,3,0); mat_a_row3=pk(0,0,0,4);
    mat_b_col0=pk(1,1,1,1); mat_b_col1=pk(1,1,1,1);
    mat_b_col2=pk(1,1,1,1); mat_b_col3=pk(1,1,1,1);
    do_matmul(120);
    chk("C[0][0]",col(result_row0,0),32'd1);
    chk("C[0][2]",col(result_row0,2),32'd1);
    chk("C[1][1]",col(result_row1,1),32'd2);
    chk("C[2][3]",col(result_row2,3),32'd3);
    chk("C[3][0]",col(result_row3,0),32'd4);

    // === TEST 3: Zero matrix ===
    $display("\n--- TEST 3: Zero * Anything = Zero ---");
    mat_a_row0='0; mat_a_row1='0; mat_a_row2='0; mat_a_row3='0;
    mat_b_col0=pk(99,88,77,66); mat_b_col1=pk(55,44,33,22);
    mat_b_col2=pk(11,22,33,44); mat_b_col3=pk(55,66,77,88);
    do_matmul(120);
    chk("C[0][0]_zero",col(result_row0,0),32'd0);
    chk("C[3][3]_zero",col(result_row3,3),32'd0);

    $display("\n============================");
    $display("  Tensor Unit TB Summary");
    $display("  PASS: %0d  FAIL: %0d", pass_cnt, fail_cnt);
    $display("============================");
    $finish;
  end
  initial begin #500000; $display("[TIMEOUT]"); $finish; end
endmodule
