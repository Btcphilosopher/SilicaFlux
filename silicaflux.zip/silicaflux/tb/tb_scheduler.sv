// SilicaFlux — Scheduler Testbench (fully flat, no struct arrays)
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"
module tb_scheduler;
  import silicaflux_pkg::*;
  logic clk=0, rst_n;
  decoded_instr_t instr_in='0;
  logic instr_valid=0, instr_ready;
  logic [XLEN-1:0] scalar_a='0,scalar_b='0;
  logic [VLEN-1:0] vector_a='0,vector_b='0;
  logic tile_tok_valid_0,tile_tok_valid_1,tile_tok_valid_2,tile_tok_valid_3;
  logic tile_tok_ready_0=1,tile_tok_ready_1=1,tile_tok_ready_2=1,tile_tok_ready_3=1;
  logic [XLEN-1:0] sched_scalar_out;
  logic [VLEN-1:0] sched_vector_a_out, sched_vector_b_out;
  logic [4:0]  tok_opcode; logic [2:0] tok_tile_id;
  logic [4:0]  tok_src_reg, tok_dst_reg;
  logic [3:0]  tok_vsrc_reg, tok_vdst_reg;
  logic [13:0] tok_mem_addr; logic [4:0] tok_length; logic [7:0] tok_func;
  logic [NUM_TILES-1:0]       tile_status_done='0;
  logic [NUM_TILES*XLEN-1:0]  tile_status_scalar='0;
  logic wb_valid, sync_stall; logic [4:0] wb_reg; logic [XLEN-1:0] wb_data;

  scheduler dut(.clk(clk),.rst_n(rst_n),
    .instr_in(instr_in),.instr_valid(instr_valid),.instr_ready(instr_ready),
    .scalar_a(scalar_a),.scalar_b(scalar_b),.vector_a(vector_a),.vector_b(vector_b),
    .tile_tok_valid_0(tile_tok_valid_0),.tile_tok_valid_1(tile_tok_valid_1),
    .tile_tok_valid_2(tile_tok_valid_2),.tile_tok_valid_3(tile_tok_valid_3),
    .tile_tok_ready_0(tile_tok_ready_0),.tile_tok_ready_1(tile_tok_ready_1),
    .tile_tok_ready_2(tile_tok_ready_2),.tile_tok_ready_3(tile_tok_ready_3),
    .sched_scalar_out(sched_scalar_out),.sched_vector_a_out(sched_vector_a_out),.sched_vector_b_out(sched_vector_b_out),
    .tok_opcode(tok_opcode),.tok_tile_id(tok_tile_id),
    .tok_src_reg(tok_src_reg),.tok_dst_reg(tok_dst_reg),
    .tok_vsrc_reg(tok_vsrc_reg),.tok_vdst_reg(tok_vdst_reg),
    .tok_mem_addr(tok_mem_addr),.tok_length(tok_length),.tok_func(tok_func),
    .tile_status_done(tile_status_done),.tile_status_scalar(tile_status_scalar),
    .wb_valid(wb_valid),.wb_reg(wb_reg),.wb_data(wb_data),.sync_stall(sync_stall));

  always #5 clk=~clk;
  int pass_cnt=0, fail_cnt=0;

  task chk; input string n; input logic g,e;
    if(g===e) begin $display("[PASS] %s",n); pass_cnt++; end
    else begin $display("[FAIL] %s got=%b exp=%b",n,g,e); fail_cnt++; end
  endtask

  function automatic decoded_instr_t mdi;
    input logic [4:0] op; input logic [2:0] tile;
    mdi='0; mdi.opcode=op; mdi.tile_id=tile; mdi.fmt=FMT_D; mdi.valid=1'b1;
  endfunction

  task tdone; input int t; input logic [XLEN-1:0] r;
    @(negedge clk);
    tile_status_done[t]=1'b1; tile_status_scalar[t*32+:32]=r;
    @(negedge clk);
    tile_status_done[t]=1'b0; tile_status_scalar[t*32+:32]='0;
  endtask

  initial begin
    $dumpfile("scheduler.vcd"); $dumpvars(0,tb_scheduler);
    // ready lines already initialised in declaration
    rst_n=0; repeat(4)@(posedge clk); @(negedge clk); rst_n=1;

    // TEST 1
    $display("\n--- TEST 1: Dispatch VADD to tile 0 ---");
    @(negedge clk); instr_in=mdi(OP_VADD,3'd0); instr_valid=1'b1;
    @(posedge clk);  // sample combinational tile_tok_valid at the posedge
    chk("tile0_valid",  tile_tok_valid_0, 1'b1);
    chk("tile1_silent", tile_tok_valid_1, 1'b0);
    chk("tile2_silent", tile_tok_valid_2, 1'b0);
    chk("tile3_silent", tile_tok_valid_3, 1'b0);
    @(negedge clk); instr_valid=1'b0;
    fork tdone(0,32'hA5A5A5A5); join_none
    repeat(8)@(posedge clk);

    // TEST 2
    $display("\n--- TEST 2: Dispatch VMUL to tile 2 ---");
    @(negedge clk); instr_in=mdi(OP_VMUL,3'd2); instr_valid=1'b1;
    @(posedge clk);
    chk("tile2_valid",  tile_tok_valid_2, 1'b1);
    chk("tile0_silent", tile_tok_valid_0, 1'b0);
    @(negedge clk); instr_valid=1'b0;
    fork tdone(2,32'd200); join_none
    repeat(8)@(posedge clk);

    // TEST 3: DFSYNC
    $display("\n--- TEST 3: DFSYNC barrier ---");
    @(negedge clk); instr_in=mdi(OP_VADD,3'd0); instr_valid=1'b1; @(negedge clk); instr_valid=1'b0;
    @(negedge clk); instr_in=mdi(OP_VADD,3'd3); instr_valid=1'b1; @(negedge clk); instr_valid=1'b0;
    repeat(2)@(posedge clk);
    @(negedge clk); instr_in=mdi(OP_DFSYNC,3'd0); instr_valid=1'b1; @(negedge clk); instr_valid=1'b0;
    repeat(3)@(posedge clk); #1;
    chk("sync_stall_active",  sync_stall, 1'b1);
    // Sequential done pulses — no fork, ensures they actually execute before checking
    tdone(0,'0);
    tdone(3,'0);
    repeat(5)@(posedge clk);
    chk("sync_stall_cleared", sync_stall, 1'b0);

    // TEST 4: writeback — wb_valid is registered 1 cycle after done
    $display("\n--- TEST 4: Writeback ---");
    @(negedge clk);
    tile_status_done[1]=1'b1; tile_status_scalar[32+:32]=32'hDEAD_BEEF;
    @(posedge clk);  // registered on this edge
    @(negedge clk); tile_status_done[1]=1'b0; tile_status_scalar[32+:32]='0;
    @(posedge clk);  // wb_valid goes high here (1 cycle after done pulse)
    chk("wb_valid_fires", wb_valid, 1'b1);

    $display("\n============================");
    $display("  Scheduler TB Summary");
    $display("  PASS: %0d  FAIL: %0d", pass_cnt, fail_cnt);
    $display("============================");
    $finish;
  end
  initial begin #100000; $display("[TIMEOUT]"); $finish; end
endmodule
