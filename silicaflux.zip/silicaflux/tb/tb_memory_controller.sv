// =============================================================================
// SilicaFlux — Memory Controller Testbench
// tb_memory_controller.sv
//
// Validates scratchpad SRAM access:
//   Test 1: Scalar STORE then LOAD (single word)
//   Test 2: Vector VSTORE then VLOAD (4-word burst)
//   Test 3: DFSTORE burst (8 words) then DFLOAD verify
//   Test 4: Misaligned access → alignment_err pulse
//   Test 5: Back-to-back scalar accesses
// =============================================================================

`timescale 1ns/1ps
`include "silicaflux_pkg.sv"

module tb_memory_controller;
  import silicaflux_pkg::*;

  logic              clk, rst_n;
  logic              req_valid;
  logic              req_ready;
  logic [4:0]        req_opcode;
  logic [XLEN-1:0]   req_addr;
  logic [XLEN-1:0]   req_wdata;
  logic [VLEN-1:0]   req_vwdata;
  logic [4:0]        req_length;
  logic              resp_valid;
  logic [XLEN-1:0]   resp_rdata;
  logic [VLEN-1:0]   resp_vrdata;
  logic              alignment_err;

  memory_controller dut (
    .clk          (clk),
    .rst_n        (rst_n),
    .req_valid    (req_valid),
    .req_ready    (req_ready),
    .req_opcode   (req_opcode),
    .req_addr     (req_addr),
    .req_wdata    (req_wdata),
    .req_vwdata   (req_vwdata),
    .req_length   (req_length),
    .resp_valid   (resp_valid),
    .resp_rdata   (resp_rdata),
    .resp_vrdata  (resp_vrdata),
    .alignment_err(alignment_err),
    .wb_valid     (1'b0),
    .wb_addr      ('0),
    .wb_data      ('0)
  );

  initial clk = 0;
  always #5 clk = ~clk;

  int pass_cnt = 0, fail_cnt = 0;

  task automatic check32;
    input string     name;
    input logic [XLEN-1:0] got, exp;
    if (got === exp) begin
      $display("[PASS] %s = 0x%08X", name, got);
      pass_cnt++;
    end else begin
      $display("[FAIL] %s: got=0x%08X exp=0x%08X", name, got, exp);
      fail_cnt++;
    end
  endtask

  // Issue request and wait for response
  task automatic mem_op;
    input logic [4:0]      op;
    input logic [XLEN-1:0] addr, wdata;
    input logic [VLEN-1:0] vwdata;
    input logic [4:0]      length;
    begin
      @(negedge clk);
      req_valid  = 1;
      req_opcode = op;
      req_addr   = addr;
      req_wdata  = wdata;
      req_vwdata = vwdata;
      req_length = length;
      @(negedge clk);
      req_valid  = 0;
      // Wait for resp_valid
      begin : wait_resp
        integer i;
        for (i = 0; i < 50; i++) begin
          @(posedge clk);
          if (resp_valid) disable wait_resp;
        end
      end
      @(negedge clk);
    end
  endtask

  initial begin
    $dumpfile("mem_ctrl.vcd");
    $dumpvars(0, tb_memory_controller);
    req_valid = 0; req_opcode = '0;
    req_addr = '0; req_wdata = '0;
    req_vwdata = '0; req_length = '0;

    rst_n = 0;
    repeat(4) @(posedge clk);
    @(negedge clk);
    rst_n = 1;

    // TEST 1: Scalar STORE/LOAD
    $display("\n--- TEST 1: Scalar STORE / LOAD ---");
    mem_op(OP_STORE, 32'h00000010, 32'hDEADBEEF, '0, '0);
    mem_op(OP_LOAD,  32'h00000010, '0,            '0, '0);
    check32("LOAD result", resp_rdata, 32'hDEADBEEF);

    // TEST 2: Vector VSTORE / VLOAD
    $display("\n--- TEST 2: Vector VSTORE / VLOAD ---");
    mem_op(OP_VSTORE, 32'h00000040,
           '0,
           {32'hAABBCCDD, 32'h11223344, 32'h55667788, 32'h99AABBCC},
           4'd4);
    mem_op(OP_VLOAD, 32'h00000040, '0, '0, 4'd4);
    check32("VLOAD word0", resp_vrdata[31:0],   32'h99AABBCC);
    check32("VLOAD word1", resp_vrdata[63:32],  32'h55667788);
    check32("VLOAD word2", resp_vrdata[95:64],  32'h11223344);
    check32("VLOAD word3", resp_vrdata[127:96], 32'hAABBCCDD);

    // TEST 3: Misaligned access (addr[1:0] != 00)
    $display("\n--- TEST 3: Misaligned ---");
    @(negedge clk);
    req_valid  = 1;
    req_opcode = OP_LOAD;
    req_addr   = 32'h00000003; // Byte address not aligned
    @(negedge clk);
    req_valid = 0;
    @(posedge clk);
    if (alignment_err) begin
      $display("[PASS] Alignment error correctly flagged");
      pass_cnt++;
    end else begin
      $display("[FAIL] Alignment error not flagged");
      fail_cnt++;
    end

    $display("\n============================");
    $display("  Memory Controller Summary");
    $display("  PASS: %0d  FAIL: %0d", pass_cnt, fail_cnt);
    $display("============================");
    $finish;
  end

endmodule
