// =============================================================================
// SilicaFlux — Control Core
// control_core.sv
//
// The scalar execution backbone of the SilicaFlux pipeline.
// Handles all non-dataflow instructions and manages pipeline flow control.
//
// Responsibilities:
//   1. Scalar ALU: ADD, SUB, MUL, MOV, LOAD/STORE address generation
//   2. Branch resolution: BEQ, BNE, JMP → branch_taken + branch_target to fetch
//   3. Hazard detection: RAW stall insertion (1-cycle interlock)
//   4. Forwarding: EX→ID and MEM→ID paths for scalar results
//   5. Dataflow handoff: passes DF/vector instructions to Scheduler
//   6. Writeback: scalar results back to register bank
// =============================================================================

`include "silicaflux_pkg.sv"

module control_core
  import silicaflux_pkg::*;
(
  input  logic          clk,
  input  logic          rst_n,

  // --- ID/IS Input (from Decoder) ---
  input  id_is_reg_t    id_is,
  output logic          id_stall,     // Request stall to IF/ID
  output logic          pipeline_flush,

  // --- Branch Redirect (to Fetch Unit) ---
  output logic                  branch_taken,
  output logic [PC_WIDTH-1:0]   branch_target,

  // --- Scheduler Interface (for DF/Vector ops) ---
  output decoded_instr_t sched_instr,
  output logic           sched_valid,
  input  logic           sched_ready,
  output logic [XLEN-1:0] sched_scalar_a,
  output logic [XLEN-1:0] sched_scalar_b,
  output logic [VLEN-1:0] sched_vector_a,
  output logic [VLEN-1:0] sched_vector_b,

  // --- Register Writeback (to Register Bank) ---
  output logic            s_wr_en,
  output logic [4:0]      s_wr_addr,
  output logic [XLEN-1:0] s_wr_data,
  output logic            v_wr_en,
  output logic [3:0]      v_wr_addr,
  output logic [VLEN-1:0] v_wr_data,

  // --- Memory Interface (scalar LOAD/STORE) ---
  output logic            mem_req_valid,
  input  logic            mem_req_ready,
  output logic [4:0]      mem_req_opcode,
  output logic [XLEN-1:0] mem_req_addr,
  output logic [XLEN-1:0] mem_req_wdata,
  input  logic            mem_resp_valid,
  input  logic [XLEN-1:0] mem_resp_rdata,

  // --- Scheduler Sync Stall (back-pressure) ---
  input  logic            sync_stall
);

  // ---------------------------------------------------------------------------
  // IS → EX Pipeline Register
  // ---------------------------------------------------------------------------
  is_ex_reg_t is_ex;

  // Forwarded operands
  logic [XLEN-1:0] fwd_op_a, fwd_op_b;

  // ---------------------------------------------------------------------------
  // EX → MEM Pipeline Register
  // ---------------------------------------------------------------------------
  ex_mem_reg_t ex_mem;

  // ---------------------------------------------------------------------------
  // MEM → WB Pipeline Register
  // ---------------------------------------------------------------------------
  mem_wb_reg_t mem_wb;

  // ---------------------------------------------------------------------------
  // Forwarding Unit
  // Compares rs1/rs2 of current IS stage against in-flight rd values in EX/MEM
  // ---------------------------------------------------------------------------
  always_comb begin
    // Default: use register file values
    fwd_op_a = id_is.rs1_data;
    fwd_op_b = id_is.rs2_data;

    // Forward from EX stage (1 cycle old)
    if (ex_mem.valid && ex_mem.instr.rd != '0) begin
      if (ex_mem.instr.rd == id_is.instr.rs1)
        fwd_op_a = ex_mem.alu_result;
      if (ex_mem.instr.rd == id_is.instr.rs2)
        fwd_op_b = ex_mem.alu_result;
    end

    // Forward from MEM/WB stage (2 cycles old)
    if (mem_wb.valid && mem_wb.instr.rd != '0) begin
      if (mem_wb.instr.rd == id_is.instr.rs1)
        fwd_op_a = mem_wb.result;
      if (mem_wb.instr.rd == id_is.instr.rs2)
        fwd_op_b = mem_wb.result;
    end
  end

  // ---------------------------------------------------------------------------
  // Hazard Detection
  // RAW hazard: LOAD result not available until MEM stage
  // Stall one cycle if EX instruction is a LOAD and ID reads the same register
  // ---------------------------------------------------------------------------
  logic load_use_hazard;
  assign load_use_hazard =
    is_ex.valid &&
    (is_ex.instr.opcode == OP_LOAD) &&
    ((is_ex.instr.rd == id_is.instr.rs1 && id_is.instr.rs1 != '0) ||
     (is_ex.instr.rd == id_is.instr.rs2 && id_is.instr.rs2 != '0));

  assign id_stall = load_use_hazard || sync_stall ||
                    (sched_valid && !sched_ready);

  // ---------------------------------------------------------------------------
  // IS/EX Stage Register
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      is_ex <= '0;
    end else if (pipeline_flush) begin
      is_ex <= '0;
    end else if (!id_stall) begin
      is_ex.instr      <= id_is.instr;
      is_ex.op_a       <= fwd_op_a;
      is_ex.op_b       <= fwd_op_b;
      is_ex.vop_a      <= id_is.vrs1_data;
      is_ex.vop_b      <= id_is.vrs2_data;
      is_ex.imm_ext    <= sign_ext17(id_is.instr.imm);
      is_ex.pc         <= id_is.pc;
      is_ex.valid      <= id_is.valid;
    end
  end

  // ---------------------------------------------------------------------------
  // Execute Stage — Scalar ALU
  // ---------------------------------------------------------------------------
  logic [XLEN-1:0]   alu_result;
  logic              br_taken_comb;
  logic [PC_WIDTH-1:0] br_target_comb;

  always_comb begin
    alu_result    = '0;
    br_taken_comb = 1'b0;
    br_target_comb = is_ex.pc;

    case (is_ex.instr.opcode)
      OP_ADD:  alu_result = is_ex.op_a + is_ex.op_b;
      OP_SUB:  alu_result = is_ex.op_a - is_ex.op_b;
      OP_MUL:  alu_result = is_ex.op_a * is_ex.op_b;
      OP_MOV:  alu_result = is_ex.imm_ext;

      OP_LOAD,
      OP_STORE: alu_result = is_ex.op_a + is_ex.imm_ext; // Address gen

      OP_BEQ: begin
        br_taken_comb  = (is_ex.op_a == is_ex.op_b);
        br_target_comb = is_ex.pc + is_ex.imm_ext[PC_WIDTH-1:0];
        alu_result     = '0;
      end
      OP_BNE: begin
        br_taken_comb  = (is_ex.op_a != is_ex.op_b);
        br_target_comb = is_ex.pc + is_ex.imm_ext[PC_WIDTH-1:0];
        alu_result     = '0;
      end
      OP_JMP: begin
        br_taken_comb  = 1'b1;
        br_target_comb = (is_ex.op_a[PC_WIDTH-1:0] + is_ex.imm_ext[PC_WIDTH-1:0]);
        alu_result     = '0;
      end

      default: alu_result = is_ex.op_a;
    endcase
  end

  // Scheduler dispatch for DF/Vector ops
  logic is_sched_op;
  assign is_sched_op = is_ex.valid && (
    is_ex.instr.opcode == OP_DFLOAD  || is_ex.instr.opcode == OP_DFSTORE ||
    is_ex.instr.opcode == OP_DFMAP   || is_ex.instr.opcode == OP_DFEXEC  ||
    is_ex.instr.opcode == OP_DFSYNC  ||
    is_ex.instr.opcode == OP_VADD    || is_ex.instr.opcode == OP_VSUB    ||
    is_ex.instr.opcode == OP_VMUL    || is_ex.instr.opcode == OP_DOT     ||
    is_ex.instr.opcode == OP_MATMUL  || is_ex.instr.opcode == OP_REDUCE  ||
    is_ex.instr.opcode == OP_BCAST   || is_ex.instr.opcode == OP_VLOAD   ||
    is_ex.instr.opcode == OP_VSTORE
  );

  assign sched_instr    = is_ex.instr;
  assign sched_valid    = is_sched_op;
  assign sched_scalar_a = is_ex.op_a;
  assign sched_scalar_b = is_ex.op_b;
  assign sched_vector_a = is_ex.vop_a;
  assign sched_vector_b = is_ex.vop_b;

  // ---------------------------------------------------------------------------
  // EX/MEM Pipeline Register
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ex_mem         <= '0;
      branch_taken   <= 1'b0;
      branch_target  <= '0;
      pipeline_flush <= 1'b0;
    end else begin
      branch_taken   <= br_taken_comb && is_ex.valid;
      branch_target  <= br_target_comb;
      pipeline_flush <= br_taken_comb && is_ex.valid;

      ex_mem.instr        <= is_ex.instr;
      ex_mem.alu_result   <= alu_result;
      ex_mem.valu_result  <= is_ex.vop_a; // Pass-through; tile handles vector
      ex_mem.store_data   <= is_ex.op_b;
      ex_mem.vstore_data  <= is_ex.vop_b;
      ex_mem.mem_addr     <= alu_result;  // For LOAD/STORE
      ex_mem.branch_target <= br_target_comb;
      ex_mem.branch_taken  <= br_taken_comb;
      ex_mem.valid        <= is_ex.valid && !is_sched_op;
    end
  end

  // ---------------------------------------------------------------------------
  // Memory Stage — Issue LOAD/STORE to Memory Controller
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mem_req_valid  <= 1'b0;
      mem_req_addr   <= '0;
      mem_req_wdata  <= '0;
      mem_req_opcode <= '0;
    end else begin
      mem_req_valid <= 1'b0;
      if (ex_mem.valid) begin
        case (ex_mem.instr.opcode)
          OP_LOAD: begin
            mem_req_valid  <= 1'b1;
            mem_req_opcode <= OP_LOAD;
            mem_req_addr   <= ex_mem.mem_addr;
          end
          OP_STORE: begin
            mem_req_valid  <= 1'b1;
            mem_req_opcode <= OP_STORE;
            mem_req_addr   <= ex_mem.mem_addr;
            mem_req_wdata  <= ex_mem.store_data;
          end
          default: ;
        endcase
      end
    end
  end

  // ---------------------------------------------------------------------------
  // MEM/WB Pipeline Register
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mem_wb <= '0;
    end else begin
      mem_wb.instr     <= ex_mem.instr;
      mem_wb.valid     <= ex_mem.valid;
      mem_wb.mem_valid <= mem_resp_valid;
      // Result: LOAD takes from memory, others from ALU
      if (ex_mem.instr.opcode == OP_LOAD && mem_resp_valid)
        mem_wb.result <= mem_resp_rdata;
      else
        mem_wb.result <= ex_mem.alu_result;
    end
  end

  // ---------------------------------------------------------------------------
  // Writeback Stage
  // ---------------------------------------------------------------------------
  always_comb begin
    s_wr_en   = 1'b0;
    s_wr_addr = '0;
    s_wr_data = '0;
    v_wr_en   = 1'b0;
    v_wr_addr = '0;
    v_wr_data = '0;

    if (mem_wb.valid && mem_wb.instr.rd != '0) begin
      case (mem_wb.instr.opcode)
        OP_ADD, OP_SUB, OP_MUL, OP_MOV, OP_LOAD: begin
          s_wr_en   = 1'b1;
          s_wr_addr = mem_wb.instr.rd;
          s_wr_data = mem_wb.result;
        end
        default: ;
      endcase
    end
  end

endmodule
