// =============================================================================
// SilicaFlux — Tensor Unit
// tensor_unit.sv
//
// 4×4 signed-integer matrix multiply: C = A × B
// Element width: 32-bit (result truncated to lower 32-bit).
// Latency: 64 MAC cycles + 2 state cycles = ~66 cycles.
//
// Implementation note: 2D arrays flattened to 1D with row*4+col indexing
// to work around iverilog 12's variable-index 2D array access bug.
// Synthesis targets (Vivado/VCS) handle 2D arrays natively.
// =============================================================================

`include "silicaflux_pkg.sv"

module tensor_unit
  import silicaflux_pkg::*;
(
  input  logic              clk,
  input  logic              rst_n,
  input  logic              start,

  input  logic [4*XLEN-1:0] mat_a_row0,
  input  logic [4*XLEN-1:0] mat_a_row1,
  input  logic [4*XLEN-1:0] mat_a_row2,
  input  logic [4*XLEN-1:0] mat_a_row3,
  input  logic [4*XLEN-1:0] mat_b_col0,
  input  logic [4*XLEN-1:0] mat_b_col1,
  input  logic [4*XLEN-1:0] mat_b_col2,
  input  logic [4*XLEN-1:0] mat_b_col3,

  output logic              done,
  output logic              busy,
  output logic [4*XLEN-1:0] result_row0,
  output logic [4*XLEN-1:0] result_row1,
  output logic [4*XLEN-1:0] result_row2,
  output logic [4*XLEN-1:0] result_row3
);

  // ---------------------------------------------------------------------------
  // Flat 1D storage: index = row*4 + col, range 0..15
  // A[r][c] → A_flat[r*4+c], etc.
  // ---------------------------------------------------------------------------
  logic [XLEN-1:0] A_flat [0:15];  // A[0..3][0..3]
  logic [XLEN-1:0] B_flat [0:15];  // B[0..3][0..3]
  logic [XLEN-1:0] C_flat [0:15];  // accumulator

  // ---------------------------------------------------------------------------
  // FSM
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] { IDLE=2'b00, LOAD=2'b01, CALC=2'b10, FINISH=2'b11 } state_t;
  state_t state;

  logic [1:0] row_cnt, col_cnt, k_cnt;

  // Current element index: row*4+col and k index
  logic [3:0] elem_idx;   // row*4 + col (0..15)
  logic [3:0] a_idx;      // row*4 + k
  logic [3:0] b_idx;      // k*4  + col

  assign elem_idx = {row_cnt, col_cnt};  // row*4+col (2-bit concat = 4-bit)
  assign a_idx    = {row_cnt, k_cnt};
  assign b_idx    = {k_cnt,   col_cnt};

  // MAC wires — read from flat arrays using elem addresses
  // These use the REGISTERED counter values so are always 1-cycle behind
  logic [2*XLEN-1:0] mac_full;
  logic [XLEN-1:0]   mac_lo;

  // Mux A_flat[a_idx] and B_flat[b_idx] using explicit 16-way case
  logic [XLEN-1:0] a_sel, b_sel, c_sel;

  always_comb begin : mux_a
    case (a_idx)
      4'd0:  a_sel = A_flat[0];   4'd1:  a_sel = A_flat[1];
      4'd2:  a_sel = A_flat[2];   4'd3:  a_sel = A_flat[3];
      4'd4:  a_sel = A_flat[4];   4'd5:  a_sel = A_flat[5];
      4'd6:  a_sel = A_flat[6];   4'd7:  a_sel = A_flat[7];
      4'd8:  a_sel = A_flat[8];   4'd9:  a_sel = A_flat[9];
      4'd10: a_sel = A_flat[10];  4'd11: a_sel = A_flat[11];
      4'd12: a_sel = A_flat[12];  4'd13: a_sel = A_flat[13];
      4'd14: a_sel = A_flat[14];  default: a_sel = A_flat[15];
    endcase
  end

  always_comb begin : mux_b
    case (b_idx)
      4'd0:  b_sel = B_flat[0];   4'd1:  b_sel = B_flat[1];
      4'd2:  b_sel = B_flat[2];   4'd3:  b_sel = B_flat[3];
      4'd4:  b_sel = B_flat[4];   4'd5:  b_sel = B_flat[5];
      4'd6:  b_sel = B_flat[6];   4'd7:  b_sel = B_flat[7];
      4'd8:  b_sel = B_flat[8];   4'd9:  b_sel = B_flat[9];
      4'd10: b_sel = B_flat[10];  4'd11: b_sel = B_flat[11];
      4'd12: b_sel = B_flat[12];  4'd13: b_sel = B_flat[13];
      4'd14: b_sel = B_flat[14];  default: b_sel = B_flat[15];
    endcase
  end

  always_comb begin : mux_c
    case (elem_idx)
      4'd0:  c_sel = C_flat[0];   4'd1:  c_sel = C_flat[1];
      4'd2:  c_sel = C_flat[2];   4'd3:  c_sel = C_flat[3];
      4'd4:  c_sel = C_flat[4];   4'd5:  c_sel = C_flat[5];
      4'd6:  c_sel = C_flat[6];   4'd7:  c_sel = C_flat[7];
      4'd8:  c_sel = C_flat[8];   4'd9:  c_sel = C_flat[9];
      4'd10: c_sel = C_flat[10];  4'd11: c_sel = C_flat[11];
      4'd12: c_sel = C_flat[12];  4'd13: c_sel = C_flat[13];
      4'd14: c_sel = C_flat[14];  default: c_sel = C_flat[15];
    endcase
  end

  assign mac_full = $signed(a_sel) * $signed(b_sel);
  assign mac_lo   = mac_full[XLEN-1:0];

  // ---------------------------------------------------------------------------
  // C_flat registers — explicit 16-way case write to avoid variable bit-select
  // ---------------------------------------------------------------------------
  logic [XLEN-1:0] c_next;
  assign c_next = c_sel + mac_lo;

  always_ff @(posedge clk or negedge rst_n) begin : c_regs
    integer i;
    if (!rst_n) begin
      for (i = 0; i < 16; i = i+1) C_flat[i] <= '0;
    end else if (state == IDLE && start) begin
      for (i = 0; i < 16; i = i+1) C_flat[i] <= '0;
    end else if (state == CALC) begin
      case (elem_idx)
        4'd0:  C_flat[0]  <= c_next;  4'd1:  C_flat[1]  <= c_next;
        4'd2:  C_flat[2]  <= c_next;  4'd3:  C_flat[3]  <= c_next;
        4'd4:  C_flat[4]  <= c_next;  4'd5:  C_flat[5]  <= c_next;
        4'd6:  C_flat[6]  <= c_next;  4'd7:  C_flat[7]  <= c_next;
        4'd8:  C_flat[8]  <= c_next;  4'd9:  C_flat[9]  <= c_next;
        4'd10: C_flat[10] <= c_next;  4'd11: C_flat[11] <= c_next;
        4'd12: C_flat[12] <= c_next;  4'd13: C_flat[13] <= c_next;
        4'd14: C_flat[14] <= c_next;  4'd15: C_flat[15] <= c_next;
        default: ;
      endcase
    end
  end

  genvar gi;

  // ---------------------------------------------------------------------------
  // A_flat and B_flat registers — loaded from input ports
  // ---------------------------------------------------------------------------
  generate
    for (gi = 0; gi < 4; gi++) begin : g_ab_regs
      always_ff @(posedge clk) begin
        if (state == IDLE && start) begin
          case (gi)
            0: begin
              A_flat[0]  <= mat_a_row0[  0 +: XLEN];
              A_flat[1]  <= mat_a_row0[ 32 +: XLEN];
              A_flat[2]  <= mat_a_row0[ 64 +: XLEN];
              A_flat[3]  <= mat_a_row0[ 96 +: XLEN];
              B_flat[0]  <= mat_b_col0[  0 +: XLEN];
              B_flat[4]  <= mat_b_col0[ 32 +: XLEN];
              B_flat[8]  <= mat_b_col0[ 64 +: XLEN];
              B_flat[12] <= mat_b_col0[ 96 +: XLEN];
            end
            1: begin
              A_flat[4]  <= mat_a_row1[  0 +: XLEN];
              A_flat[5]  <= mat_a_row1[ 32 +: XLEN];
              A_flat[6]  <= mat_a_row1[ 64 +: XLEN];
              A_flat[7]  <= mat_a_row1[ 96 +: XLEN];
              B_flat[1]  <= mat_b_col1[  0 +: XLEN];
              B_flat[5]  <= mat_b_col1[ 32 +: XLEN];
              B_flat[9]  <= mat_b_col1[ 64 +: XLEN];
              B_flat[13] <= mat_b_col1[ 96 +: XLEN];
            end
            2: begin
              A_flat[8]  <= mat_a_row2[  0 +: XLEN];
              A_flat[9]  <= mat_a_row2[ 32 +: XLEN];
              A_flat[10] <= mat_a_row2[ 64 +: XLEN];
              A_flat[11] <= mat_a_row2[ 96 +: XLEN];
              B_flat[2]  <= mat_b_col2[  0 +: XLEN];
              B_flat[6]  <= mat_b_col2[ 32 +: XLEN];
              B_flat[10] <= mat_b_col2[ 64 +: XLEN];
              B_flat[14] <= mat_b_col2[ 96 +: XLEN];
            end
            default: begin
              A_flat[12] <= mat_a_row3[  0 +: XLEN];
              A_flat[13] <= mat_a_row3[ 32 +: XLEN];
              A_flat[14] <= mat_a_row3[ 64 +: XLEN];
              A_flat[15] <= mat_a_row3[ 96 +: XLEN];
              B_flat[3]  <= mat_b_col3[  0 +: XLEN];
              B_flat[7]  <= mat_b_col3[ 32 +: XLEN];
              B_flat[11] <= mat_b_col3[ 64 +: XLEN];
              B_flat[15] <= mat_b_col3[ 96 +: XLEN];
            end
          endcase
        end
      end
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // FSM: state, counters, done, busy
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state   <= IDLE;
      done    <= 1'b0;
      busy    <= 1'b0;
      row_cnt <= '0;
      col_cnt <= '0;
      k_cnt   <= '0;
    end else begin
      done <= 1'b0;
      case (state)
        IDLE: begin
          if (start) begin
            row_cnt <= '0;
            col_cnt <= '0;
            k_cnt   <= '0;
            busy    <= 1'b1;
            state   <= LOAD;  // 1-cycle stall so A/B are registered
          end
        end
        LOAD: begin
          state <= CALC;  // A and B now have new values
        end
        CALC: begin
          // Advance counters
          if (k_cnt == 2'd3) begin
            k_cnt <= '0;
            if (col_cnt == 2'd3) begin
              col_cnt <= '0;
              if (row_cnt == 2'd3) begin
                state <= FINISH;
              end else begin
                row_cnt <= row_cnt + 1'b1;
              end
            end else begin
              col_cnt <= col_cnt + 1'b1;
            end
          end else begin
            k_cnt <= k_cnt + 1'b1;
          end
        end
        FINISH: begin
          done  <= 1'b1;
          busy  <= 1'b0;
          state <= IDLE;
        end
        default: state <= IDLE;
      endcase
    end
  end

  // ---------------------------------------------------------------------------
  // Result outputs (explicit flat indexing)
  // ---------------------------------------------------------------------------
  assign result_row0 = { C_flat[3],  C_flat[2],  C_flat[1],  C_flat[0]  };
  assign result_row1 = { C_flat[7],  C_flat[6],  C_flat[5],  C_flat[4]  };
  assign result_row2 = { C_flat[11], C_flat[10], C_flat[9],  C_flat[8]  };
  assign result_row3 = { C_flat[15], C_flat[14], C_flat[13], C_flat[12] };

endmodule
