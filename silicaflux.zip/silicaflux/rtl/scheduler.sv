// =============================================================================
// SilicaFlux — Dataflow Scheduler  (fully flat — iverilog 12 compatible)
// scheduler.sv
//
// All struct-array ports replaced with flat packed vectors.
// Synthesis tools (Vivado/VCS) accept struct arrays natively; this flat
// variant targets iverilog 12 which crashes on struct-array ports.
//
// Port mapping for callers:
//   tile_token_flat[t*TOKEN_W +: TOKEN_W] = df_token for tile t
//   tile_status_done[t]                   = tile_status[t].done
//   tile_status_scalar[t*XLEN +: XLEN]    = tile_status[t].result_scalar
// =============================================================================

`include "silicaflux_pkg.sv"

module scheduler
  import silicaflux_pkg::*;
(
  input  logic            clk,
  input  logic            rst_n,

  input  decoded_instr_t  instr_in,
  input  logic            instr_valid,
  output logic            instr_ready,

  input  logic [XLEN-1:0] scalar_a,
  input  logic [XLEN-1:0] scalar_b,
  input  logic [VLEN-1:0] vector_a,
  input  logic [VLEN-1:0] vector_b,

  // Tile token outputs as four separate scalar registers (avoids struct-array port crash)
  output logic            tile_tok_valid_0,
  output logic            tile_tok_valid_1,
  output logic            tile_tok_valid_2,
  output logic            tile_tok_valid_3,
  input  logic            tile_tok_ready_0,
  input  logic            tile_tok_ready_1,
  input  logic            tile_tok_ready_2,
  input  logic            tile_tok_ready_3,

  // Tile scalar / vector data feeds (one per tile)
  // Scalar/vector feeds — broadcast (same value to all tiles)
  output logic [XLEN-1:0] sched_scalar_out,
  output logic [VLEN-1:0] sched_vector_a_out,
  output logic [VLEN-1:0] sched_vector_b_out,

  // Token content — flat fields broadcast to all tiles (tile selects by valid)
  output logic [4:0]      tok_opcode,
  output logic [2:0]      tok_tile_id,
  output logic [4:0]      tok_src_reg,
  output logic [4:0]      tok_dst_reg,
  output logic [3:0]      tok_vsrc_reg,
  output logic [3:0]      tok_vdst_reg,
  output logic [13:0]     tok_mem_addr,
  output logic [4:0]      tok_length,
  output logic [7:0]      tok_func,

  // Tile status (flat vectors)
  input  logic [NUM_TILES-1:0]       tile_status_done,
  input  logic [NUM_TILES*XLEN-1:0]  tile_status_scalar,

  output logic            wb_valid,
  output logic [4:0]      wb_reg,
  output logic [XLEN-1:0] wb_data,

  output logic            sync_stall
);

  // ---------------------------------------------------------------------------
  // Tile Busy Scoreboard
  // ---------------------------------------------------------------------------
  logic [NUM_TILES-1:0] tile_busy;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tile_busy <= '0;
    end else begin
      // Set busy when token accepted; clear when tile reports done
      if (tile_tok_valid_0 && tile_tok_ready_0) tile_busy[0] <= 1'b1;
      if (tile_tok_valid_1 && tile_tok_ready_1) tile_busy[1] <= 1'b1;
      if (tile_tok_valid_2 && tile_tok_ready_2) tile_busy[2] <= 1'b1;
      if (tile_tok_valid_3 && tile_tok_ready_3) tile_busy[3] <= 1'b1;
      if (tile_status_done[0]) tile_busy[0] <= 1'b0;
      if (tile_status_done[1]) tile_busy[1] <= 1'b0;
      if (tile_status_done[2]) tile_busy[2] <= 1'b0;
      if (tile_status_done[3]) tile_busy[3] <= 1'b0;
    end
  end

  logic all_tiles_idle;
  assign all_tiles_idle = (tile_busy == '0);

  // ---------------------------------------------------------------------------
  // DFSYNC Barrier
  // ---------------------------------------------------------------------------
  logic sync_barrier_active;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)
      sync_barrier_active <= 1'b0;
    else if (instr_valid && instr_in.opcode == OP_DFSYNC && instr_ready)
      sync_barrier_active <= 1'b1;
    else if (all_tiles_idle)
      sync_barrier_active <= 1'b0;
  end

  assign sync_stall = sync_barrier_active && !all_tiles_idle;

  // ---------------------------------------------------------------------------
  // Token field broadcast (flat)
  // ---------------------------------------------------------------------------
  logic [2:0] target_tile;
  assign target_tile = instr_in.tile_id[2:0];

  assign tok_opcode   = instr_in.opcode;
  assign tok_tile_id  = target_tile;
  assign tok_src_reg  = instr_in.rs1;
  assign tok_dst_reg  = instr_in.rd;
  assign tok_vsrc_reg = instr_in.vrs1;
  assign tok_vdst_reg = instr_in.vrd;
  assign tok_mem_addr = instr_in.imm[13:0];
  assign tok_length   = instr_in.func[4:0];
  assign tok_func     = instr_in.func;

  // ---------------------------------------------------------------------------
  // Dispatch
  // ---------------------------------------------------------------------------
  logic dispatch_ok;
  assign dispatch_ok = instr_valid && !sync_stall && (
    (target_tile==3'd0 && !tile_busy[0] && tile_tok_ready_0) ||
    (target_tile==3'd1 && !tile_busy[1] && tile_tok_ready_1) ||
    (target_tile==3'd2 && !tile_busy[2] && tile_tok_ready_2) ||
    (target_tile==3'd3 && !tile_busy[3] && tile_tok_ready_3));

  assign instr_ready = !sync_stall && (
    (target_tile==3'd0 && (tile_tok_ready_0 || !tile_busy[0])) ||
    (target_tile==3'd1 && (tile_tok_ready_1 || !tile_busy[1])) ||
    (target_tile==3'd2 && (tile_tok_ready_2 || !tile_busy[2])) ||
    (target_tile==3'd3 && (tile_tok_ready_3 || !tile_busy[3])));

  // tile_token_valid — one-hot based on target_tile
  always_comb begin
    tile_tok_valid_0 = dispatch_ok && (target_tile == 3'd0);
    tile_tok_valid_1 = dispatch_ok && (target_tile == 3'd1);
    tile_tok_valid_2 = dispatch_ok && (target_tile == 3'd2);
    tile_tok_valid_3 = dispatch_ok && (target_tile == 3'd3);
  end

  // Broadcast scalar/vector operands to all tiles
  assign sched_scalar_out    = scalar_a;
  assign sched_vector_a_out  = vector_a;
  assign sched_vector_b_out  = vector_b;

  // ---------------------------------------------------------------------------
  // Scalar Writeback
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wb_valid <= 1'b0; wb_reg <= '0; wb_data <= '0;
    end else begin
      wb_valid <= 1'b0;
      // Priority: tile 0 > 1 > 2 > 3 (first match wins)
      if      (tile_status_done[3] && tile_status_scalar[3*32+:32] != '0)
        begin wb_valid<=1'b1; wb_reg<='0; wb_data<=tile_status_scalar[3*32+:32]; end
      if      (tile_status_done[2] && tile_status_scalar[2*32+:32] != '0)
        begin wb_valid<=1'b1; wb_reg<='0; wb_data<=tile_status_scalar[2*32+:32]; end
      if      (tile_status_done[1] && tile_status_scalar[1*32+:32] != '0)
        begin wb_valid<=1'b1; wb_reg<='0; wb_data<=tile_status_scalar[1*32+:32]; end
      if      (tile_status_done[0] && tile_status_scalar[0*32+:32] != '0)
        begin wb_valid<=1'b1; wb_reg<='0; wb_data<=tile_status_scalar[0*32+:32]; end
    end
  end

endmodule
