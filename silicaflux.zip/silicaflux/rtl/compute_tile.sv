// =============================================================================
// SilicaFlux — Compute Tile
// compute_tile.sv
//
// Self-contained compute unit. Instantiated N times (default: 4) to form
// the SilicaFlux cluster fabric.
//
// Each tile contains:
//   - Vector Engine   (SIMD ALU, LANES-wide)
//   - Tensor Unit     (4x4 MATMUL engine)
//   - Memory Controller (local scratchpad SRAM)
//   - Local vector register staging (8 x 128-bit)
//
// Tile receives work tokens from the Scheduler and reports completion.
// Tiles communicate via the NoC interconnect (separate path).
//
// Parameters:
//   TILE_ID  — Unique tile identifier [0..NUM_TILES-1]
//   LANES    — SIMD lane count for the vector engine
// =============================================================================

`include "silicaflux_pkg.sv"

module compute_tile
  import silicaflux_pkg::*;
#(
  parameter int TILE_ID = 0,
  parameter int LANES   = LANES_DEFAULT
)
(
  input  logic          clk,
  input  logic          rst_n,

  // --- Scheduler Work Token Interface (flat fields) ---
  input  logic [4:0]    tok_opcode,
  input  logic [2:0]    tok_tile_id,
  input  logic [4:0]    tok_src_reg,
  input  logic [4:0]    tok_dst_reg,
  input  logic [3:0]    tok_vsrc_reg,
  input  logic [3:0]    tok_vdst_reg,
  input  logic [13:0]   tok_mem_addr,
  input  logic [4:0]    tok_length,
  input  logic [7:0]    tok_func,
  input  logic          token_valid,
  output logic          token_ready,

  // --- Scalar Data Feed (from register bank, via control core) ---
  input  logic [XLEN-1:0]  scalar_data_in,   // rs1/rd scalar value
  input  logic [VLEN-1:0]  vector_data_in,   // vrs1 value
  input  logic [VLEN-1:0]  vector_data_in_b, // vrs2 value

  // --- Result Output ---
  output logic            tile_done,
  output logic            tile_error,
  output logic [XLEN-1:0] tile_result_scalar,
  output logic [VLEN-1:0] tile_result_vector,

  // --- NoC Send Interface ---
  output noc_flit_t     noc_flit_out,
  output logic          noc_flit_valid,
  input  logic          noc_flit_ready,

  // --- NoC Receive Interface ---
  input  noc_flit_t     noc_flit_in,
  input  logic          noc_flit_in_valid,
  output logic          noc_flit_in_ready
);

  // ---------------------------------------------------------------------------
  // Local Vector Register Staging (8 x 128-bit scratch registers)
  // ---------------------------------------------------------------------------
  logic [VLEN-1:0] vreg_local [0:7];

  // ---------------------------------------------------------------------------
  // Memory Controller Interface
  // ---------------------------------------------------------------------------
  logic               mem_req_valid;
  logic               mem_req_ready;
  logic [XLEN-1:0]    mem_req_addr;
  logic [XLEN-1:0]    mem_req_wdata;
  logic [VLEN-1:0]    mem_req_vwdata;
  logic [4:0]         mem_req_opcode;
  logic [4:0]         mem_req_length;
  logic               mem_resp_valid;
  logic [XLEN-1:0]    mem_resp_rdata;
  logic [VLEN-1:0]    mem_resp_vrdata;

  memory_controller u_mem (
    .clk           (clk),
    .rst_n         (rst_n),
    .req_valid     (mem_req_valid),
    .req_ready     (mem_req_ready),
    .req_opcode    (mem_req_opcode),
    .req_addr      (mem_req_addr),
    .req_wdata     (mem_req_wdata),
    .req_vwdata    (mem_req_vwdata),
    .req_length    (mem_req_length),
    .resp_valid    (mem_resp_valid),
    .resp_rdata    (mem_resp_rdata),
    .resp_vrdata   (mem_resp_vrdata),
    .alignment_err (/* tie off */),
    .wb_valid      (1'b0),
    .wb_addr       ('0),
    .wb_data       ('0)
  );

  // ---------------------------------------------------------------------------
  // Vector Engine Interface
  // ---------------------------------------------------------------------------
  logic               vec_issue_valid;
  logic [4:0]         vec_opcode;
  logic [7:0]         vec_func;
  logic [LANES*XLEN-1:0] vec_op_a;
  logic [LANES*XLEN-1:0] vec_op_b;
  logic               vec_result_valid;
  logic [LANES*XLEN-1:0] vec_vresult;
  logic [XLEN-1:0]    vec_scalar_result;
  logic               vec_is_scalar;

  vector_engine #(.LANES(LANES)) u_vec (
    .clk             (clk),
    .rst_n           (rst_n),
    .issue_valid     (vec_issue_valid),
    .opcode          (vec_opcode),
    .func            (vec_func),
    .vop_a           (vec_op_a),
    .vop_b           (vec_op_b),
    .scalar_in       (scalar_data_in),
    .result_valid    (vec_result_valid),
    .vresult         (vec_vresult),
    .scalar_result   (vec_scalar_result),
    .is_scalar_result(vec_is_scalar)
  );

  // ---------------------------------------------------------------------------
  // Tensor Unit Interface
  // ---------------------------------------------------------------------------
  logic               tensor_start;
  logic               tensor_done;
  logic               tensor_busy;
  logic [4*XLEN-1:0]  tensor_result_row [0:3];

  tensor_unit u_tensor (
    .clk          (clk),
    .rst_n        (rst_n),
    .start        (tensor_start),
    .mat_a_row0   (vreg_local[0][127:0]),
    .mat_a_row1   (vreg_local[1][127:0]),
    .mat_a_row2   (vreg_local[2][127:0]),
    .mat_a_row3   (vreg_local[3][127:0]),
    .mat_b_col0   (vreg_local[4][127:0]),
    .mat_b_col1   (vreg_local[5][127:0]),
    .mat_b_col2   (vreg_local[6][127:0]),
    .mat_b_col3   (vreg_local[7][127:0]),
    .done         (tensor_done),
    .result_row0  (tensor_result_row[0]),
    .result_row1  (tensor_result_row[1]),
    .result_row2  (tensor_result_row[2]),
    .result_row3  (tensor_result_row[3]),
    .busy         (tensor_busy)
  );

  // ---------------------------------------------------------------------------
  // Assemble df_token_t from flat input fields
  // ---------------------------------------------------------------------------
  df_token_t token_in;
  always_comb begin
    token_in         = '0;
    token_in.opcode  = tok_opcode;
    token_in.tile_id = tok_tile_id;
    token_in.src_reg = tok_src_reg;
    token_in.dst_reg = tok_dst_reg;
    token_in.vsrc_reg= tok_vsrc_reg;
    token_in.vdst_reg= tok_vdst_reg;
    token_in.mem_addr= tok_mem_addr;
    token_in.length  = tok_length;
    token_in.func    = tok_func;
    token_in.valid   = 1'b1;
  end

  // ---------------------------------------------------------------------------
  // Tile FSM
  // ---------------------------------------------------------------------------
  typedef enum logic [2:0] {
    T_IDLE    = 3'b000,
    T_MEMWAIT = 3'b001,
    T_VECEXEC = 3'b010,
    T_TENSOR  = 3'b011,
    T_DONE    = 3'b100
  } tile_state_t;

  tile_state_t tstate;
  df_token_t   active_token;

  // NoC receive: buffer incoming flits into local vector register
  assign noc_flit_in_ready = (tstate == T_IDLE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tstate          <= T_IDLE;
      token_ready     <= 1'b1;
      tile_done          <= 1'b0;
      tile_error         <= 1'b0;
      tile_result_scalar <= '0;
      tile_result_vector <= '0;
      vec_issue_valid <= 1'b0;
      tensor_start    <= 1'b0;
      mem_req_valid   <= 1'b0;
      noc_flit_valid  <= 1'b0;
      noc_flit_out    <= '0;
      for (int i = 0; i < 8; i++) vreg_local[i] <= '0;
    end else begin
      vec_issue_valid <= 1'b0;
      tensor_start    <= 1'b0;
      mem_req_valid   <= 1'b0;
      noc_flit_valid  <= 1'b0;
      tile_done     <= 1'b0;

      case (tstate)
        // -----------------------------------------------------------
        T_IDLE: begin
          token_ready <= 1'b1;

          // Accept NoC data into local vreg
          if (noc_flit_in_valid) begin
            vreg_local[noc_flit_in.src_col[2:0]] <=
              {96'b0, noc_flit_in.data};
          end

          if (token_valid) begin
            token_ready  <= 1'b0;
            active_token <= token_in;

            case (token_in.opcode)
              // Memory ops — go wait for memory
              OP_LOAD, OP_DFLOAD, OP_VLOAD: begin
                mem_req_valid  <= 1'b1;
                mem_req_opcode <= token_in.opcode;
                mem_req_addr   <= {18'b0, token_in.mem_addr, 2'b00};
                mem_req_length <= token_in.length;
                tstate         <= T_MEMWAIT;
              end
              OP_STORE, OP_DFSTORE, OP_VSTORE: begin
                mem_req_valid  <= 1'b1;
                mem_req_opcode <= token_in.opcode;
                mem_req_addr   <= {18'b0, token_in.mem_addr, 2'b00};
                mem_req_wdata  <= scalar_data_in;
                mem_req_vwdata <= vector_data_in;
                mem_req_length <= token_in.length;
                tstate         <= T_MEMWAIT;
              end

              // Vector ops — issue to vector engine
              OP_VADD, OP_VSUB, OP_VMUL,
              OP_DOT, OP_REDUCE, OP_BCAST: begin
                vec_issue_valid <= 1'b1;
                vec_opcode      <= token_in.opcode;
                vec_func        <= token_in.func;
                vec_op_a        <= vector_data_in [LANES*XLEN-1:0];
                vec_op_b        <= vector_data_in_b[LANES*XLEN-1:0];
                tstate          <= T_VECEXEC;
              end

              // Matrix multiply — preload local vregs from inputs then start
              OP_MATMUL: begin
                vreg_local[0] <= vector_data_in;
                vreg_local[1] <= vector_data_in_b;
                tensor_start  <= 1'b1;
                tstate        <= T_TENSOR;
              end

              // DFSYNC — just complete immediately
              OP_DFSYNC: begin
                tile_done      <= 1'b1;
                
                tstate           <= T_IDLE;
                token_ready      <= 1'b1;
              end

              default: begin
                tstate <= T_IDLE;
              end
            endcase
          end
        end

        // -----------------------------------------------------------
        T_MEMWAIT: begin
          if (mem_resp_valid) begin
            tile_result_scalar <= mem_resp_rdata;
            tile_result_vector <= mem_resp_vrdata;
            tile_done          <= 1'b1;
            
            tstate               <= T_IDLE;
            token_ready          <= 1'b1;
          end
        end

        // -----------------------------------------------------------
        T_VECEXEC: begin
          if (vec_result_valid) begin
            if (vec_is_scalar) begin
              tile_result_scalar <= vec_scalar_result;
              tile_result_vector <= '0;
            end else begin
              tile_result_scalar <= '0;
              tile_result_vector <= {'0, vec_vresult};
            end
            tile_done      <= 1'b1;
            
            tstate           <= T_IDLE;
            token_ready      <= 1'b1;
          end
        end

        // -----------------------------------------------------------
        T_TENSOR: begin
          if (tensor_done) begin
            // Pack result into vector result field (row 0 only in scalar path)
            tile_result_vector[127:96] <= tensor_result_row[3];
            tile_result_vector[95:64]  <= tensor_result_row[2];
            tile_result_vector[63:32]  <= tensor_result_row[1];
            tile_result_vector[31:0]   <= tensor_result_row[0];
            tile_result_scalar <= tensor_result_row[0][31:0];
            tile_done          <= 1'b1;
            
            tstate               <= T_IDLE;
            token_ready          <= 1'b1;
          end
        end

        default: tstate <= T_IDLE;
      endcase
    end
  end

  // NoC send: forward scalar result to destination tile after DFEXEC
  always_ff @(posedge clk) begin
    if (tile_done && active_token.opcode == OP_DFEXEC) begin
      noc_flit_out.flit_type <= FLIT_SINGLE;
      noc_flit_out.dst_row   <= active_token.tile_id[2:1];
      noc_flit_out.dst_col   <= {1'b0, active_token.tile_id[0]};
      noc_flit_out.src_row   <= TILE_ID[1:0] >> 1;
      noc_flit_out.src_col   <= TILE_ID[1:0] & 2'b01;
      noc_flit_out.data      <= tile_result_scalar;
      noc_flit_out.valid     <= 1'b1;
      noc_flit_valid         <= 1'b1;
    end
  end

endmodule
