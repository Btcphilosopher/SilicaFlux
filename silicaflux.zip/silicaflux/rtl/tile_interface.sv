// =============================================================================
// SilicaFlux — Tile Interface (Chiplet Boundary Abstraction)
// tile_interface.sv
//
// Provides the inter-die communication layer for multi-chiplet SilicaFlux
// deployments. Serialises 32-bit NoC flits over a narrow parallel link
// suitable for bump-array or SerDes physical implementation.
//
// Features:
//   - Serialisation: 32-bit flit → 4 x 8-bit beats (link_width=8 default)
//   - Header beat encodes destination and flit type
//   - Synchronous handshake: valid/ready on both sides
//   - Retimer FFs at die boundary (for timing closure on inter-die links)
//   - Parameterisable link width (8 / 16 / 32 bits)
//
// Physical Layer Model (simulation-accurate):
//   - 2-FF retimer synchroniser on RX path
//   - ECC placeholder (parity bit on each beat, not correcting — flag only)
//
// Usage:
//   Instantiated at the periphery of each SilicaFlux cluster die.
//   TX side connects to the cluster's NoC boundary router port.
//   RX side injects received flits into the cluster's NoC injection port.
// =============================================================================

`include "silicaflux_pkg.sv"

module tile_interface
  import silicaflux_pkg::*;
#(
  parameter int LINK_WIDTH = 8  // Physical link width in bits (8/16/32)
)
(
  input  logic  clk,
  input  logic  rst_n,

  // === Internal Side (connects to NoC boundary) ===

  // TX: NoC → off-chip
  input  noc_flit_t  tx_flit_in,
  input  logic       tx_flit_valid,
  output logic       tx_flit_ready,   // Can accept new flit

  // RX: off-chip → NoC injection
  output noc_flit_t  rx_flit_out,
  output logic       rx_flit_valid,
  input  logic       rx_flit_ready,

  // === Physical Die-Boundary Signals ===

  // TX physical outputs
  output logic [LINK_WIDTH-1:0] phy_tx_data,
  output logic                  phy_tx_valid,
  input  logic                  phy_tx_credit,  // Back-pressure from RX die

  // RX physical inputs
  input  logic [LINK_WIDTH-1:0] phy_rx_data,
  input  logic                  phy_rx_valid,
  output logic                  phy_rx_credit,  // Credit grant to TX die

  // Status
  output logic  link_up,        // Link is active
  output logic  parity_error    // Parity check failure detected
);

  // ---------------------------------------------------------------------------
  // Parameters
  // ---------------------------------------------------------------------------
  // Flit total width: noc_flit_t packed size
  // noc_flit_t = flit_type(2) + dst_row(2) + dst_col(2) + src_row(2) +
  //              src_col(2) + data(32) + valid(1) = 43 bits
  // Round up to ceil(43/LINK_WIDTH) beats
  localparam int FLIT_BITS  = 43;
  localparam int NUM_BEATS  = (FLIT_BITS + LINK_WIDTH - 1) / LINK_WIDTH;
  localparam int PAD_BITS   = NUM_BEATS * LINK_WIDTH - FLIT_BITS;

  // ---------------------------------------------------------------------------
  // TX Serialiser
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    TX_IDLE = 2'b00,
    TX_SEND = 2'b01,
    TX_WAIT = 2'b10
  } tx_state_t;

  tx_state_t            tx_state;
  logic [FLIT_BITS-1:0] tx_shift_reg;   // Flit data being shifted out
  logic [$clog2(NUM_BEATS):0] tx_beat_cnt;

  // Pack noc_flit_t to flat bits
  logic [FLIT_BITS-1:0] flit_packed;
  assign flit_packed = {
    tx_flit_in.flit_type,   // [42:41]
    tx_flit_in.dst_row,     // [40:39]
    tx_flit_in.dst_col,     // [38:37]
    tx_flit_in.src_row,     // [36:35]
    tx_flit_in.src_col,     // [34:33]
    tx_flit_in.data,        // [32:1]
    tx_flit_in.valid        // [0]
  };

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tx_state     <= TX_IDLE;
      tx_flit_ready <= 1'b1;
      phy_tx_valid  <= 1'b0;
      phy_tx_data   <= '0;
      tx_beat_cnt   <= '0;
      tx_shift_reg  <= '0;
    end else begin
      phy_tx_valid <= 1'b0;

      case (tx_state)
        TX_IDLE: begin
          tx_flit_ready <= 1'b1;
          if (tx_flit_valid) begin
            tx_flit_ready <= 1'b0;
            tx_shift_reg  <= flit_packed;
            tx_beat_cnt   <= '0;
            tx_state      <= TX_SEND;
          end
        end

        TX_SEND: begin
          if (phy_tx_credit) begin  // Credit available from receiver
            // Send LSB-first beats
            phy_tx_data  <= tx_shift_reg[LINK_WIDTH-1:0];
            phy_tx_valid <= 1'b1;
            tx_shift_reg <= {{LINK_WIDTH{1'b0}}, tx_shift_reg[FLIT_BITS-1:LINK_WIDTH]};
            tx_beat_cnt  <= tx_beat_cnt + 1;

            if (tx_beat_cnt == NUM_BEATS - 1) begin
              tx_state      <= TX_IDLE;
              tx_flit_ready <= 1'b1;
            end
          end
        end

        default: tx_state <= TX_IDLE;
      endcase
    end
  end

  // ---------------------------------------------------------------------------
  // RX Deserialiser with 2-FF Retimer (synchroniser)
  // ---------------------------------------------------------------------------
  // 2-FF synchroniser for phy_rx_valid (cross-clock safety)
  logic phy_rx_valid_s1, phy_rx_valid_sync;
  logic [LINK_WIDTH-1:0] phy_rx_data_s1, phy_rx_data_sync;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      phy_rx_valid_s1   <= 1'b0;
      phy_rx_valid_sync <= 1'b0;
      phy_rx_data_s1    <= '0;
      phy_rx_data_sync  <= '0;
    end else begin
      phy_rx_valid_s1   <= phy_rx_valid;
      phy_rx_valid_sync <= phy_rx_valid_s1;
      phy_rx_data_s1    <= phy_rx_data;
      phy_rx_data_sync  <= phy_rx_data_s1;
    end
  end

  typedef enum logic [1:0] {
    RX_IDLE = 2'b00,
    RX_RECV = 2'b01,
    RX_EJECT= 2'b10
  } rx_state_t;

  rx_state_t            rx_state;
  logic [FLIT_BITS-1:0] rx_shift_reg;
  logic [$clog2(NUM_BEATS):0] rx_beat_cnt;
  noc_flit_t            rx_assembled;

  // Parity check (odd parity over received bits — placeholder for ECC)
  logic rx_parity_ok;
  assign rx_parity_ok = ^rx_shift_reg; // Must be 1 for odd parity

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rx_state      <= RX_IDLE;
      rx_flit_valid <= 1'b0;
      rx_flit_out   <= '0;
      phy_rx_credit <= 1'b1;
      rx_beat_cnt   <= '0;
      rx_shift_reg  <= '0;
      parity_error  <= 1'b0;
    end else begin
      parity_error <= 1'b0;

      case (rx_state)
        RX_IDLE: begin
          phy_rx_credit <= 1'b1;
          if (phy_rx_valid_sync) begin
            rx_shift_reg <= {{(FLIT_BITS-LINK_WIDTH){1'b0}}, phy_rx_data_sync};
            rx_beat_cnt  <= 1;
            rx_state     <= RX_RECV;
            phy_rx_credit <= 1'b1;
          end
        end

        RX_RECV: begin
          if (phy_rx_valid_sync) begin
            // Shift in next beat at MSB
            rx_shift_reg <= {phy_rx_data_sync,
                             rx_shift_reg[FLIT_BITS-1:LINK_WIDTH]};
            rx_beat_cnt  <= rx_beat_cnt + 1;

            if (rx_beat_cnt == NUM_BEATS - 1) begin
              phy_rx_credit <= 1'b0; // Stop accepting until ejected
              rx_state      <= RX_EJECT;
            end
          end
        end

        RX_EJECT: begin
          if (rx_flit_ready || !rx_flit_valid) begin
            // Unpack flat bits back to noc_flit_t
            rx_assembled.valid     <= rx_shift_reg[0];
            rx_assembled.data      <= rx_shift_reg[32:1];
            rx_assembled.src_col   <= rx_shift_reg[34:33];
            rx_assembled.src_row   <= rx_shift_reg[36:35];
            rx_assembled.dst_col   <= rx_shift_reg[38:37];
            rx_assembled.dst_row   <= rx_shift_reg[40:39];
            rx_assembled.flit_type <= flit_type_t'(rx_shift_reg[42:41]);

            rx_flit_out   <= rx_assembled;
            rx_flit_valid <= 1'b1;
            phy_rx_credit <= 1'b1;
            rx_state      <= RX_IDLE;
          end
        end

        default: rx_state <= RX_IDLE;
      endcase

      // Clear rx_flit_valid after accepted
      if (rx_flit_valid && rx_flit_ready)
        rx_flit_valid <= 1'b0;
    end
  end

  // ---------------------------------------------------------------------------
  // Link Up Detection — simple: link is up when TX and RX have both exchanged
  // at least one beat successfully. (Production: replace with init handshake.)
  // ---------------------------------------------------------------------------
  logic tx_ever_sent, rx_ever_received;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tx_ever_sent     <= 1'b0;
      rx_ever_received <= 1'b0;
    end else begin
      if (phy_tx_valid)           tx_ever_sent     <= 1'b1;
      if (phy_rx_valid_sync)      rx_ever_received <= 1'b1;
    end
  end

  assign link_up = tx_ever_sent && rx_ever_received;

endmodule
