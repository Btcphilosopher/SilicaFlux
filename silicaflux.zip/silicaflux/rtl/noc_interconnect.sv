// =============================================================================
// SilicaFlux — NoC Interconnect (2×2 mesh using noc_router instances)
// noc_interconnect.sv
//
// Topology:   R(0,0) -- E/W -- R(0,1)
//                |                |
//               N/S              N/S
//                |                |
//             R(1,0) -- E/W -- R(1,1)
//
// The flit payload injected/ejected from tiles is a packed 32-bit data word.
// Internally routers carry the full 43-bit flit (header + data + valid).
// =============================================================================
`include "silicaflux_pkg.sv"

module noc_interconnect
  import silicaflux_pkg::*;
#(parameter int ROWS=NOC_ROWS, parameter int COLS=NOC_COLS)
(
  input  logic  clk, rst_n,
  input  noc_flit_t inject_flit [0:ROWS-1][0:COLS-1],
  input  logic      inject_valid[0:ROWS-1][0:COLS-1],
  output logic      inject_ready[0:ROWS-1][0:COLS-1],
  output noc_flit_t eject_flit  [0:ROWS-1][0:COLS-1],
  output logic      eject_valid [0:ROWS-1][0:COLS-1],
  input  logic      eject_ready [0:ROWS-1][0:COLS-1],
  output logic [NOC_WIDTH-1:0] eject_data[0:ROWS-1][0:COLS-1],
  // Flat 1D versions to work around iverilog 2D port limitation (same signals)
  output logic [3:0] inject_ready_flat,  // [3]=r1c1 [2]=r1c0 [1]=r0c1 [0]=r0c0
  output logic [3:0] eject_valid_flat,
  output logic [NOC_WIDTH-1:0] ej_data_flat_0,
  output logic [NOC_WIDTH-1:0] ej_data_flat_1,
  output logic [NOC_WIDTH-1:0] ej_data_flat_2,
  output logic [NOC_WIDTH-1:0] ej_data_flat_3
);
  localparam int FW=43;

  // Pack noc_flit_t → 43-bit word for internal links
  function automatic logic [FW-1:0] pk(input noc_flit_t f);
    pk={f.flit_type,f.dst_row,f.dst_col,f.src_row,f.src_col,f.data,f.valid};
  endfunction
  function automatic noc_flit_t up(input logic [NOC_WIDTH-1:0] data,
                                   input logic [FW-1:0] hdr);
    // Reconstruct eject flit from output data (header preserved in upper bits)
    up.flit_type = flit_type_t'(hdr[42:41]);
    up.dst_row   = hdr[40:39]; up.dst_col = hdr[38:37];
    up.src_row   = hdr[36:35]; up.src_col = hdr[34:33];
    up.data      = data; up.valid = 1'b1;
  endfunction

  // Inject packing (tile → router)
  logic [FW-1:0] inj_pkt[0:1][0:1];
  assign inj_pkt[0][0] = pk(inject_flit[0][0]);
  assign inj_pkt[0][1] = pk(inject_flit[0][1]);
  assign inj_pkt[1][0] = pk(inject_flit[1][0]);
  assign inj_pkt[1][1] = pk(inject_flit[1][1]);

  // Inter-router link wires — 43-bit packed flits
  logic [42:0] ew_e_data[0:1], ew_w_data[0:1]; // East/West per row
  logic        ew_e_vld[0:1],  ew_e_rdy[0:1];
  logic        ew_w_vld[0:1],  ew_w_rdy[0:1];
  logic [42:0] ns_s_data[0:1], ns_n_data[0:1]; // South/North per col
  logic        ns_s_vld[0:1],  ns_s_rdy[0:1];
  logic        ns_n_vld[0:1],  ns_n_rdy[0:1];

  // Eject wires
  logic [NOC_WIDTH-1:0] ej_data[0:1][0:1];
  logic                  ej_vld[0:1][0:1];

  // ---- Router [0][0] ----
  noc_router #(.MY_ROW(0),.MY_COL(0)) r00 (
    .clk(clk),.rst_n(rst_n),
    .local_in_data(inj_pkt[0][0][FW-1:0]),.local_in_valid(inject_valid[0][0]),
    .local_in_ready(inject_ready[0][0]),
    .local_out_data(ej_data[0][0]),.local_out_valid(ej_vld[0][0]),
    .local_out_ready(eject_ready[0][0]),
    .north_in_data('0),.north_in_valid(1'b0),.north_in_ready(),
    .north_out_data(),.north_out_valid(),.north_out_ready(1'b1),
    .south_in_data(ns_n_data[0]),.south_in_valid(ns_n_vld[0]),
    .south_in_ready(ns_n_rdy[0]),
    .south_out_data(ns_s_data[0]),.south_out_valid(ns_s_vld[0]),
    .south_out_ready(ns_s_rdy[0]),
    .east_in_data(ew_w_data[0]),.east_in_valid(ew_w_vld[0]),
    .east_in_ready(ew_w_rdy[0]),
    .east_out_data(ew_e_data[0]),.east_out_valid(ew_e_vld[0]),
    .east_out_ready(ew_e_rdy[0]),
    .west_in_data('0),.west_in_valid(1'b0),.west_in_ready(),
    .west_out_data(),.west_out_valid(),.west_out_ready(1'b1)
  );

  // ---- Router [0][1] ----
  noc_router #(.MY_ROW(0),.MY_COL(1)) r01 (
    .clk(clk),.rst_n(rst_n),
    .local_in_data(inj_pkt[0][1][FW-1:0]),.local_in_valid(inject_valid[0][1]),
    .local_in_ready(inject_ready[0][1]),
    .local_out_data(ej_data[0][1]),.local_out_valid(ej_vld[0][1]),
    .local_out_ready(eject_ready[0][1]),
    .north_in_data('0),.north_in_valid(1'b0),.north_in_ready(),
    .north_out_data(),.north_out_valid(),.north_out_ready(1'b1),
    .south_in_data(ns_n_data[1]),.south_in_valid(ns_n_vld[1]),
    .south_in_ready(ns_n_rdy[1]),
    .south_out_data(ns_s_data[1]),.south_out_valid(ns_s_vld[1]),
    .south_out_ready(ns_s_rdy[1]),
    .east_in_data('0),.east_in_valid(1'b0),.east_in_ready(),
    .east_out_data(),.east_out_valid(),.east_out_ready(1'b1),
    .west_in_data(ew_e_data[0]),.west_in_valid(ew_e_vld[0]),
    .west_in_ready(ew_e_rdy[0]),
    .west_out_data(ew_w_data[0]),.west_out_valid(ew_w_vld[0]),
    .west_out_ready(ew_w_rdy[0])
  );

  // ---- Router [1][0] ----
  noc_router #(.MY_ROW(1),.MY_COL(0)) r10 (
    .clk(clk),.rst_n(rst_n),
    .local_in_data(inj_pkt[1][0][FW-1:0]),.local_in_valid(inject_valid[1][0]),
    .local_in_ready(inject_ready[1][0]),
    .local_out_data(ej_data[1][0]),.local_out_valid(ej_vld[1][0]),
    .local_out_ready(eject_ready[1][0]),
    .north_in_data(ns_s_data[0]),.north_in_valid(ns_s_vld[0]),
    .north_in_ready(ns_s_rdy[0]),
    .north_out_data(ns_n_data[0]),.north_out_valid(ns_n_vld[0]),
    .north_out_ready(ns_n_rdy[0]),
    .south_in_data('0),.south_in_valid(1'b0),.south_in_ready(),
    .south_out_data(),.south_out_valid(),.south_out_ready(1'b1),
    .east_in_data(ew_w_data[1]),.east_in_valid(ew_w_vld[1]),
    .east_in_ready(ew_w_rdy[1]),
    .east_out_data(ew_e_data[1]),.east_out_valid(ew_e_vld[1]),
    .east_out_ready(ew_e_rdy[1]),
    .west_in_data('0),.west_in_valid(1'b0),.west_in_ready(),
    .west_out_data(),.west_out_valid(),.west_out_ready(1'b1)
  );

  // ---- Router [1][1] ----
  noc_router #(.MY_ROW(1),.MY_COL(1)) r11 (
    .clk(clk),.rst_n(rst_n),
    .local_in_data(inj_pkt[1][1][FW-1:0]),.local_in_valid(inject_valid[1][1]),
    .local_in_ready(inject_ready[1][1]),
    .local_out_data(ej_data[1][1]),.local_out_valid(ej_vld[1][1]),
    .local_out_ready(eject_ready[1][1]),
    .north_in_data(ns_s_data[1]),.north_in_valid(ns_s_vld[1]),
    .north_in_ready(ns_s_rdy[1]),
    .north_out_data(ns_n_data[1]),.north_out_valid(ns_n_vld[1]),
    .north_out_ready(ns_n_rdy[1]),
    .south_in_data('0),.south_in_valid(1'b0),.south_in_ready(),
    .south_out_data(),.south_out_valid(),.south_out_ready(1'b1),
    .east_in_data('0),.east_in_valid(1'b0),.east_in_ready(),
    .east_out_data(),.east_out_valid(),.east_out_ready(1'b1),
    .west_in_data(ew_e_data[1]),.west_in_valid(ew_e_vld[1]),
    .west_in_ready(ew_e_rdy[1]),
    .west_out_data(ew_w_data[1]),.west_out_valid(ew_w_vld[1]),
    .west_out_ready(ew_w_rdy[1])
  );

  // Flat output aliases (iverilog 2D port workaround)
  assign inject_ready_flat[0] = inject_ready[0][0];
  assign inject_ready_flat[1] = inject_ready[0][1];
  assign inject_ready_flat[2] = inject_ready[1][0];
  assign inject_ready_flat[3] = inject_ready[1][1];
  assign eject_valid_flat[0] = eject_valid[0][0];
  assign eject_valid_flat[1] = eject_valid[0][1];
  assign eject_valid_flat[2] = eject_valid[1][0];
  assign eject_valid_flat[3] = eject_valid[1][1];
  assign ej_data_flat_0 = ej_data[0][0];
  assign ej_data_flat_1 = ej_data[0][1];
  assign ej_data_flat_2 = ej_data[1][0];
  assign ej_data_flat_3 = ej_data[1][1];

  // Drive eject outputs from router local outputs
  assign eject_flit[0][0]  = up(ej_data[0][0], '0);
  assign eject_valid[0][0] = ej_vld[0][0];
  assign eject_data[0][0]  = ej_data[0][0];
  assign eject_flit[0][1]  = up(ej_data[0][1], '0);
  assign eject_valid[0][1] = ej_vld[0][1];
  assign eject_data[0][1]  = ej_data[0][1];
  assign eject_flit[1][0]  = up(ej_data[1][0], '0);
  assign eject_valid[1][0] = ej_vld[1][0];
  assign eject_data[1][0]  = ej_data[1][0];
  assign eject_flit[1][1]  = up(ej_data[1][1], '0);
  assign eject_valid[1][1] = ej_vld[1][1];
  assign eject_data[1][1]  = ej_data[1][1];

endmodule
