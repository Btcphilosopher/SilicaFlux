// =============================================================================
// SilicaFlux — Vector Engine
// vector_engine.sv
//
// Parameterized SIMD execution unit. Operates on VLEN-bit register data
// partitioned into LANES independent 32-bit processing lanes.
//
// Operations:
//   VADD     — lane-wise addition
//   VSUB     — lane-wise subtraction
//   VMUL     — lane-wise multiplication (32x32→32 lower half)
//   DOT      — inner product reduction → scalar result
//   REDUCE   — tree reduction (sum/min/max/and) → scalar result
//   BROADCAST— scalar replicated to all lanes → vector result
//
// Pipeline: 2 stages (issue → writeback)
//   Stage 0: operand select, lane computation
//   Stage 1: reduction tree + result register
//
// Parameters:
//   LANES  — SIMD width (4 / 8 / 16); default 4 (128-bit / 4x32)
//   XLEN   — scalar element width (32)
// =============================================================================

`include "silicaflux_pkg.sv"

module vector_engine
  import silicaflux_pkg::*;
#(
  parameter int LANES = LANES_DEFAULT  // Must be power of 2: 4, 8, or 16
)
(
  input  logic                        clk,
  input  logic                        rst_n,

  // --- Issue Interface ---
  input  logic                        issue_valid,
  input  logic [4:0]                  opcode,
  input  logic [7:0]                  func,           // Reduce op in func[1:0]
  input  logic [LANES*XLEN-1:0]       vop_a,          // Vector operand A
  input  logic [LANES*XLEN-1:0]       vop_b,          // Vector operand B
  input  logic [XLEN-1:0]             scalar_in,      // For BROADCAST

  // --- Result Interface ---
  output logic                        result_valid,
  output logic [LANES*XLEN-1:0]       vresult,        // Vector result (VADD/VMUL/VSUB/BCAST)
  output logic [XLEN-1:0]             scalar_result,  // Scalar result (DOT/REDUCE)
  output logic                        is_scalar_result // 1 = scalar_result valid
);

  // ---------------------------------------------------------------------------
  // Local Types
  // ---------------------------------------------------------------------------
  typedef logic [XLEN-1:0] lane_t;

  // ---------------------------------------------------------------------------
  // Lane Arrays — unpack input vectors
  // ---------------------------------------------------------------------------
  lane_t op_a [0:LANES-1];
  lane_t op_b [0:LANES-1];

  genvar gi;
  generate
    for (gi = 0; gi < LANES; gi++) begin : g_unpack
      assign op_a[gi] = vop_a[gi*XLEN +: XLEN];
      assign op_b[gi] = vop_b[gi*XLEN +: XLEN];
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // Stage 0 — Per-Lane Computation
  // ---------------------------------------------------------------------------
  lane_t lane_result [0:LANES-1];

  always_comb begin
    for (int i = 0; i < LANES; i++) begin
      case (opcode)
        OP_VADD:  lane_result[i] = op_a[i] + op_b[i];
        OP_VSUB:  lane_result[i] = op_a[i] - op_b[i];
        OP_VMUL:  lane_result[i] = op_a[i] * op_b[i];  // 32x32→32 (lower)
        OP_DOT:   lane_result[i] = op_a[i] * op_b[i];  // Partial product, reduced below
        OP_BCAST: lane_result[i] = scalar_in;
        default:  lane_result[i] = op_a[i];
      endcase
    end
  end

  // ---------------------------------------------------------------------------
  // Reduction Tree — REDUCE and DOT
  // Depth = log2(LANES) levels, each level halves active elements.
  // Implemented combinationally; registered at output.
  // ---------------------------------------------------------------------------
  // Intermediate levels — wide enough for max LANES=16
  lane_t reduce_lvl0 [0:LANES-1];
  lane_t reduce_lvl1 [0:LANES/2-1];
  lane_t reduce_lvl2 [0:LANES/4-1]; // Valid only when LANES >= 8

  reduce_op_t red_op;
  assign red_op = reduce_op_t'(func[1:0]);

  // Helper function: reduce two values per op
  function automatic lane_t reduce_pair;
    input lane_t a, b;
    input reduce_op_t op;
    case (op)
      REDUCE_SUM: reduce_pair = a + b;
      REDUCE_MIN: reduce_pair = ($signed(a) < $signed(b)) ? a : b;
      REDUCE_MAX: reduce_pair = ($signed(a) > $signed(b)) ? a : b;
      REDUCE_AND: reduce_pair = a & b;
      default:    reduce_pair = a + b;
    endcase
  endfunction

  always_comb begin
    // Level 0: copy lane results in
    for (int i = 0; i < LANES; i++)
      reduce_lvl0[i] = lane_result[i];

    // Level 1: reduce pairs
    for (int i = 0; i < LANES/2; i++)
      reduce_lvl1[i] = reduce_pair(reduce_lvl0[2*i], reduce_lvl0[2*i+1], red_op);
  end

  // Level 2 (only used when LANES >= 8)
  generate
    if (LANES >= 8) begin : g_reduce_l2
      always_comb begin
        for (int i = 0; i < LANES/4; i++)
          reduce_lvl2[i] = reduce_pair(reduce_lvl1[2*i], reduce_lvl1[2*i+1], red_op);
      end
    end else begin : g_reduce_l2_tie
      assign reduce_lvl2[0] = reduce_lvl1[0];
    end
  endgenerate

  // Final scalar result mux
  lane_t scalar_comb;
  always_comb begin
    if (LANES == 4)
      scalar_comb = reduce_pair(reduce_lvl1[0], reduce_lvl1[1], red_op);
    else if (LANES == 8)
      scalar_comb = reduce_pair(reduce_lvl2[0], reduce_lvl2[1], red_op);
    else // 16
      scalar_comb = reduce_pair(reduce_lvl2[0], reduce_lvl2[1], red_op); // simplified
    end

  // ---------------------------------------------------------------------------
  // Pack lane results back to vector word
  // ---------------------------------------------------------------------------
  logic [LANES*XLEN-1:0] vresult_comb;
  generate
    for (gi = 0; gi < LANES; gi++) begin : g_pack
      assign vresult_comb[gi*XLEN +: XLEN] = lane_result[gi];
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // Stage 1 — Output Register
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      result_valid     <= 1'b0;
      vresult          <= '0;
      scalar_result    <= '0;
      is_scalar_result <= 1'b0;
    end else begin
      result_valid <= issue_valid;

      case (opcode)
        OP_VADD, OP_VSUB, OP_VMUL, OP_BCAST: begin
          vresult          <= vresult_comb;
          scalar_result    <= '0;
          is_scalar_result <= 1'b0;
        end
        OP_DOT, OP_REDUCE: begin
          vresult          <= '0;
          scalar_result    <= scalar_comb;
          is_scalar_result <= 1'b1;
        end
        default: begin
          vresult          <= vresult_comb;
          scalar_result    <= '0;
          is_scalar_result <= 1'b0;
        end
      endcase
    end
  end

endmodule
