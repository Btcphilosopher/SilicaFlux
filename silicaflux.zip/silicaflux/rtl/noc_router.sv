// =============================================================================
// SilicaFlux — Single NoC Router (5-port, 1-flit buffer)
// noc_router.sv
// Ports: LOCAL(0) NORTH(1) SOUTH(2) EAST(3) WEST(4)
// Routing: XY deterministic
// =============================================================================
`include "silicaflux_pkg.sv"
module noc_router
  import silicaflux_pkg::*;
#(parameter int MY_ROW=0, parameter int MY_COL=0)
(
  input  logic clk, rst_n,
  // LOCAL inject/eject
  // LOCAL: accepts full 43-bit packed flit; outputs 32-bit data payload
  input  logic [42:0]          local_in_data,
  input  logic                 local_in_valid,
  output logic                 local_in_ready,
  output logic [NOC_WIDTH-1:0] local_out_data,
  output logic                 local_out_valid,
  input  logic                 local_out_ready,
  // Inter-router links carry 43-bit packed flits
  input  logic [42:0] north_in_data,  input  logic north_in_valid,  output logic north_in_ready,
  output logic [42:0] north_out_data, output logic north_out_valid, input  logic north_out_ready,
  input  logic [42:0] south_in_data,  input  logic south_in_valid,  output logic south_in_ready,
  output logic [42:0] south_out_data, output logic south_out_valid, input  logic south_out_ready,
  input  logic [42:0] east_in_data,   input  logic east_in_valid,   output logic east_in_ready,
  output logic [42:0] east_out_data,  output logic east_out_valid,  input  logic east_out_ready,
  input  logic [42:0] west_in_data,   input  logic west_in_valid,   output logic west_in_ready,
  output logic [42:0] west_out_data,  output logic west_out_valid,  input  logic west_out_ready
);

  localparam int FW = 43;  // packed flit width

  // Flit packing: [42:41]=flit_type [40:39]=dst_row [38:37]=dst_col
  //              [36:35]=src_row [34:33]=src_col [32:1]=data [0]=valid
  function automatic logic [1:0] get_dst_row(input logic [FW-1:0] f); get_dst_row=f[40:39]; endfunction
  function automatic logic [1:0] get_dst_col(input logic [FW-1:0] f); get_dst_col=f[38:37]; endfunction
  function automatic logic [NOC_WIDTH-1:0] get_data(input logic [FW-1:0] f); get_data=f[32:1]; endfunction

  // Route: returns output port 0=LOCAL 1=N 2=S 3=E 4=W
  function automatic logic [2:0] route(input logic [FW-1:0] f);
    logic [1:0] dr, dc;
    dr = get_dst_row(f); dc = get_dst_col(f);
    if      (MY_COL[1:0] < dc)                route = 3'd3; // EAST
    else if (MY_COL[1:0] > dc)                route = 3'd4; // WEST
    else if (MY_ROW[1:0] < dr)                route = 3'd2; // SOUTH
    else if (MY_ROW[1:0] > dr)                route = 3'd1; // NORTH
    else                                       route = 3'd0; // LOCAL
  endfunction

  // Input buffers: one per input port (0=LOCAL 1=N 2=S 3=E 4=W)
  logic [FW-1:0] ibuf[0:4];
  logic          ivld[0:4];

  // Output buffers: one per output port
  logic [FW-1:0] obuf[0:4];
  logic          ovld[0:4];

  // Route decisions for each input buffer
  logic [2:0] rt[0:4];
  assign rt[0] = route(ibuf[0]);
  assign rt[1] = route(ibuf[1]);
  assign rt[2] = route(ibuf[2]);
  assign rt[3] = route(ibuf[3]);
  assign rt[4] = route(ibuf[4]);

  // Input buffer loading
  logic out_accept[0:4]; // output port accepted (out_ready fires)
  assign out_accept[0] = ovld[0] && local_out_ready;
  assign out_accept[1] = ovld[1] && north_out_ready;
  assign out_accept[2] = ovld[2] && south_out_ready;
  assign out_accept[3] = ovld[3] && east_out_ready;
  assign out_accept[4] = ovld[4] && west_out_ready;

  // Input ready: buffer empty
  assign local_in_ready  = !ivld[0];
  assign north_in_ready  = !ivld[1];
  assign south_in_ready  = !ivld[2];
  assign east_in_ready   = !ivld[3];
  assign west_in_ready   = !ivld[4];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ibuf[0]<='0; ivld[0]<=0;
      ibuf[1]<='0; ivld[1]<=0;
      ibuf[2]<='0; ivld[2]<=0;
      ibuf[3]<='0; ivld[3]<=0;
      ibuf[4]<='0; ivld[4]<=0;
    end else begin
      // Load or drain each input buffer
      // LOCAL
      if (!ivld[0] && local_in_valid)
        begin ibuf[0]<=local_in_data; ivld[0]<=1; end
      else if (ivld[0] && out_accept[rt[0]])
        ivld[0] <= 0;

      // Unpack: local_in_data is NOC_WIDTH bits (data payload only),
      // but we need the full flit. Use a packed flit.
      // Actually local_in_data IS the full flit word here.
      // NORTH
      if (!ivld[1] && north_in_valid)
        begin ibuf[1]<=north_in_data[FW-1:0]; ivld[1]<=1; end
      else if (ivld[1] && out_accept[rt[1]])
        ivld[1] <= 0;
      // SOUTH
      if (!ivld[2] && south_in_valid)
        begin ibuf[2]<=south_in_data[FW-1:0]; ivld[2]<=1; end
      else if (ivld[2] && out_accept[rt[2]])
        ivld[2] <= 0;
      // EAST
      if (!ivld[3] && east_in_valid)
        begin ibuf[3]<=east_in_data[FW-1:0]; ivld[3]<=1; end
      else if (ivld[3] && out_accept[rt[3]])
        ivld[3] <= 0;
      // WEST
      if (!ivld[4] && west_in_valid)
        begin ibuf[4]<=west_in_data[FW-1:0]; ivld[4]<=1; end
      else if (ivld[4] && out_accept[rt[4]])
        ivld[4] <= 0;
    end
  end

  // Output arbitration: one always_ff per output port
  // Priority: LOCAL > NORTH > SOUTH > EAST > WEST (index 0..4 highest first)
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      obuf[0]<='0; ovld[0]<=0;
    end else begin
      if (!ovld[0] || out_accept[0]) begin
        ovld[0] <= 0;
        if      (ivld[0] && rt[0]==0) begin obuf[0]<=ibuf[0]; ovld[0]<=1; end
        else if (ivld[1] && rt[1]==0) begin obuf[0]<=ibuf[1]; ovld[0]<=1; end
        else if (ivld[2] && rt[2]==0) begin obuf[0]<=ibuf[2]; ovld[0]<=1; end
        else if (ivld[3] && rt[3]==0) begin obuf[0]<=ibuf[3]; ovld[0]<=1; end
        else if (ivld[4] && rt[4]==0) begin obuf[0]<=ibuf[4]; ovld[0]<=1; end
      end
    end
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin obuf[1]<='0; ovld[1]<=0; end
    else begin
      if (!ovld[1] || out_accept[1]) begin
        ovld[1] <= 0;
        if      (ivld[0]&&rt[0]==1) begin obuf[1]<=ibuf[0]; ovld[1]<=1; end
        else if (ivld[1]&&rt[1]==1) begin obuf[1]<=ibuf[1]; ovld[1]<=1; end
        else if (ivld[2]&&rt[2]==1) begin obuf[1]<=ibuf[2]; ovld[1]<=1; end
        else if (ivld[3]&&rt[3]==1) begin obuf[1]<=ibuf[3]; ovld[1]<=1; end
        else if (ivld[4]&&rt[4]==1) begin obuf[1]<=ibuf[4]; ovld[1]<=1; end
      end
    end
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin obuf[2]<='0; ovld[2]<=0; end
    else begin
      if (!ovld[2] || out_accept[2]) begin
        ovld[2] <= 0;
        if      (ivld[0]&&rt[0]==2) begin obuf[2]<=ibuf[0]; ovld[2]<=1; end
        else if (ivld[1]&&rt[1]==2) begin obuf[2]<=ibuf[1]; ovld[2]<=1; end
        else if (ivld[2]&&rt[2]==2) begin obuf[2]<=ibuf[2]; ovld[2]<=1; end
        else if (ivld[3]&&rt[3]==2) begin obuf[2]<=ibuf[3]; ovld[2]<=1; end
        else if (ivld[4]&&rt[4]==2) begin obuf[2]<=ibuf[4]; ovld[2]<=1; end
      end
    end
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin obuf[3]<='0; ovld[3]<=0; end
    else begin
      if (!ovld[3] || out_accept[3]) begin
        ovld[3] <= 0;
        if      (ivld[0]&&rt[0]==3) begin obuf[3]<=ibuf[0]; ovld[3]<=1; end
        else if (ivld[1]&&rt[1]==3) begin obuf[3]<=ibuf[1]; ovld[3]<=1; end
        else if (ivld[2]&&rt[2]==3) begin obuf[3]<=ibuf[2]; ovld[3]<=1; end
        else if (ivld[3]&&rt[3]==3) begin obuf[3]<=ibuf[3]; ovld[3]<=1; end
        else if (ivld[4]&&rt[4]==3) begin obuf[3]<=ibuf[4]; ovld[3]<=1; end
      end
    end
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin obuf[4]<='0; ovld[4]<=0; end
    else begin
      if (!ovld[4] || out_accept[4]) begin
        ovld[4] <= 0;
        if      (ivld[0]&&rt[0]==4) begin obuf[4]<=ibuf[0]; ovld[4]<=1; end
        else if (ivld[1]&&rt[1]==4) begin obuf[4]<=ibuf[1]; ovld[4]<=1; end
        else if (ivld[2]&&rt[2]==4) begin obuf[4]<=ibuf[2]; ovld[4]<=1; end
        else if (ivld[3]&&rt[3]==4) begin obuf[4]<=ibuf[3]; ovld[4]<=1; end
        else if (ivld[4]&&rt[4]==4) begin obuf[4]<=ibuf[4]; ovld[4]<=1; end
      end
    end
  end

  // Output wires
  assign local_out_data  = get_data(obuf[0]);
  assign local_out_valid = ovld[0];
  assign north_out_data  = obuf[1][42:0]; assign north_out_valid = ovld[1];
  assign south_out_data  = obuf[2][42:0]; assign south_out_valid = ovld[2];
  assign east_out_data   = obuf[3][42:0]; assign east_out_valid  = ovld[3];
  assign west_out_data   = obuf[4][42:0]; assign west_out_valid  = ovld[4];

endmodule
