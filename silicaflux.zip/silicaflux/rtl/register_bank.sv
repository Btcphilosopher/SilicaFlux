// =============================================================================
// SilicaFlux — Register Bank
// register_bank.sv
//
// Implements the SilicaFlux unified register file:
//   - 32 x 32-bit scalar registers (r0 hardwired to zero)
//   - 16 x 128-bit vector registers (v0..v15)
//
// Port Configuration:
//   Scalar: 2 read ports, 1 write port
//   Vector: 2 read ports, 1 write port
//
// Write-before-read (same-cycle forwarding) is handled here so the
// decoder always sees current data.
// =============================================================================

`include "silicaflux_pkg.sv"

module register_bank
  import silicaflux_pkg::*;
(
  input  logic            clk,
  input  logic            rst_n,

  // --- Scalar Read Ports (combinational) ---
  input  logic [4:0]      s_rd_addr1,
  input  logic [4:0]      s_rd_addr2,
  output logic [XLEN-1:0] s_rd_data1,
  output logic [XLEN-1:0] s_rd_data2,

  // --- Scalar Write Port ---
  input  logic            s_wr_en,
  input  logic [4:0]      s_wr_addr,
  input  logic [XLEN-1:0] s_wr_data,

  // --- Vector Read Ports (combinational) ---
  input  logic [3:0]      v_rd_addr1,
  input  logic [3:0]      v_rd_addr2,
  output logic [VLEN-1:0] v_rd_data1,
  output logic [VLEN-1:0] v_rd_data2,

  // --- Vector Write Port ---
  input  logic            v_wr_en,
  input  logic [3:0]      v_wr_addr,
  input  logic [VLEN-1:0] v_wr_data
);

  // ---------------------------------------------------------------------------
  // Register Storage
  // ---------------------------------------------------------------------------
  logic [XLEN-1:0] sregs [0:NUM_SREGS-1];
  logic [VLEN-1:0] vregs [0:NUM_VREGS-1];

  // ---------------------------------------------------------------------------
  // Scalar Register Writes
  // r0 is hardwired zero — writes to r0 are silently discarded
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NUM_SREGS; i++)
        sregs[i] <= '0;
    end else begin
      if (s_wr_en && s_wr_addr != '0)
        sregs[s_wr_addr] <= s_wr_data;
    end
  end

  // ---------------------------------------------------------------------------
  // Scalar Register Reads with Write-Before-Read Forwarding
  // ---------------------------------------------------------------------------
  always_comb begin
    // Port 1
    if (s_rd_addr1 == '0)
      s_rd_data1 = '0;
    else if (s_wr_en && s_wr_addr == s_rd_addr1)
      s_rd_data1 = s_wr_data;  // Forward from write port
    else
      s_rd_data1 = sregs[s_rd_addr1];

    // Port 2
    if (s_rd_addr2 == '0)
      s_rd_data2 = '0;
    else if (s_wr_en && s_wr_addr == s_rd_addr2)
      s_rd_data2 = s_wr_data;
    else
      s_rd_data2 = sregs[s_rd_addr2];
  end

  // ---------------------------------------------------------------------------
  // Vector Register Writes
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NUM_VREGS; i++)
        vregs[i] <= '0;
    end else begin
      if (v_wr_en)
        vregs[v_wr_addr] <= v_wr_data;
    end
  end

  // ---------------------------------------------------------------------------
  // Vector Register Reads with Write-Before-Read Forwarding
  // ---------------------------------------------------------------------------
  always_comb begin
    // Port 1
    if (v_wr_en && v_wr_addr == v_rd_addr1)
      v_rd_data1 = v_wr_data;
    else
      v_rd_data1 = vregs[v_rd_addr1];

    // Port 2
    if (v_wr_en && v_wr_addr == v_rd_addr2)
      v_rd_data2 = v_wr_data;
    else
      v_rd_data2 = vregs[v_rd_addr2];
  end

endmodule
