// =============================================================================
// SilicaFlux — Fetch Unit
// fetch_unit.sv
//
// Stage 1 of the SilicaFlux pipeline.
// Manages the Program Counter, reads from instruction SRAM, and handles
// branch redirects from the Execute stage.
//
// Features:
//  - Synchronous instruction SRAM (initializable for simulation)
//  - Single-cycle fetch with 1-cycle SRAM read latency
//  - Branch/jump redirect with 1-cycle flush
//  - Stall support (pipeline back-pressure)
// =============================================================================

`include "silicaflux_pkg.sv"

module fetch_unit
  import silicaflux_pkg::*;
(
  input  logic                  clk,
  input  logic                  rst_n,

  // --- Pipeline Control ---
  input  logic                  stall,          // Hold PC and output
  input  logic                  flush,          // Invalidate current fetch

  // --- Branch Redirect (from Execute stage) ---
  input  logic                  branch_taken,
  input  logic [PC_WIDTH-1:0]   branch_target,

  // --- Instruction Memory Write Port (for loading programs) ---
  input  logic                  imem_wr_en,
  input  logic [PC_WIDTH-1:0]   imem_wr_addr,
  input  logic [XLEN-1:0]       imem_wr_data,

  // --- IF/ID Pipeline Register Output ---
  output if_id_reg_t            if_id
);

  // ---------------------------------------------------------------------------
  // Instruction Memory — Synchronous SRAM, IMEM_DEPTH x 32-bit words
  // Synthesizes to Block RAM on FPGA targets.
  // ---------------------------------------------------------------------------
  logic [XLEN-1:0] imem [0:IMEM_DEPTH-1];

  // Program counter
  logic [PC_WIDTH-1:0] pc_reg;
  logic [PC_WIDTH-1:0] pc_next;

  // Registered instruction output (1-cycle SRAM latency)
  logic [XLEN-1:0]     instr_reg;
  logic [PC_WIDTH-1:0] pc_reg_d1;   // PC delayed to match SRAM output
  logic                valid_reg;

  // ---------------------------------------------------------------------------
  // PC Next Logic
  // ---------------------------------------------------------------------------
  always_comb begin
    if (branch_taken)
      pc_next = branch_target;
    else if (stall)
      pc_next = pc_reg;
    else
      pc_next = pc_reg + 1'b1;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)
      pc_reg <= '0;
    else
      pc_reg <= pc_next;
  end

  // ---------------------------------------------------------------------------
  // Instruction Memory Write (load program at reset or via debug port)
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk) begin
    if (imem_wr_en)
      imem[imem_wr_addr] <= imem_wr_data;
  end

  // ---------------------------------------------------------------------------
  // Synchronous SRAM Read
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      instr_reg  <= '0;
      pc_reg_d1  <= '0;
      valid_reg  <= 1'b0;
    end else if (!stall) begin
      instr_reg  <= imem[pc_reg];
      pc_reg_d1  <= pc_reg;
      valid_reg  <= 1'b1;
    end
  end

  // ---------------------------------------------------------------------------
  // IF/ID Register Drive
  // Flush overrides with NOP (all-zeros = OP_NOP)
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      if_id <= '0;
    end else if (flush || branch_taken) begin
      if_id.instruction <= '0;       // NOP bubble
      if_id.pc          <= pc_reg_d1;
      if_id.valid       <= 1'b0;
    end else if (!stall) begin
      if_id.instruction <= instr_reg;
      if_id.pc          <= pc_reg_d1;
      if_id.valid       <= valid_reg;
    end
    // On stall: hold current if_id unchanged
  end

endmodule
