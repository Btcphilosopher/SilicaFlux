// =============================================================================
// SilicaFlux — Forwarding Unit
// forwarding_unit.sv
//
// Combinational hazard detection and operand forwarding for the scalar
// pipeline. Implemented as a standalone module for clarity and formal proofs.
//
// Forwarding Paths:
//   EX  → IS: 1-cycle bypass  (result available end of EX stage)
//   MEM → IS: 2-cycle bypass  (result available end of MEM stage)
//   WB  → IS: register file write-before-read handles this case
//
// Load-Use Hazard:
//   A LOAD in EX cannot forward to IS/ID — result not yet available.
//   A 1-cycle bubble (stall) is required.
//   This module raises load_use_stall when this condition is detected.
//
// Outputs:
//   fwd_sel_a [1:0] — 00=regfile, 01=EX bypass, 10=MEM bypass
//   fwd_sel_b [1:0] — same encoding
//   load_use_stall  — 1 = insert stall bubble
// =============================================================================

`include "silicaflux_pkg.sv"

module forwarding_unit
  import silicaflux_pkg::*;
(
  // IS stage instruction (the one needing operands)
  input  logic [4:0]  is_rs1,
  input  logic [4:0]  is_rs2,

  // EX stage instruction (1 cycle ahead)
  input  logic [4:0]  ex_rd,
  input  logic        ex_reg_write,   // EX writes to rd
  input  logic        ex_is_load,     // EX is a LOAD (result not yet ready)
  input  logic        ex_valid,

  // MEM stage instruction (2 cycles ahead)
  input  logic [4:0]  mem_rd,
  input  logic        mem_reg_write,
  input  logic        mem_valid,

  // Forwarding select outputs
  output logic [1:0]  fwd_sel_a,     // Operand A select
  output logic [1:0]  fwd_sel_b,     // Operand B select
  output logic        load_use_stall // Stall pipeline 1 cycle
);

  // ---------------------------------------------------------------------------
  // Forwarding Select Encoding
  // ---------------------------------------------------------------------------
  localparam logic [1:0] FWD_REGFILE = 2'b00;
  localparam logic [1:0] FWD_EX      = 2'b01;
  localparam logic [1:0] FWD_MEM     = 2'b10;

  // ---------------------------------------------------------------------------
  // Forwarding Logic — EX path has priority over MEM path
  // r0 is always zero; never forward to it
  // ---------------------------------------------------------------------------
  always_comb begin
    fwd_sel_a = FWD_REGFILE;
    fwd_sel_b = FWD_REGFILE;

    // ---- Operand A ----
    if (ex_valid && ex_reg_write && ex_rd != '0 && ex_rd == is_rs1)
      fwd_sel_a = FWD_EX;
    else if (mem_valid && mem_reg_write && mem_rd != '0 && mem_rd == is_rs1)
      fwd_sel_a = FWD_MEM;

    // ---- Operand B ----
    if (ex_valid && ex_reg_write && ex_rd != '0 && ex_rd == is_rs2)
      fwd_sel_b = FWD_EX;
    else if (mem_valid && mem_reg_write && mem_rd != '0 && mem_rd == is_rs2)
      fwd_sel_b = FWD_MEM;
  end

  // ---------------------------------------------------------------------------
  // Load-Use Hazard Detection
  // EX is a LOAD and IS needs the destination register as a source
  // ---------------------------------------------------------------------------
  always_comb begin
    load_use_stall = 1'b0;
    if (ex_valid && ex_is_load && ex_rd != '0) begin
      if (ex_rd == is_rs1 || ex_rd == is_rs2)
        load_use_stall = 1'b1;
    end
  end

endmodule
