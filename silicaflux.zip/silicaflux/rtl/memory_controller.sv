// =============================================================================
// SilicaFlux — Memory Controller
// memory_controller.sv
//
// Manages a per-tile synchronous scratchpad SRAM (SRAM_DEPTH x 32-bit words).
// Supports:
//   - Scalar LOAD / STORE (single word, 1-cycle latency after request)
//   - VLOAD / VSTORE     (4-word aligned burst, 4 cycles)
//   - DFLOAD / DFSTORE   (parameterized burst, up to 31 words)
//
// Address space: word-addressed. Byte alignment is enforced (addr[1:0] = 00).
// An alignment_error pulse is raised on misaligned access.
//
// Interface is request/acknowledge handshake:
//   req_valid  → assert to begin transaction
//   req_ready  → high when controller is idle (able to accept)
//   resp_valid → high when read data is valid
// =============================================================================

`include "silicaflux_pkg.sv"

module memory_controller
  import silicaflux_pkg::*;
(
  input  logic                        clk,
  input  logic                        rst_n,

  // --- Request Interface ---
  input  logic                        req_valid,
  output logic                        req_ready,    // Controller is free
  input  logic [4:0]                  req_opcode,   // OP_LOAD/STORE/VLOAD/VSTORE/DFLOAD/DFSTORE
  input  logic [XLEN-1:0]             req_addr,     // Byte address
  input  logic [XLEN-1:0]             req_wdata,    // Scalar write data
  input  logic [VLEN-1:0]             req_vwdata,   // Vector write data (128-bit)
  input  logic [4:0]                  req_length,   // Burst word count (DFLOAD/DFSTORE)

  // --- Response Interface ---
  output logic                        resp_valid,
  output logic [XLEN-1:0]             resp_rdata,   // Scalar read result
  output logic [VLEN-1:0]             resp_vrdata,  // Vector read result
  output logic                        alignment_err,

  // --- SRAM Write-Back Port (from compute tile results) ---
  input  logic                        wb_valid,
  input  logic [XLEN-1:0]             wb_addr,
  input  logic [XLEN-1:0]             wb_data
);

  // ---------------------------------------------------------------------------
  // Scratchpad SRAM
  // ---------------------------------------------------------------------------
  logic [XLEN-1:0] sram [0:SRAM_DEPTH-1];

  // Word address from byte address (>>2, ignore low 2 bits)
  logic [$clog2(SRAM_DEPTH)-1:0] word_addr;
  assign word_addr = req_addr[($clog2(SRAM_DEPTH)+1):2];

  // ---------------------------------------------------------------------------
  // Controller FSM
  // ---------------------------------------------------------------------------
  typedef enum logic [2:0] {
    IDLE      = 3'b000,
    SCALAR_RD = 3'b001,
    SCALAR_WR = 3'b010,
    BURST_RD  = 3'b011,
    BURST_WR  = 3'b100,
    RESP      = 3'b101
  } mem_state_t;

  mem_state_t state;

  logic [4:0]                  burst_count;   // Remaining burst words
  logic [4:0]                  burst_idx;     // Current word index in burst
  logic [$clog2(SRAM_DEPTH)-1:0] burst_addr;
  logic [VLEN-1:0]             burst_rd_buf;  // Assemble read burst here
  logic [4:0]                  burst_len_reg;

  // Alignment check: byte address[1:0] must be 00
  logic align_ok;
  assign align_ok = (req_addr[1:0] == 2'b00);

  // ---------------------------------------------------------------------------
  // Write-Back Port (independent of request FSM)
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk) begin
    if (wb_valid)
      sram[wb_addr[($clog2(SRAM_DEPTH)+1):2]] <= wb_data;
  end

  // ---------------------------------------------------------------------------
  // Main FSM
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state         <= IDLE;
      req_ready     <= 1'b1;
      resp_valid    <= 1'b0;
      resp_rdata    <= '0;
      resp_vrdata   <= '0;
      alignment_err <= 1'b0;
      burst_count   <= '0;
      burst_idx     <= '0;
      burst_addr    <= '0;
      burst_rd_buf  <= '0;
    end else begin
      resp_valid    <= 1'b0;
      alignment_err <= 1'b0;

      case (state)
        // ----------------------------------------------------------------
        IDLE: begin
          req_ready <= 1'b1;
          if (req_valid) begin
            req_ready <= 1'b0;

            if (!align_ok) begin
              alignment_err <= 1'b1;
              resp_valid    <= 1'b1;
              req_ready     <= 1'b1; // Reject, stay idle
            end else begin
              case (req_opcode)
                // Scalar read
                OP_LOAD: begin
                  state <= SCALAR_RD;
                end

                // Scalar write
                OP_STORE: begin
                  sram[word_addr] <= req_wdata;
                  resp_valid      <= 1'b1;
                  req_ready       <= 1'b1; // Done immediately
                end

                // Vector read (4 words = 128-bit)
                OP_VLOAD: begin
                  burst_addr  <= word_addr;
                  burst_count <= 4;
                  burst_idx   <= '0;
                  burst_rd_buf <= '0;
                  state       <= BURST_RD;
                end

                // Vector write (4 words)
                OP_VSTORE: begin
                  burst_addr  <= word_addr;
                  burst_count <= 4;
                  burst_idx   <= '0;
                  state       <= BURST_WR;
                end

                // DF burst read
                OP_DFLOAD: begin
                  burst_addr   <= word_addr;
                  burst_len_reg <= req_length;
                  burst_count  <= req_length;
                  burst_idx    <= '0;
                  burst_rd_buf <= '0;
                  state        <= BURST_RD;
                end

                // DF burst write
                OP_DFSTORE: begin
                  burst_addr   <= word_addr;
                  burst_len_reg <= req_length;
                  burst_count  <= req_length;
                  burst_idx    <= '0;
                  state        <= BURST_WR;
                end

                default: begin
                  req_ready <= 1'b1;
                end
              endcase
            end
          end
        end

        // ----------------------------------------------------------------
        SCALAR_RD: begin
          resp_rdata <= sram[word_addr];
          resp_valid <= 1'b1;
          state      <= IDLE;
          req_ready  <= 1'b1;
        end

        // ----------------------------------------------------------------
        BURST_RD: begin
          // Accumulate one SRAM word per cycle into burst_rd_buf
          if (burst_count > 0) begin
            // Explicit index case (iverilog variable part-select workaround)
            case (burst_idx[1:0])
              2'd0: burst_rd_buf[  0 +: XLEN] <= sram[burst_addr];
              2'd1: burst_rd_buf[ 32 +: XLEN] <= sram[burst_addr + 1];
              2'd2: burst_rd_buf[ 64 +: XLEN] <= sram[burst_addr + 2];
              2'd3: burst_rd_buf[ 96 +: XLEN] <= sram[burst_addr + 3];
            endcase
            burst_idx   <= burst_idx + 1;
            burst_count <= burst_count - 1;
          end else begin
            // All words accumulated — deliver to output port
            resp_vrdata <= burst_rd_buf;
            resp_valid  <= 1'b1;
            state       <= IDLE;
            req_ready   <= 1'b1;
          end
        end

        // ----------------------------------------------------------------
        BURST_WR: begin
          if (burst_count > 0) begin
            // Explicit case (iverilog variable part-select workaround)
            case (burst_idx[1:0])
              2'd0: sram[burst_addr]     <= req_vwdata[  0 +: XLEN];
              2'd1: sram[burst_addr + 1] <= req_vwdata[ 32 +: XLEN];
              2'd2: sram[burst_addr + 2] <= req_vwdata[ 64 +: XLEN];
              2'd3: sram[burst_addr + 3] <= req_vwdata[ 96 +: XLEN];
            endcase
            burst_idx   <= burst_idx + 1;
            burst_count <= burst_count - 1;
          end else begin
            resp_valid <= 1'b1;
            state      <= IDLE;
            req_ready  <= 1'b1;
          end
        end

        default: state <= IDLE;
      endcase
    end
  end

endmodule
