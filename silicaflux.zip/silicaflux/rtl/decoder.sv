// =============================================================================
// SilicaFlux — Instruction Decoder
// decoder.sv
//
// Stage 2 of the SilicaFlux pipeline.
// Decodes a 32-bit instruction into control signals and register addresses.
// Issues reads to the register bank and advances the ID/IS pipeline register.
//
// Instruction Encoding Summary:
//
//   R-Format: [31:27]=opcode [26:22]=rd  [21:17]=rs1 [16:12]=rs2 [11:0]=func
//   I-Format: [31:27]=opcode [26:22]=rd  [21:17]=rs1 [16:0]=imm17
//   D-Format: [31:27]=opcode [26:24]=tid [23:19]=reg [18:14]=len [13:0]=addr
//   V-Format: [31:27]=opcode [26:22]=vrd [21:17]=vrs1[16:12]=vrs2[11:8]=lanes[7:0]=func
//
// =============================================================================

`include "silicaflux_pkg.sv"

module decoder
  import silicaflux_pkg::*;
(
  input  logic        clk,
  input  logic        rst_n,

  // --- Pipeline Control ---
  input  logic        stall,
  input  logic        flush,

  // --- IF/ID Input ---
  input  if_id_reg_t  if_id,

  // --- Register Bank Read Interface (combinational) ---
  output logic [4:0]  sreg_rd_addr1,  // Scalar reg read port A
  output logic [4:0]  sreg_rd_addr2,  // Scalar reg read port B
  output logic [3:0]  vreg_rd_addr1,  // Vector reg read port A
  output logic [3:0]  vreg_rd_addr2,  // Vector reg read port B
  input  logic [XLEN-1:0]  sreg_rd_data1,
  input  logic [XLEN-1:0]  sreg_rd_data2,
  input  logic [VLEN-1:0]  vreg_rd_data1,
  input  logic [VLEN-1:0]  vreg_rd_data2,

  // --- ID/IS Pipeline Register Output ---
  output id_is_reg_t  id_is
);

  // ---------------------------------------------------------------------------
  // Combinational Decode
  // ---------------------------------------------------------------------------
  decoded_instr_t dec;
  logic [XLEN-1:0] imm_ext_comb;

  always_comb begin
    // Defaults
    dec = '0;

    dec.opcode  = if_id.instruction[31:27];
    dec.fmt     = get_format(if_id.instruction[31:27]);
    dec.valid   = if_id.valid;

    case (dec.fmt)
      FMT_R: begin
        dec.rd      = if_id.instruction[26:22];
        dec.rs1     = if_id.instruction[21:17];
        dec.rs2     = if_id.instruction[16:12];
        dec.func    = {3'b0, if_id.instruction[4:0]};
        imm_ext_comb = '0;
      end
      FMT_I: begin
        dec.rd      = if_id.instruction[26:22];
        dec.rs1     = if_id.instruction[21:17];
        dec.rs2     = '0;
        dec.imm     = if_id.instruction[16:0];
        imm_ext_comb = sign_ext17(if_id.instruction[16:0]);
      end
      FMT_D: begin
        dec.tile_id = if_id.instruction[26:24];
        dec.rs1     = if_id.instruction[23:19]; // Source register
        dec.imm     = {3'b0, if_id.instruction[13:0]}; // SRAM address
        dec.func    = {3'b0, if_id.instruction[18:14]}; // burst length in [7:3]
        imm_ext_comb = {18'b0, if_id.instruction[13:0]};
      end
      FMT_V: begin
        dec.vrd     = if_id.instruction[26:23];
        dec.vrs1    = if_id.instruction[22:19];
        dec.vrs2    = if_id.instruction[18:15];
        dec.func    = if_id.instruction[7:0];
        imm_ext_comb = '0;
      end
      default: begin
        imm_ext_comb = '0;
      end
    endcase
  end

  // ---------------------------------------------------------------------------
  // Register Bank Read Address Drive (combinational)
  // ---------------------------------------------------------------------------
  assign sreg_rd_addr1 = dec.rs1;
  assign sreg_rd_addr2 = dec.rs2;
  assign vreg_rd_addr1 = dec.vrs1;
  assign vreg_rd_addr2 = dec.vrs2;

  // ---------------------------------------------------------------------------
  // ID/IS Pipeline Register
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      id_is <= '0;
    end else if (flush) begin
      id_is <= '0;
    end else if (!stall) begin
      id_is.instr      <= dec;
      id_is.rs1_data   <= (dec.rs1 == '0) ? '0 : sreg_rd_data1;
      id_is.rs2_data   <= (dec.rs2 == '0) ? '0 : sreg_rd_data2;
      id_is.vrs1_data  <= vreg_rd_data1;
      id_is.vrs2_data  <= vreg_rd_data2;
      id_is.pc         <= if_id.pc;
      id_is.valid      <= if_id.valid && !flush;
    end
  end

endmodule
