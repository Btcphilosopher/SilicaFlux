// =============================================================================
// SilicaFlux — Scalar ALU
// alu.sv
//
// Dedicated 32-bit scalar arithmetic-logic unit.
// Extracted from control_core for reuse and formal verification targeting.
//
// Operations:
//   ADD  — addition with carry-out
//   SUB  — subtraction (a - b), borrow-out
//   MUL  — 32×32 → 32-bit lower half multiply
//   AND  — bitwise AND
//   OR   — bitwise OR
//   XOR  — bitwise exclusive-OR
//   SHL  — logical shift left by b[4:0]
//   SHR  — logical shift right by b[4:0]
//   SAR  — arithmetic shift right by b[4:0]
//   PASS — pass operand A unchanged (used for MOV/branch address)
//   SLT  — set if a < b (signed comparison)
//   SLTU — set if a < b (unsigned comparison)
//
// All operations are fully combinational (single-cycle).
// Condition flags (zero, negative, carry, overflow) are always computed.
// =============================================================================

`include "silicaflux_pkg.sv"

module alu
  import silicaflux_pkg::*;
(
  input  logic [XLEN-1:0]  a,         // Operand A
  input  logic [XLEN-1:0]  b,         // Operand B
  input  logic [3:0]        op,        // ALU operation select

  output logic [XLEN-1:0]  result,    // ALU result
  output logic              flag_zero, // result == 0
  output logic              flag_neg,  // result[31] (MSB)
  output logic              flag_carry,// Carry out of bit 31 (ADD/SUB)
  output logic              flag_ovf   // Signed overflow (ADD/SUB)
);

  // ---------------------------------------------------------------------------
  // ALU Operation Codes
  // ---------------------------------------------------------------------------
  localparam logic [3:0] ALU_ADD  = 4'h0;
  localparam logic [3:0] ALU_SUB  = 4'h1;
  localparam logic [3:0] ALU_MUL  = 4'h2;
  localparam logic [3:0] ALU_AND  = 4'h3;
  localparam logic [3:0] ALU_OR   = 4'h4;
  localparam logic [3:0] ALU_XOR  = 4'h5;
  localparam logic [3:0] ALU_SHL  = 4'h6;
  localparam logic [3:0] ALU_SHR  = 4'h7;
  localparam logic [3:0] ALU_SAR  = 4'h8;
  localparam logic [3:0] ALU_PASS = 4'h9;
  localparam logic [3:0] ALU_SLT  = 4'hA;
  localparam logic [3:0] ALU_SLTU = 4'hB;

  // ---------------------------------------------------------------------------
  // Extended arithmetic — 33-bit wide to capture carry
  // ---------------------------------------------------------------------------
  logic [XLEN:0] add_result_ext;   // 33-bit ADD result (bit 32 = carry)
  logic [XLEN:0] sub_result_ext;   // 33-bit SUB result (bit 32 = borrow)

  assign add_result_ext = {1'b0, a} + {1'b0, b};
  assign sub_result_ext = {1'b0, a} - {1'b0, b};

  // Signed overflow detection
  // ADD overflow: same-sign operands produce different-sign result
  logic ovf_add, ovf_sub;
  assign ovf_add = (~a[XLEN-1] & ~b[XLEN-1] &  add_result_ext[XLEN-1]) |
                   ( a[XLEN-1] &  b[XLEN-1] & ~add_result_ext[XLEN-1]);
  assign ovf_sub = (~a[XLEN-1] &  b[XLEN-1] &  sub_result_ext[XLEN-1]) |
                   ( a[XLEN-1] & ~b[XLEN-1] & ~sub_result_ext[XLEN-1]);

  // ---------------------------------------------------------------------------
  // Result Mux
  // ---------------------------------------------------------------------------
  logic [XLEN-1:0] mul_result;
  assign mul_result = a * b; // Synthesizes to DSP slices on FPGA

  // Pre-extract parameterised slices as plain wires (iverilog workaround)
  logic [XLEN-1:0] add_lo, sub_lo;
  logic            add_cy, sub_cy;
  assign add_lo = add_result_ext[XLEN-1:0];
  assign add_cy = add_result_ext[XLEN];
  assign sub_lo = sub_result_ext[XLEN-1:0];
  assign sub_cy = sub_result_ext[XLEN];

  always_comb begin
    result     = '0;
    flag_carry = 1'b0;
    flag_ovf   = 1'b0;

    case (op)
      ALU_ADD: begin
        result     = add_lo;
        flag_carry = add_cy;
        flag_ovf   = ovf_add;
      end
      ALU_SUB: begin
        result     = sub_lo;
        flag_carry = sub_cy; // Borrow
        flag_ovf   = ovf_sub;
      end
      ALU_MUL:  result = mul_result;
      ALU_AND:  result = a & b;
      ALU_OR:   result = a | b;
      ALU_XOR:  result = a ^ b;
      ALU_SHL:  result = a << (b & 32'h1F);
      ALU_SHR:  result = a >> (b & 32'h1F);
      ALU_SAR:  result = $signed(a) >>> (b & 32'h1F);
      ALU_PASS: result = a;
      ALU_SLT:  result = ($signed(a) < $signed(b)) ? 32'd1 : 32'd0;
      ALU_SLTU: result = (a < b) ? 32'd1 : 32'd0;
      default:  result = '0;
    endcase
  end

  // ---------------------------------------------------------------------------
  // Condition Flags
  // ---------------------------------------------------------------------------
  assign flag_zero = (result == '0);
  assign flag_neg  = result[XLEN-1];

endmodule
