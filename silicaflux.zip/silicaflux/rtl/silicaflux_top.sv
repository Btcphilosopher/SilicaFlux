// =============================================================================
// SilicaFlux — Top Level
// silicaflux_top.sv
//
// Integrates all SilicaFlux components into a single synthesizable cluster:
//
//   ┌─────────────────────────────────────────────────────────────┐
//   │  SilicaFlux Cluster                                         │
//   │                                                             │
//   │  ┌──────────┐   ┌──────────┐   ┌────────────┐             │
//   │  │  Fetch   │→  │ Decoder  │→  │  Control   │             │
//   │  │  Unit    │   │          │   │  Core      │             │
//   │  └──────────┘   └──────────┘   └─────┬──────┘             │
//   │                                       │DF/Vec ops           │
//   │  ┌────────────────────────────────────▼──────┐             │
//   │  │           Dataflow Scheduler               │             │
//   │  └────┬──────────┬──────────┬──────────┬─────┘             │
//   │       │          │          │          │                    │
//   │  ┌────▼──┐  ┌────▼──┐  ┌───▼───┐  ┌───▼───┐              │
//   │  │ Tile0 │  │ Tile1 │  │ Tile2 │  │ Tile3 │              │
//   │  └───┬───┘  └───┬───┘  └───┬───┘  └───┬───┘              │
//   │      └──────────┴─── NoC ──┴──────────┘                   │
//   │                                                             │
//   │  ┌──────────────────────────────────────────────────────┐  │
//   │  │  Register Bank (32 scalar, 16 vector)                │  │
//   │  └──────────────────────────────────────────────────────┘  │
//   └─────────────────────────────────────────────────────────────┘
//
// External Interfaces:
//   - imem_wr_*    : Program load port (loads instructions into fetch SRAM)
//   - tile_phy_*   : Chiplet boundary physical links (via tile_interface)
//   - halt          : Driven when a HALT instruction is encountered (opcode=0x1F)
// =============================================================================

`include "silicaflux_pkg.sv"

module silicaflux_top
  import silicaflux_pkg::*;
#(
  parameter int LANES = LANES_DEFAULT   // SIMD lane count per tile
)
(
  input  logic          clk,
  input  logic          rst_n,

  // --- Program Load Interface ---
  input  logic                  imem_wr_en,
  input  logic [PC_WIDTH-1:0]   imem_wr_addr,
  input  logic [XLEN-1:0]       imem_wr_data,

  // --- Chiplet Physical Link (Tile 0, North boundary example) ---
  output logic [7:0]            tile_phy_tx_data,
  output logic                  tile_phy_tx_valid,
  input  logic                  tile_phy_tx_credit,
  input  logic [7:0]            tile_phy_rx_data,
  input  logic                  tile_phy_rx_valid,
  output logic                  tile_phy_rx_credit,

  // --- Status Outputs ---
  output logic                  halt,
  output logic [XLEN-1:0]       debug_scalar_r1   // r1 value for test observation
);

  // ===========================================================================
  // Internal Signal Declarations
  // ===========================================================================

  // Pipeline registers
  if_id_reg_t  if_id;
  id_is_reg_t  id_is;

  // Pipeline control
  logic        stall;
  logic        flush;
  logic        pipeline_flush_int;  // from control_core
  logic        branch_taken;
  logic [PC_WIDTH-1:0] branch_target;
  logic        sync_stall;
  logic        id_stall;

  // Register bank signals
  logic [4:0]      sreg_rd_addr1, sreg_rd_addr2;
  logic [3:0]      vreg_rd_addr1, vreg_rd_addr2;
  logic [XLEN-1:0] sreg_rd_data1, sreg_rd_data2;
  logic [VLEN-1:0] vreg_rd_data1, vreg_rd_data2;
  logic            s_wr_en;
  logic [4:0]      s_wr_addr;
  logic [XLEN-1:0] s_wr_data;
  logic            v_wr_en;
  logic [3:0]      v_wr_addr;
  logic [VLEN-1:0] v_wr_data;

  // Scheduler signals
  decoded_instr_t  sched_instr;
  logic            sched_valid;
  logic            sched_ready;
  logic [XLEN-1:0] sched_scalar_a, sched_scalar_b;
  logic [VLEN-1:0] sched_vector_a, sched_vector_b;

  df_token_t      tile_token     [0:NUM_TILES-1];
  logic           tile_token_valid[0:NUM_TILES-1];
  logic           tile_token_ready[0:NUM_TILES-1];
  // Flat tile status signals (replaces tile_status_t array for iverilog compat)
  logic [NUM_TILES-1:0]       tile_done_flat;
  logic [NUM_TILES-1:0]       tile_error_flat;
  logic [NUM_TILES*XLEN-1:0]  tile_scalar_flat;
  logic [NUM_TILES*VLEN-1:0]  tile_vector_flat;

  // Scheduler writeback
  logic            sched_wb_valid;
  logic [4:0]      sched_wb_reg;
  logic [XLEN-1:0] sched_wb_data;

  // Memory controller (control core's scalar path)
  logic            mem_req_valid;
  logic            mem_req_ready;
  logic [4:0]      mem_req_opcode;
  logic [XLEN-1:0] mem_req_addr;
  logic [XLEN-1:0] mem_req_wdata;
  logic            mem_resp_valid;
  logic [XLEN-1:0] mem_resp_rdata;

  // NoC signals (2x2 mesh → 4 tiles)
  noc_flit_t  noc_inject_flit  [0:NOC_ROWS-1][0:NOC_COLS-1];
  logic       noc_inject_valid [0:NOC_ROWS-1][0:NOC_COLS-1];
  logic       noc_inject_ready [0:NOC_ROWS-1][0:NOC_COLS-1];
  noc_flit_t  noc_eject_flit   [0:NOC_ROWS-1][0:NOC_COLS-1];
  logic       noc_eject_valid  [0:NOC_ROWS-1][0:NOC_COLS-1];
  logic       noc_eject_ready  [0:NOC_ROWS-1][0:NOC_COLS-1];

  // Tile-to-NoC wiring
  noc_flit_t  tile_noc_out  [0:NUM_TILES-1];
  logic       tile_noc_ovalid[0:NUM_TILES-1];
  logic       tile_noc_oready[0:NUM_TILES-1];
  noc_flit_t  tile_noc_in   [0:NUM_TILES-1];
  logic       tile_noc_ivalid[0:NUM_TILES-1];
  logic       tile_noc_iready[0:NUM_TILES-1];

  // Tile interface (chiplet boundary) for tile 0
  noc_flit_t  tif_rx_flit;
  logic       tif_rx_valid;
  logic       tif_rx_ready;

  // ===========================================================================
  // Stall / Flush Combination
  // ===========================================================================
  assign stall = id_stall;
  assign flush = pipeline_flush_int;

  // ===========================================================================
  // Module Instantiations
  // ===========================================================================

  // ---------------------------------------------------------------------------
  // Fetch Unit
  // ---------------------------------------------------------------------------
  fetch_unit u_fetch (
    .clk            (clk),
    .rst_n          (rst_n),
    .stall          (stall),
    .flush          (flush),
    .branch_taken   (branch_taken),
    .branch_target  (branch_target),
    .imem_wr_en     (imem_wr_en),
    .imem_wr_addr   (imem_wr_addr),
    .imem_wr_data   (imem_wr_data),
    .if_id          (if_id)
  );

  // ---------------------------------------------------------------------------
  // Register Bank
  // ---------------------------------------------------------------------------
  // Writeback mux: scheduler writeback takes priority over control core
  logic            wb_s_wr_en;
  logic [4:0]      wb_s_wr_addr;
  logic [XLEN-1:0] wb_s_wr_data;

  always_comb begin
    if (sched_wb_valid) begin
      wb_s_wr_en   = 1'b1;
      wb_s_wr_addr = sched_wb_reg;
      wb_s_wr_data = sched_wb_data;
    end else begin
      wb_s_wr_en   = s_wr_en;
      wb_s_wr_addr = s_wr_addr;
      wb_s_wr_data = s_wr_data;
    end
  end

  register_bank u_regs (
    .clk          (clk),
    .rst_n        (rst_n),
    .s_rd_addr1   (sreg_rd_addr1),
    .s_rd_addr2   (sreg_rd_addr2),
    .s_rd_data1   (sreg_rd_data1),
    .s_rd_data2   (sreg_rd_data2),
    .s_wr_en      (wb_s_wr_en),
    .s_wr_addr    (wb_s_wr_addr),
    .s_wr_data    (wb_s_wr_data),
    .v_rd_addr1   (vreg_rd_addr1),
    .v_rd_addr2   (vreg_rd_addr2),
    .v_rd_data1   (vreg_rd_data1),
    .v_rd_data2   (vreg_rd_data2),
    .v_wr_en      (v_wr_en),
    .v_wr_addr    (v_wr_addr),
    .v_wr_data    (v_wr_data)
  );

  // ---------------------------------------------------------------------------
  // Decoder
  // ---------------------------------------------------------------------------
  decoder u_dec (
    .clk            (clk),
    .rst_n          (rst_n),
    .stall          (stall),
    .flush          (flush),
    .if_id          (if_id),
    .sreg_rd_addr1  (sreg_rd_addr1),
    .sreg_rd_addr2  (sreg_rd_addr2),
    .vreg_rd_addr1  (vreg_rd_addr1),
    .vreg_rd_addr2  (vreg_rd_addr2),
    .sreg_rd_data1  (sreg_rd_data1),
    .sreg_rd_data2  (sreg_rd_data2),
    .vreg_rd_data1  (vreg_rd_data1),
    .vreg_rd_data2  (vreg_rd_data2),
    .id_is          (id_is)
  );

  // ---------------------------------------------------------------------------
  // Control Core (Scalar + Branch + Writeback)
  // ---------------------------------------------------------------------------
  // Shared memory controller for scalar LOAD/STORE via control core
  memory_controller u_ctrl_mem (
    .clk           (clk),
    .rst_n         (rst_n),
    .req_valid     (mem_req_valid),
    .req_ready     (mem_req_ready),
    .req_opcode    (mem_req_opcode),
    .req_addr      (mem_req_addr),
    .req_wdata     (mem_req_wdata),
    .req_vwdata    ('0),
    .req_length    ('0),
    .resp_valid    (mem_resp_valid),
    .resp_rdata    (mem_resp_rdata),
    .resp_vrdata   (/* unused */),
    .alignment_err (/* unused */),
    .wb_valid      (1'b0),
    .wb_addr       ('0),
    .wb_data       ('0)
  );

  control_core u_ctrl (
    .clk              (clk),
    .rst_n            (rst_n),
    .id_is            (id_is),
    .id_stall         (id_stall),
    .pipeline_flush   (pipeline_flush_int),
    .branch_taken     (branch_taken),
    .branch_target    (branch_target),
    .sched_instr      (sched_instr),
    .sched_valid      (sched_valid),
    .sched_ready      (sched_ready),
    .sched_scalar_a   (sched_scalar_a),
    .sched_scalar_b   (sched_scalar_b),
    .sched_vector_a   (sched_vector_a),
    .sched_vector_b   (sched_vector_b),
    .s_wr_en          (s_wr_en),
    .s_wr_addr        (s_wr_addr),
    .s_wr_data        (s_wr_data),
    .v_wr_en          (v_wr_en),
    .v_wr_addr        (v_wr_addr),
    .v_wr_data        (v_wr_data),
    .mem_req_valid    (mem_req_valid),
    .mem_req_ready    (mem_req_ready),
    .mem_req_opcode   (mem_req_opcode),
    .mem_req_addr     (mem_req_addr),
    .mem_req_wdata    (mem_req_wdata),
    .mem_resp_valid   (mem_resp_valid),
    .mem_resp_rdata   (mem_resp_rdata),
    .sync_stall       (sync_stall)
  );



  // ---------------------------------------------------------------------------
  // Scheduler
  // ---------------------------------------------------------------------------
  // Scheduler broadcast outputs
  logic [XLEN-1:0] sched_scalar_out;
  logic [VLEN-1:0] sched_vector_a_out, sched_vector_b_out;

  // Scheduler flat token field wires
  logic [4:0]  tok_opcode;
  logic [2:0]  tok_tile_id;
  logic [4:0]  tok_src_reg, tok_dst_reg;
  logic [3:0]  tok_vsrc_reg, tok_vdst_reg;
  logic [13:0] tok_mem_addr;
  logic [4:0]  tok_length;
  logic [7:0]  tok_func;


  scheduler u_sched (
    .clk              (clk),
    .rst_n            (rst_n),
    .instr_in         (sched_instr),
    .instr_valid      (sched_valid),
    .instr_ready      (sched_ready),
    .scalar_a         (sched_scalar_a),
    .scalar_b         (sched_scalar_b),
    .vector_a         (sched_vector_a),
    .vector_b         (sched_vector_b),
    .tile_tok_valid_0 (tile_token_valid[0]),
    .tile_tok_valid_1 (tile_token_valid[1]),
    .tile_tok_valid_2 (tile_token_valid[2]),
    .tile_tok_valid_3 (tile_token_valid[3]),
    .tile_tok_ready_0 (tile_token_ready[0]),
    .tile_tok_ready_1 (tile_token_ready[1]),
    .tile_tok_ready_2 (tile_token_ready[2]),
    .tile_tok_ready_3 (tile_token_ready[3]),
    .sched_scalar_out   (sched_scalar_out),
    .sched_vector_a_out (sched_vector_a_out),
    .sched_vector_b_out (sched_vector_b_out),
    .tok_opcode       (tok_opcode),
    .tok_tile_id      (tok_tile_id),
    .tok_src_reg      (tok_src_reg),
    .tok_dst_reg      (tok_dst_reg),
    .tok_vsrc_reg     (tok_vsrc_reg),
    .tok_vdst_reg     (tok_vdst_reg),
    .tok_mem_addr     (tok_mem_addr),
    .tok_length       (tok_length),
    .tok_func         (tok_func),
    .tile_status_done   (tile_done_flat),
    .tile_status_scalar (tile_scalar_flat),
    .wb_valid         (sched_wb_valid),
    .wb_reg           (sched_wb_reg),
    .wb_data          (sched_wb_data),
    .sync_stall       (sync_stall)
  );

  // ---------------------------------------------------------------------------
  // Compute Tiles (4 tiles, 2x2 layout)
  // Tile IDs:  [0]=row0/col0, [1]=row0/col1, [2]=row1/col0, [3]=row1/col1
  // ---------------------------------------------------------------------------
  generate
    for (genvar t = 0; t < NUM_TILES; t++) begin : g_tiles
      compute_tile #(
        .TILE_ID (t),
        .LANES   (LANES)
      ) u_tile (
        .clk             (clk),
        .rst_n           (rst_n),
        .tok_opcode      (tok_opcode),
        .tok_tile_id     (tok_tile_id),
        .tok_src_reg     (tok_src_reg),
        .tok_dst_reg     (tok_dst_reg),
        .tok_vsrc_reg    (tok_vsrc_reg),
        .tok_vdst_reg    (tok_vdst_reg),
        .tok_mem_addr    (tok_mem_addr),
        .tok_length      (tok_length),
        .tok_func        (tok_func),
        .token_valid     (tile_token_valid[t]),
        .token_ready     (tile_token_ready[t]),
        .scalar_data_in  (sched_scalar_out),
        .vector_data_in  (sched_vector_a_out),
        .vector_data_in_b(sched_vector_b_out),
        .tile_done          (tile_done_flat[t]),
        .tile_error         (tile_error_flat[t]),
        .tile_result_scalar (tile_scalar_flat[t*XLEN +: XLEN]),
        .tile_result_vector (tile_vector_flat[t*VLEN +: VLEN]),
        .noc_flit_out    (tile_noc_out[t]),
        .noc_flit_valid  (tile_noc_ovalid[t]),
        .noc_flit_ready  (tile_noc_oready[t]),
        .noc_flit_in     (tile_noc_in[t]),
        .noc_flit_in_valid(tile_noc_ivalid[t]),
        .noc_flit_in_ready(tile_noc_iready[t])
      );
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // Tile ↔ NoC Wiring (flat tile index to 2D mesh coordinates)
  // Tile 0 → [0][0], Tile 1 → [0][1], Tile 2 → [1][0], Tile 3 → [1][1]
  // ---------------------------------------------------------------------------
  // Inject: tile → NoC
  assign noc_inject_flit [0][0] = tile_noc_out[0];  assign noc_inject_valid[0][0] = tile_noc_ovalid[0];
  assign noc_inject_flit [0][1] = tile_noc_out[1];  assign noc_inject_valid[0][1] = tile_noc_ovalid[1];
  assign noc_inject_flit [1][0] = tile_noc_out[2];  assign noc_inject_valid[1][0] = tile_noc_ovalid[2];
  assign noc_inject_flit [1][1] = tile_noc_out[3];  assign noc_inject_valid[1][1] = tile_noc_ovalid[3];

  assign tile_noc_oready[0] = noc_inject_ready[0][0];
  assign tile_noc_oready[1] = noc_inject_ready[0][1];
  assign tile_noc_oready[2] = noc_inject_ready[1][0];
  assign tile_noc_oready[3] = noc_inject_ready[1][1];

  // Eject: NoC → tile
  assign tile_noc_in[0] = noc_eject_flit[0][0];  assign tile_noc_ivalid[0] = noc_eject_valid[0][0];
  assign tile_noc_in[1] = noc_eject_flit[0][1];  assign tile_noc_ivalid[1] = noc_eject_valid[0][1];
  assign tile_noc_in[2] = noc_eject_flit[1][0];  assign tile_noc_ivalid[2] = noc_eject_valid[1][0];
  assign tile_noc_in[3] = noc_eject_flit[1][1];  assign tile_noc_ivalid[3] = noc_eject_valid[1][1];

  assign noc_eject_ready[0][0] = tile_noc_iready[0];
  assign noc_eject_ready[0][1] = tile_noc_iready[1];
  assign noc_eject_ready[1][0] = tile_noc_iready[2];
  assign noc_eject_ready[1][1] = tile_noc_iready[3];

  // ---------------------------------------------------------------------------
  // NoC Interconnect
  // ---------------------------------------------------------------------------
  noc_interconnect #(
    .ROWS (NOC_ROWS),
    .COLS (NOC_COLS)
  ) u_noc (
    .clk          (clk),
    .rst_n        (rst_n),
    .inject_flit  (noc_inject_flit),
    .inject_valid (noc_inject_valid),
    .inject_ready (noc_inject_ready),
    .eject_flit   (noc_eject_flit),
    .eject_valid  (noc_eject_valid),
    .eject_ready  (noc_eject_ready),
    .eject_data      (/* unused */),
    .inject_ready_flat(/* unused */),
    .eject_valid_flat  (/* unused */),
    .ej_data_flat_0    (/* unused */),
    .ej_data_flat_1    (/* unused */),
    .ej_data_flat_2    (/* unused */),
    .ej_data_flat_3    (/* unused */)
  );

  // ---------------------------------------------------------------------------
  // Tile Interface — Chiplet Boundary (Tile 0, outgoing link)
  // ---------------------------------------------------------------------------
  tile_interface #(.LINK_WIDTH(8)) u_tif (
    .clk              (clk),
    .rst_n            (rst_n),
    .tx_flit_in       (tile_noc_out[0]),
    .tx_flit_valid    (tile_noc_ovalid[0]),
    .tx_flit_ready    (/* merged with NoC inject_ready */),
    .rx_flit_out      (tif_rx_flit),
    .rx_flit_valid    (tif_rx_valid),
    .rx_flit_ready    (tif_rx_ready),
    .phy_tx_data      (tile_phy_tx_data),
    .phy_tx_valid     (tile_phy_tx_valid),
    .phy_tx_credit    (tile_phy_tx_credit),
    .phy_rx_data      (tile_phy_rx_data),
    .phy_rx_valid     (tile_phy_rx_valid),
    .phy_rx_credit    (tile_phy_rx_credit),
    .link_up          (/* unused in this example */),
    .parity_error     (/* unused */)
  );

  assign tif_rx_ready = noc_inject_ready[0][0];

  // ---------------------------------------------------------------------------
  // Halt Detection (opcode 0x1F reserved as HALT)
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)
      halt <= 1'b0;
    else if (if_id.valid && if_id.instruction[31:27] == 5'h1F)
      halt <= 1'b1;
  end

  // Debug observation port
  assign debug_scalar_r1 = sreg_rd_data1; // Wired to r1 read

endmodule
