// =============================================================================
// SilicaFlux Architecture — Package Definition
// silicaflux_pkg.sv
//
// Defines all shared types, parameters, opcodes, and pipeline structs
// used across the SilicaFlux RTL hierarchy.
//
// Architecture: Dataflow-Oriented Compute Fabric
// Word Width:   32-bit fixed instruction encoding
// Targets:      FPGA prototyping, ASIC/chiplet deployment
// =============================================================================

`ifndef SILICAFLUX_PKG_SV
`define SILICAFLUX_PKG_SV

package silicaflux_pkg;

  // ---------------------------------------------------------------------------
  // Global Architecture Parameters
  // ---------------------------------------------------------------------------
  parameter int XLEN          = 32;   // Scalar data width
  parameter int VLEN          = 128;  // Vector register width (4 x 32-bit lanes)
  parameter int NUM_SREGS     = 32;   // Scalar register file depth
  parameter int NUM_VREGS     = 16;   // Vector register file depth
  parameter int NUM_TILES     = 4;    // Compute tiles per cluster
  parameter int LANES_DEFAULT = 4;    // Default SIMD lane count
  parameter int SRAM_DEPTH    = 256;  // Scratchpad SRAM words per tile
  parameter int NOC_WIDTH     = 32;   // NoC flit data width
  parameter int NOC_ROWS      = 2;    // Mesh rows
  parameter int NOC_COLS      = 2;    // Mesh columns
  parameter int PC_WIDTH      = 16;   // Program counter width (64K words)
  parameter int IMEM_DEPTH    = 1024; // Instruction memory depth (words)

  // ---------------------------------------------------------------------------
  // ISA Opcode Definitions (5-bit field [31:27])
  // ---------------------------------------------------------------------------
  // Scalar Control Group (0x00–0x09)
  parameter logic [4:0] OP_NOP      = 5'h00; // No operation
  parameter logic [4:0] OP_ADD      = 5'h01; // rd = rs1 + rs2
  parameter logic [4:0] OP_SUB      = 5'h02; // rd = rs1 - rs2
  parameter logic [4:0] OP_MUL      = 5'h03; // rd = rs1 * rs2 [31:0]
  parameter logic [4:0] OP_LOAD     = 5'h04; // rd = MEM[rs1 + imm12]
  parameter logic [4:0] OP_STORE    = 5'h05; // MEM[rs1 + imm12] = rs2
  parameter logic [4:0] OP_MOV      = 5'h06; // rd = imm17 (sign-extended)
  parameter logic [4:0] OP_BEQ      = 5'h07; // if rs1==rs2: PC += imm12
  parameter logic [4:0] OP_BNE      = 5'h08; // if rs1!=rs2: PC += imm12
  parameter logic [4:0] OP_JMP      = 5'h09; // PC = rs1 + imm12

  // Dataflow Control Group (0x0A–0x0E)
  parameter logic [4:0] OP_DFLOAD   = 5'h0A; // Stream burst from SRAM to tile
  parameter logic [4:0] OP_DFSTORE  = 5'h0B; // Write burst from tile to SRAM
  parameter logic [4:0] OP_DFMAP    = 5'h0C; // Map scalar reg to tile lane
  parameter logic [4:0] OP_DFEXEC   = 5'h0D; // Trigger dataflow execution kernel
  parameter logic [4:0] OP_DFSYNC   = 5'h0E; // Barrier — wait all tiles complete

  // Vector/Tensor Group (0x0F–0x17)
  parameter logic [4:0] OP_VADD     = 5'h0F; // vrd = vrs1 + vrs2 (per lane)
  parameter logic [4:0] OP_VMUL     = 5'h10; // vrd = vrs1 * vrs2 (per lane)
  parameter logic [4:0] OP_VSUB     = 5'h11; // vrd = vrs1 - vrs2 (per lane)
  parameter logic [4:0] OP_DOT      = 5'h12; // rd  = dot(vrs1, vrs2)
  parameter logic [4:0] OP_MATMUL   = 5'h13; // vrd = mat_a * mat_b (4x4)
  parameter logic [4:0] OP_REDUCE   = 5'h14; // rd  = reduce_op(vrs1)
  parameter logic [4:0] OP_BCAST    = 5'h15; // vrd = broadcast(rs1)
  parameter logic [4:0] OP_VLOAD    = 5'h16; // vrd = MEM[rs1 + imm] (128-bit)
  parameter logic [4:0] OP_VSTORE   = 5'h17; // MEM[rs1 + imm] = vrs1 (128-bit)

  // ---------------------------------------------------------------------------
  // Instruction Format Types
  // ---------------------------------------------------------------------------
  // R-Format: [31:27]=opcode [26:22]=rd [21:17]=rs1 [16:12]=rs2 [11:0]=func
  // I-Format: [31:27]=opcode [26:22]=rd [21:17]=rs1 [16:0]=imm17
  // D-Format: [31:27]=opcode [26:24]=tile_id [23:19]=reg [18:14]=len [13:0]=addr
  // V-Format: [31:27]=opcode [26:22]=vrd [21:17]=vrs1 [16:12]=vrs2 [11:8]=lanes [7:0]=func

  typedef enum logic [1:0] {
    FMT_R = 2'b00,
    FMT_I = 2'b01,
    FMT_D = 2'b10,
    FMT_V = 2'b11
  } instr_fmt_t;

  // Reduce operation select (func[1:0] of REDUCE instruction)
  typedef enum logic [1:0] {
    REDUCE_SUM = 2'b00,
    REDUCE_MIN = 2'b01,
    REDUCE_MAX = 2'b10,
    REDUCE_AND = 2'b11
  } reduce_op_t;

  // ---------------------------------------------------------------------------
  // Decoded Instruction Bundle
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic [4:0]  opcode;
    logic [4:0]  rd;       // Destination scalar reg
    logic [4:0]  rs1;      // Source scalar reg 1
    logic [4:0]  rs2;      // Source scalar reg 2
    logic [3:0]  vrd;      // Destination vector reg
    logic [3:0]  vrs1;     // Source vector reg 1
    logic [3:0]  vrs2;     // Source vector reg 2
    logic [16:0] imm;      // Immediate (sign-extended at use site)
    logic [2:0]  tile_id;  // Target tile for dataflow ops
    logic [7:0]  func;     // Sub-function code
    instr_fmt_t  fmt;      // Instruction format
    logic        valid;    // Slot contains valid instruction
  } decoded_instr_t;

  // ---------------------------------------------------------------------------
  // Pipeline Stage Registers
  // ---------------------------------------------------------------------------

  // IF → ID
  typedef struct packed {
    logic [XLEN-1:0]    instruction;
    logic [PC_WIDTH-1:0] pc;
    logic                valid;
  } if_id_reg_t;

  // ID → IS (Issue)
  typedef struct packed {
    decoded_instr_t      instr;
    logic [XLEN-1:0]     rs1_data;
    logic [XLEN-1:0]     rs2_data;
    logic [VLEN-1:0]     vrs1_data;
    logic [VLEN-1:0]     vrs2_data;
    logic [PC_WIDTH-1:0] pc;
    logic                valid;
  } id_is_reg_t;

  // IS → EX
  typedef struct packed {
    decoded_instr_t      instr;
    logic [XLEN-1:0]     op_a;
    logic [XLEN-1:0]     op_b;
    logic [VLEN-1:0]     vop_a;
    logic [VLEN-1:0]     vop_b;
    logic [XLEN-1:0]     imm_ext;
    logic [PC_WIDTH-1:0] pc;
    logic                valid;
  } is_ex_reg_t;

  // EX → MEM
  typedef struct packed {
    decoded_instr_t      instr;
    logic [XLEN-1:0]     alu_result;
    logic [VLEN-1:0]     valu_result;
    logic [XLEN-1:0]     store_data;
    logic [VLEN-1:0]     vstore_data;
    logic [XLEN-1:0]     mem_addr;
    logic [PC_WIDTH-1:0] branch_target;
    logic                branch_taken;
    logic                valid;
  } ex_mem_reg_t;

  // MEM → WB
  typedef struct packed {
    decoded_instr_t      instr;
    logic [XLEN-1:0]     result;
    logic [VLEN-1:0]     vresult;
    logic                mem_valid;
    logic                valid;
  } mem_wb_reg_t;

  // ---------------------------------------------------------------------------
  // Dataflow Token / Work Order (Control Core → Scheduler → Tiles)
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic [4:0]  opcode;
    logic [2:0]  tile_id;
    logic [4:0]  src_reg;
    logic [4:0]  dst_reg;
    logic [3:0]  vsrc_reg;
    logic [3:0]  vdst_reg;
    logic [13:0] mem_addr;  // 14-bit SRAM word address
    logic [4:0]  length;    // Burst length in words (max 31)
    logic [7:0]  func;
    logic        valid;
  } df_token_t;

  // ---------------------------------------------------------------------------
  // NoC Flit Definition
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    FLIT_HEAD = 2'b00,
    FLIT_BODY = 2'b01,
    FLIT_TAIL = 2'b10,
    FLIT_SINGLE = 2'b11
  } flit_type_t;

  typedef struct packed {
    flit_type_t  flit_type;
    logic [1:0]  dst_row;   // Destination tile row
    logic [1:0]  dst_col;   // Destination tile column
    logic [1:0]  src_row;
    logic [1:0]  src_col;
    logic [NOC_WIDTH-1:0] data;
    logic        valid;
  } noc_flit_t;

  // ---------------------------------------------------------------------------
  // Tile Completion / Status
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic [2:0]  tile_id;
    logic        done;
    logic        error;
    logic [XLEN-1:0] result_scalar;
    logic [VLEN-1:0] result_vector;
  } tile_status_t;

  // ---------------------------------------------------------------------------
  // Helper Functions
  // ---------------------------------------------------------------------------

  // Sign-extend 17-bit immediate to 32 bits
  function automatic logic [XLEN-1:0] sign_ext17;
    input logic [16:0] imm;
    return {{15{imm[16]}}, imm};
  endfunction

  // Sign-extend 12-bit immediate to 32 bits
  function automatic logic [XLEN-1:0] sign_ext12;
    input logic [11:0] imm;
    return {{20{imm[11]}}, imm};
  endfunction

  // Determine instruction format from opcode
  function automatic instr_fmt_t get_format;
    input logic [4:0] opcode;
    case (opcode)
      OP_ADD, OP_SUB, OP_MUL:
        get_format = FMT_R;
      OP_LOAD, OP_STORE, OP_MOV, OP_BEQ, OP_BNE, OP_JMP:
        get_format = FMT_I;
      OP_DFLOAD, OP_DFSTORE, OP_DFMAP, OP_DFEXEC, OP_DFSYNC:
        get_format = FMT_D;
      OP_VADD, OP_VMUL, OP_VSUB, OP_DOT, OP_MATMUL,
      OP_REDUCE, OP_BCAST, OP_VLOAD, OP_VSTORE:
        get_format = FMT_V;
      default:
        get_format = FMT_R;
    endcase
  endfunction

endpackage

`endif // SILICAFLUX_PKG_SV
