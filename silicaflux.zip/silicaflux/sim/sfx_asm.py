#!/usr/bin/env python3
"""
SilicaFlux Assembler
====================
Converts SilicaFlux assembly source files (.sfx) into:
  - .hex  — 32-bit hex words (one per line), loadable by testbenches
  - .bin  — raw little-endian 32-bit binary for FPGA BRAM initialisation
  - .mif  — Altera/Intel .mif format for Quartus
  - .coe  — Xilinx .coe format for Vivado

Usage:
    python3 sfx_asm.py input.sfx -o output [--format hex|bin|mif|coe|all]

Assembly Syntax:
    ; comment
    label:
    MNEMONIC [operands]     ; inline comment

Register Syntax:
    Scalar: r0..r31
    Vector: v0..v15

Immediate Syntax:
    Decimal: 42
    Hex:     0xFF
    Negative: -10

Directives:
    .org ADDR   — set address counter
    .word VAL   — emit 32-bit literal word
"""

import sys
import re
import struct
import argparse
from dataclasses import dataclass, field
from typing import Optional

# ---------------------------------------------------------------------------
# ISA Constants
# ---------------------------------------------------------------------------
OPCODES = {
    'NOP':      0x00,
    'ADD':      0x01,
    'SUB':      0x02,
    'MUL':      0x03,
    'LOAD':     0x04,
    'STORE':    0x05,
    'MOV':      0x06,
    'BEQ':      0x07,
    'BNE':      0x08,
    'JMP':      0x09,
    'DFLOAD':   0x0A,
    'DFSTORE':  0x0B,
    'DFMAP':    0x0C,
    'DFEXEC':   0x0D,
    'DFSYNC':   0x0E,
    'VADD':     0x0F,
    'VMUL':     0x10,
    'VSUB':     0x11,
    'DOT':      0x12,
    'MATMUL':   0x13,
    'REDUCE':   0x14,
    'BROADCAST':0x15,
    'BCAST':    0x15,
    'VLOAD':    0x16,
    'VSTORE':   0x17,
    'HALT':     0x1F,
}

# Instruction formats by opcode
R_OPS  = {'ADD', 'SUB', 'MUL', 'NOP'}
I_OPS  = {'LOAD', 'STORE', 'MOV', 'BEQ', 'BNE', 'JMP'}
D_OPS  = {'DFLOAD', 'DFSTORE', 'DFMAP', 'DFEXEC', 'DFSYNC'}
V_OPS  = {'VADD', 'VMUL', 'VSUB', 'DOT', 'MATMUL', 'REDUCE', 'BROADCAST', 'BCAST',
          'VLOAD', 'VSTORE'}

REDUCE_OPS = {'SUM': 0, 'MIN': 1, 'MAX': 2, 'AND': 3}

# ---------------------------------------------------------------------------
# Token & Source Line
# ---------------------------------------------------------------------------
@dataclass
class AsmLine:
    lineno:  int
    raw:     str
    label:   Optional[str]
    mnemonic:Optional[str]
    operands:list
    addr:    int = 0


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------
def parse_reg(tok: str) -> int:
    tok = tok.strip().lower().rstrip(',')
    if tok.startswith('r'):
        n = int(tok[1:])
        assert 0 <= n <= 31, f"Scalar reg out of range: {tok}"
        return n
    raise ValueError(f"Expected scalar register, got: {tok}")

def parse_vreg(tok: str) -> int:
    tok = tok.strip().lower().rstrip(',')
    if tok.startswith('v'):
        n = int(tok[1:])
        assert 0 <= n <= 15, f"Vector reg out of range: {tok}"
        return n
    raise ValueError(f"Expected vector register, got: {tok}")

def parse_imm(tok: str, bits: int, signed_: bool = True) -> int:
    tok = tok.strip().rstrip(',')
    val = int(tok, 0)
    if signed_:
        lo, hi = -(1 << (bits-1)), (1 << (bits-1)) - 1
        assert lo <= val <= hi, f"Immediate {val} out of range [{lo},{hi}]"
        return val & ((1 << bits) - 1)
    else:
        assert 0 <= val < (1 << bits), f"Unsigned imm {val} out of range"
        return val

def parse_tile(tok: str) -> int:
    tok = tok.strip().rstrip(',')
    # Accepts: tile=2, TILE=2, 2
    if '=' in tok:
        tok = tok.split('=')[1]
    val = int(tok, 0)
    assert 0 <= val <= 7
    return val

def tokenise_line(raw: str, lineno: int) -> Optional[AsmLine]:
    # Strip comment
    line = raw.split(';')[0].strip()
    if not line:
        return None

    label = None
    mnemonic = None
    operands = []

    # Label detection
    if ':' in line:
        parts = line.split(':', 1)
        lbl = parts[0].strip()
        if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', lbl):
            label = lbl
            line = parts[1].strip()

    if not line:
        return AsmLine(lineno=lineno, raw=raw, label=label,
                       mnemonic=None, operands=[])

    # Directive
    if line.startswith('.'):
        parts = line.split()
        return AsmLine(lineno=lineno, raw=raw, label=label,
                       mnemonic=parts[0].upper(),
                       operands=parts[1:] if len(parts) > 1 else [])

    # Mnemonic + operands
    parts = line.split(None, 1)
    mnemonic = parts[0].upper()
    if len(parts) > 1:
        # Split on commas and spaces, ignoring quoted stuff
        ops_raw = parts[1]
        operands = [o.strip() for o in re.split(r'[,\s]+', ops_raw) if o.strip()]

    return AsmLine(lineno=lineno, raw=raw, label=label,
                   mnemonic=mnemonic, operands=operands)


# ---------------------------------------------------------------------------
# Encoder
# ---------------------------------------------------------------------------
def encode(aline: AsmLine, labels: dict) -> int:
    mn   = aline.mnemonic
    ops  = aline.operands
    addr = aline.addr

    op = OPCODES[mn]

    # ---- HALT ----
    if mn == 'HALT' or mn == 'NOP':
        return (op << 27)

    # ---- R-Format ----
    if mn in R_OPS:
        rd  = parse_reg(ops[0]) if len(ops) > 0 else 0
        rs1 = parse_reg(ops[1]) if len(ops) > 1 else 0
        rs2 = parse_reg(ops[2]) if len(ops) > 2 else 0
        return (op << 27) | (rd << 22) | (rs1 << 17) | (rs2 << 12)

    # ---- I-Format ----
    if mn in I_OPS:
        if mn == 'MOV':
            rd  = parse_reg(ops[0])
            imm = parse_imm(ops[1], 17)
            rs1 = 0
        elif mn in ('BEQ', 'BNE'):
            rs1 = parse_reg(ops[0])
            rs2_or_lbl = ops[1].rstrip(',')
            # Third operand: label or immediate
            if len(ops) > 2:
                target = ops[2]
            else:
                target = rs2_or_lbl
                rs2_or_lbl = ops[0]  # fallback
            rd  = parse_reg(rs2_or_lbl) if not rs2_or_lbl.startswith('+') else 0
            # Resolve label or immediate
            if re.match(r'^[A-Za-z_]', target):
                target_addr = labels[target]
                imm_val = target_addr - addr
                imm = imm_val & 0x1FFFF
            else:
                imm = parse_imm(target, 17)
            rs2 = parse_reg(ops[1]) if len(ops) >= 3 else 0
            return (op << 27) | (rs1 << 17) | (rs2 << 12) | (imm & 0x1FFFF)
        elif mn == 'JMP':
            rs1 = parse_reg(ops[0]) if ops else 0
            target = ops[1] if len(ops) > 1 else '0'
            if re.match(r'^[A-Za-z_]', target):
                target_addr = labels[target]
                imm_val = target_addr - addr
                imm = imm_val & 0x1FFFF
            else:
                imm = parse_imm(target, 17)
            return (op << 27) | (rs1 << 17) | (imm & 0x1FFFF)
        elif mn == 'LOAD':
            rd  = parse_reg(ops[0])
            rs1 = parse_reg(ops[1])
            imm = parse_imm(ops[2], 17) if len(ops) > 2 else 0
        elif mn == 'STORE':
            rs1 = parse_reg(ops[0])
            rs2 = parse_reg(ops[1]) if len(ops) > 1 else 0
            imm = parse_imm(ops[2], 17) if len(ops) > 2 else 0
            rd  = 0
            return (op << 27) | (rd << 22) | (rs1 << 17) | (imm & 0x1FFFF)
        else:
            rd = rs1 = 0
            imm = 0
        return (op << 27) | (rd << 22) | (rs1 << 17) | (imm & 0x1FFFF)

    # ---- D-Format ----
    if mn in D_OPS:
        if mn == 'DFSYNC':
            return (op << 27)
        tile  = parse_tile(ops[0]) if ops else 0
        reg   = (parse_vreg(ops[1]) if ops[1].lower().startswith('v')
                 else parse_reg(ops[1])) if len(ops) > 1 else 0
        length = parse_imm(ops[2], 5, signed_=False) if len(ops) > 2 else 0
        saddr  = parse_imm(ops[3], 14, signed_=False) if len(ops) > 3 else 0
        return ((op << 27) | (tile << 24) | (reg << 19) |
                (length << 14) | saddr)

    # ---- V-Format ----
    if mn in V_OPS:
        if mn in ('VADD', 'VMUL', 'VSUB'):
            vrd  = parse_vreg(ops[0])
            vrs1 = parse_vreg(ops[1])
            vrs2 = parse_vreg(ops[2])
            return (op << 27) | (vrd << 23) | (vrs1 << 19) | (vrs2 << 15)
        elif mn in ('DOT',):
            rd   = parse_reg(ops[0])
            vrs1 = parse_vreg(ops[1])
            vrs2 = parse_vreg(ops[2])
            func = REDUCE_OPS.get(ops[3].upper(), 0) if len(ops) > 3 else 0
            return (op << 27) | (rd << 22) | (vrs1 << 19) | (vrs2 << 15) | func
        elif mn == 'REDUCE':
            rd   = parse_reg(ops[0])
            vrs1 = parse_vreg(ops[1])
            red  = REDUCE_OPS.get(ops[2].upper(), 0) if len(ops) > 2 else 0
            return (op << 27) | (rd << 22) | (vrs1 << 19) | red
        elif mn in ('BROADCAST', 'BCAST'):
            vrd = parse_vreg(ops[0])
            rs1 = parse_reg(ops[1])
            return (op << 27) | (vrd << 23) | (rs1 << 17)
        elif mn == 'MATMUL':
            return (op << 27)
        elif mn in ('VLOAD', 'VSTORE'):
            vrd  = parse_vreg(ops[0])
            rs1  = parse_reg(ops[1])
            imm  = parse_imm(ops[2], 12) if len(ops) > 2 else 0
            return (op << 27) | (vrd << 23) | (rs1 << 17) | (imm & 0xFFF)

    raise ValueError(f"Cannot encode mnemonic: {mn}")


# ---------------------------------------------------------------------------
# Two-Pass Assembler
# ---------------------------------------------------------------------------
def assemble(source: str) -> list:
    lines_raw = source.splitlines()
    parsed = []
    addr = 0

    # Pass 1 — assign addresses, collect labels
    for lineno, raw in enumerate(lines_raw, 1):
        al = tokenise_line(raw, lineno)
        if al is None:
            continue

        if al.mnemonic == '.ORG':
            addr = int(al.operands[0], 0)
            continue

        al.addr = addr
        parsed.append(al)

        if al.mnemonic not in (None, '.WORD'):
            addr += 1
        elif al.mnemonic == '.WORD':
            addr += 1

    # Build label map
    labels = {}
    for al in parsed:
        if al.label:
            labels[al.label] = al.addr

    # Pass 2 — encode
    program = []
    for al in parsed:
        if al.mnemonic is None:
            continue
        if al.mnemonic == '.WORD':
            program.append((al.addr, int(al.operands[0], 0) & 0xFFFFFFFF))
            continue
        if al.mnemonic not in OPCODES:
            raise ValueError(f"Line {al.lineno}: Unknown mnemonic '{al.mnemonic}'")
        word = encode(al, labels)
        program.append((al.addr, word & 0xFFFFFFFF))

    return program


# ---------------------------------------------------------------------------
# Output Formatters
# ---------------------------------------------------------------------------
def write_hex(program, out_file, depth=1024):
    words = [0] * depth
    for addr, word in program:
        words[addr] = word
    with open(out_file, 'w') as f:
        for i, w in enumerate(words):
            if w or i < max(a for a, _ in program) + 4:
                f.write(f"{w:08X}\n")

def write_bin(program, out_file, depth=1024):
    words = [0] * depth
    for addr, word in program:
        words[addr] = word
    with open(out_file, 'wb') as f:
        for w in words:
            f.write(struct.pack('<I', w))

def write_mif(program, out_file, depth=1024):
    words = [0] * depth
    for addr, word in program:
        words[addr] = word
    with open(out_file, 'w') as f:
        f.write(f"DEPTH = {depth};\n")
        f.write(f"WIDTH = 32;\n")
        f.write("ADDRESS_RADIX = HEX;\n")
        f.write("DATA_RADIX = HEX;\n\n")
        f.write("CONTENT BEGIN\n")
        for i, w in enumerate(words):
            f.write(f"  {i:04X} : {w:08X};\n")
        f.write("END;\n")

def write_coe(program, out_file, depth=1024):
    words = [0] * depth
    for addr, word in program:
        words[addr] = word
    with open(out_file, 'w') as f:
        f.write("; SilicaFlux Program Image\n")
        f.write("; Generated by sfx_asm.py\n\n")
        f.write("memory_initialization_radix=16;\n")
        f.write("memory_initialization_vector=\n")
        for i, w in enumerate(words):
            sep = ',' if i < len(words)-1 else ';'
            f.write(f"{w:08X}{sep}\n")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description='SilicaFlux Assembler')
    parser.add_argument('input',          help='Assembly source file (.sfx)')
    parser.add_argument('-o', '--output', default='out', help='Output base name')
    parser.add_argument('--format',       default='all',
                        choices=['hex','bin','mif','coe','all'],
                        help='Output format(s)')
    parser.add_argument('--depth',        type=int, default=1024,
                        help='IMEM depth in words')
    parser.add_argument('--list',         action='store_true',
                        help='Print assembled listing to stdout')
    args = parser.parse_args()

    with open(args.input) as f:
        source = f.read()

    try:
        program = assemble(source)
    except (ValueError, AssertionError, KeyError) as e:
        print(f"[ASSEMBLER ERROR] {e}", file=sys.stderr)
        sys.exit(1)

    if args.list:
        print(f"{'ADDR':>6}  {'HEX':>10}  BINARY")
        print('-' * 50)
        for addr, word in program:
            print(f"  {addr:04X}   {word:08X}   {word:032b}")

    fmt = args.format
    if fmt in ('hex', 'all'):
        write_hex(program, args.output + '.hex', args.depth)
        print(f"Written: {args.output}.hex")
    if fmt in ('bin', 'all'):
        write_bin(program, args.output + '.bin', args.depth)
        print(f"Written: {args.output}.bin")
    if fmt in ('mif', 'all'):
        write_mif(program, args.output + '.mif', args.depth)
        print(f"Written: {args.output}.mif")
    if fmt in ('coe', 'all'):
        write_coe(program, args.output + '.coe', args.depth)
        print(f"Written: {args.output}.coe")

    print(f"Assembled {len(program)} instructions.")


if __name__ == '__main__':
    main()
