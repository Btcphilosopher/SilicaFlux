#!/usr/bin/env bash
# =============================================================================
# SilicaFlux — Simulation Runner
# Usage: ./run_sim.sh [vec|tensor|mem|sched|noc|tile|top|all]
# Requires: iverilog 11.0+
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJ_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
RTL_DIR="$PROJ_DIR/rtl"
TB_DIR="$PROJ_DIR/tb"
BUILD_DIR="$SCRIPT_DIR/build"
mkdir -p "$BUILD_DIR"

RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
info() { echo -e "${CYAN}  ► ${NC}$*"; }
pass() { echo -e "${GREEN}  ✔ $*${NC}"; }
fail() { echo -e "${RED}  ✘ $*${NC}"; }

RTL_SOURCES=(
  "$RTL_DIR/silicaflux_pkg.sv"   "$RTL_DIR/alu.sv"
  "$RTL_DIR/forwarding_unit.sv"  "$RTL_DIR/fetch_unit.sv"
  "$RTL_DIR/decoder.sv"          "$RTL_DIR/register_bank.sv"
  "$RTL_DIR/vector_engine.sv"    "$RTL_DIR/tensor_unit.sv"
  "$RTL_DIR/memory_controller.sv" "$RTL_DIR/control_core.sv"
  "$RTL_DIR/scheduler.sv"        "$RTL_DIR/compute_tile.sv"
  "$RTL_DIR/noc_router.sv"       "$RTL_DIR/noc_interconnect.sv"
  "$RTL_DIR/tile_interface.sv"   "$RTL_DIR/silicaflux_top.sv"
)

declare -A TB_MAP=(
  ["vec"]="tb_vector_engine"  ["tensor"]="tb_tensor_unit"
  ["mem"]="tb_memory_controller" ["sched"]="tb_scheduler"
  ["noc"]="tb_noc_interconnect" ["tile"]="tb_compute_tile"
  ["top"]="tb_silicaflux_top"
)
ALL_ORDER=(vec tensor mem sched noc tile top)

PASS_COUNT=0; FAIL_COUNT=0

run_tb() {
  local name=$1; local out_bin="$BUILD_DIR/${name}"
  info "Compiling $name ..."
  if ! iverilog -g2012 -I"$RTL_DIR" -o "$out_bin" "${RTL_SOURCES[@]}" "$TB_DIR/${name}.sv" \
       > "$BUILD_DIR/${name}.compile.log" 2>&1; then
    cat "$BUILD_DIR/${name}.compile.log"
    fail "$name — COMPILE FAILED"; ((FAIL_COUNT++)); return
  fi
  info "Running $name ..."
  cd "$BUILD_DIR"
  if timeout 60 vvp "$out_bin" 2>&1 | tee "$BUILD_DIR/${name}.log"; then
    local fp; fp=$(grep -c "^\[FAIL\]" "$BUILD_DIR/${name}.log" 2>/dev/null || echo 0)
    local pp; pp=$(grep -c "^\[PASS\]" "$BUILD_DIR/${name}.log" 2>/dev/null || echo 0)
    if [[ "${fp}" -gt 0 ]]; then
      fail "$name — ${pp} PASS / ${fp} FAIL"; ((FAIL_COUNT++))
    else
      pass "$name — ${pp} assertions passed"; ((PASS_COUNT++))
    fi
  else
    fail "$name — TIMEOUT or CRASH"; ((FAIL_COUNT++))
  fi
  cd "$SCRIPT_DIR"
}

TARGETS=(); if [[ $# -eq 0 ]] || [[ "$1" == "all" ]]; then TARGETS=("${ALL_ORDER[@]}"); else TARGETS=("$@"); fi

echo -e "\n${BOLD}${CYAN}═══════════════════════════════════════${NC}"
echo -e "${BOLD}${CYAN}    SilicaFlux RTL Simulation Suite${NC}"
echo -e "${BOLD}${CYAN}═══════════════════════════════════════${NC}"
command -v iverilog >/dev/null 2>&1 || { echo "ERROR: iverilog not found"; exit 1; }
info "Simulator: $(iverilog -V 2>&1 | head -1)"
echo ""

for t in "${TARGETS[@]}"; do
  if [[ -v TB_MAP[$t] ]]; then
    tb="${TB_MAP[$t]}"
    echo -e "${BOLD}─── ${tb} ───${NC}"
    [[ -f "$TB_DIR/${tb}.sv" ]] && run_tb "$tb" || { echo "  ⚠ Not found: $TB_DIR/${tb}.sv"; }
  else echo "  ⚠ Unknown: $t"; fi
done

echo ""
echo -e "${BOLD}${CYAN}═══════════════════════════════════════${NC}"
echo -e "  ${GREEN}PASSED: $PASS_COUNT${NC}  ${RED}FAILED: $FAIL_COUNT${NC}"
echo -e "${BOLD}${CYAN}═══════════════════════════════════════${NC}"
[[ $FAIL_COUNT -eq 0 && $PASS_COUNT -gt 0 ]] && echo -e "${GREEN}${BOLD}  ✔ ALL PASSED${NC}"
echo "  VCDs: $BUILD_DIR/*.vcd"
exit $FAIL_COUNT
