# SoC Integration Framework

A modular, production-grade System-on-Chip integration framework in
synthesisable SystemVerilog, targeting Icarus Verilog 12 simulation and
compatible with standard synthesis flows.

---

## Architecture

```
  ┌─────────────────────────────────────────────────────────────────────┐
  │                           SoC Top                                   │
  │                                                                     │
  │  CPU / BFM (external)                                               │
  │       │  flat SSB master bus                                        │
  │       ▼                                                             │
  │  ┌──────────┐                                                       │
  │  │  Fabric  │  1-master / 6-slave address-decode interconnect       │
  │  └─────┬────┘                                                       │
  │        │  per-slave SSB buses                                       │
  │  ┌─────┼────────────────────────────────────────┐                  │
  │  │     │                                        │                  │
  │  S0    S1     S2      S3     S4      S5         │                  │
  │ ROM   SRAM  Timer   GPIO   UART   IRQ Ctrl      │                  │
  │               │       │      │      ▲            │                  │
  │           timer_irq gpio_irq│ uart_rx/tx_irq    │                  │
  │               └───────┴──────┴───────┘           │                  │
  │                        irq_o ──────────► cpu_irq_o                 │
  │                                                                     │
  │  gpio_in/out/oe, uart_txd/rxd exposed at top level                  │
  └─────────────────────────────────────────────────────────────────────┘
```

---

## Address Map

| Region         | Base         | Top          | Size  | Slave |
|----------------|--------------|--------------|-------|-------|
| Boot ROM       | `0x0000_0000`| `0x0000_FFFF`| 64 KB |  S0   |
| SRAM           | `0x2000_0000`| `0x2001_FFFF`| 128 KB|  S1   |
| Timer          | `0x4000_0000`| `0x4000_0FFF`|  4 KB |  S2   |
| GPIO           | `0x4000_1000`| `0x4000_1FFF`|  4 KB |  S3   |
| UART           | `0x4000_2000`| `0x4000_2FFF`|  4 KB |  S4   |
| IRQ Controller | `0x4000_3000`| `0x4000_3FFF`|  4 KB |  S5   |

---

## SSB Bus Protocol

**SoC Simple Bus (SSB)** — a lightweight handshake protocol:

```
  Request phase  (master → slave)
    req_valid + req_addr + req_write + req_wdata + req_wstrb
    Slave asserts req_ready when it accepts.
    Handshake: both signals high on same rising clock edge.

  Response phase (slave → master)
    Slave drives rsp_valid + rsp_rdata/rsp_error.
    Master drives rsp_ready to accept.

  Timing guarantee: all slaves respond in exactly 1 cycle after handshake.
```

---

## Boot ROM Program

The ROM is preloaded at elaboration time with a 15-instruction RV32I boot
sequence (addresses `0x0000_0000` – `0x0000_003C`):

| PC       | Hex Encoding | Assembly                      | Action                     |
|----------|--------------|-------------------------------|----------------------------|
| `0x0000` | `2002_0137`  | `lui sp, 0x20020`             | SP = 0x2002_0000           |
| `0x0004` | `FF01_0113`  | `addi sp, sp, -16`            | SP = 0x2001_FFF0 (stack)   |
| `0x0008` | `4000_22B7`  | `lui t0, 0x40002`             | t0 = UART_BASE             |
| `0x000C` | `1B20_0313`  | `addi t1, x0, 434`            | t1 = baud divisor (115 200)|
| `0x0010` | `0062_A623`  | `sw t1, 12(t0)`               | UART_BAUD = 434            |
| `0x0014` | `4000_02B7`  | `lui t0, 0x40000`             | t0 = TIMER_BASE            |
| `0x0018` | `0000_C337`  | `lui t1, 0xC`                 | t1[15:12] = 0xC            |
| `0x001C` | `3503_0313`  | `addi t1, t1, 848`            | t1 = 50 000 (1 ms reload)  |
| `0x0020` | `0062_A223`  | `sw t1, 4(t0)`                | TIMER_RELOAD = 50 000      |
| `0x0024` | `0070_0313`  | `addi t1, x0, 7`              | t1 = 7                     |
| `0x0028` | `0062_A023`  | `sw t1, 0(t0)`                | TIMER_CTRL = 7 (run)       |
| `0x002C` | `4000_32B7`  | `lui t0, 0x40003`             | t0 = IRQ_CTRL_BASE         |
| `0x0030` | `0070_0313`  | `addi t1, x0, 7`              | t1 = 7                     |
| `0x0034` | `0062_A023`  | `sw t1, 0(t0)`                | IRQ_ENABLE = 0b111         |
| `0x0038` | `0000_006F`  | `jal x0, 0`                   | idle loop                  |

---

## Peripheral Register Maps

### Timer (`0x4000_0000`)
| Offset | Name   | Access | Description                                      |
|--------|--------|--------|--------------------------------------------------|
| `0x00` | CTRL   | RW     | `[2]` auto_reload  `[1]` irq_en  `[0]` enable   |
| `0x04` | RELOAD | RW     | Reload value (counts from here to 0)             |
| `0x08` | VALUE  | RO     | Current counter value                            |
| `0x0C` | STATUS | W1C    | `[0]` expired flag                               |

### GPIO (`0x4000_1000`)
| Offset | Name   | Access | Description                        |
|--------|--------|--------|------------------------------------|
| `0x00` | DIR    | RW     | `1`=output per bit                 |
| `0x04` | OUT    | RW     | Output data register               |
| `0x08` | IN     | RO     | Synchronised input snapshot        |
| `0x0C` | IRQ_EN | RW     | Rising-edge IRQ enable per pin     |
| `0x10` | IRQ_ST | W1C    | IRQ status (set on rising edge)    |

### UART (`0x4000_2000`)
| Offset | Name   | Access | Description                                          |
|--------|--------|--------|------------------------------------------------------|
| `0x00` | DATA   | RW     | Write = TX push; Read = RX pop                       |
| `0x04` | STATUS | RO     | `[3]`rx_err `[2]`rx_valid `[1]`tx_empty `[0]`tx_ready|
| `0x08` | CTRL   | RW     | `[1]`rx_irq_en `[0]`tx_irq_en                        |
| `0x0C` | BAUD   | RW     | Bit-period divisor (`CLK_FREQ / baud_rate`)          |

### IRQ Controller (`0x4000_3000`)
| Offset | Name    | Access | Description                        |
|--------|---------|--------|------------------------------------|
| `0x00` | ENABLE  | RW     | Per-source enable                  |
| `0x04` | PENDING | W1C    | Latched pending (W1C to clear)     |
| `0x08` | ACTIVE  | RO     | `ENABLE & PENDING`                 |

**Interrupt sources:**  
`[0]` Timer  `[1]` GPIO  `[2]` UART RX  `[3]` UART TX

---

## File Structure

```
soc_integration/
├── rtl/
│   ├── soc_pkg.sv                  Global package (address map, types)
│   ├── bus/
│   │   ├── soc_bus_if.sv           SSB interface definition + modports
│   │   └── soc_fabric.sv           1:6 address-decode interconnect
│   ├── cpu/
│   │   └── cpu_if_adapter.sv       RV32I I/D port → SSB bridge
│   ├── memory/
│   │   ├── boot_rom.sv             64 KB ROM with preloaded boot program
│   │   └── soc_sram.sv             128 KB byte-enable SRAM
│   ├── peripherals/
│   │   ├── soc_timer.sv            32-bit countdown timer
│   │   ├── soc_gpio.sv             32-bit GPIO with IRQ
│   │   ├── soc_uart.sv             Full-duplex UART (8N1, FIFOs)
│   │   └── soc_irq_ctrl.sv         Vectored interrupt controller
│   └── soc_top.sv                  Top-level SoC wrapper
├── tb/
│   ├── models/
│   │   ├── cpu_bfm.sv              CPU Bus Functional Model
│   │   └── uart_mon.sv             UART bit-stream decoder
│   └── tb_soc_top.sv               Full-chip testbench
├── sim/
│   └── Makefile                    Icarus Verilog build system
└── README.md
```

---

## Simulation

```bash
cd sim
make sim        # compile + run
make wave       # run + open GTKWave
make lint       # elaboration check only
make clean      # remove build artefacts
```

**Requirements:** Icarus Verilog ≥ 12, GTKWave (optional).

---

## Integrating the RV32I CPU Core

`soc_top.sv` exposes a flat SSB master bus (`cpu_req_*` / `cpu_rsp_*`).
To connect Tom's RV32I 5-stage pipelined core:

1. Instantiate `cpu_if_adapter` between the CPU and `soc_top`.
2. Wire the CPU's instruction-fetch and data-memory ports to the adapter.
3. Wire the adapter's flat bus outputs to `soc_top`'s `cpu_req_*` inputs.
4. Feed `soc_top.cpu_irq_o` back to the CPU's external-interrupt input.

```systemverilog
cpu_if_adapter u_cpu_bus (
  .clk            (clk),        .rst_n          (rst_n),
  // CPU instruction fetch
  .if_addr_i      (cpu_if_addr),  .if_valid_i  (cpu_if_valid),
  .if_ready_o     (cpu_if_ready), .if_rdata_o  (cpu_if_rdata),
  .if_err_o       (cpu_if_err),
  // CPU data memory
  .dm_addr_i      (cpu_dm_addr),  .dm_valid_i  (cpu_dm_valid),
  .dm_ready_o     (cpu_dm_ready), .dm_write_i  (cpu_dm_write),
  .dm_wdata_i     (cpu_dm_wdata), .dm_wstrb_i  (cpu_dm_wstrb),
  .dm_rdata_o     (cpu_dm_rdata), .dm_err_o    (cpu_dm_err),
  // SSB to soc_top
  .bus_req_valid_o(cpu_req_valid), .bus_req_ready_i(cpu_req_ready),
  .bus_req_addr_o (cpu_req_addr),  .bus_req_write_o(cpu_req_write),
  .bus_req_wdata_o(cpu_req_wdata), .bus_req_wstrb_o(cpu_req_wstrb),
  .bus_rsp_valid_i(cpu_rsp_valid), .bus_rsp_ready_o(cpu_rsp_ready),
  .bus_rsp_rdata_i(cpu_rsp_rdata), .bus_rsp_error_i(cpu_rsp_error)
);
```

---

## Adding a Peripheral

1. Implement the module with `soc_bus_if.slave bus` port.
2. Add its base address and mask to `soc_pkg.sv`.
3. Add a decode branch in `soc_fabric.sv` (`always_comb` decode block).
4. Increment `NUM_SLAVES` in `soc_pkg.sv`.
5. Wire the new slave index in `soc_top.sv` (one block of 10 `assign` lines).
6. Add the IRQ source to the `irq_src` vector if needed.

The modular SSB slave interface ensures all peripherals follow the same
one-cycle-response contract; no changes to the fabric timing model are
required for standard register-mapped slaves.
