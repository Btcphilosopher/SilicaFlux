// ============================================================================
// FILE        : boot_rom.sv
// PROJECT     : SoC Integration Framework
// DESCRIPTION : 64 KB Boot ROM with SSB slave interface.
//
//  • Read-only. Write transactions return a bus error.
//  • Responds exactly one cycle after request handshake.
//  • req_ready is always high (can accept every cycle).
//  • Optional $readmemh preload from INIT_FILE (empty string = use defaults).
//
// Preloaded Boot Program (RV32I — offset from 0x0000_0000)
// ──────────────────────────────────────────────────────────────────────────
//  PC=0x00  lui   sp, 0x20020      // sp = 0x20020000
//  PC=0x04  addi  sp, sp, -16     // sp = 0x2001_FFF0  (stack top)
//  PC=0x08  lui   t0, 0x40002     // t0 = 0x4000_2000  (UART base)
//  PC=0x0C  addi  t1, x0, 434     // t1 = 434          (50 MHz / 115200)
//  PC=0x10  sw    t1, 12(t0)      // UART_BAUD = 434
//  PC=0x14  lui   t0, 0x40000     // t0 = 0x4000_0000  (TIMER base)
//  PC=0x18  lui   t1, 0x0000C     // t1 = 0xC000
//  PC=0x1C  addi  t1, t1, 848     // t1 = 0xC350 = 50000 (1 ms @ 50 MHz)
//  PC=0x20  sw    t1, 4(t0)       // TIMER_RELOAD = 50000
//  PC=0x24  addi  t1, x0, 7      // t1 = 7  (enable|irq_en|auto_reload)
//  PC=0x28  sw    t1, 0(t0)       // TIMER_CTRL = 7
//  PC=0x2C  lui   t0, 0x40003     // t0 = 0x4000_3000  (IRQ_CTRL base)
//  PC=0x30  addi  t1, x0, 7      // t1 = 7  (enable IRQ 0,1,2)
//  PC=0x34  sw    t1, 0(t0)       // IRQ_ENABLE = 7
//  PC=0x38  jal   x0, 0           // idle loop (spin forever at 0x38)
// ============================================================================

module boot_rom
#(
  parameter int    ROM_DEPTH = 16384,            // 64 KB = 16 K × 32-bit words
  parameter string INIT_FILE = ""                // hex file; "" = use defaults
)(
  input  logic        clk,
  input  logic        rst_n,
  // SSB slave bus
  input  logic        req_valid,
  output logic        req_ready,
  input  logic [31:0] req_addr,
  input  logic        req_write,
  input  logic [31:0] req_wdata,
  input  logic  [3:0] req_wstrb,
  output logic        rsp_valid,
  input  logic        rsp_ready,
  output logic [31:0] rsp_rdata,
  output logic        rsp_error
);
  import soc_pkg::*;

  // ─── ROM Storage ──────────────────────────────────────────────────────────
  localparam int ADDR_BITS = $clog2(ROM_DEPTH);

  logic [DATA_W-1:0] mem [0:ROM_DEPTH-1];

  // ─── Default Initialisation (boot program) ────────────────────────────────
  initial begin : rom_init
    integer i;
    for (i = 0; i < ROM_DEPTH; i++) mem[i] = 32'h0000_0013; // NOP (addi x0,x0,0)

    // ── Boot sequence ──
    mem[0]  = 32'h2002_0137; // lui  sp, 0x20020
    mem[1]  = 32'hFF01_0113; // addi sp, sp, -16
    mem[2]  = 32'h4000_22B7; // lui  t0, 0x40002
    mem[3]  = 32'h1B20_0313; // addi t1, x0, 434
    mem[4]  = 32'h0062_A623; // sw   t1, 12(t0)   [UART_BAUD]
    mem[5]  = 32'h4000_02B7; // lui  t0, 0x40000
    mem[6]  = 32'h0000_C337; // lui  t1, 0xC
    mem[7]  = 32'h3503_0313; // addi t1, t1, 848
    mem[8]  = 32'h0062_A223; // sw   t1, 4(t0)    [TIMER_RELOAD]
    mem[9]  = 32'h0070_0313; // addi t1, x0, 7
    mem[10] = 32'h0062_A023; // sw   t1, 0(t0)    [TIMER_CTRL]
    mem[11] = 32'h4000_32B7; // lui  t0, 0x40003
    mem[12] = 32'h0070_0313; // addi t1, x0, 7
    mem[13] = 32'h0062_A023; // sw   t1, 0(t0)    [IRQ_ENABLE]
    mem[14] = 32'h0000_006F; // jal  x0, 0        [idle]

    // Optional file override
    if (INIT_FILE != "") $readmemh(INIT_FILE, mem);
  end

  // ─── Response Pipeline ────────────────────────────────────────────────────
  logic [DATA_W-1:0] rsp_data_q;
  logic              rsp_vld_q;
  logic              rsp_err_q;

  // Word address from byte address (word-aligned accesses)
  wire [ADDR_BITS-1:0] word_addr = req_addr[ADDR_BITS+1:2];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rsp_data_q <= '0;
      rsp_vld_q  <= 1'b0;
      rsp_err_q  <= 1'b0;
    end else begin
      // Capture response on request handshake
      if (req_valid && req_ready) begin
        if (req_write) begin
          // Write to ROM is an error
          rsp_data_q <= '0;
          rsp_err_q  <= 1'b1;
        end else begin
          rsp_data_q <= mem[word_addr];
          rsp_err_q  <= 1'b0;
        end
        rsp_vld_q <= 1'b1;
      end
      // Clear after response consumed
      if (rsp_valid && rsp_ready) begin
        rsp_vld_q <= 1'b0;
      end
    end
  end

  // ─── Bus Outputs ──────────────────────────────────────────────────────────
  assign req_ready = 1'b1;          // ROM never stalls requests
  assign rsp_valid = rsp_vld_q;
  assign rsp_rdata = rsp_data_q;
  assign rsp_error = rsp_err_q;

  // ─── Simulation Checks ────────────────────────────────────────────────────
  // pragma translate_off
  `ifdef SIMULATION
  always @(posedge clk) begin
    if (rst_n && req_valid && req_write)
      $display("[BOOT_ROM] WARNING: write attempt to ROM addr=0x%08X t=%0t",
               req_addr, $time);
  end
  `endif
  // pragma translate_on

endmodule
