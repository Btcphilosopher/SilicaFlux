// ============================================================================
// FILE        : soc_sram.sv
// PROJECT     : SoC Integration Framework
// DESCRIPTION : 128 KB byte-enable SRAM with SSB slave interface.
//
//  • Word-aligned accesses (byte-enable mask selects active bytes).
//  • Unaligned byte / half-word writes supported through req_wstrb.
//  • req_ready is always high (single-cycle accept).
//  • Responds exactly one cycle after request handshake.
//  • Synthesises to on-chip SRAM using standard inferred memory pattern.
// ============================================================================

module soc_sram
#(
  parameter int SRAM_DEPTH = 32768,   // 128 KB = 32 K × 32-bit words
  parameter string INIT_FILE = ""     // optional hex preload
)(
  input  logic        clk,
  input  logic        rst_n,
  // SSB slave bus
  input  logic        req_valid,
  output logic        req_ready,
  input  logic [31:0] req_addr,
  input  logic        req_write,
  input  logic [31:0] req_wdata,
  input  logic  [3:0] req_wstrb,
  output logic        rsp_valid,
  input  logic        rsp_ready,
  output logic [31:0] rsp_rdata,
  output logic        rsp_error
);
  import soc_pkg::*;

  // ─── Storage Array ────────────────────────────────────────────────────────
  localparam int ADDR_BITS = $clog2(SRAM_DEPTH);

  logic [DATA_W-1:0] mem [0:SRAM_DEPTH-1];

  initial begin
    integer i;
    for (i = 0; i < SRAM_DEPTH; i++) mem[i] = '0;
    if (INIT_FILE != "") $readmemh(INIT_FILE, mem);
  end

  // ─── Request Handling ─────────────────────────────────────────────────────
  logic [DATA_W-1:0] rsp_data_q;
  logic              rsp_vld_q;

  wire [ADDR_BITS-1:0] word_addr = req_addr[ADDR_BITS+1:2];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rsp_data_q <= '0;
      rsp_vld_q  <= 1'b0;
    end else begin
      // Accept every request immediately (req_ready = 1)
      if (req_valid) begin
        rsp_vld_q <= 1'b1;
        if (req_write) begin
          // Byte-enable write
          if (req_wstrb[0]) mem[word_addr][ 7: 0] <= req_wdata[ 7: 0];
          if (req_wstrb[1]) mem[word_addr][15: 8] <= req_wdata[15: 8];
          if (req_wstrb[2]) mem[word_addr][23:16] <= req_wdata[23:16];
          if (req_wstrb[3]) mem[word_addr][31:24] <= req_wdata[31:24];
          rsp_data_q <= '0;
        end else begin
          // Read: latch word
          rsp_data_q <= mem[word_addr];
        end
      end
      // Clear rsp_valid after handshake
      if (rsp_valid && rsp_ready) rsp_vld_q <= 1'b0;
    end
  end

  // ─── Bus Outputs ──────────────────────────────────────────────────────────
  assign req_ready = 1'b1;
  assign rsp_valid = rsp_vld_q;
  assign rsp_rdata = rsp_data_q;
  assign rsp_error = 1'b0;        // SRAM never faults

  // ─── Simulation Checks ────────────────────────────────────────────────────
  // pragma translate_off
  `ifdef SIMULATION
  always @(posedge clk) begin
    if (rst_n && req_valid &&
        (req_addr[1:0] != 2'b00))
      $display("[SRAM] WARNING: unaligned word access addr=0x%08X t=%0t",
               req_addr, $time);
  end
  `endif
  // pragma translate_on

endmodule
