// ============================================================================
// FILE        : soc_pkg.sv
// PROJECT     : SoC Integration Framework
// DESCRIPTION : Global package — address map, bus types, register offsets,
//               interrupt IDs, and synthesis-safe helper functions.
//
// Memory Map
// ──────────────────────────────────────────────────────────────────────────
//  Region          │ Base         │ Top          │ Size  │ Slave ID
//  ────────────────┼──────────────┼──────────────┼───────┼─────────
//  Boot ROM        │ 0x0000_0000  │ 0x0000_FFFF  │  64KB │  0
//  SRAM            │ 0x2000_0000  │ 0x2001_FFFF  │ 128KB │  1
//  Timer           │ 0x4000_0000  │ 0x4000_0FFF  │   4KB │  2
//  GPIO            │ 0x4000_1000  │ 0x4000_1FFF  │   4KB │  3
//  UART            │ 0x4000_2000  │ 0x4000_2FFF  │   4KB │  4
//  IRQ Controller  │ 0x4000_3000  │ 0x4000_3FFF  │   4KB │  5
// ============================================================================

package soc_pkg;

  // ─── Global Bus Width ──────────────────────────────────────────────────────
  localparam int ADDR_W     = 32;
  localparam int DATA_W     = 32;
  localparam int STRB_W     = DATA_W / 8;

  // ─── SoC Configuration ────────────────────────────────────────────────────
  localparam int NUM_SLAVES  = 6;
  localparam int NUM_IRQS    = 8;
  localparam int CLK_FREQ_HZ = 50_000_000;    // 50 MHz reference

  // ─── Address Map: Base Addresses ──────────────────────────────────────────
  localparam logic [ADDR_W-1:0] BOOT_ROM_BASE  = 32'h0000_0000;
  localparam logic [ADDR_W-1:0] SRAM_BASE       = 32'h2000_0000;
  localparam logic [ADDR_W-1:0] TIMER_BASE      = 32'h4000_0000;
  localparam logic [ADDR_W-1:0] GPIO_BASE       = 32'h4000_1000;
  localparam logic [ADDR_W-1:0] UART_BASE       = 32'h4000_2000;
  localparam logic [ADDR_W-1:0] IRQ_CTRL_BASE   = 32'h4000_3000;

  // ─── Address Map: Range Masks (bits that vary within a region) ────────────
  //   in_range(addr) = ((addr & ~MASK) == BASE)
  localparam logic [ADDR_W-1:0] BOOT_ROM_MASK  = 32'h0000_FFFF;  //  64 KB
  localparam logic [ADDR_W-1:0] SRAM_MASK       = 32'h0001_FFFF;  // 128 KB
  localparam logic [ADDR_W-1:0] TIMER_MASK      = 32'h0000_0FFF;  //   4 KB
  localparam logic [ADDR_W-1:0] GPIO_MASK       = 32'h0000_0FFF;
  localparam logic [ADDR_W-1:0] UART_MASK       = 32'h0000_0FFF;
  localparam logic [ADDR_W-1:0] IRQ_CTRL_MASK   = 32'h0000_0FFF;

  // ─── Slave Index Constants ─────────────────────────────────────────────────
  localparam int S_BOOT_ROM  = 0;
  localparam int S_SRAM      = 1;
  localparam int S_TIMER     = 2;
  localparam int S_GPIO      = 3;
  localparam int S_UART      = 4;
  localparam int S_IRQ_CTRL  = 5;
  localparam int S_NONE      = 7;  // sentinel — decode error

  // ─── Reset Vector ──────────────────────────────────────────────────────────
  localparam logic [ADDR_W-1:0] RESET_VECTOR = 32'h0000_0000;

  // ─── Interrupt Source IDs ──────────────────────────────────────────────────
  localparam int IRQ_TIMER   = 0;
  localparam int IRQ_GPIO    = 1;
  localparam int IRQ_UART_RX = 2;
  localparam int IRQ_UART_TX = 3;

  // ─── Timer Register Offsets (byte) ────────────────────────────────────────
  //  CTRL   [2:0]  {auto_reload, irq_en, enable}
  //  RELOAD [31:0] reload value
  //  VALUE  [31:0] current counter (read-only)
  //  STATUS [0]    expired flag (W1C)
  localparam logic [11:0] TIMER_REG_CTRL   = 12'h000;
  localparam logic [11:0] TIMER_REG_RELOAD = 12'h004;
  localparam logic [11:0] TIMER_REG_VALUE  = 12'h008;
  localparam logic [11:0] TIMER_REG_STATUS = 12'h00C;

  // ─── GPIO Register Offsets (byte) ─────────────────────────────────────────
  //  DIR     [31:0] 1=output, 0=input
  //  OUT     [31:0] output data register
  //  IN      [31:0] sampled input (read-only)
  //  IRQ_EN  [31:0] rising-edge IRQ enable per pin
  //  IRQ_ST  [31:0] IRQ status (W1C)
  localparam logic [11:0] GPIO_REG_DIR    = 12'h000;
  localparam logic [11:0] GPIO_REG_OUT    = 12'h004;
  localparam logic [11:0] GPIO_REG_IN     = 12'h008;
  localparam logic [11:0] GPIO_REG_IRQ_EN = 12'h00C;
  localparam logic [11:0] GPIO_REG_IRQ_ST = 12'h010;

  // ─── UART Register Offsets (byte) ─────────────────────────────────────────
  //  DATA   [7:0]  TX write / RX read
  //  STATUS [3:0]  {rx_err, rx_valid, tx_empty, tx_ready}
  //  CTRL   [1:0]  {rx_irq_en, tx_irq_en}
  //  BAUD   [31:0] bit-period divisor  (CLK_FREQ / baud_rate)
  localparam logic [11:0] UART_REG_DATA   = 12'h000;
  localparam logic [11:0] UART_REG_STATUS = 12'h004;
  localparam logic [11:0] UART_REG_CTRL   = 12'h008;
  localparam logic [11:0] UART_REG_BAUD   = 12'h00C;

  // ─── IRQ Controller Register Offsets (byte) ───────────────────────────────
  //  ENABLE  [NUM_IRQS-1:0] per-source enable
  //  PENDING [NUM_IRQS-1:0] latched (W1C to clear)
  //  ACTIVE  [NUM_IRQS-1:0] ENABLE & PENDING (read-only)
  localparam logic [11:0] IRQ_REG_ENABLE  = 12'h000;
  localparam logic [11:0] IRQ_REG_PENDING = 12'h004;
  localparam logic [11:0] IRQ_REG_ACTIVE  = 12'h008;

  // ─── Bus Struct Types ──────────────────────────────────────────────────────
  typedef struct packed {
    logic [ADDR_W-1:0] addr;
    logic [DATA_W-1:0] wdata;
    logic [STRB_W-1:0] wstrb;
    logic              write;
  } bus_req_t;

  typedef struct packed {
    logic [DATA_W-1:0] rdata;
    logic              error;
  } bus_rsp_t;

  // ─── Address Range Helper ──────────────────────────────────────────────────
  // Usage: in_range(addr, PERIPH_BASE, PERIPH_MASK)
  function automatic logic in_range(
    input logic [ADDR_W-1:0] addr,
    input logic [ADDR_W-1:0] base,
    input logic [ADDR_W-1:0] mask
  );
    return (addr & ~mask) == base;
  endfunction

endpackage
