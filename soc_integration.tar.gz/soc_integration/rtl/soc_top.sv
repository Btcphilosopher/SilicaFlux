// ============================================================================
// FILE        : soc_top.sv
// PROJECT     : SoC Integration Framework
// DESCRIPTION : Top-level SoC integration wrapper.
//               Uses flat SSB signals throughout (IVerilog-12 compatible).
//
// External master (CPU or testbench BFM) drives the cpu_req_*/cpu_rsp_* ports.
// cpu_if_adapter.sv bridges a dual-port RV32I CPU core to this interface.
// ============================================================================

module soc_top
  import soc_pkg::*;
(
  input  logic        clk,
  input  logic        rst_n,

  // ─── CPU / BFM master bus ─────────────────────────────────────────────────
  input  logic              cpu_req_valid,
  output logic              cpu_req_ready,
  input  logic [ADDR_W-1:0] cpu_req_addr,
  input  logic              cpu_req_write,
  input  logic [DATA_W-1:0] cpu_req_wdata,
  input  logic [STRB_W-1:0] cpu_req_wstrb,
  output logic              cpu_rsp_valid,
  input  logic              cpu_rsp_ready,
  output logic [DATA_W-1:0] cpu_rsp_rdata,
  output logic              cpu_rsp_error,

  // ─── GPIO ─────────────────────────────────────────────────────────────────
  input  logic [31:0] gpio_in,
  output logic [31:0] gpio_out,
  output logic [31:0] gpio_oe,

  // ─── UART ─────────────────────────────────────────────────────────────────
  output logic uart_txd,
  input  logic uart_rxd,

  // ─── IRQ to CPU ───────────────────────────────────────────────────────────
  output logic cpu_irq_o
);

  // ─── Fabric flat slave arrays ─────────────────────────────────────────────
  localparam int NS = NUM_SLAVES;

  logic [NS-1:0]          s_req_valid;
  logic [NS-1:0]          s_req_ready;
  logic [NS*ADDR_W-1:0]   s_req_addr;
  logic [NS-1:0]          s_req_write;
  logic [NS*DATA_W-1:0]   s_req_wdata;
  logic [NS*STRB_W-1:0]   s_req_wstrb;
  logic [NS-1:0]          s_rsp_valid;
  logic [NS-1:0]          s_rsp_ready;
  logic [NS*DATA_W-1:0]   s_rsp_rdata;
  logic [NS-1:0]          s_rsp_error;

  // ─── Fabric ───────────────────────────────────────────────────────────────
  soc_fabric #(.NS(NS)) u_fabric (
    .clk         (clk),
    .rst_n       (rst_n),
    .m_req_valid (cpu_req_valid),
    .m_req_ready (cpu_req_ready),
    .m_req_addr  (cpu_req_addr),
    .m_req_write (cpu_req_write),
    .m_req_wdata (cpu_req_wdata),
    .m_req_wstrb (cpu_req_wstrb),
    .m_rsp_valid (cpu_rsp_valid),
    .m_rsp_ready (cpu_rsp_ready),
    .m_rsp_rdata (cpu_rsp_rdata),
    .m_rsp_error (cpu_rsp_error),
    .s_req_valid (s_req_valid),
    .s_req_ready (s_req_ready),
    .s_req_addr  (s_req_addr),
    .s_req_write (s_req_write),
    .s_req_wdata (s_req_wdata),
    .s_req_wstrb (s_req_wstrb),
    .s_rsp_valid (s_rsp_valid),
    .s_rsp_ready (s_rsp_ready),
    .s_rsp_rdata (s_rsp_rdata),
    .s_rsp_error (s_rsp_error)
  );

  // ─── Shorthand macros for connecting slave i ──────────────────────────────
  // Each slave gets: clk, rst_n, and the 10 flat bus signals sliced from arrays

  // ─── S0: Boot ROM ─────────────────────────────────────────────────────────
  boot_rom u_rom (
    .clk       (clk),
    .rst_n     (rst_n),
    .req_valid (s_req_valid[S_BOOT_ROM]),
    .req_ready (s_req_ready[S_BOOT_ROM]),
    .req_addr  (s_req_addr [S_BOOT_ROM*ADDR_W +: ADDR_W]),
    .req_write (s_req_write[S_BOOT_ROM]),
    .req_wdata (s_req_wdata[S_BOOT_ROM*DATA_W +: DATA_W]),
    .req_wstrb (s_req_wstrb[S_BOOT_ROM*STRB_W +: STRB_W]),
    .rsp_valid (s_rsp_valid[S_BOOT_ROM]),
    .rsp_ready (s_rsp_ready[S_BOOT_ROM]),
    .rsp_rdata (s_rsp_rdata[S_BOOT_ROM*DATA_W +: DATA_W]),
    .rsp_error (s_rsp_error[S_BOOT_ROM])
  );

  // ─── S1: SRAM ─────────────────────────────────────────────────────────────
  soc_sram u_sram (
    .clk       (clk),
    .rst_n     (rst_n),
    .req_valid (s_req_valid[S_SRAM]),
    .req_ready (s_req_ready[S_SRAM]),
    .req_addr  (s_req_addr [S_SRAM*ADDR_W +: ADDR_W]),
    .req_write (s_req_write[S_SRAM]),
    .req_wdata (s_req_wdata[S_SRAM*DATA_W +: DATA_W]),
    .req_wstrb (s_req_wstrb[S_SRAM*STRB_W +: STRB_W]),
    .rsp_valid (s_rsp_valid[S_SRAM]),
    .rsp_ready (s_rsp_ready[S_SRAM]),
    .rsp_rdata (s_rsp_rdata[S_SRAM*DATA_W +: DATA_W]),
    .rsp_error (s_rsp_error[S_SRAM])
  );

  // ─── S2: Timer ────────────────────────────────────────────────────────────
  logic timer_irq;

  soc_timer u_timer (
    .clk       (clk),
    .rst_n     (rst_n),
    .req_valid (s_req_valid[S_TIMER]),
    .req_ready (s_req_ready[S_TIMER]),
    .req_addr  (s_req_addr [S_TIMER*ADDR_W +: ADDR_W]),
    .req_write (s_req_write[S_TIMER]),
    .req_wdata (s_req_wdata[S_TIMER*DATA_W +: DATA_W]),
    .req_wstrb (s_req_wstrb[S_TIMER*STRB_W +: STRB_W]),
    .rsp_valid (s_rsp_valid[S_TIMER]),
    .rsp_ready (s_rsp_ready[S_TIMER]),
    .rsp_rdata (s_rsp_rdata[S_TIMER*DATA_W +: DATA_W]),
    .rsp_error (s_rsp_error[S_TIMER]),
    .irq_o     (timer_irq)
  );

  // ─── S3: GPIO ─────────────────────────────────────────────────────────────
  logic gpio_irq;

  soc_gpio u_gpio (
    .clk        (clk),
    .rst_n      (rst_n),
    .req_valid  (s_req_valid[S_GPIO]),
    .req_ready  (s_req_ready[S_GPIO]),
    .req_addr   (s_req_addr [S_GPIO*ADDR_W +: ADDR_W]),
    .req_write  (s_req_write[S_GPIO]),
    .req_wdata  (s_req_wdata[S_GPIO*DATA_W +: DATA_W]),
    .req_wstrb  (s_req_wstrb[S_GPIO*STRB_W +: STRB_W]),
    .rsp_valid  (s_rsp_valid[S_GPIO]),
    .rsp_ready  (s_rsp_ready[S_GPIO]),
    .rsp_rdata  (s_rsp_rdata[S_GPIO*DATA_W +: DATA_W]),
    .rsp_error  (s_rsp_error[S_GPIO]),
    .gpio_in_i  (gpio_in),
    .gpio_out_o (gpio_out),
    .gpio_oe_o  (gpio_oe),
    .irq_o      (gpio_irq)
  );

  // ─── S4: UART ─────────────────────────────────────────────────────────────
  logic uart_rx_irq, uart_tx_irq;

  soc_uart u_uart (
    .clk        (clk),
    .rst_n      (rst_n),
    .req_valid  (s_req_valid[S_UART]),
    .req_ready  (s_req_ready[S_UART]),
    .req_addr   (s_req_addr [S_UART*ADDR_W +: ADDR_W]),
    .req_write  (s_req_write[S_UART]),
    .req_wdata  (s_req_wdata[S_UART*DATA_W +: DATA_W]),
    .req_wstrb  (s_req_wstrb[S_UART*STRB_W +: STRB_W]),
    .rsp_valid  (s_rsp_valid[S_UART]),
    .rsp_ready  (s_rsp_ready[S_UART]),
    .rsp_rdata  (s_rsp_rdata[S_UART*DATA_W +: DATA_W]),
    .rsp_error  (s_rsp_error[S_UART]),
    .uart_txd_o (uart_txd),
    .uart_rxd_i (uart_rxd),
    .tx_irq_o   (uart_tx_irq),
    .rx_irq_o   (uart_rx_irq)
  );

  // ─── S5: IRQ Controller ───────────────────────────────────────────────────
  logic [NUM_IRQS-1:0] irq_src;
  logic [2:0]          irq_id;

  assign irq_src[IRQ_TIMER]   = timer_irq;
  assign irq_src[IRQ_GPIO]    = gpio_irq;
  assign irq_src[IRQ_UART_RX] = uart_rx_irq;
  assign irq_src[IRQ_UART_TX] = uart_tx_irq;
  assign irq_src[7:4]         = 4'b0;

  soc_irq_ctrl #(.NIRQ(NUM_IRQS)) u_irq_ctrl (
    .clk       (clk),
    .rst_n     (rst_n),
    .req_valid (s_req_valid[S_IRQ_CTRL]),
    .req_ready (s_req_ready[S_IRQ_CTRL]),
    .req_addr  (s_req_addr [S_IRQ_CTRL*ADDR_W +: ADDR_W]),
    .req_write (s_req_write[S_IRQ_CTRL]),
    .req_wdata (s_req_wdata[S_IRQ_CTRL*DATA_W +: DATA_W]),
    .req_wstrb (s_req_wstrb[S_IRQ_CTRL*STRB_W +: STRB_W]),
    .rsp_valid (s_rsp_valid[S_IRQ_CTRL]),
    .rsp_ready (s_rsp_ready[S_IRQ_CTRL]),
    .rsp_rdata (s_rsp_rdata[S_IRQ_CTRL*DATA_W +: DATA_W]),
    .rsp_error (s_rsp_error[S_IRQ_CTRL]),
    .irq_src_i (irq_src),
    .irq_o     (cpu_irq_o),
    .irq_id_o  (irq_id)
  );

endmodule
