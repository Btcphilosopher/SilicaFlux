// ============================================================================
// FILE        : soc_gpio.sv
// PROJECT     : SoC Integration Framework
// DESCRIPTION : 32-bit GPIO with SSB slave interface.
//
// Register Map (byte offsets)
// ──────────────────────────────────────────────────────────────────────────
//  0x000  DIR     [31:0] pin direction — 1 = output, 0 = input
//  0x004  OUT     [31:0] output data register
//  0x008  IN      [31:0] synchronised input snapshot (read-only)
//  0x00C  IRQ_EN  [31:0] rising-edge interrupt enable per pin
//  0x010  IRQ_ST  [31:0] interrupt status — W1C to clear
//
// Input path:  gpio_in_i → 2-FF metastability filter → edge detect
// Output path: gpio_out_o driven by OUT register; direction indicated by
//              gpio_oe_o (1 = driving output, 0 = high-Z / input).
// IRQ:         asserted (level) when any (IRQ_EN & IRQ_ST) bit is set.
// ============================================================================

module soc_gpio
(
  input  logic        clk,
  input  logic        rst_n,
  // SSB slave bus
  input  logic        req_valid,
  output logic        req_ready,
  input  logic [31:0] req_addr,
  input  logic        req_write,
  input  logic [31:0] req_wdata,
  input  logic  [3:0] req_wstrb,
  output logic        rsp_valid,
  input  logic        rsp_ready,
  output logic [31:0] rsp_rdata,
  output logic        rsp_error,
  input  logic [31:0] gpio_in_i,
  output logic [31:0] gpio_out_o,
  output logic [31:0] gpio_oe_o,    // 1 = output-enable for each pin
  output logic        irq_o
);
  import soc_pkg::*;

  // ─── Register storage ─────────────────────────────────────────────────────
  logic [31:0] dir_q;
  logic [31:0] out_q;
  logic [31:0] irq_en_q;
  logic [31:0] irq_st_q;

  // ─── Input synchroniser (2-FF) ────────────────────────────────────────────
  logic [31:0] sync1_q, sync2_q, prev_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sync1_q <= '0;
      sync2_q <= '0;
      prev_q  <= '0;
    end else begin
      sync1_q <= gpio_in_i;
      sync2_q <= sync1_q;
      prev_q  <= sync2_q;
    end
  end

  wire [31:0] rise_edge = sync2_q & ~prev_q;  // rising edges on input pins

  // ─── Register decode helpers ──────────────────────────────────────────────
  wire [9:0] reg_idx = req_addr[11:2];

  localparam logic [9:0] IDX_DIR    = 10'(GPIO_REG_DIR   [11:2]);
  localparam logic [9:0] IDX_OUT    = 10'(GPIO_REG_OUT   [11:2]);
  localparam logic [9:0] IDX_IN     = 10'(GPIO_REG_IN    [11:2]);
  localparam logic [9:0] IDX_IRQ_EN = GPIO_REG_IRQ_EN[11:2];
  localparam logic [9:0] IDX_IRQ_ST = GPIO_REG_IRQ_ST[11:2];

  // ─── Functional register logic ────────────────────────────────────────────
  logic w_dir, w_out, w_irq_en, w_irq_st;
  assign w_dir    = req_valid && req_write && (reg_idx == IDX_DIR);
  assign w_out    = req_valid && req_write && (reg_idx == IDX_OUT);
  assign w_irq_en = req_valid && req_write && (reg_idx == IDX_IRQ_EN);
  assign w_irq_st = req_valid && req_write && (reg_idx == IDX_IRQ_ST);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      dir_q    <= '0;
      out_q    <= '0;
      irq_en_q <= '0;
      irq_st_q <= '0;
    end else begin
      if (w_dir)    dir_q    <= req_wdata;
      if (w_out)    out_q    <= req_wdata;
      if (w_irq_en) irq_en_q <= req_wdata;

      // IRQ_ST: set on rising edge (enabled pins), W1C clear
      irq_st_q <= (irq_st_q & ~(w_irq_st ? req_wdata : '0))
                | (rise_edge & irq_en_q);
    end
  end

  // ─── SSB response pipeline ────────────────────────────────────────────────
  logic [DATA_W-1:0] rsp_data_q;
  logic              rsp_vld_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rsp_data_q <= '0;
      rsp_vld_q  <= 1'b0;
    end else begin
      if (req_valid && req_ready) begin
        rsp_vld_q <= 1'b1;
        if (!req_write) begin
          case (reg_idx)
            IDX_DIR:    rsp_data_q <= dir_q;
            IDX_OUT:    rsp_data_q <= out_q;
            IDX_IN:     rsp_data_q <= sync2_q;
            IDX_IRQ_EN: rsp_data_q <= irq_en_q;
            IDX_IRQ_ST: rsp_data_q <= irq_st_q;
            default:    rsp_data_q <= 32'hDEAD_BEEF;
          endcase
        end else begin
          rsp_data_q <= '0;
        end
      end
      if (rsp_valid && rsp_ready)
        rsp_vld_q <= 1'b0;
    end
  end

  // ─── Bus outputs ──────────────────────────────────────────────────────────
  assign req_ready = 1'b1;
  assign rsp_valid = rsp_vld_q;
  assign rsp_rdata = rsp_data_q;
  assign rsp_error = 1'b0;

  // ─── Pad outputs ──────────────────────────────────────────────────────────
  assign gpio_out_o = out_q;
  assign gpio_oe_o  = dir_q;

  // ─── IRQ output ───────────────────────────────────────────────────────────
  assign irq_o = |(irq_st_q & irq_en_q);

endmodule
