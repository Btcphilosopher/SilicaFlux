// ============================================================================
// FILE        : soc_timer.sv
// PROJECT     : SoC Integration Framework
// DESCRIPTION : 32-bit countdown timer with SSB slave interface.
//
// Register Map (byte offsets, word-aligned access)
// ──────────────────────────────────────────────────────────────────────────
//  0x000  CTRL    [2:0]  {auto_reload, irq_en, enable}
//  0x004  RELOAD  [31:0] reload value (loaded when timer expires or on start)
//  0x008  VALUE   [31:0] current counter (read only; writes are ignored)
//  0x00C  STATUS  [0]    expired flag  — W1C to clear
//
// Operation
//  • Counter counts from RELOAD down to 0.
//  • On reaching 0: expired flag is set; if auto_reload → counter reloads;
//    else counter stays at 0.
//  • IRQ output is level-high while (irq_en && expired).
//  • Writing 1 to STATUS[0] clears the expired flag (W1C).
// ============================================================================

module soc_timer
(
  input  logic        clk,
  input  logic        rst_n,
  // SSB slave bus
  input  logic        req_valid,
  output logic        req_ready,
  input  logic [31:0] req_addr,
  input  logic        req_write,
  input  logic [31:0] req_wdata,
  input  logic  [3:0] req_wstrb,
  output logic        rsp_valid,
  input  logic        rsp_ready,
  output logic [31:0] rsp_rdata,
  output logic        rsp_error,

  output logic     irq_o
);
  import soc_pkg::*;

  // ─── Register storage ─────────────────────────────────────────────────────
  logic        enable_q;
  logic        irq_en_q;
  logic        auto_rld_q;
  logic [31:0] reload_q;
  logic [31:0] cnt_q;
  logic        expired_q;

  // ─── SSB response pipeline ────────────────────────────────────────────────
  logic [DATA_W-1:0] rsp_data_q;
  logic              rsp_vld_q;

  // ─── Register decode helpers ──────────────────────────────────────────────
  // Word-address = req_addr[11:2] (4-KB aperture, word-aligned)
  wire [9:0] reg_idx = req_addr[11:2];

  // Localparams for register word indices
  localparam logic [9:0] IDX_CTRL   = 10'(TIMER_REG_CTRL  [11:2]);
  localparam logic [9:0] IDX_RELOAD = TIMER_REG_RELOAD[11:2];
  localparam logic [9:0] IDX_VALUE  = 10'(TIMER_REG_VALUE [11:2]);
  localparam logic [9:0] IDX_STATUS = TIMER_REG_STATUS[11:2];

  // ─── Timer functional logic ───────────────────────────────────────────────
  // Decode write strobes from bus
  logic w_ctrl, w_reload, w_status;
  logic status_clr;

  assign w_ctrl   = req_valid && req_write && (reg_idx == IDX_CTRL);
  assign w_reload = req_valid && req_write && (reg_idx == IDX_RELOAD);
  assign w_status = req_valid && req_write && (reg_idx == IDX_STATUS);
  assign status_clr = w_status && req_wdata[0];

  // Timer fire condition: enabled and just reached 0
  wire timer_fire = enable_q && (cnt_q == 32'h0);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      enable_q   <= 1'b0;
      irq_en_q   <= 1'b0;
      auto_rld_q <= 1'b0;
      reload_q   <= 32'd0;
      cnt_q      <= 32'd0;
      expired_q  <= 1'b0;
    end else begin
      // ── Register writes ──
      if (w_ctrl) begin
        enable_q   <= req_wdata[0];
        irq_en_q   <= req_wdata[1];
        auto_rld_q <= req_wdata[2];
        // On enable rising edge, load counter from RELOAD
        if (req_wdata[0] && !enable_q)
          cnt_q <= reload_q;
      end
      if (w_reload)
        reload_q <= req_wdata;

      // ── Expired flag (set on fire, W1C clear) ──
      expired_q <= timer_fire | (expired_q & ~status_clr);

      // ── Counter logic ──
      if (enable_q) begin
        if (timer_fire)
          cnt_q <= auto_rld_q ? reload_q : 32'h0;
        else
          cnt_q <= cnt_q - 32'h1;
      end
    end
  end

  // ─── SSB register read / response pipeline ────────────────────────────────
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rsp_data_q <= '0;
      rsp_vld_q  <= 1'b0;
    end else begin
      if (req_valid && req_ready) begin
        rsp_vld_q  <= 1'b1;
        if (!req_write) begin
          case (reg_idx)
            IDX_CTRL:   rsp_data_q <= {29'b0, auto_rld_q, irq_en_q, enable_q};
            IDX_RELOAD: rsp_data_q <= reload_q;
            IDX_VALUE:  rsp_data_q <= cnt_q;
            IDX_STATUS: rsp_data_q <= {31'b0, expired_q};
            default:    rsp_data_q <= 32'hDEAD_BEEF;
          endcase
        end else begin
          rsp_data_q <= '0;
        end
      end
      if (rsp_valid && rsp_ready)
        rsp_vld_q <= 1'b0;
    end
  end

  // ─── Bus outputs ──────────────────────────────────────────────────────────
  assign req_ready = 1'b1;
  assign rsp_valid = rsp_vld_q;
  assign rsp_rdata = rsp_data_q;
  assign rsp_error = 1'b0;

  // ─── IRQ output ───────────────────────────────────────────────────────────
  assign irq_o = irq_en_q & expired_q;

endmodule
