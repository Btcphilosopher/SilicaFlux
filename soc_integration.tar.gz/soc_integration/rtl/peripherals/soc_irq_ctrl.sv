// ============================================================================
// FILE        : soc_irq_ctrl.sv
// PROJECT     : SoC Integration Framework
// DESCRIPTION : Simple vectored interrupt controller with SSB slave interface.
//
// Register Map (byte offsets)
// ──────────────────────────────────────────────────────────────────────────
//  0x000  ENABLE  [NUM_IRQS-1:0]  per-source enable (RW)
//  0x004  PENDING [NUM_IRQS-1:0]  latched pending flags — W1C to clear
//  0x008  ACTIVE  [NUM_IRQS-1:0]  ENABLE & PENDING (read-only)
//
// Behaviour
//  • PENDING[i] is set on the rising edge of a synchronised irq_src_i[i].
//  • PENDING bits survive until explicitly cleared by a W1C write.
//  • ACTIVE = ENABLE & PENDING.
//  • irq_o is asserted (level) while any ACTIVE bit is set.
//  • irq_id_o carries the index of the lowest set bit in ACTIVE
//    (lower index = higher priority), or NUM_IRQS if none is active.
//
// Source assignment (matches soc_pkg.sv)
//  [0] = Timer      [1] = GPIO     [2] = UART RX   [3] = UART TX
// ============================================================================

module soc_irq_ctrl
#(
  parameter int NIRQ = 8
)(
  input  logic        clk,
  input  logic        rst_n,
  // SSB slave bus
  input  logic        req_valid,
  output logic        req_ready,
  input  logic [31:0] req_addr,
  input  logic        req_write,
  input  logic [31:0] req_wdata,
  input  logic  [3:0] req_wstrb,
  output logic        rsp_valid,
  input  logic        rsp_ready,
  output logic [31:0] rsp_rdata,
  output logic        rsp_error,
  input  logic [NIRQ-1:0]   irq_src_i,   // asynchronous (or same-domain) sources
  output logic              irq_o,
  output logic [2:0]              irq_id_o
);
  import soc_pkg::*;

  // ─── Register storage ─────────────────────────────────────────────────────
  logic [NIRQ-1:0] enable_q;
  logic [NIRQ-1:0] pending_q;

  wire  [NIRQ-1:0] active_w = enable_q & pending_q;

  // ─── Synchroniser + edge detector ────────────────────────────────────────
  logic [NIRQ-1:0] sync1_q, sync2_q, prev_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sync1_q <= '0;
      sync2_q <= '0;
      prev_q  <= '0;
    end else begin
      sync1_q <= irq_src_i;
      sync2_q <= sync1_q;
      prev_q  <= sync2_q;
    end
  end

  wire [NIRQ-1:0] posedge_w = sync2_q & ~prev_q;  // rising edges

  // ─── Register decode helpers ──────────────────────────────────────────────
  wire [9:0] reg_idx = req_addr[11:2];

  localparam logic [9:0] IDX_ENABLE  = 10'(IRQ_REG_ENABLE [11:2]);
  localparam logic [9:0] IDX_PENDING = IRQ_REG_PENDING[11:2];
  localparam logic [9:0] IDX_ACTIVE  = 10'(IRQ_REG_ACTIVE [11:2]);

  // ─── PENDING: set on rising edge, cleared by W1C ─────────────────────────
  logic pending_clr_en;
  logic [NIRQ-1:0] pending_clr_mask;

  assign pending_clr_en   = req_valid && req_write && (reg_idx == IDX_PENDING);
  assign pending_clr_mask = pending_clr_en ? req_wdata[NIRQ-1:0] : '0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      enable_q  <= '0;
      pending_q <= '0;
    end else begin
      if (req_valid && req_write && (reg_idx == IDX_ENABLE))
        enable_q <= req_wdata[NIRQ-1:0];

      // Set on posedge; W1C clear (fire takes priority when both same cycle)
      pending_q <= (pending_q | posedge_w) & ~pending_clr_mask;
    end
  end

  // ─── Priority encoder (lower index = higher priority) ────────────────────
  always_comb begin
    irq_id_o = 3'(NIRQ);  // default: none active
    for (int i = NIRQ-1; i >= 0; i--)
      if (active_w[i]) irq_id_o = 3'(i);
  end

  // ─── SSB response pipeline ────────────────────────────────────────────────
  logic [DATA_W-1:0] rsp_data_q;
  logic              rsp_vld_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rsp_data_q <= '0;
      rsp_vld_q  <= 1'b0;
    end else begin
      if (req_valid && req_ready) begin
        rsp_vld_q <= 1'b1;
        if (!req_write) begin
          case (reg_idx)
            IDX_ENABLE:  rsp_data_q <= {{(DATA_W-NIRQ){1'b0}}, enable_q};
            IDX_PENDING: rsp_data_q <= {{(DATA_W-NIRQ){1'b0}}, pending_q};
            IDX_ACTIVE:  rsp_data_q <= {{(DATA_W-NIRQ){1'b0}}, active_w};
            default:     rsp_data_q <= 32'hDEAD_BEEF;
          endcase
        end else begin
          rsp_data_q <= '0;
        end
      end
      if (rsp_valid && rsp_ready)
        rsp_vld_q <= 1'b0;
    end
  end

  // ─── Bus outputs ──────────────────────────────────────────────────────────
  assign req_ready = 1'b1;
  assign rsp_valid = rsp_vld_q;
  assign rsp_rdata = rsp_data_q;
  assign rsp_error = 1'b0;

  // ─── IRQ output ───────────────────────────────────────────────────────────
  assign irq_o = |active_w;

endmodule
