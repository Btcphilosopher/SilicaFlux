// ============================================================================
// FILE        : soc_uart.sv
// PROJECT     : SoC Integration Framework
// DESCRIPTION : Full-duplex UART with SSB slave interface.
//
// Register Map (byte offsets)
// ──────────────────────────────────────────────────────────────────────────
//  0x000  DATA    [7:0]   write = TX (push to TX FIFO)
//                         read  = RX (pop from RX FIFO; 0 if empty)
//  0x004  STATUS  [3:0]   {rx_err, rx_valid, tx_empty, tx_ready}
//                         tx_ready = TX FIFO not full
//                         rx_valid = RX FIFO not empty
//  0x008  CTRL    [1:0]   {rx_irq_en, tx_irq_en}
//  0x00C  BAUD    [31:0]  bit-period divisor  (CLK_FREQ / baud_rate)
//                         Default 434 → 50 MHz / 115200
//
// Protocol:  8N1 (8 data bits, no parity, 1 stop bit)
// TX FIFO:   8 entries deep; write to DATA when tx_ready=1
// RX FIFO:   8 entries deep; read from DATA when rx_valid=1
// IRQ:       tx_irq fires when FIFO transitions to empty (1 char sent)
//            rx_irq fires when RX FIFO becomes non-empty
// ============================================================================

module soc_uart
(
  input  logic        clk,
  input  logic        rst_n,
  // SSB slave bus
  input  logic        req_valid,
  output logic        req_ready,
  input  logic [31:0] req_addr,
  input  logic        req_write,
  input  logic [31:0] req_wdata,
  input  logic  [3:0] req_wstrb,
  output logic        rsp_valid,
  input  logic        rsp_ready,
  output logic [31:0] rsp_rdata,
  output logic        rsp_error,

  output logic     uart_txd_o,
  input  logic     uart_rxd_i,
  output logic     tx_irq_o,
  output logic     rx_irq_o
);
  import soc_pkg::*;

  // ─── BAUD register ────────────────────────────────────────────────────────
  localparam logic [31:0] DEFAULT_BAUD = 32'd434;  // 50 MHz / 115 200

  logic [31:0] baud_div_q;

  // ─── Register decode helpers ──────────────────────────────────────────────
  wire [9:0] reg_idx = req_addr[11:2];

  localparam logic [9:0] IDX_DATA   = 10'(UART_REG_DATA  [11:2]);
  localparam logic [9:0] IDX_STATUS = UART_REG_STATUS[11:2];
  localparam logic [9:0] IDX_CTRL   = 10'(UART_REG_CTRL  [11:2]);
  localparam logic [9:0] IDX_BAUD   = 10'(UART_REG_BAUD  [11:2]);

  // ─── CTRL register ────────────────────────────────────────────────────────
  logic tx_irq_en_q, rx_irq_en_q;

  // =========================================================================
  //  TX path
  // =========================================================================

  // ─── TX FIFO (8-entry circular buffer) ───────────────────────────────────
  localparam int FIFO_DEPTH = 8;

  logic [7:0] tx_fifo  [0:FIFO_DEPTH-1];
  logic [2:0] tx_wr_q, tx_rd_q;
  logic [3:0] tx_cnt_q;              // 0..8

  wire tx_full  = (tx_cnt_q == 4'd8);
  wire tx_empty = (tx_cnt_q == 4'd0);

  // TX FIFO push from CPU (write to DATA register)
  logic tx_push;
  assign tx_push = req_valid && req_write &&
                   (reg_idx == IDX_DATA) && !tx_full;

  // TX FIFO pop driven by state machine
  logic tx_pop;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tx_wr_q  <= '0;
      tx_rd_q  <= '0;
      tx_cnt_q <= '0;
    end else begin
      if (tx_push) begin
        tx_fifo[tx_wr_q] <= req_wdata[7:0];
        tx_wr_q <= tx_wr_q + 3'd1;
      end
      if (tx_pop)
        tx_rd_q <= tx_rd_q + 3'd1;

      // Counter: increment on push, decrement on pop
      if (tx_push && !tx_pop) tx_cnt_q <= tx_cnt_q + 4'd1;
      else if (!tx_push && tx_pop) tx_cnt_q <= tx_cnt_q - 4'd1;
    end
  end

  // ─── TX state machine ─────────────────────────────────────────────────────
  typedef enum logic [1:0] {
    TXS_IDLE  = 2'd0,
    TXS_START = 2'd1,
    TXS_DATA  = 2'd2,
    TXS_STOP  = 2'd3
  } tx_st_e;

  tx_st_e   tx_state_q;
  logic [7:0]  tx_shift_q;
  logic [2:0]  tx_bit_q;
  logic [31:0] tx_bcnt_q;   // baud bit counter

  assign tx_pop = (tx_state_q == TXS_IDLE) && !tx_empty;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tx_state_q  <= TXS_IDLE;
      uart_txd_o  <= 1'b1;
      tx_shift_q  <= '0;
      tx_bit_q    <= '0;
      tx_bcnt_q   <= '0;
    end else begin
      case (tx_state_q)
        TXS_IDLE: begin
          uart_txd_o <= 1'b1;
          if (!tx_empty) begin
            tx_shift_q <= tx_fifo[tx_rd_q]; // latch char (pop pulses this cycle)
            tx_bcnt_q  <= baud_div_q - 32'd1;
            tx_state_q <= TXS_START;
          end
        end

        TXS_START: begin
          uart_txd_o <= 1'b0;              // start bit
          if (tx_bcnt_q == 32'd0) begin
            tx_bcnt_q  <= baud_div_q - 32'd1;
            tx_bit_q   <= 3'd0;
            tx_state_q <= TXS_DATA;
          end else begin
            tx_bcnt_q <= tx_bcnt_q - 32'd1;
          end
        end

        TXS_DATA: begin
          uart_txd_o <= tx_shift_q[tx_bit_q];
          if (tx_bcnt_q == 32'd0) begin
            if (tx_bit_q == 3'd7) begin
              tx_bcnt_q  <= baud_div_q - 32'd1;
              tx_state_q <= TXS_STOP;
            end else begin
              tx_bit_q  <= tx_bit_q + 3'd1;
              tx_bcnt_q <= baud_div_q - 32'd1;
            end
          end else begin
            tx_bcnt_q <= tx_bcnt_q - 32'd1;
          end
        end

        TXS_STOP: begin
          uart_txd_o <= 1'b1;             // stop bit
          if (tx_bcnt_q == 32'd0)
            tx_state_q <= TXS_IDLE;
          else
            tx_bcnt_q <= tx_bcnt_q - 32'd1;
        end
      endcase
    end
  end

  // =========================================================================
  //  RX path
  // =========================================================================

  // ─── RX input synchroniser ────────────────────────────────────────────────
  logic rxd_s1, rxd_s2, rxd_prev;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rxd_s1   <= 1'b1;
      rxd_s2   <= 1'b1;
      rxd_prev <= 1'b1;
    end else begin
      rxd_s1   <= uart_rxd_i;
      rxd_s2   <= rxd_s1;
      rxd_prev <= rxd_s2;
    end
  end

  wire rxd_fall = !rxd_s2 && rxd_prev;   // start-bit falling edge

  // ─── RX FIFO ──────────────────────────────────────────────────────────────
  logic [7:0] rx_fifo  [0:FIFO_DEPTH-1];
  logic [2:0] rx_wr_q, rx_rd_q;
  logic [3:0] rx_cnt_q;

  wire rx_full  = (rx_cnt_q == 4'd8);
  wire rx_empty = (rx_cnt_q == 4'd0);

  // RX FIFO push driven by state machine
  logic       rx_push;
  logic [7:0] rx_push_data;

  // RX FIFO pop from CPU (read DATA register)
  logic rx_pop;
  assign rx_pop = req_valid && !req_write &&
                  (reg_idx == IDX_DATA) && !rx_empty;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rx_wr_q  <= '0;
      rx_rd_q  <= '0;
      rx_cnt_q <= '0;
    end else begin
      if (rx_push && !rx_full) begin
        rx_fifo[rx_wr_q] <= rx_push_data;
        rx_wr_q <= rx_wr_q + 3'd1;
      end
      if (rx_pop)
        rx_rd_q <= rx_rd_q + 3'd1;

      if ((rx_push && !rx_full) && !rx_pop) rx_cnt_q <= rx_cnt_q + 4'd1;
      else if (!(rx_push && !rx_full) && rx_pop) rx_cnt_q <= rx_cnt_q - 4'd1;
    end
  end

  // ─── RX state machine ─────────────────────────────────────────────────────
  typedef enum logic [1:0] {
    RXS_IDLE  = 2'd0,
    RXS_START = 2'd1,
    RXS_DATA  = 2'd2,
    RXS_STOP  = 2'd3
  } rx_st_e;

  rx_st_e   rx_state_q;
  logic [7:0]  rx_shift_q;
  logic [2:0]  rx_bit_q;
  logic [31:0] rx_bcnt_q;
  logic        rx_err_q;     // framing error flag

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rx_state_q <= RXS_IDLE;
      rx_shift_q <= '0;
      rx_bit_q   <= '0;
      rx_bcnt_q  <= '0;
      rx_err_q   <= 1'b0;
      rx_push     <= 1'b0;
      rx_push_data <= '0;
    end else begin
      rx_push <= 1'b0;   // default: no push

      case (rx_state_q)
        RXS_IDLE: begin
          if (rxd_fall) begin
            // Start bit detected — wait half a bit period to sample centre
            rx_bcnt_q  <= (baud_div_q >> 1) - 32'd1;
            rx_state_q <= RXS_START;
          end
        end

        RXS_START: begin
          if (rx_bcnt_q == 32'd0) begin
            if (!rxd_s2) begin
              // Confirmed start bit — full period to each data bit
              rx_bcnt_q  <= baud_div_q - 32'd1;
              rx_bit_q   <= 3'd0;
              rx_state_q <= RXS_DATA;
            end else begin
              rx_state_q <= RXS_IDLE;  // glitch / false start
            end
          end else begin
            rx_bcnt_q <= rx_bcnt_q - 32'd1;
          end
        end

        RXS_DATA: begin
          if (rx_bcnt_q == 32'd0) begin
            rx_shift_q[rx_bit_q] <= rxd_s2;
            if (rx_bit_q == 3'd7) begin
              rx_bcnt_q  <= baud_div_q - 32'd1;
              rx_state_q <= RXS_STOP;
            end else begin
              rx_bit_q  <= rx_bit_q + 3'd1;
              rx_bcnt_q <= baud_div_q - 32'd1;
            end
          end else begin
            rx_bcnt_q <= rx_bcnt_q - 32'd1;
          end
        end

        RXS_STOP: begin
          if (rx_bcnt_q == 32'd0) begin
            if (rxd_s2) begin
              // Valid stop bit
              rx_push      <= 1'b1;
              rx_push_data <= rx_shift_q;
            end else begin
              rx_err_q <= 1'b1;   // framing error
            end
            rx_state_q <= RXS_IDLE;
          end else begin
            rx_bcnt_q <= rx_bcnt_q - 32'd1;
          end
        end
      endcase
    end
  end

  // =========================================================================
  //  Bus register access
  // =========================================================================

  logic [DATA_W-1:0] rsp_data_q;
  logic              rsp_vld_q;

  // Snapshot of rx_fifo head for read data
  wire [7:0] rx_head = rx_empty ? 8'h00 : rx_fifo[rx_rd_q];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      baud_div_q   <= DEFAULT_BAUD;
      tx_irq_en_q  <= 1'b0;
      rx_irq_en_q  <= 1'b0;
      rsp_data_q   <= '0;
      rsp_vld_q    <= 1'b0;
    end else begin
      if (req_valid && req_ready) begin
        rsp_vld_q <= 1'b1;
        if (req_write) begin
          case (reg_idx)
            IDX_BAUD: baud_div_q <= (req_wdata == '0) ? DEFAULT_BAUD
                                                           : req_wdata;
            IDX_CTRL: begin
              tx_irq_en_q <= req_wdata[0];
              rx_irq_en_q <= req_wdata[1];
            end
            default: ;
          endcase
          rsp_data_q <= '0;
        end else begin
          case (reg_idx)
            IDX_DATA:   rsp_data_q <= {24'b0, rx_head};
            IDX_STATUS: rsp_data_q <= {28'b0,
                                       rx_err_q, ~rx_empty, tx_empty, ~tx_full};
            IDX_CTRL:   rsp_data_q <= {30'b0, rx_irq_en_q, tx_irq_en_q};
            IDX_BAUD:   rsp_data_q <= baud_div_q;
            default:    rsp_data_q <= 32'hDEAD_BEEF;
          endcase
        end
      end
      if (rsp_valid && rsp_ready)
        rsp_vld_q <= 1'b0;
    end
  end

  // ─── Bus outputs ──────────────────────────────────────────────────────────
  assign req_ready = 1'b1;
  assign rsp_valid = rsp_vld_q;
  assign rsp_rdata = rsp_data_q;
  assign rsp_error = 1'b0;

  // ─── IRQ outputs ──────────────────────────────────────────────────────────
  // TX IRQ: fires when TX FIFO becomes empty (last char sent)
  // RX IRQ: fires when RX FIFO is non-empty
  assign tx_irq_o = tx_irq_en_q & tx_empty & (tx_state_q == TXS_IDLE);
  assign rx_irq_o = rx_irq_en_q & ~rx_empty;

endmodule
