// ============================================================================
// FILE        : soc_bus_if.sv  (IVerilog-12 compatible)
// PROJECT     : SoC Integration Framework
// DESCRIPTION : SoC Simple Bus (SSB) interface — fixed 32-bit, no parameters.
//   Concurrent SVA assertions moved to ifdef FORMAL (iverilog -gassertions).
// ============================================================================

interface soc_bus_if (input logic clk, input logic rst_n);

  // ─── Request Channel ──────────────────────────────────────────────────────
  logic [31:0] req_addr;
  logic [31:0] req_wdata;
  logic [3:0]  req_wstrb;
  logic        req_write;
  logic        req_valid;
  logic        req_ready;

  // ─── Response Channel ─────────────────────────────────────────────────────
  logic [31:0] rsp_rdata;
  logic        rsp_error;
  logic        rsp_valid;
  logic        rsp_ready;

  // ─── Master Modport ───────────────────────────────────────────────────────
  modport master (
    input  clk, rst_n,
    output req_valid, req_addr, req_write, req_wdata, req_wstrb,
    input  req_ready,
    output rsp_ready,
    input  rsp_valid, rsp_rdata, rsp_error
  );

  // ─── Slave Modport ────────────────────────────────────────────────────────
  modport slave (
    input  clk, rst_n,
    input  req_valid, req_addr, req_write, req_wdata, req_wstrb,
    output req_ready,
    input  rsp_ready,
    output rsp_valid, rsp_rdata, rsp_error
  );

  // ─── Monitor Modport ──────────────────────────────────────────────────────
  modport monitor (
    input clk, rst_n,
    input req_valid, req_ready, req_addr, req_write, req_wdata, req_wstrb,
    input rsp_valid, rsp_ready, rsp_rdata, rsp_error
  );

  // ─── Formal / SVA assertions (iverilog -gassertions flag required) ────────
`ifdef FORMAL
  REQ_ADDR_STABLE: assert property (
    @(posedge clk) disable iff (!rst_n)
    (req_valid && !req_ready) |=> $stable(req_addr)
  ) else $error("[SSB] req_addr changed before handshake");

  REQ_WRITE_STABLE: assert property (
    @(posedge clk) disable iff (!rst_n)
    (req_valid && !req_ready) |=> $stable(req_write)
  ) else $error("[SSB] req_write changed before handshake");
`endif

endinterface
