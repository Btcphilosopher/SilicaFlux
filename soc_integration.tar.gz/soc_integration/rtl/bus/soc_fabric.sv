// ============================================================================
// FILE        : soc_fabric.sv  (revised)
// PROJECT     : SoC Integration Framework
// DESCRIPTION : 1-master / N-slave SSB interconnect fabric.
//
// Address decode → request routing → response mux.
// All slaves use 1-cycle request→response latency.
// Active transaction is tracked in active_q / active_sel_q.
// ============================================================================

module soc_fabric
  import soc_pkg::*;
#(
  parameter int NS = NUM_SLAVES
)(
  input  logic clk,
  input  logic rst_n,

  // ─── Master port ────────────────────────────────────────────────────────
  input  logic              m_req_valid,
  output logic              m_req_ready,
  input  logic [ADDR_W-1:0] m_req_addr,
  input  logic              m_req_write,
  input  logic [DATA_W-1:0] m_req_wdata,
  input  logic [STRB_W-1:0] m_req_wstrb,
  output logic              m_rsp_valid,
  input  logic              m_rsp_ready,
  output logic [DATA_W-1:0] m_rsp_rdata,
  output logic              m_rsp_error,

  // ─── Slave ports (packed flat arrays) ───────────────────────────────────
  output logic [NS-1:0]            s_req_valid,
  input  logic [NS-1:0]            s_req_ready,
  output logic [NS*ADDR_W-1:0]     s_req_addr,
  output logic [NS-1:0]            s_req_write,
  output logic [NS*DATA_W-1:0]     s_req_wdata,
  output logic [NS*STRB_W-1:0]     s_req_wstrb,
  input  logic [NS-1:0]            s_rsp_valid,
  output logic [NS-1:0]            s_rsp_ready,
  input  logic [NS*DATA_W-1:0]     s_rsp_rdata,
  input  logic [NS-1:0]            s_rsp_error
);

  // ─── Sel width needs to cover 0..(NS-1) plus sentinel NS ────────────────
  localparam int SEL_W = $clog2(NS + 1);

  // ─── Combinatorial address decode ───────────────────────────────────────
  logic [SEL_W-1:0] sel_d;
  logic             sel_vld_d;

  always_comb begin
    sel_d     = SEL_W'(S_NONE);
    sel_vld_d = 1'b0;
    if      (in_range(m_req_addr, BOOT_ROM_BASE,  BOOT_ROM_MASK )) begin sel_d = SEL_W'(S_BOOT_ROM); sel_vld_d = 1'b1; end
    else if (in_range(m_req_addr, SRAM_BASE,      SRAM_MASK     )) begin sel_d = SEL_W'(S_SRAM);     sel_vld_d = 1'b1; end
    else if (in_range(m_req_addr, TIMER_BASE,     TIMER_MASK    )) begin sel_d = SEL_W'(S_TIMER);    sel_vld_d = 1'b1; end
    else if (in_range(m_req_addr, GPIO_BASE,      GPIO_MASK     )) begin sel_d = SEL_W'(S_GPIO);     sel_vld_d = 1'b1; end
    else if (in_range(m_req_addr, UART_BASE,      UART_MASK     )) begin sel_d = SEL_W'(S_UART);     sel_vld_d = 1'b1; end
    else if (in_range(m_req_addr, IRQ_CTRL_BASE,  IRQ_CTRL_MASK )) begin sel_d = SEL_W'(S_IRQ_CTRL); sel_vld_d = 1'b1; end
  end

  // ─── Active transaction register ────────────────────────────────────────
  logic [SEL_W-1:0] active_sel_q;
  logic             active_q;
  logic             active_err_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      active_q     <= 1'b0;
      active_sel_q <= SEL_W'(S_NONE);
      active_err_q <= 1'b0;
    end else begin
      if (!active_q && m_req_valid && m_req_ready) begin
        active_q     <= 1'b1;
        active_sel_q <= sel_d;
        active_err_q <= ~sel_vld_d;
      end
      if (active_q && m_rsp_valid && m_rsp_ready)
        active_q <= 1'b0;
    end
  end

  // ─── Request routing ─────────────────────────────────────────────────────
  always_comb begin : req_route
    for (int i = 0; i < NS; i++) begin
      s_req_addr [i*ADDR_W +: ADDR_W] = m_req_addr;
      s_req_wdata[i*DATA_W +: DATA_W] = m_req_wdata;
      s_req_wstrb[i*STRB_W +: STRB_W] = m_req_wstrb;
      s_req_write[i]                   = m_req_write;
      // Only assert valid to the selected slave, and only when fabric is free
      s_req_valid[i] = m_req_valid && sel_vld_d &&
                       (sel_d == SEL_W'(i)) && !active_q;
    end
  end

  // ─── m_req_ready ─────────────────────────────────────────────────────────
  always_comb begin
    if (active_q) begin
      m_req_ready = 1'b0;
    end else if (sel_vld_d) begin
      // Propagate selected slave's ready
      m_req_ready = 1'b0;
      for (int i = 0; i < NS; i++)
        if (sel_d == SEL_W'(i)) m_req_ready = s_req_ready[i];
    end else begin
      m_req_ready = m_req_valid;   // eat decode-error request immediately
    end
  end

  // ─── Response mux ─────────────────────────────────────────────────────────
  always_comb begin : rsp_mux
    m_rsp_valid = 1'b0;
    m_rsp_rdata = '0;
    m_rsp_error = 1'b0;
    for (int i = 0; i < NS; i++) s_rsp_ready[i] = 1'b0;

    if (active_q) begin
      if (active_err_q) begin
        // Synthesise decode-error response (no slave)
        m_rsp_valid = 1'b1;
        m_rsp_error = 1'b1;
      end else begin
        for (int i = 0; i < NS; i++) begin
          if (active_sel_q == SEL_W'(i)) begin
            m_rsp_valid    = s_rsp_valid[i];
            m_rsp_rdata    = s_rsp_rdata[i*DATA_W +: DATA_W];
            m_rsp_error    = s_rsp_error[i];
            s_rsp_ready[i] = m_rsp_ready;
          end
        end
      end
    end
  end

  // ─── Assertions ──────────────────────────────────────────────────────────
  // pragma translate_off
  `ifdef SIMULATION
  always @(posedge clk) begin
    if (rst_n && m_req_valid && m_rsp_valid)
      $error("[FABRIC] req and rsp overlapped — protocol violation t=%0t", $time);
  end
  `endif
  // pragma translate_on

endmodule
