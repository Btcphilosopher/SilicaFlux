// ============================================================================
// FILE        : cpu_if_adapter.sv
// PROJECT     : SoC Integration Framework
// DESCRIPTION : Bridges a standard RV32I CPU (separate instruction-fetch and
//               data-memory ports) onto a single SSB master bus.
//
// Arbitration: data-memory access takes priority over instruction fetch.
// At most one SSB transaction is outstanding at any time.
//
// CPU port convention (matches soc_integration RV32I core):
//   if_*  — instruction fetch (read-only)
//   dm_*  — data memory (read or write)
//
// Integration note
// ──────────────────────────────────────────────────────────────────────────
//   soc_top.sv exposes the raw SSB master bus directly; this adapter is
//   instantiated between the CPU core and soc_top when the CPU presents
//   separate I/D interfaces rather than a single bus master port.
// ============================================================================

module cpu_if_adapter
(
  input  logic clk,
  input  logic rst_n,

  // ─── Instruction-Fetch port (read-only) ──────────────────────────────────
  input  logic [ADDR_W-1:0] if_addr_i,
  input  logic              if_valid_i,
  output logic              if_ready_o,
  output logic [DATA_W-1:0] if_rdata_o,
  output logic              if_err_o,

  // ─── Data-Memory port (read / write) ─────────────────────────────────────
  input  logic [ADDR_W-1:0] dm_addr_i,
  input  logic              dm_valid_i,
  output logic              dm_ready_o,
  input  logic              dm_write_i,
  input  logic [DATA_W-1:0] dm_wdata_i,
  input  logic [STRB_W-1:0] dm_wstrb_i,
  output logic [DATA_W-1:0] dm_rdata_o,
  output logic              dm_err_o,

  // ─── SSB master bus (flat signals — IVerilog compatible) ─────────────────
  output logic              bus_req_valid_o,
  input  logic              bus_req_ready_i,
  output logic [ADDR_W-1:0] bus_req_addr_o,
  output logic              bus_req_write_o,
  output logic [DATA_W-1:0] bus_req_wdata_o,
  output logic [STRB_W-1:0] bus_req_wstrb_o,
  input  logic              bus_rsp_valid_i,
  output logic              bus_rsp_ready_o,
  input  logic [DATA_W-1:0] bus_rsp_rdata_i,
  input  logic              bus_rsp_error_i
);
  import soc_pkg::*;

  // ─── State Machine ────────────────────────────────────────────────────────
  typedef enum logic [1:0] {
    ST_IDLE = 2'd0,
    ST_DM   = 2'd1,    // data-memory transaction in flight
    ST_IF   = 2'd2     // instruction-fetch transaction in flight
  } st_e;

  st_e state_q;

  // ─── Combinatorial output drive ───────────────────────────────────────────
  always_comb begin
    // Default: idle outputs
    bus_req_valid_o = 1'b0;
    bus_req_addr_o  = '0;
    bus_req_write_o = 1'b0;
    bus_req_wdata_o = '0;
    bus_req_wstrb_o = '0;
    bus_rsp_ready_o = 1'b0;

    if_ready_o = 1'b0;
    if_rdata_o = '0;
    if_err_o   = 1'b0;

    dm_ready_o = 1'b0;
    dm_rdata_o = '0;
    dm_err_o   = 1'b0;

    case (state_q)
      ST_IDLE: begin
        // Data memory has priority
        if (dm_valid_i) begin
          bus_req_valid_o = 1'b1;
          bus_req_addr_o  = dm_addr_i;
          bus_req_write_o = dm_write_i;
          bus_req_wdata_o = dm_wdata_i;
          bus_req_wstrb_o = dm_wstrb_i;
        end else if (if_valid_i) begin
          bus_req_valid_o = 1'b1;
          bus_req_addr_o  = if_addr_i;
          bus_req_write_o = 1'b0;
          bus_req_wstrb_o = '0;
        end
      end

      ST_DM: begin
        bus_rsp_ready_o = 1'b1;
        if (bus_rsp_valid_i) begin
          dm_ready_o = 1'b1;
          dm_rdata_o = bus_rsp_rdata_i;
          dm_err_o   = bus_rsp_error_i;
        end
      end

      ST_IF: begin
        bus_rsp_ready_o = 1'b1;
        if (bus_rsp_valid_i) begin
          if_ready_o = 1'b1;
          if_rdata_o = bus_rsp_rdata_i;
          if_err_o   = bus_rsp_error_i;
        end
      end

      default: ; // unreachable
    endcase
  end

  // ─── State register ───────────────────────────────────────────────────────
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state_q <= ST_IDLE;
    end else begin
      case (state_q)
        ST_IDLE: begin
          if (bus_req_valid_o && bus_req_ready_i) begin
            // Handshake: move to response-wait state
            state_q <= dm_valid_i ? ST_DM : ST_IF;
          end
        end

        ST_DM: begin
          if (bus_rsp_valid_i && bus_rsp_ready_o)
            state_q <= ST_IDLE;
        end

        ST_IF: begin
          if (bus_rsp_valid_i && bus_rsp_ready_o)
            state_q <= ST_IDLE;
        end

        default: state_q <= ST_IDLE;
      endcase
    end
  end

  // ─── Assertions ───────────────────────────────────────────────────────────
  // pragma translate_off
  `ifdef SIMULATION
  always @(posedge clk) begin
    if (rst_n && (state_q != ST_IDLE) && dm_valid_i && if_valid_i)
      $display("[CPU_ADAPTER] I+D conflict while txn in flight — D will win t=%0t", $time);
  end
  `endif
  // pragma translate_on

endmodule
