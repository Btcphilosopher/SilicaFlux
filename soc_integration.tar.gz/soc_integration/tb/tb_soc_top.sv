// ============================================================================
// FILE        : tb_soc_top.sv
// PROJECT     : SoC Integration Framework
// DESCRIPTION : Full-chip SoC testbench.
//
// Test Sequence
// ──────────────────────────────────────────────────────────────────────────
//  Phase 0 : Power-on reset (10 cycles)
//  Phase 1 : Boot ROM verification
//             - Read first 5 boot-program words; compare to expected opcodes
//  Phase 2 : SRAM read/write
//             - Write a walking-ones pattern, read back and verify
//  Phase 3 : UART configuration and transmit
//             - Set baud divisor; write 4 characters; monitor TX output
//  Phase 4 : Timer configuration and IRQ
//             - Set short reload (500 cycles); enable IRQ; wait for assertion
//             - Read PENDING via IRQ controller
//  Phase 5 : GPIO
//             - Set DIR = 0xFF; write OUT = 0xA5; read back DIR and OUT
//  Phase 6 : Decode-error response
//             - Access unmapped address 0x1000_0000; expect error response
//  Phase 7 : Summary
// ──────────────────────────────────────────────────────────────────────────
//
// VCD waveform dump written to sim/dump.vcd
// ============================================================================

`define CLK_PERIOD 20   // 20 ns = 50 MHz

module tb_soc_top;

  import soc_pkg::*;

  // ─── Clock & reset ────────────────────────────────────────────────────────
  logic clk;
  logic rst_n;

  initial clk = 1'b0;
  always #(`CLK_PERIOD/2) clk = ~clk;

  // ─── DUT I/O ──────────────────────────────────────────────────────────────
  logic [31:0] gpio_in;
  wire  [31:0] gpio_out;
  wire  [31:0] gpio_oe;
  wire         uart_txd;
  logic        uart_rxd;
  wire         cpu_irq;

  // CPU bus (driven by BFM)
  logic              cpu_req_valid;
  wire               cpu_req_ready;
  logic [ADDR_W-1:0] cpu_req_addr;
  logic              cpu_req_write;
  logic [DATA_W-1:0] cpu_req_wdata;
  logic [STRB_W-1:0] cpu_req_wstrb;
  wire               cpu_rsp_valid;
  logic              cpu_rsp_ready;
  wire  [DATA_W-1:0] cpu_rsp_rdata;
  wire               cpu_rsp_error;

  // ─── DUT instantiation ────────────────────────────────────────────────────
  soc_top u_dut (
    .clk          (clk),
    .rst_n        (rst_n),
    .cpu_req_valid(cpu_req_valid),
    .cpu_req_ready(cpu_req_ready),
    .cpu_req_addr (cpu_req_addr),
    .cpu_req_write(cpu_req_write),
    .cpu_req_wdata(cpu_req_wdata),
    .cpu_req_wstrb(cpu_req_wstrb),
    .cpu_rsp_valid(cpu_rsp_valid),
    .cpu_rsp_ready(cpu_rsp_ready),
    .cpu_rsp_rdata(cpu_rsp_rdata),
    .cpu_rsp_error(cpu_rsp_error),
    .gpio_in      (gpio_in),
    .gpio_out     (gpio_out),
    .gpio_oe      (gpio_oe),
    .uart_txd     (uart_txd),
    .uart_rxd     (uart_rxd),
    .cpu_irq_o    (cpu_irq)
  );

  // ─── CPU BFM ──────────────────────────────────────────────────────────────
  cpu_bfm u_bfm (
    .clk       (clk),
    .rst_n     (rst_n),
    .req_valid (cpu_req_valid),
    .req_ready (cpu_req_ready),
    .req_addr  (cpu_req_addr),
    .req_write (cpu_req_write),
    .req_wdata (cpu_req_wdata),
    .req_wstrb (cpu_req_wstrb),
    .rsp_valid (cpu_rsp_valid),
    .rsp_ready (cpu_rsp_ready),
    .rsp_rdata (cpu_rsp_rdata),
    .rsp_error (cpu_rsp_error),
    .irq_i     (cpu_irq),
    .txn_count (),
    .err_count ()
  );

  // ─── UART monitor ─────────────────────────────────────────────────────────
  uart_mon #(
    .CLK_FREQ  (50_000_000),
    .BAUD_RATE (500_000),   // 50 MHz / 100 divisor
    .PREFIX    ("[UART_MON]")
  ) u_uart_mon (
    .clk   (clk),
    .rst_n (rst_n),
    .txd_i (uart_txd)
  );

  // ─── Pass/fail counters ───────────────────────────────────────────────────
  int pass_cnt, fail_cnt;
  initial begin
    pass_cnt = 0;
    fail_cnt = 0;
  end

  // ─── Helper: check macro ──────────────────────────────────────────────────
  task automatic check(
    input logic [DATA_W-1:0] got,
    input logic [DATA_W-1:0] exp,
    input logic [DATA_W-1:0] mask  = 32'hFFFF_FFFF,
    input string             label = ""
  );
    if ((got & mask) === (exp & mask)) begin
      $display("  PASS  %-40s  got=0x%08X", label, got & mask);
      pass_cnt++;
    end else begin
      $display("  FAIL  %-40s  exp=0x%08X  got=0x%08X",
               label, exp & mask, got & mask);
      fail_cnt++;
    end
  endtask

  // ─── Bus helpers (wrap BFM tasks) ────────────────────────────────────────
  logic [DATA_W-1:0] rd_data;

  task automatic bwrite(input logic [31:0] addr, data);
    u_bfm.bus_write(addr, data, 4'hF);
  endtask

  task automatic bread(input logic [31:0] addr, output logic [31:0] data);
    u_bfm.bus_read(addr, data);
  endtask

  // ─── VCD dump ─────────────────────────────────────────────────────────────
  initial begin
    $dumpfile("dump.vcd");
    $dumpvars(0, tb_soc_top);
  end

  // ─── Initialise idle inputs ───────────────────────────────────────────────
  initial begin
    gpio_in  = 32'hA5A5_A5A5;
    uart_rxd = 1'b1;
  end

  // =========================================================================
  //  Main test sequence
  // =========================================================================
  initial begin
    $display("");
    $display("╔══════════════════════════════════════════════════════╗");
    $display("║        SoC Integration Framework — Testbench         ║");
    $display("╚══════════════════════════════════════════════════════╝");

    // ── Reset ──────────────────────────────────────────────────────────────
    rst_n = 1'b0;
    repeat (10) @(posedge clk);
    rst_n = 1'b1;
    repeat (5)  @(posedge clk);
    $display("\n[Phase 0] Reset released\n");

    // ═══════════════════════════════════════════════════════════════════════
    //  Phase 1: Boot ROM verification
    // ═══════════════════════════════════════════════════════════════════════
    $display("[Phase 1] Boot ROM read verification");

    bread(32'h0000_0000, rd_data);
    check(rd_data, 32'h2002_0137, 32'hFFFF_FFFF, "ROM[0]  lui sp,0x20020");

    bread(32'h0000_0004, rd_data);
    check(rd_data, 32'hFF01_0113, 32'hFFFF_FFFF, "ROM[1]  addi sp,sp,-16");

    bread(32'h0000_0008, rd_data);
    check(rd_data, 32'h4000_22B7, 32'hFFFF_FFFF, "ROM[2]  lui t0,0x40002");

    bread(32'h0000_000C, rd_data);
    check(rd_data, 32'h1B20_0313, 32'hFFFF_FFFF, "ROM[3]  li t1,434");

    bread(32'h0000_0038, rd_data);
    check(rd_data, 32'h0000_006F, 32'hFFFF_FFFF, "ROM[14] jal x0,0 (idle)");

    // Write to ROM must return error
    bwrite(32'h0000_0000, 32'hDEAD_BEEF);
    check(cpu_rsp_error, 1'b1, 1'b1, "ROM write → bus error");

    // ═══════════════════════════════════════════════════════════════════════
    //  Phase 2: SRAM read/write
    // ═══════════════════════════════════════════════════════════════════════
    $display("\n[Phase 2] SRAM read/write");

    // Walking-ones pattern
    begin
      int ok;
      ok = 1;
      for (int w = 0; w < 8; w++) begin
        logic [31:0] waddr, wdata, rdata2;
        waddr = 32'h2000_0000 + (w * 4);
        wdata = 32'h1 << w;
        bwrite(waddr, wdata);
        bread(waddr, rdata2);
        if (rdata2 !== wdata) begin
          $display("  FAIL  SRAM[%0d] exp=0x%08X got=0x%08X", w, wdata, rdata2);
          fail_cnt++;
          ok = 0;
        end
      end
      if (ok) begin
        $display("  PASS  SRAM walking-ones (8 words, 0x2000_0000)");
        pass_cnt++;
      end
    end

    // Byte-enable write: write 0xDEAD_BEEF, then patch lower byte to 0x00
    bwrite(32'h2000_0020, 32'hDEAD_BEEF);
    u_bfm.bus_write(32'h2000_0020, 32'h0000_0000, 4'b0001);  // patch byte 0
    bread(32'h2000_0020, rd_data);
    check(rd_data, 32'hDEAD_BE00, 32'hFFFF_FFFF, "SRAM byte-enable patch");

    // ═══════════════════════════════════════════════════════════════════════
    //  Phase 3: UART configuration and TX
    // ═══════════════════════════════════════════════════════════════════════
    $display("\n[Phase 3] UART configuration and transmit");

    // Set baud divisor (fast mode for simulation: 10 cycles/bit)
    bwrite(UART_BASE + {20'b0, UART_REG_BAUD}, 32'd100);
    bread (UART_BASE + {20'b0, UART_REG_BAUD}, rd_data);
    check(rd_data, 32'd100, 32'hFFFF_FFFF, "UART BAUD=100 readback");

    // Check STATUS: tx_ready should be set (FIFO empty)
    bread(UART_BASE + {20'b0, UART_REG_STATUS}, rd_data);
    check(rd_data[0], 1'b1, 1'b1, "UART STATUS tx_ready=1");

    // Enable UART TX IRQ
    bwrite(UART_BASE + {20'b0, UART_REG_CTRL}, 32'h1);

    // Transmit "SOC\n" (4 characters)
    $display("  Sending 'SOC\\n' over UART (monitor should decode)...");
    bwrite(UART_BASE + {20'b0, UART_REG_DATA}, 32'h53);  // 'S'
    bwrite(UART_BASE + {20'b0, UART_REG_DATA}, 32'h4F);  // 'O'
    bwrite(UART_BASE + {20'b0, UART_REG_DATA}, 32'h43);  // 'C'
    bwrite(UART_BASE + {20'b0, UART_REG_DATA}, 32'h0A);  // '\n'

    // Wait long enough for all bytes to be transmitted
    // Each byte takes ~10*(1+8+1)=100 cycles; 4 bytes = 400 cycles + margin
    repeat (6000) @(posedge clk);

    // STATUS tx_empty should be set after transmission
    bread(UART_BASE + {20'b0, UART_REG_STATUS}, rd_data);
    check(rd_data[1], 1'b1, 1'b1, "UART STATUS tx_empty=1 after TX");

    // ═══════════════════════════════════════════════════════════════════════
    //  Phase 4: Timer → IRQ
    // ═══════════════════════════════════════════════════════════════════════
    $display("\n[Phase 4] Timer configuration and IRQ");

    // Enable IRQ source 0 (timer) in IRQ controller
    bwrite(IRQ_CTRL_BASE + {20'b0, IRQ_REG_ENABLE}, 32'h1);

    // Load a short reload value so the test doesn't take forever
    // 500 cycles gives a clean margin at simulation speed
    bwrite(TIMER_BASE + {20'b0, TIMER_REG_RELOAD}, 32'd500);
    // CTRL: enable | irq_en | auto_reload
    bwrite(TIMER_BASE + {20'b0, TIMER_REG_CTRL}, 32'h7);

    // Wait for IRQ
    $display("  Waiting for timer IRQ (up to 1000 cycles)...");
    u_bfm.wait_irq(1000);

    // Read IRQ controller PENDING — bit 0 should be set
    bread(IRQ_CTRL_BASE + {20'b0, IRQ_REG_PENDING}, rd_data);
    check(rd_data[0], 1'b1, 1'b1, "IRQ_CTRL PENDING[0] (timer)");

    // Read ACTIVE
    bread(IRQ_CTRL_BASE + {20'b0, IRQ_REG_ACTIVE}, rd_data);
    check(rd_data[0], 1'b1, 1'b1, "IRQ_CTRL ACTIVE[0]");

    // Read timer STATUS — expired should be set
    bread(TIMER_BASE + {20'b0, TIMER_REG_STATUS}, rd_data);
    check(rd_data[0], 1'b1, 1'b1, "TIMER STATUS expired=1");

    // Clear: W1C on PENDING and STATUS
    bwrite(IRQ_CTRL_BASE + {20'b0, IRQ_REG_PENDING}, 32'h1);
    bwrite(TIMER_BASE    + {20'b0, TIMER_REG_STATUS}, 32'h1);

    // Disable timer
    bwrite(TIMER_BASE + {20'b0, TIMER_REG_CTRL}, 32'h0);

    // Confirm PENDING cleared
    bread(IRQ_CTRL_BASE + {20'b0, IRQ_REG_PENDING}, rd_data);
    check(rd_data[0], 1'b0, 1'b1, "IRQ_CTRL PENDING cleared");

    // ═══════════════════════════════════════════════════════════════════════
    //  Phase 5: GPIO
    // ═══════════════════════════════════════════════════════════════════════
    $display("\n[Phase 5] GPIO read/write");

    // Set direction: lower 8 bits = outputs
    bwrite(GPIO_BASE + {20'b0, GPIO_REG_DIR}, 32'h0000_00FF);
    bread (GPIO_BASE + {20'b0, GPIO_REG_DIR}, rd_data);
    check(rd_data, 32'h0000_00FF, 32'hFFFF_FFFF, "GPIO DIR=0x00FF readback");

    // Drive output pattern
    bwrite(GPIO_BASE + {20'b0, GPIO_REG_OUT}, 32'hA5);
    bread (GPIO_BASE + {20'b0, GPIO_REG_OUT}, rd_data);
    check(rd_data, 32'hA5, 32'hFFFF_FFFF, "GPIO OUT=0xA5 readback");

    // Read synchronised input (gpio_in was initialised to 0xA5A5_A5A5)
    // Allow 3 cycles for 2-FF synchroniser + response pipeline
    repeat (5) @(posedge clk);
    bread(GPIO_BASE + {20'b0, GPIO_REG_IN}, rd_data);
    check(rd_data, 32'hA5A5_A5A5, 32'hFFFF_FFFF, "GPIO IN = gpio_in_i (synced)");

    // ═══════════════════════════════════════════════════════════════════════
    //  Phase 6: Decode-error response
    // ═══════════════════════════════════════════════════════════════════════
    $display("\n[Phase 6] Bus decode error (unmapped address)");

    begin
      int ec_before;
      ec_before = u_bfm.err_count;
      bwrite(32'h1000_0000, 32'hDEAD_BEEF);
      check((u_bfm.err_count > ec_before) ? 1'b1 : 1'b0, 1'b1, 1'b1,
            "Decode error on 0x1000_0000 write");

      ec_before = u_bfm.err_count;
      bread(32'h1000_0000, rd_data);
      check((u_bfm.err_count > ec_before) ? 1'b1 : 1'b0, 1'b1, 1'b1,
            "Decode error on 0x1000_0000 read");
    end

    // ═══════════════════════════════════════════════════════════════════════
    //  Phase 7: Summary
    // ═══════════════════════════════════════════════════════════════════════
    repeat (10) @(posedge clk);
    $display("");
    $display("╔══════════════════════════════════════════════════════╗");
    $display("║                  Test Summary                        ║");
    $display("╠══════════════════════════════════════════════════════╣");
    $display("║  BFM transactions : %-5d                            ║", u_bfm.txn_count);
    $display("║  PASS checks      : %-5d                            ║", pass_cnt);
    $display("║  FAIL checks      : %-5d                            ║", fail_cnt);
    $display("╠══════════════════════════════════════════════════════╣");
    if (fail_cnt == 0)
      $display("║              *** ALL TESTS PASSED ***                ║");
    else
      $display("║         *** %0d TEST(S) FAILED — see above ***       ║", fail_cnt);
    $display("╚══════════════════════════════════════════════════════╝");
    $display("");

    $finish;
  end

  // ─── Simulation watchdog ──────────────────────────────────────────────────
  initial begin
    #10_000_000;   // 10 ms simulation limit
    $display("[WATCHDOG] Simulation exceeded time limit — forcing stop");
    $finish;
  end

endmodule
