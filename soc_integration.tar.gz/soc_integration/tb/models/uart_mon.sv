// ============================================================================
// FILE        : uart_mon.sv
// PROJECT     : SoC Integration Framework
// DESCRIPTION : Non-synthesisable UART 8N1 monitor (IVerilog 12 compatible).
// Monitors a UART TX line and prints every decoded byte.
// ============================================================================

// pragma translate_off
module uart_mon #(
  parameter integer CLK_FREQ  = 50_000_000,
  parameter integer BAUD_RATE = 115_200,
  parameter string  PREFIX    = "[UART_MON]"
)(
  input logic clk,
  input logic rst_n,
  input logic txd_i
);

  localparam integer BIT_CLKS      = CLK_FREQ / BAUD_RATE;
  localparam integer HALF_BIT_CLKS = BIT_CLKS / 2;

  // ─── State machine ────────────────────────────────────────────────────────
  localparam integer MON_IDLE  = 0;
  localparam integer MON_START = 1;
  localparam integer MON_DATA  = 2;
  localparam integer MON_STOP  = 3;

  integer   state;
  integer   bit_cnt;
  integer   baud_cnt;
  reg [7:0] shift_reg;

  // Input sync
  reg txd_s, txd_prev;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      txd_s    <= 1'b1;
      txd_prev <= 1'b1;
    end else begin
      txd_s    <= txd_i;
      txd_prev <= txd_s;
    end
  end

  wire start_edge = !txd_s && txd_prev;

  // ─── Decode ───────────────────────────────────────────────────────────────
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state     <= MON_IDLE;
      bit_cnt   <= 0;
      baud_cnt  <= 0;
      shift_reg <= 8'h00;
    end else begin
      case (state)
        MON_IDLE: begin
          if (start_edge) begin
            baud_cnt <= HALF_BIT_CLKS - 1;
            state    <= MON_START;
          end
        end

        MON_START: begin
          if (baud_cnt == 0) begin
            if (!txd_s) begin
              baud_cnt <= BIT_CLKS - 1;
              bit_cnt  <= 0;
              state    <= MON_DATA;
            end else
              state <= MON_IDLE;
          end else
            baud_cnt <= baud_cnt - 1;
        end

        MON_DATA: begin
          if (baud_cnt == 0) begin
            shift_reg <= {txd_s, shift_reg[7:1]};  // LSB first
            baud_cnt  <= BIT_CLKS - 1;
            if (bit_cnt == 7) begin
              state <= MON_STOP;
            end else begin
              bit_cnt <= bit_cnt + 1;
            end
          end else
            baud_cnt <= baud_cnt - 1;
        end

        MON_STOP: begin
          if (baud_cnt == 0) begin
            if (txd_s) begin
              // Valid byte received — display it
              if (shift_reg >= 8'h20 && shift_reg < 8'h7F)
                $display("%s 0x%02X '%c'  t=%0t", PREFIX, shift_reg,
                         shift_reg, $time);
              else
                $display("%s 0x%02X       t=%0t", PREFIX, shift_reg, $time);
            end else begin
              $display("%s FRAMING ERROR  t=%0t", PREFIX, $time);
            end
            state <= MON_IDLE;
          end else
            baud_cnt <= baud_cnt - 1;
        end

        default: state <= MON_IDLE;
      endcase
    end
  end

endmodule
// pragma translate_on
