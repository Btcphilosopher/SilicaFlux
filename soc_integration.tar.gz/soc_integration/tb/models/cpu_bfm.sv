// ============================================================================
// FILE        : cpu_bfm.sv
// PROJECT     : SoC Integration Framework
// DESCRIPTION : CPU Bus Functional Model.
//
// Instantiate this module in tb_soc_top.sv in place of a real CPU core.
// The testbench drives the BFM via hierarchical task calls:
//
//   tb.u_bfm.bus_write(ADDR, DATA);
//   tb.u_bfm.bus_read (ADDR, data_out);
//   tb.u_bfm.bus_write_check(ADDR, DATA, EXP, "label");
//
// All tasks are automatic so they can be called from multiple fork branches.
// Drives req signals on negedge; samples rsp on posedge.
// ============================================================================

module cpu_bfm
  import soc_pkg::*;
(
  input  logic              clk,
  input  logic              rst_n,

  // ─── SSB master bus (flat) ────────────────────────────────────────────────
  output logic              req_valid,
  input  logic              req_ready,
  output logic [ADDR_W-1:0] req_addr,
  output logic              req_write,
  output logic [DATA_W-1:0] req_wdata,
  output logic [STRB_W-1:0] req_wstrb,

  input  logic              rsp_valid,
  output logic              rsp_ready,
  input  logic [DATA_W-1:0] rsp_rdata,
  input  logic              rsp_error,

  // ─── CPU IRQ input ────────────────────────────────────────────────────────
  input  logic              irq_i,

  // ─── Status outputs ───────────────────────────────────────────────────────
  output int                txn_count,       // total transactions completed
  output int                err_count        // error transactions
);

  // ─── Initialisation ───────────────────────────────────────────────────────
  initial begin
    req_valid = 1'b0;
    req_write = 1'b0;
    req_addr  = '0;
    req_wdata = '0;
    req_wstrb = '0;
    rsp_ready = 1'b1;  // always accept responses
    txn_count = 0;
    err_count = 0;
  end

  // ─── Wait for reset release ───────────────────────────────────────────────
  task automatic wait_for_reset();
    @(posedge rst_n);
    repeat (3) @(posedge clk);
  endtask

  // ─── Single bus write ─────────────────────────────────────────────────────
  task automatic bus_write(
    input logic [ADDR_W-1:0] addr,
    input logic [DATA_W-1:0] data,
    input logic [STRB_W-1:0] strb = 4'hF
  );
    // Drive after falling edge (setup before next posedge)
    @(negedge clk);
    req_valid = 1'b1;
    req_addr  = addr;
    req_write = 1'b1;
    req_wdata = data;
    req_wstrb = strb;

    // Wait for request handshake
    @(posedge clk);
    while (!req_ready) @(posedge clk);

    // Deassert request
    @(negedge clk);
    req_valid = 1'b0;
    req_write = 1'b0;

    // Wait for response
    @(posedge clk);
    while (!rsp_valid) @(posedge clk);

    // Account transaction
    txn_count++;
    if (rsp_error) begin
      $display("[BFM] WRITE ERROR  addr=0x%08X data=0x%08X  t=%0t",
               addr, data, $time);
      err_count++;
    end
  endtask

  // ─── Single bus read ──────────────────────────────────────────────────────
  task automatic bus_read(
    input  logic [ADDR_W-1:0] addr,
    output logic [DATA_W-1:0] data
  );
    @(negedge clk);
    req_valid = 1'b1;
    req_addr  = addr;
    req_write = 1'b0;
    req_wdata = '0;
    req_wstrb = '0;

    @(posedge clk);
    while (!req_ready) @(posedge clk);

    @(negedge clk);
    req_valid = 1'b0;

    @(posedge clk);
    while (!rsp_valid) @(posedge clk);

    data = rsp_rdata;
    txn_count++;
    if (rsp_error) begin
      $display("[BFM] READ  ERROR  addr=0x%08X  t=%0t", addr, $time);
      err_count++;
    end
  endtask

  // ─── Write then read-back check ───────────────────────────────────────────
  task automatic bus_write_read_check(
    input logic [ADDR_W-1:0] addr,
    input logic [DATA_W-1:0] data,
    input logic [DATA_W-1:0] mask  = 32'hFFFF_FFFF,
    input string             label = ""
  );
    logic [DATA_W-1:0] rd;
    bus_write(addr, data);
    bus_read(addr, rd);
    if ((rd & mask) === (data & mask)) begin
      $display("[BFM] PASS  %s  addr=0x%08X  exp=0x%08X  got=0x%08X",
               label, addr, data & mask, rd & mask);
    end else begin
      $display("[BFM] FAIL  %s  addr=0x%08X  exp=0x%08X  got=0x%08X",
               label, addr, data & mask, rd & mask);
      err_count++;
    end
  endtask

  // ─── Read-and-compare check ───────────────────────────────────────────────
  task automatic bus_read_check(
    input logic [ADDR_W-1:0] addr,
    input logic [DATA_W-1:0] expected,
    input logic [DATA_W-1:0] mask  = 32'hFFFF_FFFF,
    input string             label = ""
  );
    logic [DATA_W-1:0] rd;
    bus_read(addr, rd);
    if ((rd & mask) === (expected & mask)) begin
      $display("[BFM] PASS  %s  addr=0x%08X  exp=0x%08X  got=0x%08X",
               label, addr, expected & mask, rd & mask);
    end else begin
      $display("[BFM] FAIL  %s  addr=0x%08X  exp=0x%08X  got=0x%08X",
               label, addr, expected & mask, rd & mask);
      err_count++;
    end
  endtask

  // ─── Wait for IRQ assertion with timeout ──────────────────────────────────
  task automatic wait_irq(input int timeout_cycles = 200000);
    int cnt;
    cnt = 0;
    while (!irq_i && cnt < timeout_cycles) begin
      @(posedge clk);
      cnt++;
    end
    if (cnt >= timeout_cycles)
      $display("[BFM] TIMEOUT waiting for IRQ after %0d cycles", timeout_cycles);
    else
      $display("[BFM] IRQ received after %0d cycles t=%0t", cnt, $time);
  endtask

  // ─── IRQ monitor (background) ─────────────────────────────────────────────
  always @(posedge irq_i) begin
    $display("[BFM] IRQ ASSERTED  t=%0t", $time);
  end

endmodule
