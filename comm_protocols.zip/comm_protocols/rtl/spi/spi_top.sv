// =============================================================================
// spi_top.sv  —  SPI Top-level (Master + Slave loopback demo)
// =============================================================================
`timescale 1ns/1ps

module spi_top #(
    parameter int DATA_WIDTH  = 8,
    parameter int CLK_DIV     = 4,
    parameter bit CPOL        = 0,
    parameter bit CPHA        = 0
)(
    input  logic                   clk,
    input  logic                   rst_n,
    // Master user interface
    input  logic [DATA_WIDTH-1:0]  m_mosi_data,
    input  logic                   m_start,
    output logic [DATA_WIDTH-1:0]  m_miso_data,
    output logic                   m_done,
    output logic                   m_busy,
    // Slave user interface
    input  logic [DATA_WIDTH-1:0]  s_tx_data,
    input  logic                   s_tx_load,
    output logic [DATA_WIDTH-1:0]  s_rx_data,
    output logic                   s_rx_valid
);

    // Internal SPI bus
    logic sclk_w, mosi_w, miso_w, cs_n_w;

    spi_master #(
        .DATA_WIDTH (DATA_WIDTH),
        .CLK_DIV    (CLK_DIV),
        .CPOL       (CPOL),
        .CPHA       (CPHA)
    ) u_master (
        .clk       (clk),
        .rst_n     (rst_n),
        .mosi_data (m_mosi_data),
        .start     (m_start),
        .miso_data (m_miso_data),
        .done      (m_done),
        .busy      (m_busy),
        .sclk      (sclk_w),
        .mosi      (mosi_w),
        .miso      (miso_w),
        .cs_n      (cs_n_w)
    );

    spi_slave #(
        .DATA_WIDTH (DATA_WIDTH),
        .CPOL       (CPOL),
        .CPHA       (CPHA)
    ) u_slave (
        .clk      (clk),
        .rst_n    (rst_n),
        .tx_data  (s_tx_data),
        .tx_load  (s_tx_load),
        .rx_data  (s_rx_data),
        .rx_valid (s_rx_valid),
        .busy     (/* open */),
        .sclk     (sclk_w),
        .mosi     (mosi_w),
        .miso     (miso_w),
        .cs_n     (cs_n_w)
    );

endmodule : spi_top
