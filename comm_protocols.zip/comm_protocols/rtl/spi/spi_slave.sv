// =============================================================================
// spi_slave.sv  —  SPI Slave Controller
// =============================================================================
// Timing Diagram (Mode 0, CPOL=0 CPHA=0):
//
//  CS_N   ‾‾‾|____________________________|‾‾‾
//  SCLK   _____‾‾_‾‾_‾‾_‾‾_‾‾_‾‾_‾‾_‾____
//  MOSI   ────<B7><B6><B5><B4><B3><B2><B1><B0>────
//                ↑   ↑   ↑   ↑   ↑   ↑   ↑   ↑
//             sample on rising SCLK (CPHA=0)
//  MISO   ────<B7><B6><B5><B4><B3><B2><B1><B0>────
//             driven from falling SCLK
//
//  FSM:  IDLE ─► TRANSFER ─► DONE ─► IDLE
// =============================================================================

`timescale 1ns/1ps

module spi_slave #(
    parameter int DATA_WIDTH = 8,
    parameter bit CPOL       = 0,
    parameter bit CPHA       = 0
)(
    input  logic                   clk,
    input  logic                   rst_n,
    // User interface
    input  logic [DATA_WIDTH-1:0]  tx_data,    // data to send to master
    input  logic                   tx_load,    // load tx_data before CS asserts
    output logic [DATA_WIDTH-1:0]  rx_data,    // data received from master
    output logic                   rx_valid,   // 1-cycle pulse on frame complete
    output logic                   busy,
    // SPI pins
    input  logic                   sclk,
    input  logic                   mosi,
    output logic                   miso,
    input  logic                   cs_n
);

    // ─── 2-FF synchronisers for all async SPI inputs ──────────────────────────
    logic sclk_s1, sclk_s, sclk_prev;
    logic mosi_s1, mosi_s;
    logic cs_s1,   cs_s,   cs_prev;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            {sclk_s1, sclk_s, sclk_prev} <= {3{CPOL}};
            {mosi_s1, mosi_s}             <= 2'b00;
            {cs_s1,   cs_s,   cs_prev}    <= 3'b111;
        end else begin
            {sclk_s1, sclk_s, sclk_prev} <= {sclk, sclk_s1, sclk_s};
            {mosi_s1, mosi_s}             <= {mosi, mosi_s1};
            {cs_s1,   cs_s,   cs_prev}    <= {cs_n, cs_s1,   cs_s};
        end
    end

    wire sclk_rising  = ~sclk_prev &  sclk_s;
    wire sclk_falling =  sclk_prev & ~sclk_s;
    wire cs_active    = ~cs_s;
    wire cs_falling   =  cs_prev  & ~cs_s;   // CS asserted

    // ─── FSM ──────────────────────────────────────────────────────────────────
    typedef enum logic [1:0] {
        IDLE     = 2'b00,
        TRANSFER = 2'b01,
        DONE_ST  = 2'b10
    } slv_state_t;

    slv_state_t                     state, next_state;
    logic [$clog2(DATA_WIDTH)-1:0]  bit_cnt;
    logic [DATA_WIDTH-1:0]          shift_in, shift_out;

    // Sample and shift edges depend on CPOL/CPHA
    wire sample_edge = (CPHA == 0) ? sclk_rising  : sclk_falling;
    wire drive_edge  = (CPHA == 0) ? sclk_falling : sclk_rising;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) state <= IDLE;
        else        state <= next_state;
    end

    always_comb begin
        next_state = state;
        unique case (state)
            IDLE:     if (cs_falling)                             next_state = TRANSFER;
            TRANSFER: if (!cs_active)                             next_state = DONE_ST;
            DONE_ST:                                              next_state = IDLE;
            default:  next_state = IDLE;
        endcase
    end

    // ─── Datapath ─────────────────────────────────────────────────────────────
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            shift_in  <= '0;
            shift_out <= '0;
            bit_cnt   <= '0;
            rx_data   <= '0;
            rx_valid  <= 1'b0;
        end else begin
            rx_valid <= 1'b0;

            case (state)
                IDLE: begin
                    bit_cnt <= '0;
                    if (tx_load)   shift_out <= tx_data;
                    if (cs_falling) begin
                        // Pre-load MISO with MSB (CPHA=0 drives before first edge)
                        if (CPHA == 0) shift_out <= tx_data;
                    end
                end

                TRANSFER: begin
                    if (sample_edge) begin
                        shift_in <= {shift_in[DATA_WIDTH-2:0], mosi_s};
                        bit_cnt  <= bit_cnt + 1;
                    end
                    if (drive_edge) begin
                        shift_out <= {shift_out[DATA_WIDTH-2:0], 1'b0};
                    end
                end

                DONE_ST: begin
                    rx_data  <= shift_in;
                    rx_valid <= 1'b1;
                    bit_cnt  <= '0;
                end
            endcase
        end
    end

    // ─── MISO output ──────────────────────────────────────────────────────────
    // High-Z when CS deasserted (tristate in real hardware)
    assign miso = cs_active ? shift_out[DATA_WIDTH-1] : 1'bz;
    assign busy = (state == TRANSFER);

endmodule : spi_slave
