// =============================================================================
// spi_master.sv  —  SPI Master Controller
// =============================================================================
// Timing Diagrams:
//
//  Mode 0 (CPOL=0, CPHA=0):
//   CS_N  ‾‾|_________________________|‾‾
//   SCLK  ___‾‾_‾‾_‾‾_‾‾_‾‾_‾‾_‾‾_‾__
//   MOSI  ───<B7><B6><B5><B4><B3><B2><B1><B0>───
//   MISO  ───<B7><B6><B5><B4><B3><B2><B1><B0>───
//              ↑   ↑   ↑   ↑   ↑   ↑   ↑   ↑
//           sample on rising edge
//
//  Mode 1 (CPOL=0, CPHA=1):
//   SCLK  ____‾‾_‾‾_‾‾_‾‾_‾‾_‾‾_‾‾_‾__
//   MOSI  ────<B7><B6>...<B0>
//   MISO  ────<B7><B6>...<B0>
//              sample on falling edge
//
//  FSM:  IDLE ─► CS_ASSERT ─► TRANSFER ─► CS_DEASSERT ─► DONE ─► IDLE
// =============================================================================

`timescale 1ns/1ps

module spi_master #(
    parameter int DATA_WIDTH  = 8,          // Transfer width (bits)
    parameter int CLK_DIV     = 4,          // SPI_CLK = sys_clk / (2*CLK_DIV)
    parameter bit CPOL        = 0,          // Clock polarity
    parameter bit CPHA        = 0,          // Clock phase
    parameter int CS_SETUP_CY = 2,          // CS setup cycles before first edge
    parameter int CS_HOLD_CY  = 2           // CS hold cycles after last edge
)(
    input  logic                   clk,
    input  logic                   rst_n,
    // User interface
    input  logic [DATA_WIDTH-1:0]  mosi_data,   // Data to transmit
    input  logic                   start,        // Pulse to begin transfer
    output logic [DATA_WIDTH-1:0]  miso_data,   // Received data
    output logic                   done,         // 1-cycle pulse when complete
    output logic                   busy,
    // SPI pins
    output logic                   sclk,
    output logic                   mosi,
    input  logic                   miso,
    output logic                   cs_n
);

    typedef enum logic [2:0] {
        IDLE         = 3'b000,
        CS_ASSERT    = 3'b001,
        TRANSFER     = 3'b010,
        CS_DEASSERT  = 3'b011,
        DONE_ST      = 3'b100
    } spi_state_t;

    spi_state_t                     state, next_state;
    logic [$clog2(CLK_DIV)-1:0]     clk_cnt;
    logic                            sclk_en;
    logic                            sclk_r;
    logic                            sclk_rising, sclk_falling;
    logic [$clog2(DATA_WIDTH*2)-1:0] edge_cnt;    // counts SCLK half-periods
    logic [$clog2(CS_SETUP_CY+CS_HOLD_CY+1)-1:0] delay_cnt;
    logic [DATA_WIDTH-1:0]           shift_out, shift_in;
    logic                            half_tick;   // sys-clk-domain SCLK toggle

    // ─── Clock divider / SCLK generator ──────────────────────────────────────
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) clk_cnt <= '0;
        else        clk_cnt <= (clk_cnt == CLK_DIV - 1) ? '0 : clk_cnt + 1;
    end
    assign half_tick = (clk_cnt == CLK_DIV - 1);

    // SCLK toggle register (only active during TRANSFER)
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)              sclk_r <= CPOL;
        else if (state == IDLE)  sclk_r <= CPOL;
        else if (sclk_en && half_tick) sclk_r <= ~sclk_r;
    end

    assign sclk_rising  =  half_tick && sclk_en && (sclk_r == CPOL);   // was idle, now active
    assign sclk_falling =  half_tick && sclk_en && (sclk_r != CPOL);
    assign sclk         =  sclk_r;

    // ─── State register ───────────────────────────────────────────────────────
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) state <= IDLE;
        else        state <= next_state;
    end

    // ─── Next-state logic ─────────────────────────────────────────────────────
    always_comb begin
        next_state = state;
        unique case (state)
            IDLE:        if (start)                                             next_state = CS_ASSERT;
            CS_ASSERT:   if (half_tick && delay_cnt == CS_SETUP_CY - 1)        next_state = TRANSFER;
            TRANSFER:    if (edge_cnt == DATA_WIDTH * 2 - 1 && half_tick)      next_state = CS_DEASSERT;
            CS_DEASSERT: if (half_tick && delay_cnt == CS_HOLD_CY - 1)         next_state = DONE_ST;
            DONE_ST:                                                             next_state = IDLE;
            default:     next_state = IDLE;
        endcase
    end

    // ─── Datapath ─────────────────────────────────────────────────────────────
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            shift_out  <= '0;
            shift_in   <= '0;
            miso_data  <= '0;
            edge_cnt   <= '0;
            delay_cnt  <= '0;
            done       <= 1'b0;
            sclk_en    <= 1'b0;
        end else begin
            done <= 1'b0;

            case (state)
                IDLE: begin
                    edge_cnt  <= '0;
                    delay_cnt <= '0;
                    sclk_en   <= 1'b0;
                    if (start) shift_out <= mosi_data;
                end

                CS_ASSERT: begin
                    sclk_en <= 1'b0;
                    if (half_tick) begin
                        delay_cnt <= delay_cnt + 1;
                        if (delay_cnt == CS_SETUP_CY - 1) begin
                            delay_cnt <= '0;
                            sclk_en   <= 1'b1;
                        end
                    end
                end

                TRANSFER: begin
                    sclk_en <= 1'b1;
                    if (half_tick) begin
                        edge_cnt <= edge_cnt + 1;
                        // CPHA=0: shift out on falling, sample on rising
                        // CPHA=1: shift out on rising, sample on falling
                        if (CPHA == 0) begin
                            if (sclk_falling) shift_out <= {shift_out[DATA_WIDTH-2:0], 1'b0};
                            if (sclk_rising)  shift_in  <= {shift_in[DATA_WIDTH-2:0], miso};
                        end else begin
                            if (sclk_rising)  shift_out <= {shift_out[DATA_WIDTH-2:0], 1'b0};
                            if (sclk_falling) shift_in  <= {shift_in[DATA_WIDTH-2:0], miso};
                        end
                    end
                end

                CS_DEASSERT: begin
                    sclk_en <= 1'b0;
                    if (half_tick) begin
                        delay_cnt <= delay_cnt + 1;
                        if (delay_cnt == CS_HOLD_CY - 1) delay_cnt <= '0;
                    end
                end

                DONE_ST: begin
                    miso_data <= shift_in;
                    done      <= 1'b1;
                end
            endcase
        end
    end

    // ─── Output assignments ───────────────────────────────────────────────────
    assign cs_n = ~(state inside {CS_ASSERT, TRANSFER, CS_DEASSERT});
    assign mosi  = shift_out[DATA_WIDTH-1];
    assign busy  = (state != IDLE);

endmodule : spi_master
