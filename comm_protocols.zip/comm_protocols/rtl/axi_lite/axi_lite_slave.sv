// =============================================================================
// axi_lite_slave.sv  —  AXI4-Lite Slave  (8 × 32-bit register bank)
// =============================================================================
// AXI4-Lite Write Transaction:
//
//  AWVALID ──────‾‾‾‾‾‾‾‾‾‾───────────────
//  AWREADY ───────────‾‾‾‾‾───────────────   (handshake)
//  WVALID  ──────‾‾‾‾‾‾‾‾‾‾───────────────
//  WREADY  ───────────‾‾‾‾‾───────────────   (can be concurrent with AW)
//  BVALID  ──────────────────‾‾‾‾‾────────
//  BREADY  ───────────────────────‾‾‾‾‾───   (master acknowledges response)
//  BRESP   ──────────────────<OK/SLVERR>──
//
// AXI4-Lite Read Transaction:
//
//  ARVALID ──────‾‾‾‾‾‾‾‾‾‾───────────────
//  ARREADY ───────────‾‾‾‾‾───────────────
//  RVALID  ──────────────────‾‾‾‾‾────────
//  RREADY  ───────────────────────‾‾‾‾‾───
//  RDATA   ──────────────────<DATA>───────
//  RRESP   ──────────────────<OK/SLVERR>──
//
//  Register map (byte-addressed, 32-bit aligned):
//   0x00  REG0   R/W  General purpose
//   0x04  REG1   R/W  General purpose
//   0x08  REG2   R/W  General purpose
//   0x0C  REG3   R/W  General purpose
//   0x10  REG4   R/W  General purpose
//   0x14  REG5   R/W  General purpose
//   0x18  REG6   R/W  General purpose
//   0x1C  REG7   R/W  General purpose
// =============================================================================

`timescale 1ns/1ps

module axi_lite_slave #(
    parameter int DATA_WIDTH  = 32,
    parameter int ADDR_WIDTH  = 8,
    parameter int NUM_REGS    = 8
)(
    input  logic                      aclk,
    input  logic                      aresetn,

    // ── Write Address Channel ────────────────────────────────────────────────
    input  logic [ADDR_WIDTH-1:0]     awaddr,
    input  logic [2:0]                awprot,
    input  logic                      awvalid,
    output logic                      awready,

    // ── Write Data Channel ───────────────────────────────────────────────────
    input  logic [DATA_WIDTH-1:0]     wdata,
    input  logic [DATA_WIDTH/8-1:0]   wstrb,
    input  logic                      wvalid,
    output logic                      wready,

    // ── Write Response Channel ───────────────────────────────────────────────
    output logic [1:0]                bresp,
    output logic                      bvalid,
    input  logic                      bready,

    // ── Read Address Channel ─────────────────────────────────────────────────
    input  logic [ADDR_WIDTH-1:0]     araddr,
    input  logic [2:0]                arprot,
    input  logic                      arvalid,
    output logic                      arready,

    // ── Read Data Channel ────────────────────────────────────────────────────
    output logic [DATA_WIDTH-1:0]     rdata,
    output logic [1:0]                rresp,
    output logic                      rvalid,
    input  logic                      rready,

    // ── Register access (sideband) ───────────────────────────────────────────
    output logic [DATA_WIDTH-1:0]     reg_out [NUM_REGS],
    input  logic [DATA_WIDTH-1:0]     reg_in  [NUM_REGS]   // hardware-driven values
);

    localparam int REG_BITS = $clog2(NUM_REGS) + 2;  // byte address bits for regs

    // ─── Write-side FSM ───────────────────────────────────────────────────────
    typedef enum logic [1:0] {
        WR_IDLE  = 2'd0,
        WR_DATA  = 2'd1,
        WR_RESP  = 2'd2
    } wr_state_t;

    wr_state_t wr_state;
    logic [ADDR_WIDTH-1:0] wr_addr_r;
    logic [1:0]            wr_resp_r;

    always_ff @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin
            wr_state <= WR_IDLE;
            awready  <= 1'b0;
            wready   <= 1'b0;
            bvalid   <= 1'b0;
            bresp    <= 2'b00;
            wr_addr_r<= '0;
            for (int i = 0; i < NUM_REGS; i++) reg_out[i] <= '0;
        end else begin
            case (wr_state)
                // ── Accept address ────────────────────────────────────────────
                WR_IDLE: begin
                    awready <= 1'b0;
                    wready  <= 1'b0;
                    if (awvalid) begin
                        awready   <= 1'b1;
                        wr_addr_r <= awaddr;
                        wr_state  <= WR_DATA;
                    end
                end

                // ── Accept data & write register ─────────────────────────────
                WR_DATA: begin
                    awready <= 1'b0;
                    if (wvalid) begin
                        wready <= 1'b1;
                        // Address decode
                        if (wr_addr_r[ADDR_WIDTH-1:REG_BITS] == '0) begin
                            automatic int ridx = int'(wr_addr_r[REG_BITS-1:2]);
                            if (ridx < NUM_REGS) begin
                                // Byte-enable write
                                for (int b = 0; b < DATA_WIDTH/8; b++) begin
                                    if (wstrb[b])
                                        reg_out[ridx][b*8 +: 8] <= wdata[b*8 +: 8];
                                end
                                wr_resp_r <= 2'b00;  // OKAY
                            end else
                                wr_resp_r <= 2'b10;  // SLVERR
                        end else
                            wr_resp_r <= 2'b10;
                        wr_state <= WR_RESP;
                    end
                end

                // ── Send write response ───────────────────────────────────────
                WR_RESP: begin
                    wready <= 1'b0;
                    bvalid <= 1'b1;
                    bresp  <= wr_resp_r;
                    if (bvalid && bready) begin
                        bvalid   <= 1'b0;
                        wr_state <= WR_IDLE;
                    end
                end
            endcase
        end
    end

    // ─── Read-side FSM ────────────────────────────────────────────────────────
    typedef enum logic [1:0] {
        RD_IDLE = 2'd0,
        RD_DATA = 2'd1
    } rd_state_t;

    rd_state_t rd_state;

    always_ff @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin
            rd_state <= RD_IDLE;
            arready  <= 1'b0;
            rvalid   <= 1'b0;
            rdata    <= '0;
            rresp    <= 2'b00;
        end else begin
            case (rd_state)
                // ── Accept read address ───────────────────────────────────────
                RD_IDLE: begin
                    arready <= 1'b0;
                    rvalid  <= 1'b0;
                    if (arvalid) begin
                        arready <= 1'b1;
                        // Address decode
                        if (araddr[ADDR_WIDTH-1:REG_BITS] == '0) begin
                            automatic int ridx = int'(araddr[REG_BITS-1:2]);
                            if (ridx < NUM_REGS) begin
                                rdata <= reg_in[ridx];   // hardware value takes priority
                                rresp <= 2'b00;
                            end else begin
                                rdata <= '0;
                                rresp <= 2'b10;
                            end
                        end else begin
                            rdata <= '0;
                            rresp <= 2'b10;
                        end
                        rd_state <= RD_DATA;
                    end
                end

                // ── Present read data ─────────────────────────────────────────
                RD_DATA: begin
                    arready <= 1'b0;
                    rvalid  <= 1'b1;
                    if (rvalid && rready) begin
                        rvalid   <= 1'b0;
                        rd_state <= RD_IDLE;
                    end
                end
            endcase
        end
    end

endmodule : axi_lite_slave
