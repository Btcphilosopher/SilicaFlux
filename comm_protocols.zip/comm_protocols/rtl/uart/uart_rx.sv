// =============================================================================
// uart_rx.sv  —  UART Receiver  (16× oversampling)
// =============================================================================
// Timing Diagram:
//
//  RX  ‾‾‾‾‾‾|___|D0|D1|D2|D3|D4|D5|D6|D7|‾‾‾
//              ↑   ↑                       ↑
//           edge  sample                 stop
//           detect at tick 8            sample
//
//  Each bit = 16 oversample ticks.  Sample taken at tick 8 (centre).
//  FSM: IDLE ─► START_BIT ─► DATA_BITS ─► [PARITY_BIT] ─► STOP_BIT ─► IDLE
// =============================================================================

`timescale 1ns/1ps

module uart_rx #(
    parameter int CLK_FREQ   = 50_000_000,
    parameter int BAUD_RATE  = 115_200,
    parameter int DATA_BITS  = 8,
    parameter int STOP_BITS  = 1,
    parameter bit PARITY_EN  = 0,
    parameter bit PARITY_ODD = 0
)(
    input  logic                  clk,
    input  logic                  rst_n,
    // Serial input (synchronised externally or via 2-FF)
    input  logic                  rx,
    // AXI-stream-like data output
    output logic [DATA_BITS-1:0]  rx_data,
    output logic                  rx_valid,   // 1-cycle pulse
    // Status
    output logic                  frame_err,  // stop-bit mismatch
    output logic                  parity_err  // parity mismatch
);

    localparam int OVERSAMPLE    = 16;
    localparam int BAUD_DIV      = CLK_FREQ / (BAUD_RATE * OVERSAMPLE);
    localparam int SAMPLE_POINT  = OVERSAMPLE / 2;   // tick 8

    // ─── 2-FF input synchroniser ──────────────────────────────────────────────
    logic rx_s1, rx_sync, rx_prev;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) {rx_s1, rx_sync, rx_prev} <= 3'b111;
        else        {rx_s1, rx_sync, rx_prev} <= {rx, rx_s1, rx_sync};
    end
    wire rx_falling = rx_prev & ~rx_sync;   // negedge detector

    // ─── Oversample tick generator ────────────────────────────────────────────
    logic [$clog2(BAUD_DIV)-1:0]    div_cnt;
    logic                            os_tick;   // 1 pulse per oversample period
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) div_cnt <= '0;
        else        div_cnt <= (div_cnt == BAUD_DIV - 1) ? '0 : div_cnt + 1;
    end
    assign os_tick = (div_cnt == BAUD_DIV - 1);

    // ─── FSM ──────────────────────────────────────────────────────────────────
    typedef enum logic [2:0] {
        IDLE       = 3'b000,
        START_BIT  = 3'b001,
        DATA_BITS  = 3'b010,
        PARITY_BIT = 3'b011,
        STOP_BIT   = 3'b100
    } rx_state_t;

    rx_state_t              state, next_state;
    logic [3:0]             tick_cnt;     // 0..15 within each bit
    logic [$clog2(DATA_BITS)-1:0] bit_idx;
    logic [DATA_BITS-1:0]   shift_reg;
    logic                   sampled_parity;

    // State register
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) state <= IDLE;
        else        state <= next_state;
    end

    // Next-state logic
    always_comb begin
        next_state = state;
        unique case (state)
            IDLE:       if (rx_falling)                                           next_state = START_BIT;
            START_BIT:  if (os_tick && tick_cnt == OVERSAMPLE - 1)               next_state = DATA_BITS;
            DATA_BITS:  if (os_tick && tick_cnt == OVERSAMPLE - 1
                             && bit_idx == DATA_BITS - 1)
                            next_state = PARITY_EN ? PARITY_BIT : STOP_BIT;
            PARITY_BIT: if (os_tick && tick_cnt == OVERSAMPLE - 1)               next_state = STOP_BIT;
            STOP_BIT:   if (os_tick && tick_cnt == OVERSAMPLE - 1)               next_state = IDLE;
            default:    next_state = IDLE;
        endcase
    end

    // Datapath
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tick_cnt       <= '0;
            bit_idx        <= '0;
            shift_reg      <= '0;
            sampled_parity <= 1'b0;
            rx_data        <= '0;
            rx_valid       <= 1'b0;
            frame_err      <= 1'b0;
            parity_err     <= 1'b0;
        end else begin
            rx_valid   <= 1'b0;
            frame_err  <= 1'b0;
            parity_err <= 1'b0;

            case (state)
                IDLE: tick_cnt <= '0;

                START_BIT: begin
                    if (os_tick) begin
                        tick_cnt <= tick_cnt + 1;
                        if (tick_cnt == OVERSAMPLE - 1) begin
                            tick_cnt <= '0;
                            bit_idx  <= '0;
                        end
                    end
                end

                DATA_BITS: begin
                    if (os_tick) begin
                        tick_cnt <= tick_cnt + 1;
                        if (tick_cnt == SAMPLE_POINT - 1)
                            shift_reg <= {rx_sync, shift_reg[DATA_BITS-1:1]};  // LSB first
                        if (tick_cnt == OVERSAMPLE - 1) begin
                            tick_cnt <= '0;
                            bit_idx  <= bit_idx + 1;
                        end
                    end
                end

                PARITY_BIT: begin
                    if (os_tick) begin
                        tick_cnt <= tick_cnt + 1;
                        if (tick_cnt == SAMPLE_POINT - 1)
                            sampled_parity <= rx_sync;
                        if (tick_cnt == OVERSAMPLE - 1)
                            tick_cnt <= '0;
                    end
                end

                STOP_BIT: begin
                    if (os_tick) begin
                        tick_cnt <= tick_cnt + 1;
                        if (tick_cnt == SAMPLE_POINT - 1) begin
                            // Validate stop bit
                            frame_err <= ~rx_sync;
                            // Validate parity
                            if (PARITY_EN) begin
                                logic exp_par;
                                exp_par    = PARITY_ODD ? ~^shift_reg : ^shift_reg;
                                parity_err <= (sampled_parity != exp_par);
                            end
                        end
                        if (tick_cnt == OVERSAMPLE - 1) begin
                            tick_cnt <= '0;
                            rx_data  <= shift_reg;
                            rx_valid <= 1'b1;
                        end
                    end
                end
            endcase
        end
    end

endmodule : uart_rx
