// =============================================================================
// uart_tx.sv  —  UART Transmitter
// =============================================================================
// Timing Diagram (8N1 frame):
//
//  TX  ‾‾‾‾‾‾|_|D0|D1|D2|D3|D4|D5|D6|D7|‾‾‾‾‾‾
//             START                       STOP
//  bit period = CLK_FREQ / BAUD_RATE clocks
//
// FSM:  IDLE ─► START_BIT ─► DATA_BITS ─► [PARITY_BIT] ─► STOP_BIT ─► IDLE
// =============================================================================

`timescale 1ns/1ps

module uart_tx #(
    parameter int CLK_FREQ   = 50_000_000,  // System clock (Hz)
    parameter int BAUD_RATE  = 115_200,     // Baud rate
    parameter int DATA_BITS  = 8,           // 5–9 data bits
    parameter int STOP_BITS  = 1,           // 1 or 2 stop bits
    parameter bit PARITY_EN  = 0,           // 1 = enable parity
    parameter bit PARITY_ODD = 0            // 0 = even, 1 = odd
)(
    input  logic                  clk,
    input  logic                  rst_n,
    // AXI-stream-like data interface
    input  logic [DATA_BITS-1:0]  tx_data,
    input  logic                  tx_valid,
    output logic                  tx_ready,
    // Serial output
    output logic                  tx,
    output logic                  tx_busy
);

    localparam int BIT_PERIOD = CLK_FREQ / BAUD_RATE;

    // ─── FSM state encoding ───────────────────────────────────────────────────
    typedef enum logic [2:0] {
        IDLE      = 3'b000,
        START_BIT = 3'b001,
        DATA_BITS = 3'b010,
        PARITY_BIT= 3'b011,
        STOP_BIT  = 3'b100
    } tx_state_t;

    tx_state_t              state, next_state;
    logic [$clog2(BIT_PERIOD)-1:0] baud_cnt;
    logic [$clog2(DATA_BITS)-1:0]  bit_idx;
    logic [DATA_BITS-1:0]   shift_reg;
    logic                   baud_tick;
    logic                   parity_bit;
    logic [1:0]             stop_cnt;

    // ─── Baud rate generator ─────────────────────────────────────────────────
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            baud_cnt <= '0;
        else if (state == IDLE)
            baud_cnt <= '0;
        else
            baud_cnt <= (baud_cnt == BIT_PERIOD - 1) ? '0 : baud_cnt + 1;
    end
    assign baud_tick = (baud_cnt == BIT_PERIOD - 1);

    // ─── Parity calculation (combinational) ──────────────────────────────────
    assign parity_bit = PARITY_ODD ? ~^shift_reg : ^shift_reg;

    // ─── State register ───────────────────────────────────────────────────────
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) state <= IDLE;
        else        state <= next_state;
    end

    // ─── Next-state logic ─────────────────────────────────────────────────────
    always_comb begin
        next_state = state;
        unique case (state)
            IDLE:       if (tx_valid)                                  next_state = START_BIT;
            START_BIT:  if (baud_tick)                                 next_state = DATA_BITS;
            DATA_BITS:  if (baud_tick && bit_idx == DATA_BITS-1)
                            next_state = PARITY_EN ? PARITY_BIT : STOP_BIT;
            PARITY_BIT: if (baud_tick)                                 next_state = STOP_BIT;
            STOP_BIT:   if (baud_tick && stop_cnt == STOP_BITS - 1)   next_state = IDLE;
            default:    next_state = IDLE;
        endcase
    end

    // ─── Datapath registers ───────────────────────────────────────────────────
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            shift_reg <= '0;
            bit_idx   <= '0;
            stop_cnt  <= '0;
        end else begin
            case (state)
                IDLE: if (tx_valid) shift_reg <= tx_data;

                DATA_BITS: if (baud_tick) begin
                    shift_reg <= shift_reg >> 1;          // LSB first
                    bit_idx   <= bit_idx + 1;
                end

                STOP_BIT: begin
                    bit_idx  <= '0;
                    if (baud_tick) stop_cnt <= stop_cnt + 1;
                end

                default: begin
                    bit_idx  <= '0;
                    stop_cnt <= '0;
                end
            endcase
        end
    end

    // ─── Output logic ─────────────────────────────────────────────────────────
    always_comb begin
        tx       = 1'b1;          // idle/stop high
        tx_ready = (state == IDLE);
        tx_busy  = (state != IDLE);

        unique case (state)
            IDLE:        tx = 1'b1;
            START_BIT:   tx = 1'b0;
            DATA_BITS:   tx = shift_reg[0];
            PARITY_BIT:  tx = parity_bit;
            STOP_BIT:    tx = 1'b1;
            default:     tx = 1'b1;
        endcase
    end

endmodule : uart_tx
