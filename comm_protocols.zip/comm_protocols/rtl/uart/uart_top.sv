// =============================================================================
// uart_top.sv  —  UART Top-level (TX + RX paired)
// =============================================================================
`timescale 1ns/1ps

module uart_top #(
    parameter int CLK_FREQ   = 50_000_000,
    parameter int BAUD_RATE  = 115_200,
    parameter int DATA_BITS  = 8,
    parameter int STOP_BITS  = 1,
    parameter bit PARITY_EN  = 0,
    parameter bit PARITY_ODD = 0
)(
    input  logic                  clk,
    input  logic                  rst_n,
    // TX interface
    input  logic [DATA_BITS-1:0]  tx_data,
    input  logic                  tx_valid,
    output logic                  tx_ready,
    output logic                  tx_busy,
    // RX interface
    output logic [DATA_BITS-1:0]  rx_data,
    output logic                  rx_valid,
    output logic                  frame_err,
    output logic                  parity_err,
    // Pins
    output logic                  uart_tx,
    input  logic                  uart_rx
);

    uart_tx #(
        .CLK_FREQ   (CLK_FREQ),
        .BAUD_RATE  (BAUD_RATE),
        .DATA_BITS  (DATA_BITS),
        .STOP_BITS  (STOP_BITS),
        .PARITY_EN  (PARITY_EN),
        .PARITY_ODD (PARITY_ODD)
    ) u_tx (
        .clk      (clk),
        .rst_n    (rst_n),
        .tx_data  (tx_data),
        .tx_valid (tx_valid),
        .tx_ready (tx_ready),
        .tx       (uart_tx),
        .tx_busy  (tx_busy)
    );

    uart_rx #(
        .CLK_FREQ   (CLK_FREQ),
        .BAUD_RATE  (BAUD_RATE),
        .DATA_BITS  (DATA_BITS),
        .STOP_BITS  (STOP_BITS),
        .PARITY_EN  (PARITY_EN),
        .PARITY_ODD (PARITY_ODD)
    ) u_rx (
        .clk        (clk),
        .rst_n      (rst_n),
        .rx         (uart_rx),
        .rx_data    (rx_data),
        .rx_valid   (rx_valid),
        .frame_err  (frame_err),
        .parity_err (parity_err)
    );

endmodule : uart_top
