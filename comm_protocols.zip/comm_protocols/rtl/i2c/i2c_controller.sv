// =============================================================================
// i2c_controller.sv  —  I²C Master Controller
// =============================================================================
// Timing Diagram (100 kHz standard mode, write transaction):
//
//  SDA  ‾‾‾\_7bit ADDR_/R/W\A/___DATA___\A/‾‾‾
//  SCL  ‾‾‾‾|_| |_|...|_| |_||_|...|_| |_|‾‾‾
//            ↑                                ↑
//          START                             STOP
//
//  Bit transfer (single bit):
//  SCL  ______‾‾‾‾‾‾‾‾______
//  SDA  ──<stable>────────────
//          ↑       ↑
//        setup   hold (SDA must not change while SCL high)
//
//  SCL period = 4 × QUARTER phases:
//   Phase 0: SCL low,  SDA change allowed
//   Phase 1: SCL rising
//   Phase 2: SCL high, SDA sampled
//   Phase 3: SCL falling
//
//  FSM: IDLE ─► START ─► SEND_ADDR ─► ACK_ADDR
//              ─► [WRITE: SEND_DATA ─► ACK_DATA]+
//              ─► [READ:  RECV_DATA ─► MACK_DATA]+
//              ─► STOP ─► IDLE
// =============================================================================

`timescale 1ns/1ps

module i2c_controller #(
    parameter int CLK_FREQ   = 50_000_000,   // System clock (Hz)
    parameter int SCL_FREQ   = 100_000,      // SCL frequency (Hz)
    parameter int MAX_BYTES  = 16            // Max bytes per transaction
)(
    input  logic        clk,
    input  logic        rst_n,

    // Command interface
    input  logic [6:0]  dev_addr,            // 7-bit device address
    input  logic        rw,                  // 0=write, 1=read
    input  logic [7:0]  byte_count,          // number of data bytes
    input  logic [7:0]  wr_data [MAX_BYTES], // write data array
    input  logic        start_cmd,           // pulse to begin

    // Response interface
    output logic [7:0]  rd_data [MAX_BYTES], // read data array
    output logic        done,                // 1-cycle pulse
    output logic        ack_err,             // NACK detected
    output logic        busy,

    // I²C open-drain pins (use pullups externally)
    inout  wire         scl,
    inout  wire         sda
);

    localparam int QUARTER = CLK_FREQ / (SCL_FREQ * 4);  // clocks per quarter-period

    // ─── FSM states ───────────────────────────────────────────────────────────
    typedef enum logic [3:0] {
        IDLE       = 4'd0,
        START      = 4'd1,
        SEND_ADDR  = 4'd2,
        ACK_ADDR   = 4'd3,
        SEND_DATA  = 4'd4,
        ACK_DATA   = 4'd5,
        RECV_DATA  = 4'd6,
        MACK_DATA  = 4'd7,
        STOP       = 4'd8,
        DONE_ST    = 4'd9,
        ERR_ST     = 4'd10
    } i2c_state_t;

    i2c_state_t                     state, next_state;

    // ─── Clock divider / phase generator (0–3) ────────────────────────────────
    logic [$clog2(QUARTER)-1:0] q_cnt;
    logic [1:0]                 phase;          // 0..3
    logic                       phase_tick;     // pulse at end of each phase

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) q_cnt <= '0;
        else        q_cnt <= (q_cnt == QUARTER - 1) ? '0 : q_cnt + 1;
    end
    assign phase_tick = (q_cnt == QUARTER - 1);

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)                          phase <= 2'd0;
        else if (state == IDLE)              phase <= 2'd0;
        else if (phase_tick)                 phase <= phase + 1;
    end

    // ─── Open-drain drive registers ───────────────────────────────────────────
    logic scl_oe, sda_oe;   // 1 = drive low, 0 = release (pulled high)
    assign scl = scl_oe ? 1'b0 : 1'bz;
    assign sda = sda_oe ? 1'b0 : 1'bz;

    // ─── Internal registers ───────────────────────────────────────────────────
    logic [7:0]  shift_reg;         // current byte being sent/received
    logic [2:0]  bit_cnt;           // bit index within byte (7..0)
    logic [7:0]  byte_idx;          // which byte in the transaction
    logic        sda_in;            // latched SDA sample
    logic        rw_r;              // latched rw
    logic [6:0]  addr_r;
    logic [7:0]  bcount_r;

    // ─── State register ───────────────────────────────────────────────────────
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) state <= IDLE;
        else        state <= next_state;
    end

    // ─── Next-state logic ─────────────────────────────────────────────────────
    always_comb begin
        next_state = state;
        if (phase_tick) begin
            unique case (state)
                IDLE:      if (start_cmd)                         next_state = START;

                // START condition: SDA falls while SCL high (phase 3→0 transition)
                START:     if (phase == 2'd3)                     next_state = SEND_ADDR;

                // Send 8 bits (7-bit addr + R/W)
                SEND_ADDR: if (phase == 2'd3 && bit_cnt == 3'd0)  next_state = ACK_ADDR;

                ACK_ADDR:  if (phase == 2'd2) begin
                               if (sda !== 1'b0)                  next_state = ERR_ST;
                               else if (rw_r)                     next_state = RECV_DATA;
                               else                               next_state = SEND_DATA;
                           end

                SEND_DATA: if (phase == 2'd3 && bit_cnt == 3'd0)  next_state = ACK_DATA;

                ACK_DATA:  if (phase == 2'd2) begin
                               if (sda !== 1'b0)                  next_state = ERR_ST;
                               else if (byte_idx == bcount_r - 1) next_state = STOP;
                               else                               next_state = SEND_DATA;
                           end

                RECV_DATA: if (phase == 2'd3 && bit_cnt == 3'd0)  next_state = MACK_DATA;

                MACK_DATA: if (phase == 2'd3) begin
                               if (byte_idx == bcount_r - 1)      next_state = STOP;
                               else                               next_state = RECV_DATA;
                           end

                STOP:      if (phase == 2'd3)                     next_state = DONE_ST;
                DONE_ST:                                           next_state = IDLE;
                ERR_ST:                                            next_state = IDLE;
                default:   next_state = IDLE;
            endcase
        end
    end

    // ─── Datapath ─────────────────────────────────────────────────────────────
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            scl_oe    <= 1'b0;
            sda_oe    <= 1'b0;
            shift_reg <= '0;
            bit_cnt   <= 3'd7;
            byte_idx  <= '0;
            sda_in    <= 1'b1;
            done      <= 1'b0;
            ack_err   <= 1'b0;
            rw_r      <= 1'b0;
            addr_r    <= '0;
            bcount_r  <= '0;
        end else begin
            done    <= 1'b0;
            ack_err <= 1'b0;

            case (state)
                IDLE: begin
                    scl_oe   <= 1'b0;
                    sda_oe   <= 1'b0;
                    bit_cnt  <= 3'd7;
                    byte_idx <= '0;
                    if (start_cmd) begin
                        addr_r   <= dev_addr;
                        rw_r     <= rw;
                        bcount_r <= byte_count;
                    end
                end

                // START: SCL high, pull SDA low
                START: begin
                    scl_oe <= 1'b0;
                    if (phase == 2'd1)      sda_oe <= 1'b1;   // SDA falls (START condition)
                    if (phase == 2'd3) begin
                        scl_oe    <= 1'b1;                     // SCL goes low
                        shift_reg <= {addr_r, rw_r};
                        bit_cnt   <= 3'd7;
                    end
                end

                // Send address+R/W byte, MSB first
                SEND_ADDR: begin
                    case (phase)
                        2'd0: begin
                            scl_oe <= 1'b1;                    // SCL low
                            sda_oe <= ~shift_reg[7];           // drive bit
                        end
                        2'd1: scl_oe <= 1'b0;                  // SCL rises
                        2'd2: /* SCL high — hold */;
                        2'd3: begin
                            scl_oe <= 1'b1;                    // SCL falls
                            if (bit_cnt != 3'd0) begin
                                shift_reg <= {shift_reg[6:0], 1'b0};
                                bit_cnt   <= bit_cnt - 1;
                            end
                        end
                    endcase
                end

                // ACK from slave: release SDA, sample on SCL high
                ACK_ADDR: begin
                    sda_oe <= 1'b0;                            // release SDA
                    case (phase)
                        2'd0: scl_oe <= 1'b1;
                        2'd1: scl_oe <= 1'b0;
                        2'd2: sda_in <= sda;                   // sample ACK
                        2'd3: begin
                            scl_oe <= 1'b1;
                            // Prepare first data byte
                            if (sda == 1'b0) begin
                                if (!rw_r) shift_reg <= wr_data[0];
                                bit_cnt  <= 3'd7;
                                byte_idx <= '0;
                            end
                        end
                    endcase
                end

                // Write data byte
                SEND_DATA: begin
                    case (phase)
                        2'd0: begin
                            scl_oe <= 1'b1;
                            sda_oe <= ~shift_reg[7];
                        end
                        2'd1: scl_oe <= 1'b0;
                        2'd2: /* hold */;
                        2'd3: begin
                            scl_oe <= 1'b1;
                            if (bit_cnt != 3'd0) begin
                                shift_reg <= {shift_reg[6:0], 1'b0};
                                bit_cnt   <= bit_cnt - 1;
                            end
                        end
                    endcase
                end

                // ACK after write byte
                ACK_DATA: begin
                    sda_oe <= 1'b0;
                    case (phase)
                        2'd0: scl_oe <= 1'b1;
                        2'd1: scl_oe <= 1'b0;
                        2'd2: sda_in <= sda;
                        2'd3: begin
                            scl_oe <= 1'b1;
                            if (sda == 1'b0 && byte_idx < bcount_r - 1) begin
                                byte_idx  <= byte_idx + 1;
                                shift_reg <= wr_data[byte_idx + 1];
                                bit_cnt   <= 3'd7;
                            end
                        end
                    endcase
                end

                // Read data byte from slave
                RECV_DATA: begin
                    sda_oe <= 1'b0;                            // release SDA
                    case (phase)
                        2'd0: scl_oe <= 1'b1;
                        2'd1: scl_oe <= 1'b0;
                        2'd2: shift_reg <= {shift_reg[6:0], sda};  // sample bit
                        2'd3: begin
                            scl_oe <= 1'b1;
                            bit_cnt <= bit_cnt - 1;
                        end
                    endcase
                end

                // Master ACK/NACK: NACK on last byte, ACK otherwise
                MACK_DATA: begin
                    case (phase)
                        2'd0: begin
                            scl_oe <= 1'b1;
                            // NACK (SDA high) on last byte
                            sda_oe <= (byte_idx < bcount_r - 1) ? 1'b1 : 1'b0;
                            rd_data[byte_idx] <= shift_reg;
                        end
                        2'd1: scl_oe <= 1'b0;
                        2'd2: /* hold */;
                        2'd3: begin
                            scl_oe <= 1'b1;
                            if (byte_idx < bcount_r - 1) begin
                                byte_idx <= byte_idx + 1;
                                bit_cnt  <= 3'd7;
                            end
                        end
                    endcase
                end

                // STOP: SCL high, SDA rises
                STOP: begin
                    sda_oe <= 1'b1;                            // SDA low first
                    case (phase)
                        2'd0: scl_oe <= 1'b1;
                        2'd1: scl_oe <= 1'b0;
                        2'd2: /* SCL high */;
                        2'd3: sda_oe <= 1'b0;                  // SDA rises → STOP
                    endcase
                end

                DONE_ST: done   <= 1'b1;
                ERR_ST:  ack_err <= 1'b1;
            endcase
        end
    end

    assign busy = (state != IDLE);

endmodule : i2c_controller
