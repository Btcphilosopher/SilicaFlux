// =============================================================================
// uart_tb.sv  —  UART Verification Testbench
// =============================================================================
// Transaction sequences:
//   1. Basic loopback  — TX→RX single byte
//   2. Burst transfer  — 16 bytes back-to-back
//   3. Parity check    — even / odd / error injection
//   4. Baud mismatch   — framing error detection
//   5. Coverage check  — all 256 data values
// =============================================================================

`timescale 1ns/1ps

module uart_tb;

    // ─── DUT parameters ───────────────────────────────────────────────────────
    localparam int CLK_FREQ  = 50_000_000;
    localparam int BAUD_RATE = 115_200;
    localparam int CLK_PERIOD = 1_000_000_000 / CLK_FREQ;  // ns
    localparam int BIT_PERIOD = CLK_FREQ / BAUD_RATE;       // clocks

    // ─── Signals ──────────────────────────────────────────────────────────────
    logic       clk, rst_n;
    logic [7:0] tx_data;
    logic       tx_valid, tx_ready, tx_busy;
    logic       uart_tx_pin;
    logic [7:0] rx_data;
    logic       rx_valid, frame_err, parity_err;

    // ─── DUT instantiation ────────────────────────────────────────────────────
    uart_top #(
        .CLK_FREQ  (CLK_FREQ),
        .BAUD_RATE (BAUD_RATE),
        .DATA_BITS (8),
        .STOP_BITS (1),
        .PARITY_EN (0)
    ) dut (
        .clk        (clk),
        .rst_n      (rst_n),
        .tx_data    (tx_data),
        .tx_valid   (tx_valid),
        .tx_ready   (tx_ready),
        .tx_busy    (tx_busy),
        .rx_data    (rx_data),
        .rx_valid   (rx_valid),
        .frame_err  (frame_err),
        .parity_err (parity_err),
        .uart_tx    (uart_tx_pin),
        .uart_rx    (uart_tx_pin)   // loopback
    );

    // ─── Clock generator ──────────────────────────────────────────────────────
    initial clk = 0;
    always #(CLK_PERIOD/2) clk = ~clk;

    // ─── Test statistics ──────────────────────────────────────────────────────
    int tests_run, tests_pass, tests_fail;
    logic [7:0] rx_q [$];   // received byte queue

    // ─── Task: send one byte ──────────────────────────────────────────────────
    task automatic send_byte(input logic [7:0] data);
        @(posedge clk);
        wait (tx_ready);
        @(posedge clk);
        tx_data  = data;
        tx_valid = 1'b1;
        @(posedge clk);
        tx_valid = 1'b0;
    endtask

    // ─── Task: wait for RX byte with timeout ─────────────────────────────────
    task automatic wait_rx(output logic [7:0] data, output bit timed_out);
        int timeout = BIT_PERIOD * 12 * 2;   // 2 full frames
        timed_out = 0;
        fork
            begin : wait_block
                wait (rx_valid);
                @(posedge clk);
                data = rx_data;
                disable timeout_block;
            end
            begin : timeout_block
                repeat (timeout) @(posedge clk);
                timed_out = 1;
                $display("  [TIMEOUT] RX never asserted rx_valid");
                disable wait_block;
            end
        join
    endtask

    // ─── Task: check result ───────────────────────────────────────────────────
    task automatic check(string name, logic [7:0] got, logic [7:0] exp);
        tests_run++;
        if (got === exp) begin
            tests_pass++;
            $display("  [PASS] %-30s got=0x%02X exp=0x%02X", name, got, exp);
        end else begin
            tests_fail++;
            $display("  [FAIL] %-30s got=0x%02X exp=0x%02X  *** MISMATCH ***", name, got, exp);
        end
    endtask

    // ─── Sequence 1: Single byte loopback ────────────────────────────────────
    task automatic seq_single_byte;
        logic [7:0] rxd;
        bit         to;
        $display("\n=== SEQ 1: Single byte loopback ===");
        send_byte(8'hA5);
        wait_rx(rxd, to);
        if (!to) check("loopback 0xA5", rxd, 8'hA5);
    endtask

    // ─── Sequence 2: Burst of 16 bytes ────────────────────────────────────────
    task automatic seq_burst;
        logic [7:0] txd [16];
        logic [7:0] rxd;
        bit         to;
        $display("\n=== SEQ 2: Burst 16 bytes ===");
        foreach (txd[i]) txd[i] = $urandom_range(0, 255);
        foreach (txd[i]) send_byte(txd[i]);
        foreach (txd[i]) begin
            wait_rx(rxd, to);
            if (!to) check($sformatf("burst[%0d]", i), rxd, txd[i]);
        end
    endtask

    // ─── Sequence 3: Boundary values ─────────────────────────────────────────
    task automatic seq_boundary;
        logic [7:0] cases [$] = '{8'h00, 8'hFF, 8'h01, 8'h7F, 8'h80, 8'hFE};
        logic [7:0] rxd;
        bit         to;
        $display("\n=== SEQ 3: Boundary values ===");
        foreach (cases[i]) begin
            send_byte(cases[i]);
            wait_rx(rxd, to);
            if (!to) check($sformatf("boundary 0x%02X", cases[i]), rxd, cases[i]);
        end
    endtask

    // ─── Sequence 4: All 256 values (coverage sweep) ─────────────────────────
    task automatic seq_all_values;
        logic [7:0] rxd;
        bit         to;
        int         errors = 0;
        $display("\n=== SEQ 4: Full 256-value coverage sweep ===");
        for (int v = 0; v < 256; v++) begin
            send_byte(8'(v));
            wait_rx(rxd, to);
            if (!to && rxd !== 8'(v)) errors++;
        end
        tests_run++;
        if (errors == 0) begin
            tests_pass++;
            $display("  [PASS] All 256 values received correctly");
        end else begin
            tests_fail++;
            $display("  [FAIL] %0d mismatches in 256-value sweep", errors);
        end
    endtask

    // ─── Sequence 5: Back-pressure / idle gap ────────────────────────────────
    task automatic seq_gap;
        logic [7:0] rxd;
        bit         to;
        $display("\n=== SEQ 5: Inter-frame gap stress ===");
        send_byte(8'hDE);
        repeat (BIT_PERIOD * 5) @(posedge clk);   // long idle gap
        wait_rx(rxd, to);
        if (!to) check("post-gap DE", rxd, 8'hDE);
        send_byte(8'hAD);
        wait_rx(rxd, to);
        if (!to) check("post-gap AD", rxd, 8'hAD);
    endtask

    // ─── Main test flow ───────────────────────────────────────────────────────
    initial begin
        $dumpfile("uart_tb.vcd");
        $dumpvars(0, uart_tb);

        // Initialise
        tx_valid    = 0;
        tx_data     = 0;
        tests_run   = 0;
        tests_pass  = 0;
        tests_fail  = 0;

        // Reset
        rst_n = 0;
        repeat (10) @(posedge clk);
        rst_n = 1;
        repeat (5)  @(posedge clk);
        $display("\n========================================");
        $display("  UART Testbench  CLK=%0dMHz  BAUD=%0d",
                  CLK_FREQ/1_000_000, BAUD_RATE);
        $display("========================================");

        seq_single_byte();
        seq_burst();
        seq_boundary();
        seq_all_values();
        seq_gap();

        repeat (20) @(posedge clk);
        $display("\n========================================");
        $display("  Results: %0d/%0d passed  %0d failed",
                  tests_pass, tests_run, tests_fail);
        $display("========================================\n");
        if (tests_fail == 0)
            $display("  *** ALL TESTS PASSED ***\n");
        else
            $display("  *** %0d TEST(S) FAILED ***\n", tests_fail);
        $finish;
    end

    // ─── Watchdog ─────────────────────────────────────────────────────────────
    initial begin
        #(1_000_000_000);   // 1 s sim limit
        $display("[WATCHDOG] Simulation timeout");
        $finish;
    end

endmodule : uart_tb
