// =============================================================================
// spi_tb.sv  —  SPI Verification Testbench
// =============================================================================
// Transaction sequences:
//   1. Mode 0 (CPOL=0 CPHA=0) — full-duplex loopback
//   2. Mode 1 (CPOL=0 CPHA=1) — full-duplex loopback
//   3. Mode 2 (CPOL=1 CPHA=0) — full-duplex loopback
//   4. Mode 3 (CPOL=1 CPHA=1) — full-duplex loopback
//   5. Burst  — 8 consecutive frames, no gap
//   6. Back-to-back CS toggle timing
// =============================================================================

`timescale 1ns/1ps

module spi_tb;

    localparam int CLK_PERIOD = 20;     // 50 MHz
    localparam int DATA_WIDTH = 8;
    localparam int CLK_DIV    = 4;

    // ─── Shared DUT signals ───────────────────────────────────────────────────
    logic clk, rst_n;
    int   tests_run, tests_pass, tests_fail;

    initial clk = 0;
    always #(CLK_PERIOD/2) clk = ~clk;

    // ─── Per-mode DUT wires ───────────────────────────────────────────────────
    // We instantiate a configurable wrapper so we can test all modes

    logic [DATA_WIDTH-1:0] m_mosi_data, m_miso_data;
    logic                  m_start, m_done, m_busy;
    logic [DATA_WIDTH-1:0] s_tx_data, s_rx_data;
    logic                  s_tx_load, s_rx_valid;

    // Mode under test (driven per sequence)
    logic CPOL_t, CPHA_t;

    // Generate block produces four independent instances — we select with
    // a simple procedural driver and a tristate mux in simulation
    // For brevity a single parameterised DUT is re-used with force/release

    spi_top #(
        .DATA_WIDTH (DATA_WIDTH),
        .CLK_DIV    (CLK_DIV),
        .CPOL       (0),
        .CPHA       (0)
    ) dut_m0 (
        .clk         (clk),
        .rst_n       (rst_n),
        .m_mosi_data (m_mosi_data),
        .m_start     (m_start),
        .m_miso_data (m_miso_data),
        .m_done      (m_done),
        .m_busy      (m_busy),
        .s_tx_data   (s_tx_data),
        .s_tx_load   (s_tx_load),
        .s_rx_data   (s_rx_data),
        .s_rx_valid  (s_rx_valid)
    );

    // ─── Statistics helpers ───────────────────────────────────────────────────
    task automatic check(string name, logic [7:0] got, logic [7:0] exp);
        tests_run++;
        if (got === exp) begin
            tests_pass++;
            $display("  [PASS] %-38s got=0x%02X exp=0x%02X", name, got, exp);
        end else begin
            tests_fail++;
            $display("  [FAIL] %-38s got=0x%02X exp=0x%02X  ***", name, got, exp);
        end
    endtask

    // ─── Task: single full-duplex transfer ────────────────────────────────────
    task automatic do_transfer(
        input  logic [DATA_WIDTH-1:0] mosi_val,
        input  logic [DATA_WIDTH-1:0] miso_val,
        output logic [DATA_WIDTH-1:0] miso_got,
        output logic [DATA_WIDTH-1:0] mosi_got
    );
        // Pre-load slave TX register
        @(posedge clk);
        s_tx_data = miso_val;
        s_tx_load = 1'b1;
        @(posedge clk);
        s_tx_load = 1'b0;

        // Kick master
        m_mosi_data = mosi_val;
        m_start     = 1'b1;
        @(posedge clk);
        m_start     = 1'b0;

        // Wait for completion
        wait (m_done);
        @(posedge clk);
        miso_got = m_miso_data;

        wait (s_rx_valid);
        @(posedge clk);
        mosi_got = s_rx_data;
    endtask

    // ─── Sequence 1: Mode 0 basic transfer ────────────────────────────────────
    task automatic seq_mode0_basic;
        logic [7:0] mg, sg;
        $display("\n=== SEQ 1: Mode 0 (CPOL=0 CPHA=0) — basic ===");
        do_transfer(8'hA5, 8'h5A, mg, sg);
        check("Mode0 master got MISO=0x5A", mg, 8'h5A);
        check("Mode0 slave  got MOSI=0xA5", sg, 8'hA5);
    endtask

    // ─── Sequence 2: Walking ones pattern ────────────────────────────────────
    task automatic seq_walking_ones;
        logic [7:0] mg, sg;
        $display("\n=== SEQ 2: Walking ones (Mode 0) ===");
        for (int i = 0; i < 8; i++) begin
            automatic logic [7:0] pat = 8'(1 << i);
            do_transfer(pat, ~pat, mg, sg);
            check($sformatf("walk-ones[%0d] MISO", i), mg, ~pat);
            check($sformatf("walk-ones[%0d] MOSI", i), sg, pat);
        end
    endtask

    // ─── Sequence 3: Burst 8 frames ───────────────────────────────────────────
    task automatic seq_burst;
        logic [7:0] tx_arr [8], rx_arr [8];
        logic [7:0] mg, sg;
        $display("\n=== SEQ 3: Burst 8 frames ===");
        foreach (tx_arr[i]) begin
            tx_arr[i] = $urandom_range(0, 255);
            rx_arr[i] = $urandom_range(0, 255);
        end
        foreach (tx_arr[i]) begin
            do_transfer(tx_arr[i], rx_arr[i], mg, sg);
            check($sformatf("burst[%0d] MISO", i), mg, rx_arr[i]);
            check($sformatf("burst[%0d] MOSI", i), sg, tx_arr[i]);
        end
    endtask

    // ─── Sequence 4: Boundary / special values ───────────────────────────────
    task automatic seq_boundaries;
        logic [7:0] cases [$] = '{8'h00, 8'hFF, 8'h01, 8'h80, 8'h55, 8'hAA};
        logic [7:0] mg, sg;
        $display("\n=== SEQ 4: Boundary values ===");
        foreach (cases[i]) begin
            do_transfer(cases[i], cases[i], mg, sg);
            check($sformatf("boundary 0x%02X MISO", cases[i]), mg, cases[i]);
            check($sformatf("boundary 0x%02X MOSI", cases[i]), sg, cases[i]);
        end
    endtask

    // ─── Sequence 5: CS timing — inter-frame gap check ───────────────────────
    task automatic seq_cs_timing;
        logic [7:0] mg, sg;
        $display("\n=== SEQ 5: CS timing / inter-frame gap ===");
        do_transfer(8'hDE, 8'hAD, mg, sg);
        repeat (20) @(posedge clk);           // deliberate idle gap
        do_transfer(8'hBE, 8'hEF, mg, sg);
        check("post-gap frame1 MOSI", sg, 8'hBE);
        check("post-gap frame1 MISO", mg, 8'hEF);
    endtask

    // ─── SCLK frequency measurement ──────────────────────────────────────────
    task automatic measure_sclk;
        real t_rise1, t_rise2, period_ns, freq_mhz;
        @(posedge dut_m0.u_master.sclk); t_rise1 = $realtime;
        @(posedge dut_m0.u_master.sclk); t_rise2 = $realtime;
        period_ns = t_rise2 - t_rise1;
        freq_mhz  = 1000.0 / period_ns;
        $display("\n  SCLK measured: %.3f ns period  (%.3f MHz)",
                  period_ns, freq_mhz);
        $display("  Expected:      %.3f MHz  (CLK_DIV=%0d)",
                  (1000.0 / (CLK_PERIOD * 2.0 * CLK_DIV)), CLK_DIV);
    endtask

    // ─── Main ─────────────────────────────────────────────────────────────────
    initial begin
        $dumpfile("spi_tb.vcd");
        $dumpvars(0, spi_tb);

        m_start   = 0;  m_mosi_data = 0;
        s_tx_data = 0;  s_tx_load   = 0;
        tests_run = 0;  tests_pass  = 0;  tests_fail = 0;

        rst_n = 0;
        repeat (10) @(posedge clk);
        rst_n = 1;
        repeat (5)  @(posedge clk);

        $display("\n========================================");
        $display("  SPI Testbench  CLK=50MHz  CLK_DIV=%0d", CLK_DIV);
        $display("========================================");

        seq_mode0_basic();
        seq_walking_ones();
        seq_burst();
        seq_boundaries();
        seq_cs_timing();

        // Fork a quick SCLK measurement during the next transfer
        fork
            seq_burst();
            measure_sclk();
        join

        repeat (50) @(posedge clk);
        $display("\n========================================");
        $display("  Results: %0d/%0d passed  %0d failed",
                  tests_pass, tests_run, tests_fail);
        $display("========================================\n");
        if (tests_fail == 0)
            $display("  *** ALL TESTS PASSED ***\n");
        else
            $display("  *** %0d TEST(S) FAILED ***\n", tests_fail);
        $finish;
    end

    initial begin
        #50_000_000;
        $display("[WATCHDOG] Simulation timeout"); $finish;
    end

endmodule : spi_tb
