// =============================================================================
// axi_lite_tb.sv  —  AXI4-Lite Slave Verification Testbench
// =============================================================================
// Transaction sequences:
//   1. Single write then read-back (all 8 registers)
//   2. Byte-enable partial write
//   3. Out-of-range address → SLVERR response
//   4. Back-to-back burst (no idle cycles between transactions)
//   5. Concurrent write + read (overlapping valid signals)
//   6. Write-response back-pressure (bready delayed)
//   7. Read-response back-pressure (rready delayed)
// =============================================================================

`timescale 1ns/1ps

module axi_lite_tb;

    localparam int DATA_WIDTH = 32;
    localparam int ADDR_WIDTH = 8;
    localparam int NUM_REGS   = 8;
    localparam int CLK_PER    = 10;   // 100 MHz

    // ─── AXI-Lite signals ────────────────────────────────────────────────────
    logic                    aclk, aresetn;
    // Write address
    logic [ADDR_WIDTH-1:0]   awaddr;
    logic [2:0]              awprot;
    logic                    awvalid, awready;
    // Write data
    logic [DATA_WIDTH-1:0]   wdata;
    logic [DATA_WIDTH/8-1:0] wstrb;
    logic                    wvalid, wready;
    // Write response
    logic [1:0]              bresp;
    logic                    bvalid, bready;
    // Read address
    logic [ADDR_WIDTH-1:0]   araddr;
    logic [2:0]              arprot;
    logic                    arvalid, arready;
    // Read data
    logic [DATA_WIDTH-1:0]   rdata;
    logic [1:0]              rresp;
    logic                    rvalid, rready;
    // Sideband
    logic [DATA_WIDTH-1:0]   reg_out [NUM_REGS];
    logic [DATA_WIDTH-1:0]   reg_in  [NUM_REGS];

    int tests_run, tests_pass, tests_fail;

    initial aclk = 0;
    always #(CLK_PER/2) aclk = ~aclk;

    // ─── DUT ──────────────────────────────────────────────────────────────────
    axi_lite_slave #(
        .DATA_WIDTH (DATA_WIDTH),
        .ADDR_WIDTH (ADDR_WIDTH),
        .NUM_REGS   (NUM_REGS)
    ) dut (.*);

    // Hardware inputs mirror reg_out for read-back
    always_comb foreach (reg_in[i]) reg_in[i] = reg_out[i];

    // ─── Statistics helpers ───────────────────────────────────────────────────
    task automatic check32(string name, logic [31:0] got, logic [31:0] exp);
        tests_run++;
        if (got === exp) begin
            tests_pass++;
            $display("  [PASS] %-40s got=0x%08X exp=0x%08X", name, got, exp);
        end else begin
            tests_fail++;
            $display("  [FAIL] %-40s got=0x%08X exp=0x%08X ***", name, got, exp);
        end
    endtask

    task automatic check2(string name, logic [1:0] got, logic [1:0] exp);
        tests_run++;
        if (got === exp) begin
            tests_pass++;
            $display("  [PASS] %-40s resp=%0b", name, got);
        end else begin
            tests_fail++;
            $display("  [FAIL] %-40s got=%0b exp=%0b ***", name, got, exp);
        end
    endtask

    // ─── Task: AXI-Lite write ─────────────────────────────────────────────────
    task automatic axi_write(
        input  logic [ADDR_WIDTH-1:0]   addr,
        input  logic [DATA_WIDTH-1:0]   data,
        input  logic [DATA_WIDTH/8-1:0] strb = '1,
        input  int                      bready_delay = 0,
        output logic [1:0]              resp
    );
        // Drive address channel
        @(posedge aclk);
        awaddr  = addr;  awprot = 3'b000;  awvalid = 1'b1;
        wdata   = data;  wstrb  = strb;    wvalid  = 1'b1;

        // Wait for address handshake
        @(posedge aclk);
        while (!awready) @(posedge aclk);
        awvalid = 1'b0;

        // Wait for data handshake
        while (!wready) @(posedge aclk);
        wvalid = 1'b0;

        // Optional back-pressure on BREADY
        if (bready_delay > 0) repeat (bready_delay) @(posedge aclk);
        bready = 1'b1;

        // Wait for write response
        @(posedge aclk);
        while (!bvalid) @(posedge aclk);
        resp   = bresp;
        @(posedge aclk);
        bready = 1'b0;
    endtask

    // ─── Task: AXI-Lite read ──────────────────────────────────────────────────
    task automatic axi_read(
        input  logic [ADDR_WIDTH-1:0] addr,
        input  int                    rready_delay = 0,
        output logic [DATA_WIDTH-1:0] data,
        output logic [1:0]            resp
    );
        @(posedge aclk);
        araddr  = addr;  arprot = 3'b000;  arvalid = 1'b1;

        @(posedge aclk);
        while (!arready) @(posedge aclk);
        arvalid = 1'b0;

        if (rready_delay > 0) repeat (rready_delay) @(posedge aclk);
        rready = 1'b1;

        @(posedge aclk);
        while (!rvalid) @(posedge aclk);
        data   = rdata;
        resp   = rresp;
        @(posedge aclk);
        rready = 1'b0;
    endtask

    // ─── Sequence 1: Write all regs then read back ────────────────────────────
    task automatic seq_write_read_all;
        logic [31:0] wvals [NUM_REGS] = '{
            32'hDEADBEEF, 32'hCAFEBABE, 32'h12345678, 32'h87654321,
            32'hA5A5A5A5, 32'h5A5A5A5A, 32'h00FF00FF, 32'hFF00FF00
        };
        logic [31:0] rd;
        logic [1:0]  r;
        $display("\n=== SEQ 1: Write all regs, read back ===");
        for (int i = 0; i < NUM_REGS; i++) begin
            axi_write(8'(i*4), wvals[i], '1, 0, r);
            check2($sformatf("wr_resp reg[%0d]", i), r, 2'b00);
        end
        for (int i = 0; i < NUM_REGS; i++) begin
            axi_read(8'(i*4), 0, rd, r);
            check32($sformatf("rd_data reg[%0d]", i), rd, wvals[i]);
            check2($sformatf("rd_resp reg[%0d]", i), r, 2'b00);
        end
    endtask

    // ─── Sequence 2: Byte-enable partial write ────────────────────────────────
    task automatic seq_byte_enable;
        logic [31:0] rd;
        logic [1:0]  r;
        $display("\n=== SEQ 2: Byte-enable partial write ===");
        axi_write(8'h00, 32'hFFFFFFFF, 4'b1111, 0, r);
        axi_write(8'h00, 32'h00AA00BB, 4'b0101, 0, r);   // byte 0 and 2 only
        axi_read(8'h00, 0, rd, r);
        check32("byte-enable [0101] result", rd, 32'hFFAAFFBB);
    endtask

    // ─── Sequence 3: Out-of-range address → SLVERR ────────────────────────────
    task automatic seq_slverr;
        logic [31:0] rd;
        logic [1:0]  r;
        $display("\n=== SEQ 3: Out-of-range → SLVERR ===");
        axi_write(8'hF0, 32'hDEAD, '1, 0, r);
        check2("write SLVERR", r, 2'b10);
        axi_read(8'hF0, 0, rd, r);
        check2("read  SLVERR", r, 2'b10);
    endtask

    // ─── Sequence 4: Back-to-back burst (no gap) ─────────────────────────────
    task automatic seq_burst;
        logic [31:0] rd;
        logic [1:0]  r;
        logic [31:0] vals [4] = '{32'h11111111, 32'h22222222,
                                  32'h33333333, 32'h44444444};
        $display("\n=== SEQ 4: Back-to-back write burst ===");
        for (int i = 0; i < 4; i++)
            axi_write(8'(i*4), vals[i], '1, 0, r);
        for (int i = 0; i < 4; i++) begin
            axi_read(8'(i*4), 0, rd, r);
            check32($sformatf("burst rd reg[%0d]", i), rd, vals[i]);
        end
    endtask

    // ─── Sequence 5: Write-response back-pressure ────────────────────────────
    task automatic seq_bready_bp;
        logic [1:0] r;
        $display("\n=== SEQ 5: BREADY back-pressure (5 cycle delay) ===");
        axi_write(8'h10, 32'hBEEFCAFE, '1, 5, r);
        check2("bready_bp wr resp", r, 2'b00);
    endtask

    // ─── Sequence 6: Read-response back-pressure ─────────────────────────────
    task automatic seq_rready_bp;
        logic [31:0] rd;
        logic [1:0]  r;
        $display("\n=== SEQ 6: RREADY back-pressure (5 cycle delay) ===");
        axi_write(8'h14, 32'hFACEFACE, '1, 0, r);
        axi_read(8'h14, 5, rd, r);
        check32("rready_bp rd data", rd, 32'hFACEFACE);
    endtask

    // ─── Main ─────────────────────────────────────────────────────────────────
    initial begin
        $dumpfile("axi_lite_tb.vcd");
        $dumpvars(0, axi_lite_tb);

        {awvalid,wvalid,bready,arvalid,rready} = '0;
        {awaddr,wdata,wstrb,araddr}            = '0;
        {awprot,arprot}                        = '0;
        tests_run = 0; tests_pass = 0; tests_fail = 0;

        aresetn = 0;
        repeat (10) @(posedge aclk);
        aresetn = 1;
        repeat (5)  @(posedge aclk);

        $display("\n========================================");
        $display("  AXI-Lite Testbench  CLK=100MHz");
        $display("  DATA=%0db  ADDR=%0db  REGS=%0d",
                  DATA_WIDTH, ADDR_WIDTH, NUM_REGS);
        $display("========================================");

        seq_write_read_all();
        seq_byte_enable();
        seq_slverr();
        seq_burst();
        seq_bready_bp();
        seq_rready_bp();

        repeat (20) @(posedge aclk);
        $display("\n========================================");
        $display("  Results: %0d/%0d passed  %0d failed",
                  tests_pass, tests_run, tests_fail);
        $display("========================================\n");
        if (tests_fail == 0)
            $display("  *** ALL TESTS PASSED ***\n");
        else
            $display("  *** %0d TEST(S) FAILED ***\n", tests_fail);
        $finish;
    end

    initial begin #50_000_000; $display("[WATCHDOG] timeout"); $finish; end

endmodule : axi_lite_tb
