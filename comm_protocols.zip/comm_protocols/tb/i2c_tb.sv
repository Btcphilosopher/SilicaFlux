// =============================================================================
// i2c_tb.sv  —  I²C Verification Testbench
// =============================================================================
// The testbench instantiates the i2c_controller and a behavioural I²C slave
// model that ACKs all transactions, latches writes, and returns stored data
// on reads.
//
// Transaction sequences:
//   1. Single-byte write
//   2. Single-byte read
//   3. Multi-byte write  (4 bytes)
//   4. Multi-byte read   (4 bytes)
//   5. NACK injection    — slave refuses address
//   6. Zero-length guard — byte_count == 1 edge case
// =============================================================================

`timescale 1ns/1ps

module i2c_tb;

    localparam int CLK_FREQ  = 50_000_000;
    localparam int SCL_FREQ  = 100_000;
    localparam int CLK_PER   = 1_000_000_000 / CLK_FREQ;
    localparam int MAX_BYTES = 16;

    // ─── Signals ──────────────────────────────────────────────────────────────
    logic       clk, rst_n;
    logic [6:0] dev_addr;
    logic       rw;
    logic [7:0] byte_count;
    logic [7:0] wr_data [MAX_BYTES];
    logic       start_cmd;
    logic [7:0] rd_data [MAX_BYTES];
    logic       done, ack_err, busy;
    wire        scl_wire, sda_wire;

    int tests_run, tests_pass, tests_fail;

    initial clk = 0;
    always #(CLK_PER/2) clk = ~clk;

    // ─── DUT ──────────────────────────────────────────────────────────────────
    i2c_controller #(
        .CLK_FREQ  (CLK_FREQ),
        .SCL_FREQ  (SCL_FREQ),
        .MAX_BYTES (MAX_BYTES)
    ) dut (
        .clk        (clk),
        .rst_n      (rst_n),
        .dev_addr   (dev_addr),
        .rw         (rw),
        .byte_count (byte_count),
        .wr_data    (wr_data),
        .start_cmd  (start_cmd),
        .rd_data    (rd_data),
        .done       (done),
        .ack_err    (ack_err),
        .busy       (busy),
        .scl        (scl_wire),
        .sda        (sda_wire)
    );

    // ─── Pull-up resistors (open-drain) ───────────────────────────────────────
    pullup(scl_wire);
    pullup(sda_wire);

    // ─── Behavioural I²C Slave model ─────────────────────────────────────────
    // Implements: ACK on address match, store write bytes, replay on read
    logic [7:0] slave_mem [256];
    logic [6:0] SLAVE_ADDR = 7'h48;
    logic       slave_nack_next = 1'b0;   // force NACK on next address phase

    logic sda_drive;
    assign sda_wire = sda_drive ? 1'b0 : 1'bz;

    task automatic slave_model;
        logic       sda_prev;
        logic [7:0] rx_byte;
        logic [7:0] tx_byte;
        logic [7:0] mem_ptr;
        logic       is_read;
        int         nbytes;

        sda_drive = 1'bz;
        mem_ptr   = 8'h00;

        forever begin
            // Detect START condition: SDA falls while SCL high
            @(negedge sda_wire iff (scl_wire === 1'b1));

            // Receive address byte (7 bits + R/W)
            rx_byte = 8'h00;
            for (int i = 7; i >= 0; i--) begin
                @(posedge scl_wire);
                rx_byte[i] = sda_wire;
            end
            is_read = rx_byte[0];

            // Send ACK / NACK
            @(negedge scl_wire);
            if (!slave_nack_next && (rx_byte[7:1] == SLAVE_ADDR)) begin
                sda_drive = 1'b1;   // ACK (drive low)
                @(posedge scl_wire); @(negedge scl_wire);
                sda_drive = 1'bz;
            end else begin
                sda_drive = 1'bz;   // NACK (release)
                slave_nack_next = 1'b0;
                @(posedge scl_wire); @(negedge scl_wire);
                // Wait for STOP
                @(posedge sda_wire iff (scl_wire === 1'b1));
                continue;
            end

            if (!is_read) begin
                // ── Write mode ────────────────────────────────────────────────
                nbytes = 0;
                while (1) begin
                    rx_byte = 8'h00;
                    for (int i = 7; i >= 0; i--) begin
                        @(posedge scl_wire);
                        if (scl_wire === 1'b1 && sda_wire === 1'b1) begin
                            // Could be STOP
                        end
                        rx_byte[i] = sda_wire;
                    end
                    slave_mem[mem_ptr + nbytes] = rx_byte;
                    nbytes++;
                    // Send ACK
                    @(negedge scl_wire);
                    sda_drive = 1'b1;
                    @(posedge scl_wire); @(negedge scl_wire);
                    sda_drive = 1'bz;
                    // Check for STOP
                    @(posedge clk);
                    if (scl_wire === 1'b1 && sda_wire === 1'b1) break;
                end
            end else begin
                // ── Read mode ─────────────────────────────────────────────────
                nbytes = 0;
                while (1) begin
                    tx_byte = slave_mem[mem_ptr + nbytes];
                    for (int i = 7; i >= 0; i--) begin
                        @(negedge scl_wire);
                        sda_drive = ~tx_byte[i];   // drive 0 for '0', release for '1'
                        @(posedge scl_wire);
                    end
                    sda_drive = 1'bz;
                    nbytes++;
                    // Check master ACK/NACK
                    @(posedge scl_wire);
                    if (sda_wire === 1'b1) break;   // NACK = last byte
                    @(negedge scl_wire);
                end
            end
            // Wait for STOP condition
            @(posedge sda_wire iff (scl_wire === 1'b1));
        end
    endtask

    // ─── Statistics helpers ───────────────────────────────────────────────────
    task automatic check_byte(string name, logic [7:0] got, logic [7:0] exp);
        tests_run++;
        if (got === exp) begin
            tests_pass++;
            $display("  [PASS] %-35s got=0x%02X exp=0x%02X", name, got, exp);
        end else begin
            tests_fail++;
            $display("  [FAIL] %-35s got=0x%02X exp=0x%02X ***", name, got, exp);
        end
    endtask

    task automatic check_flag(string name, logic got, logic exp);
        tests_run++;
        if (got === exp) begin
            tests_pass++;
            $display("  [PASS] %-35s = %0b", name, got);
        end else begin
            tests_fail++;
            $display("  [FAIL] %-35s got=%0b exp=%0b ***", name, got, exp);
        end
    endtask

    // ─── Task: issue command and wait ─────────────────────────────────────────
    task automatic issue(
        input  logic [6:0] addr,
        input  logic       rw_i,
        input  int         n,
        input  logic [7:0] wdata []
    );
        dev_addr   = addr;
        rw         = rw_i;
        byte_count = 8'(n);
        if (!rw_i) foreach (wdata[i]) wr_data[i] = wdata[i];
        @(posedge clk);
        start_cmd = 1'b1;
        @(posedge clk);
        start_cmd = 1'b0;
        wait (done || ack_err);
        @(posedge clk);
    endtask

    // ─── Sequences ────────────────────────────────────────────────────────────
    task automatic seq_write_1;
        $display("\n=== SEQ 1: Single-byte write ===");
        slave_mem[0] = 8'hFF;
        issue(SLAVE_ADDR, 1'b0, 1, '{8'hAB});
        check_flag("no ACK error", ack_err, 1'b0);
        check_byte("slave_mem[0]", slave_mem[0], 8'hAB);
    endtask

    task automatic seq_read_1;
        $display("\n=== SEQ 2: Single-byte read ===");
        slave_mem[0] = 8'hC3;
        issue(SLAVE_ADDR, 1'b1, 1, '{});
        check_flag("no ACK error",  ack_err,   1'b0);
        check_byte("rd_data[0]",    rd_data[0], 8'hC3);
    endtask

    task automatic seq_write_multi;
        $display("\n=== SEQ 3: Multi-byte write (4 bytes) ===");
        issue(SLAVE_ADDR, 1'b0, 4, '{8'h11, 8'h22, 8'h33, 8'h44});
        check_flag("no ACK error",  ack_err, 1'b0);
        check_byte("slave_mem[0]",  slave_mem[0], 8'h11);
        check_byte("slave_mem[1]",  slave_mem[1], 8'h22);
        check_byte("slave_mem[2]",  slave_mem[2], 8'h33);
        check_byte("slave_mem[3]",  slave_mem[3], 8'h44);
    endtask

    task automatic seq_read_multi;
        $display("\n=== SEQ 4: Multi-byte read (4 bytes) ===");
        slave_mem[0] = 8'hDE; slave_mem[1] = 8'hAD;
        slave_mem[2] = 8'hBE; slave_mem[3] = 8'hEF;
        issue(SLAVE_ADDR, 1'b1, 4, '{});
        check_flag("no ACK error",  ack_err,    1'b0);
        check_byte("rd_data[0]",    rd_data[0], 8'hDE);
        check_byte("rd_data[1]",    rd_data[1], 8'hAD);
        check_byte("rd_data[2]",    rd_data[2], 8'hBE);
        check_byte("rd_data[3]",    rd_data[3], 8'hEF);
    endtask

    task automatic seq_nack;
        $display("\n=== SEQ 5: NACK injection (wrong address) ===");
        issue(7'h55, 1'b0, 1, '{8'hFF});   // wrong address
        check_flag("ack_err asserted", ack_err, 1'b1);
    endtask

    // ─── Main ─────────────────────────────────────────────────────────────────
    initial begin
        $dumpfile("i2c_tb.vcd");
        $dumpvars(0, i2c_tb);
        tests_run  = 0; tests_pass = 0; tests_fail = 0;
        foreach (slave_mem[i]) slave_mem[i] = 8'h00;
        start_cmd  = 0;

        rst_n = 0;
        repeat (10) @(posedge clk);
        rst_n = 1;
        repeat (5)  @(posedge clk);

        $display("\n========================================");
        $display("  I2C Testbench  CLK=%0dMHz  SCL=%0dkHz",
                  CLK_FREQ/1_000_000, SCL_FREQ/1_000);
        $display("========================================");

        fork slave_model(); join_none

        seq_write_1();
        seq_read_1();
        seq_write_multi();
        seq_read_multi();
        seq_nack();

        repeat (200) @(posedge clk);
        $display("\n========================================");
        $display("  Results: %0d/%0d passed  %0d failed",
                  tests_pass, tests_run, tests_fail);
        $display("========================================\n");
        if (tests_fail == 0)
            $display("  *** ALL TESTS PASSED ***\n");
        else
            $display("  *** %0d TEST(S) FAILED ***\n", tests_fail);
        $finish;
    end

    initial begin #500_000_000; $display("[WATCHDOG] timeout"); $finish; end

endmodule : i2c_tb
