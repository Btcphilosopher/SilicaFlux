// =============================================================================
// HANDSHAKE CONTROLLER — FORMAL PROPERTY MODULE
// File   : handshake/handshake_formal_props.sv
// Purpose: Protocol compliance, arbitration correctness, and liveness
//          properties for handshake_controller.sv.
//
// Property naming:
//   ap_*  — assert property  (must always hold)
//   asm_* — assume property  (constrains formal input space)
//   cp_*  — cover  property  (reachability / completeness)
//
// Property categories:
//   [P]  Protocol    — AXI-stream valid/ready rules
//   [A]  Arbitration — mutual exclusion, grant correctness
//   [R]  Reset       — initialised state after rst_n deassertion
//   [L]  Liveness    — every source is eventually served (fairness)
//   [C]  Cover       — reachability obligations
// =============================================================================
module handshake_formal_props #(
  parameter int DATA_W   = 8,
  parameter int MAX_WAIT = 64    // Liveness bound: worst-case grant latency
)(
  input logic              clk,
  input logic              rst_n,
  // Source 0
  input logic              src0_valid,
  input logic [DATA_W-1:0] src0_data,
  input logic              src0_ready,
  // Source 1
  input logic              src1_valid,
  input logic [DATA_W-1:0] src1_data,
  input logic              src1_ready,
  // Sink
  input logic              snk_valid,
  input logic [DATA_W-1:0] snk_data,
  input logic              snk_ready,
  // DUT internal signals (exposed via bind for structural checks)
  input logic              rr_sel_q,
  input logic              sel_idx
);

  // =========================================================================
  // INPUT ASSUMPTIONS
  //
  // Formal reasoning: these constraints model a well-behaved upstream agent.
  // Without them, the formal tool explores scenarios where a source drops
  // valid mid-transfer — violating the INPUT contract rather than the DUT.
  // The assumptions let us focus proofs on the controller's output behaviour.
  //
  // Note: these are ENVIRONMENT constraints, not DUT properties. If the
  // upstream is adversarial (e.g. drops valid), the controller may legitimately
  // fail — that failure belongs to the upstream, not the arbiter.
  // =========================================================================

  // src0: once asserted, valid stays high until src0_ready is returned.
  asm_src0_valid_persistent: assume property (
    @(posedge clk) disable iff (!rst_n)
    (src0_valid && !src0_ready) |=> src0_valid
  );

  // src0: data must be stable while valid is pending.
  asm_src0_data_stable: assume property (
    @(posedge clk) disable iff (!rst_n)
    (src0_valid && !src0_ready) |=> $stable(src0_data)
  );

  // src1: same AXI-stream constraints.
  asm_src1_valid_persistent: assume property (
    @(posedge clk) disable iff (!rst_n)
    (src1_valid && !src1_ready) |=> src1_valid
  );

  asm_src1_data_stable: assume property (
    @(posedge clk) disable iff (!rst_n)
    (src1_valid && !src1_ready) |=> $stable(src1_data)
  );

  // snk_ready: the sink can assert ready at any time (no constraint).
  // Formal reasoning: by leaving snk_ready free, we prove properties
  // for all possible downstream back-pressure patterns including
  // persistent stall (snk_ready=0 forever) — the hardest case for P1 liveness.

  // =========================================================================
  // [P1] PROTOCOL: snk_valid must persist until snk_ready is seen
  //
  // Formal reasoning: AXI-stream §2.2.1 states TVALID must not be
  // deasserted before TREADY. A controller that drops valid leaves the
  // sink's state machine in an undefined "partially-accepted" condition,
  // because the sink observed a valid header but never got confirmation.
  // This is the most critical protocol invariant.
  // BUG_VALID_DROP intentionally violates this property.
  // =========================================================================
  ap_snk_valid_persist: assert property (
    @(posedge clk) disable iff (!rst_n)
    (snk_valid && !snk_ready) |=> snk_valid
  ) else $error("[P1] snk_valid dropped before snk_ready — AXI-stream violation");

  // =========================================================================
  // [P2] PROTOCOL: snk_data must be stable while snk_valid && !snk_ready
  //
  // Formal reasoning: the receiver samples snk_data on the cycle where
  // snk_ready goes high. If snk_data mutates between valid assertion and
  // ready, the receiver sees a different value on each possible sampling
  // cycle — effectively a race condition on the bus.
  // BUG_DATA_CHANGE intentionally violates this property.
  // =========================================================================
  ap_snk_data_stable: assert property (
    @(posedge clk) disable iff (!rst_n)
    (snk_valid && !snk_ready) |=> $stable(snk_data)
  ) else $error("[P2] snk_data changed during a pending handshake — data race");

  // =========================================================================
  // [P3] PROTOCOL: snk_valid only asserted when at least one source is valid
  //
  // Formal reasoning: the arbiter must not fabricate valid transactions.
  // A spurious valid with no upstream source means the controller is
  // inventing data — corrupting the downstream processing pipeline.
  // =========================================================================
  ap_no_spurious_valid: assert property (
    @(posedge clk) disable iff (!rst_n)
    snk_valid |-> (src0_valid || src1_valid)
  ) else $error("[P3] snk_valid asserted with no upstream source valid");

  // =========================================================================
  // [P4] PROTOCOL: snk_data correctly routes the selected source's payload
  //
  // Formal reasoning: the mux must preserve data integrity. If sel_idx=0,
  // snk_data must equal src0_data. Corruption anywhere in the forwarding
  // path (mux select, registered latch, data bus) fires this property.
  // =========================================================================
  ap_mux_correct_src0: assert property (
    @(posedge clk) disable iff (!rst_n)
    (snk_valid && !sel_idx) |-> (snk_data == src0_data)
  ) else $error("[P4] snk_data=%0h != src0_data=%0h when src0 selected", snk_data, src0_data);

  ap_mux_correct_src1: assert property (
    @(posedge clk) disable iff (!rst_n)
    (snk_valid && sel_idx) |-> (snk_data == src1_data)
  ) else $error("[P4] snk_data=%0h != src1_data=%0h when src1 selected", snk_data, src1_data);

  // =========================================================================
  // [A1] ARBITRATION: src0_ready and src1_ready are mutually exclusive
  //
  // Formal reasoning: a single downstream channel can only complete one
  // transfer per cycle. Granting ready to both sources simultaneously would
  // mean two transfers complete in one cycle — impossible for a 1-sink system.
  // This is the mutual-exclusion invariant for the arbitration layer.
  // =========================================================================
  ap_ready_mutex: assert property (
    @(posedge clk) disable iff (!rst_n)
    !(src0_ready && src1_ready)
  ) else $error("[A1] DOUBLE GRANT: src0_ready && src1_ready simultaneously");

  // =========================================================================
  // [A2] ARBITRATION: src_ready only fires on a completed sink handshake
  //
  // Formal reasoning: src_ready is the "transfer acknowledged" signal.
  // Asserting it before snk_ready means the controller is telling the source
  // its data was consumed before the sink actually consumed it — a phantom ACK
  // that would cause the source to discard data the sink never received.
  // =========================================================================
  ap_src0_ready_gated: assert property (
    @(posedge clk) disable iff (!rst_n)
    src0_ready |-> (snk_valid && snk_ready && !sel_idx)
  ) else $error("[A2] src0_ready without sink handshake completion");

  ap_src1_ready_gated: assert property (
    @(posedge clk) disable iff (!rst_n)
    src1_ready |-> (snk_valid && snk_ready && sel_idx)
  ) else $error("[A2] src1_ready without sink handshake completion");

  // =========================================================================
  // [A3] ARBITRATION: round-robin selector advances on every completed handshake
  //
  // Formal reasoning: the RR pointer must toggle after each transfer.
  // If it doesn't, one source is permanently preferred, and the other
  // can starve even if it continuously asserts valid — a fairness failure
  // that the liveness properties ([L2]) will also catch.
  // =========================================================================
  ap_rr_advances_on_grant: assert property (
    @(posedge clk) disable iff (!rst_n)
    (snk_valid && snk_ready) |=> (rr_sel_q == ~$past(rr_sel_q))
  ) else $error("[A3] round-robin selector did not toggle after completed handshake");

  // =========================================================================
  // [R1] RESET: rr_sel_q initialises to 0 (src0 has initial priority)
  // =========================================================================
  ap_reset_rr_zero: assert property (
    @(posedge clk)
    $rose(rst_n) |=> (rr_sel_q == 1'b0)
  ) else $error("[R1] rr_sel_q != 0 one cycle after reset deassertion");

  // =========================================================================
  // [R2] RESET: No output valid during or immediately after reset
  //
  // Formal reasoning: sources should be quiescent during reset. Even if
  // src_valid is asserted, the controller must not propagate it downstream
  // until the internal state is initialised.
  // =========================================================================
  ap_reset_no_valid: assert property (
    @(posedge clk)
    !rst_n |-> !snk_valid
  ) else $error("[R2] snk_valid asserted while in reset");

  // =========================================================================
  // [L1] LIVENESS: a valid source is served within MAX_WAIT cycles
  //
  // Formal reasoning: a controller that holds valid but never returns ready
  // to the source is a protocol deadlock — a liveness failure. The bound
  // MAX_WAIT is chosen to be larger than any legitimate back-pressure window.
  // The BUG_VALID_DROP injection will violate this by dropping snk_valid,
  // so the sink never fires snk_ready for the pending transfer.
  // =========================================================================
  ap_src0_served_bounded: assert property (
    @(posedge clk) disable iff (!rst_n)
    src0_valid |-> ##[1:MAX_WAIT] src0_ready
  ) else $error("[L1] src0 not served within %0d cycles — liveness failure", MAX_WAIT);

  ap_src1_served_bounded: assert property (
    @(posedge clk) disable iff (!rst_n)
    src1_valid |-> ##[1:MAX_WAIT] src1_ready
  ) else $error("[L1] src1 not served within %0d cycles — liveness failure", MAX_WAIT);

  // =========================================================================
  // [L2] LIVENESS (FAIRNESS): with both sources valid, both are served within
  //      MAX_WAIT cycles of each other.
  //
  // Formal reasoning: round-robin prevents indefinite starvation. If src0
  // monopolises the bus while src1 is also requesting, the fairness property
  // fires. This is stronger than [L1] — it proves fairness under contention.
  // =========================================================================
  ap_fairness_src0: assert property (
    @(posedge clk) disable iff (!rst_n)
    (src0_valid && src1_valid) |-> ##[1:MAX_WAIT] src0_ready
  ) else $error("[L2] src0 starved while both sources valid — fairness violation");

  ap_fairness_src1: assert property (
    @(posedge clk) disable iff (!rst_n)
    (src0_valid && src1_valid) |-> ##[1:MAX_WAIT] src1_ready
  ) else $error("[L2] src1 starved while both sources valid — fairness violation");

  // =========================================================================
  // COVER OBLIGATIONS
  // =========================================================================

  // Basic grants
  cp_src0_granted: cover property (@(posedge clk) src0_ready);
  cp_src1_granted: cover property (@(posedge clk) src1_ready);

  // Both sources simultaneously valid — the contention case
  cp_both_valid: cover property (@(posedge clk) src0_valid && src1_valid);

  // Back-pressure scenario: stall then complete
  cp_backpressure: cover property (
    @(posedge clk) (snk_valid && !snk_ready) ##[1:8] (snk_valid && snk_ready)
  );

  // Alternating grants — proves round-robin is actually working
  cp_alternating_grants: cover property (
    @(posedge clk) src0_ready ##[1:MAX_WAIT] src1_ready ##[1:MAX_WAIT] src0_ready
  );

  // Both sources served in the same "window" of time
  cp_both_served: cover property (
    @(posedge clk) src0_ready ##[1:MAX_WAIT] src1_ready
  );

endmodule

// =============================================================================
// BIND DIRECTIVE
//
// Attaches the property module to every instance of handshake_controller.
// Internal signals rr_sel_q and sel_idx are exposed for structural checks.
// =============================================================================
bind handshake_controller handshake_formal_props #(
  .DATA_W  (DATA_W),
  .MAX_WAIT(64)
) u_hs_formal_props (
  .clk       (clk),
  .rst_n     (rst_n),
  .src0_valid(src0_valid),
  .src0_data (src0_data),
  .src0_ready(src0_ready),
  .src1_valid(src1_valid),
  .src1_data (src1_data),
  .src1_ready(src1_ready),
  .snk_valid (snk_valid),
  .snk_data  (snk_data),
  .snk_ready (snk_ready),
  .rr_sel_q  (rr_sel_q),
  .sel_idx   (sel_idx)
);
