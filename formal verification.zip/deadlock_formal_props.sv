// =============================================================================
// RESOURCE ALLOCATOR — FORMAL PROPERTY MODULE
// File   : deadlock/deadlock_formal_props.sv
// Purpose: Deadlock freedom, liveness, and mutual-exclusion properties for
//          resource_allocator.sv.
//
// Property naming:
//   ap_*  — assert property  (safety + liveness)
//   asm_* — assume property  (legal environment)
//   cp_*  — cover  property  (reachability)
//
// Property categories:
//   [D] Deadlock Freedom — no circular hold-and-wait can form
//   [M] Mutual Exclusion — resource uniqueness invariants
//   [L] Liveness         — requesting agents are eventually granted
//   [B] Bounded Hold     — granted agents eventually release
//   [R] Reset            — clean initial state
//   [C] Cover            — prove scenarios are reachable
//
// How to find the deadlock counterexample:
//   With BUG_DEADLOCK=1 bound to resource_allocator:
//   1. Set req[3:0]=4'b1111 for all formal time steps (assume).
//   2. Set release_r[3:0]=4'b0000 (agents never voluntarily release).
//   3. Run JasperGold: the tool finds a 3-cycle trace where all agents
//      transition IDLE→WAIT1→HOLD1 and then permanently stall.
//   The counterexample witness is the deadlock trace described in resource_allocator.sv.
// =============================================================================
module deadlock_formal_props #(
  parameter int  N           = 4,
  parameter bit  BUG_DEADLOCK = 1'b0,  // Match the DUT parameter
  parameter int  MAX_WAIT    = 64      // Liveness bound
)(
  input logic         clk,
  input logic         rst_n,
  input logic [N-1:0] req,
  input logic [N-1:0] release_r,
  input logic [N-1:0] grant,
  input logic [N-1:0] waiting,
  input logic [N-1:0] res_held,
  // Agent state signals (individual 3-bit ports, flattened from state_q[N])
  input logic [2:0]   sq0,   // state_q[0]
  input logic [2:0]   sq1,   // state_q[1]
  input logic [2:0]   sq2,   // state_q[2]
  input logic [2:0]   sq3    // state_q[3]
);

  // Local state encoding (mirrors resource_allocator.sv)
  localparam logic [2:0] ST_IDLE  = 3'b000;
  localparam logic [2:0] ST_WAIT1 = 3'b001;
  localparam logic [2:0] ST_HOLD1 = 3'b010;
  localparam logic [2:0] ST_CS    = 3'b011;
  localparam logic [2:0] ST_FREE  = 3'b100;

  // Resource pair constants — must match resource_allocator.sv
  localparam int RA0 = 0; localparam int RB0 = 1;
  localparam int RA1 = 1; localparam int RB1 = 2;
  localparam int RA2 = 2; localparam int RB2 = 3;
  localparam int RA3 = BUG_DEADLOCK ? 3 : 0;
  localparam int RB3 = BUG_DEADLOCK ? 0 : 3;

  // =========================================================================
  // INPUT ASSUMPTIONS
  //
  // Formal reasoning: we model a persistent, adversarial environment:
  //  - All agents continuously request (req stays high once raised).
  //  - Agents only release after the tool grants them the critical section.
  //  - release_r is a one-cycle pulse following a grant.
  // This maximises contention and is the hardest input pattern for liveness.
  // =========================================================================

  // req is a level signal: stays asserted until the agent is granted.
  asm_req_persistent: assume property (
    @(posedge clk) disable iff (!rst_n)
    (req[0] && !grant[0]) |=> req[0]
  );
  // (same assumption for agents 1..3 — abbreviated)
  asm_req1_persistent: assume property (
    @(posedge clk) disable iff (!rst_n) (req[1] && !grant[1]) |=> req[1]);
  asm_req2_persistent: assume property (
    @(posedge clk) disable iff (!rst_n) (req[2] && !grant[2]) |=> req[2]);
  asm_req3_persistent: assume property (
    @(posedge clk) disable iff (!rst_n) (req[3] && !grant[3]) |=> req[3]);

  // release_r is a one-cycle pulse: deasserted the cycle after it fires.
  asm_release_pulse: assume property (
    @(posedge clk) disable iff (!rst_n)
    $onehot0(release_r)   // At most one agent releases per cycle
  );

  // An agent only releases when it is in the critical section.
  asm_release_requires_cs: assume property (
    @(posedge clk) disable iff (!rst_n)
    release_r[0] |-> grant[0]
  );
  asm_release1_requires_cs: assume property (
    @(posedge clk) disable iff (!rst_n) release_r[1] |-> grant[1]);
  asm_release2_requires_cs: assume property (
    @(posedge clk) disable iff (!rst_n) release_r[2] |-> grant[2]);
  asm_release3_requires_cs: assume property (
    @(posedge clk) disable iff (!rst_n) release_r[3] |-> grant[3]);

  // =========================================================================
  // [D1] DEADLOCK FREEDOM: all four agents cannot be in HOLD1 simultaneously
  //
  // Formal reasoning: HOLD1 means "holding first resource, waiting for second."
  // For all four agents to be in HOLD1 simultaneously:
  //   - Agent 0 holds res0, needs res1 (held by Agent 1) → blocked
  //   - Agent 1 holds res1, needs res2 (held by Agent 2) → blocked
  //   - Agent 2 holds res2, needs res3 (held by Agent 3) → blocked
  //   - Agent 3 holds resX, needs resY (held by Agent 0) → blocked
  // This is the textbook circular-wait condition (Coffman condition 4).
  // The system is deadlocked: no agent can make progress, ever.
  //
  // With BUG_DEADLOCK=0: Agent 3 competes for res0 (not res3), so Agent 3
  //   cannot reach HOLD1 while Agent 0 holds res0. No circular wait.
  //
  // With BUG_DEADLOCK=1: the formal tool produces a 3-cycle counterexample
  //   trace (req→wait1→hold1 for all agents simultaneously).
  // =========================================================================
  ap_no_deadlock: assert property (
    @(posedge clk) disable iff (!rst_n)
    !(sq0 == ST_HOLD1 && sq1 == ST_HOLD1 &&
      sq2 == ST_HOLD1 && sq3 == ST_HOLD1)
  ) else $error("[D1] *** DEADLOCK DETECTED *** all agents in HOLD1 — circular wait!");

  // =========================================================================
  // [D2] DEADLOCK FREEDOM: no three-way circular wait (partial deadlock)
  //
  // Formal reasoning: even if only three agents deadlock, the fourth may
  // also be blocked waiting for one of the deadlocked resources, causing
  // a system-wide stall. Checking all 3-agent HOLD1 combinations.
  // =========================================================================
  ap_no_3way_deadlock_012: assert property (
    @(posedge clk) disable iff (!rst_n)
    !(sq0 == ST_HOLD1 && sq1 == ST_HOLD1 && sq2 == ST_HOLD1)
  ) else $error("[D2] 3-way near-deadlock: agents 0,1,2 all in HOLD1");

  ap_no_3way_deadlock_123: assert property (
    @(posedge clk) disable iff (!rst_n)
    !(sq1 == ST_HOLD1 && sq2 == ST_HOLD1 && sq3 == ST_HOLD1)
  ) else $error("[D2] 3-way near-deadlock: agents 1,2,3 all in HOLD1");

  // =========================================================================
  // [M1] MUTUAL EXCLUSION: at most one agent in CS per resource
  //
  // Formal reasoning: two agents simultaneously in CS means two entities
  // hold the same resource — the fundamental mutual exclusion guarantee is
  // broken. This allows concurrent modification of the shared data structure.
  //
  // Agent pairs that share a resource:
  //   (0,1) share res1  (RB0=1 == RA1=1)
  //   (1,2) share res2  (RB1=2 == RA2=2)
  //   (2,3) share res3  (RB2=3 == RA3_safe=? / RB3=?)
  //   (0,3) share res0  (RA0=0 == RA3_safe=0)
  //
  // Note: agents (0,2) and (1,3) have no overlapping resources:
  //   Agent 0: {res0,res1}  Agent 2: {res2,res3} — disjoint → can both be in CS.
  //   Agent 1: {res1,res2}  Agent 3_safe: {res0,res3} — disjoint → can both be in CS.
  // =========================================================================
  ap_mutex_agents01: assert property (
    @(posedge clk) disable iff (!rst_n)
    !(sq0 == ST_CS && sq1 == ST_CS)
  ) else $error("[M1] mutual exclusion violation: agents 0 and 1 both in CS (share res1)");

  ap_mutex_agents12: assert property (
    @(posedge clk) disable iff (!rst_n)
    !(sq1 == ST_CS && sq2 == ST_CS)
  ) else $error("[M1] mutual exclusion violation: agents 1 and 2 both in CS (share res2)");

  ap_mutex_agents23: assert property (
    @(posedge clk) disable iff (!rst_n)
    !(sq2 == ST_CS && sq3 == ST_CS)
  ) else $error("[M1] mutual exclusion violation: agents 2 and 3 both in CS (share res3)");

  ap_mutex_agents03: assert property (
    @(posedge clk) disable iff (!rst_n)
    !(sq0 == ST_CS && sq3 == ST_CS)
  ) else $error("[M1] mutual exclusion violation: agents 0 and 3 both in CS (share res0)");

  // =========================================================================
  // [M2] RESOURCE UNIQUENESS: res_held is consistent with agent state
  //
  // Formal reasoning: the res_held output is derived purely from agent state.
  // If grant[i]=1 (ST_CS), both of agent i's resources must show in res_held.
  // A violation indicates a bug in the combinatorial resource tracking logic.
  // =========================================================================
  ap_res_held_cs_agent0: assert property (
    @(posedge clk) disable iff (!rst_n)
    (sq0 == ST_CS) |-> (res_held[RA0] && res_held[RB0])
  ) else $error("[M2] agent 0 in CS but not both resources held");

  ap_res_held_cs_agent1: assert property (
    @(posedge clk) disable iff (!rst_n)
    (sq1 == ST_CS) |-> (res_held[RA1] && res_held[RB1])
  ) else $error("[M2] agent 1 in CS but not both resources held");

  ap_res_held_cs_agent2: assert property (
    @(posedge clk) disable iff (!rst_n)
    (sq2 == ST_CS) |-> (res_held[RA2] && res_held[RB2])
  ) else $error("[M2] agent 2 in CS but not both resources held");

  ap_res_held_cs_agent3: assert property (
    @(posedge clk) disable iff (!rst_n)
    (sq3 == ST_CS) |-> (res_held[RA3] && res_held[RB3])
  ) else $error("[M2] agent 3 in CS but not both resources held");

  // =========================================================================
  // [L1] LIVENESS: every requesting agent is eventually granted
  //
  // Formal reasoning: this is the core progress guarantee.
  // With BUG_DEADLOCK=0, the resource-ordering scheme guarantees progress:
  //   the agent with lowest index always wins arbitration for any contested
  //   resource, and once it completes its CS, higher-indexed agents unblock.
  //
  // With BUG_DEADLOCK=1, the formal tool will find a counterexample where:
  //   req[0] is permanently asserted but grant[0] never fires (agent 0 is
  //   stuck in HOLD1 waiting for res1, held by agent 1 forever).
  // =========================================================================
  ap_agent0_progress: assert property (
    @(posedge clk) disable iff (!rst_n)
    req[0] |-> ##[1:MAX_WAIT] grant[0]
  ) else $error("[L1] agent 0 not granted within %0d cycles — liveness failure", MAX_WAIT);

  ap_agent1_progress: assert property (
    @(posedge clk) disable iff (!rst_n)
    req[1] |-> ##[1:MAX_WAIT] grant[1]
  ) else $error("[L1] agent 1 not granted within %0d cycles — liveness failure", MAX_WAIT);

  ap_agent2_progress: assert property (
    @(posedge clk) disable iff (!rst_n)
    req[2] |-> ##[1:MAX_WAIT] grant[2]
  ) else $error("[L1] agent 2 not granted within %0d cycles — liveness failure", MAX_WAIT);

  ap_agent3_progress: assert property (
    @(posedge clk) disable iff (!rst_n)
    req[3] |-> ##[1:MAX_WAIT] grant[3]
  ) else $error("[L1] agent 3 not granted within %0d cycles — liveness failure", MAX_WAIT);

  // =========================================================================
  // [B1] BOUNDED HOLD: a granted agent eventually releases
  //
  // Formal reasoning: an agent that holds resources indefinitely without
  // releasing them causes starvation for all agents sharing those resources —
  // a liveness failure even if the grant was correct. With the assume that
  // release_r fires whenever grant fires, this should always pass.
  // =========================================================================
  ap_grant_implies_release0: assert property (
    @(posedge clk) disable iff (!rst_n)
    grant[0] |-> ##[1:MAX_WAIT] !grant[0]
  ) else $error("[B1] agent 0 held CS >%0d cycles", MAX_WAIT);

  ap_grant_implies_release1: assert property (
    @(posedge clk) disable iff (!rst_n)
    grant[1] |-> ##[1:MAX_WAIT] !grant[1]
  ) else $error("[B1] agent 1 held CS >%0d cycles", MAX_WAIT);

  ap_grant_implies_release2: assert property (
    @(posedge clk) disable iff (!rst_n)
    grant[2] |-> ##[1:MAX_WAIT] !grant[2]
  ) else $error("[B1] agent 2 held CS >%0d cycles", MAX_WAIT);

  ap_grant_implies_release3: assert property (
    @(posedge clk) disable iff (!rst_n)
    grant[3] |-> ##[1:MAX_WAIT] !grant[3]
  ) else $error("[B1] agent 3 held CS >%0d cycles", MAX_WAIT);

  // =========================================================================
  // [R1] RESET: all agents idle and no resources held after reset
  // =========================================================================
  ap_reset_all_idle: assert property (
    @(posedge clk)
    $rose(rst_n) |=> (sq0 == ST_IDLE && sq1 == ST_IDLE &&
                      sq2 == ST_IDLE && sq3 == ST_IDLE)
  ) else $error("[R1] agents not idle after reset");

  ap_reset_no_resources: assert property (
    @(posedge clk)
    $rose(rst_n) |=> (res_held == '0)
  ) else $error("[R1] resources held after reset");

  // =========================================================================
  // COVER: deadlock state is reachable (with BUG_DEADLOCK=1 only)
  //
  // Formal reasoning: if cover passes with BUG_DEADLOCK=1, the tool has
  // confirmed the deadlock state IS reachable — validating that our
  // deadlock injection is effective and the [D1] assertion will fire.
  // =========================================================================
  cp_all_agents_hold1: cover property (
    @(posedge clk)
    sq0 == ST_HOLD1 && sq1 == ST_HOLD1 &&
    sq2 == ST_HOLD1 && sq3 == ST_HOLD1
  );

  // Verify a non-trivial concurrent execution: two agents in CS together
  // (agents 0+2 or 1+3 share no resources so CAN be concurrent)
  cp_agents02_concurrent_cs: cover property (
    @(posedge clk) (sq0 == ST_CS && sq2 == ST_CS)
  );

  cp_agents13_concurrent_cs: cover property (
    @(posedge clk) (sq1 == ST_CS && sq3 == ST_CS)
  );

  // Full round: agent 0 completes a CS entry and exits
  cp_agent0_full_cycle: cover property (
    @(posedge clk)
    $rose(req[0]) ##[1:MAX_WAIT] $rose(grant[0]) ##[1:MAX_WAIT] $fell(grant[0])
  );

endmodule

// =============================================================================
// BIND DIRECTIVE
//
// Attaches deadlock_formal_props to every resource_allocator instance.
// The individual state ports (sq0..sq3) are driven by state_q[0..3].
// =============================================================================
bind resource_allocator deadlock_formal_props #(
  .N          (N),
  .BUG_DEADLOCK(BUG_DEADLOCK),
  .MAX_WAIT   (64)
) u_dl_formal_props (
  .clk       (clk),
  .rst_n     (rst_n),
  .req       (req),
  .release_r (release_r),
  .grant     (grant),
  .waiting   (waiting),
  .res_held  (res_held),
  .sq0       (state_q[0]),
  .sq1       (state_q[1]),
  .sq2       (state_q[2]),
  .sq3       (state_q[3])
);
