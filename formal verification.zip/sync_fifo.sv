// =============================================================================
// SYNCHRONOUS FIFO WITH BUG INJECTION
// File   : fifo/sync_fifo.sv
// Purpose: Parameterised synchronous FIFO used as the design-under-test (DUT)
//          for FIFO correctness formal verification.
//
// Implementation: circular buffer with binary read/write pointers that carry
//   one extra "generation" bit. Full/empty detection uses the generation bits
//   rather than a separate counter — this is the classic N+1-bit pointer design.
//
// Bug injection parameters (set to 1'b1 to trigger assertion failures):
//
//   BUG_OVERFLOW  — wr_ptr advances even when FIFO is full.
//                   Overwrites the oldest entry; wr_ptr collides with rd_ptr,
//                   making the FIFO appear empty. Triggers: ap_no_overflow.
//
//   BUG_UNDERFLOW — rd_ptr advances even when FIFO is empty.
//                   rd_ptr leaps past wr_ptr, wrapping to appear full.
//                   Triggers: ap_no_underflow.
//
//   BUG_COUNT_ERR — count reports +2 instead of +1 per push.
//                   Diverges from (wr_ptr - rd_ptr). Triggers: ap_count_correct.
//
//   BUG_FLAG_INV  — full and empty outputs are swapped.
//                   Immediately wrong after reset (empty=0, full=1).
//                   Triggers: ap_full_correct, ap_empty_correct, ap_reset_state.
// =============================================================================
module sync_fifo #(
  parameter int  DEPTH        = 8,    // Must be a power of two
  parameter int  WIDTH        = 8,
  parameter bit  BUG_OVERFLOW  = 1'b0,
  parameter bit  BUG_UNDERFLOW = 1'b0,
  parameter bit  BUG_COUNT_ERR = 1'b0,
  parameter bit  BUG_FLAG_INV  = 1'b0
)(
  input  logic             clk,
  input  logic             rst_n,
  // ---- Write interface ----
  input  logic             wr_en,
  input  logic [WIDTH-1:0] wr_data,
  output logic             full,
  // ---- Read interface ----
  input  logic             rd_en,
  output logic [WIDTH-1:0] rd_data,
  output logic             empty,
  // ---- Status ----
  output logic [$clog2(DEPTH):0] count
);

  // ---- Compile-time depth check ----
  // clog2(DEPTH) must correctly address all entries.
  // A non-power-of-two DEPTH causes pointer wrap issues.
  initial begin
    if ((DEPTH == 0) || ((DEPTH & (DEPTH - 1)) != 0))
      $fatal(1, "sync_fifo: DEPTH=%0d must be a power of two", DEPTH);
  end

  localparam int PTR_W = $clog2(DEPTH) + 1;   // Extra bit = generation flag
  localparam int IDX_W = $clog2(DEPTH);        // Actual memory address width

  // ---- Storage ----
  logic [WIDTH-1:0] mem [0:DEPTH-1];

  // ---- Pointers — PTR_W bits each ----
  // Bit [PTR_W-1] is the generation bit (flips on wrap-around).
  // Bits [IDX_W-1:0] are the memory address.
  logic [PTR_W-1:0] wr_ptr_q, rd_ptr_q;

  // ---- True full / empty derived from pointers ----
  // Empty:  pointers identical (same generation, same address)
  // Full:   address bits match but generation bits differ (one extra wrap)
  wire empty_real = (wr_ptr_q == rd_ptr_q);
  wire full_real  = (wr_ptr_q[PTR_W-1]    != rd_ptr_q[PTR_W-1]) &&
                    (wr_ptr_q[IDX_W-1:0]  == rd_ptr_q[IDX_W-1:0]);

  // ---- Correct occupancy count ----
  // The difference of unsigned pointers in the (PTR_W)-bit space gives
  // the number of entries currently in the FIFO.
  wire [PTR_W-1:0] count_real = wr_ptr_q - rd_ptr_q;

  // ---- Bug: count inflation — reports wr_delta×2 ----
  // Normal: count_real. Bug: adds an extra +1 on any push, doubling the
  // effective increment. Once count_real = DEPTH/2 with all pushes,
  // count_bug reaches DEPTH+1 — exceeding DEPTH and breaking ap_count_bounded.
  assign count = count_real + (BUG_COUNT_ERR
                   ? PTR_W'(wr_en & ~full_real)   // Extra phantom +1
                   : '0);

  // ---- Bug: flag inversion — swap full and empty ----
  // After reset: empty_real=1, full_real=0.
  // With flag inversion: empty=0 (wrong), full=1 (wrong).
  // Immediately triggers ap_reset_state, ap_full_correct, ap_empty_correct.
  assign empty = BUG_FLAG_INV ? full_real  : empty_real;
  assign full  = BUG_FLAG_INV ? empty_real : full_real;

  // ---- Read data (combinatorial from rd_ptr) ----
  assign rd_data = mem[rd_ptr_q[IDX_W-1:0]];

  // ---- Write logic ----
  // Normal:       advance wr_ptr only when !full_real.
  // BUG_OVERFLOW: advance wr_ptr unconditionally (even when full_real=1).
  //   The next write overwrites mem[rd_ptr] — oldest data corrupted.
  //   After the extra advance, wr_ptr_q[IDX_W-1:0] == rd_ptr_q[IDX_W-1:0]
  //   but the generation bits now also match → FIFO appears empty.
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wr_ptr_q <= '0;
    end else begin
      if (wr_en && (!full_real || BUG_OVERFLOW)) begin
        mem[wr_ptr_q[IDX_W-1:0]] <= wr_data;
        wr_ptr_q <= wr_ptr_q + 1'b1;
      end
    end
  end

  // ---- Read logic ----
  // Normal:        advance rd_ptr only when !empty_real.
  // BUG_UNDERFLOW: advance rd_ptr unconditionally (even when empty_real=1).
  //   rd_ptr leaps past wr_ptr in the generation-bit space. The difference
  //   wr_ptr_q - rd_ptr_q wraps to DEPTH (appears full) even though there
  //   is no valid data — breaking all count-based properties.
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_ptr_q <= '0;
    end else begin
      if (rd_en && (!empty_real || BUG_UNDERFLOW)) begin
        rd_ptr_q <= rd_ptr_q + 1'b1;
      end
    end
  end

endmodule
