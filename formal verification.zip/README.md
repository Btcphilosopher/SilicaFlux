# Formal Verification Repository — SystemVerilog Assertions (SVA)

A production-grade formal verification repository covering SVA property patterns,
FIFO correctness, handshake protocol compliance, and deadlock detection.

---

## Repository Structure

```
formal_verification/
├── lib/
│   └── sva_assertion_lib.sv        Reusable assertion macros + bindable checkers
├── fifo/
│   ├── sync_fifo.sv                Sync FIFO DUT  (4 orthogonal bug modes)
│   └── fifo_formal_props.sv        13 properties  + bind directive
├── handshake/
│   ├── handshake_controller.sv     2:1 AXI-stream arbiter  (2 bug modes)
│   └── handshake_formal_props.sv   16 properties  + bind directive
├── deadlock/
│   ├── resource_allocator.sv       Dining Philosophers allocator (safe / buggy)
│   └── deadlock_formal_props.sv    17 properties  + bind directive
├── tb/
│   ├── fifo_bug_tb.sv              Simulation testbenches triggering FIFO assertions
│   ├── handshake_bug_tb.sv         Simulation testbenches triggering HS assertions
│   └── deadlock_bug_tb.sv          Deadlock demonstration + safe reference run
└── scripts/
    ├── run_jasper.tcl              JasperGold automated flow  (9 configurations)
    └── run_questa.do               Questa Formal automated flow (9 configurations)
```

---

## Property Map

### FIFO (`fifo_formal_props.sv`)

| ID  | Name                       | Category   | Fires when                              |
|-----|----------------------------|------------|-----------------------------------------|
| I1  | `ap_count_ptr_coherent`    | Invariant  | `count != wr_ptr - rd_ptr`              |
| I2  | `ap_count_bounded`         | Invariant  | `count > DEPTH`                         |
| I3  | `ap_full_correct`          | Invariant  | `full != (count == DEPTH)`              |
| I4  | `ap_empty_correct`         | Invariant  | `empty != (count == 0)`                 |
| I5  | `ap_full_empty_mutex`      | Invariant  | `full && empty` simultaneously          |
| S1  | `ap_no_overflow`           | Safety     | count changes while full                |
| S2  | `ap_no_underflow`          | Safety     | count changes while empty               |
| S3  | `ap_push_increments_by_one`| Safety     | count advances by ≠1 on push            |
| S4  | `ap_pop_decrements_by_one` | Safety     | count decrements by ≠1 on pop           |
| S5  | `ap_push_pop_net_zero`     | Safety     | count changes on simultaneous push+pop  |
| S6  | `ap_rddata_stable_when_idle`| Safety    | `rd_data` changes with no push/pop      |
| R1  | `ap_reset_state`           | Reset      | `empty,count` wrong after reset         |
| R2  | `ap_reset_ptrs_zero`       | Reset      | pointers non-zero during reset          |

**Bug-to-assertion map:**

| Bug mode        | Fires                                     |
|-----------------|-------------------------------------------|
| `BUG_OVERFLOW`  | `ap_no_overflow`, `ap_count_bounded`      |
| `BUG_UNDERFLOW` | `ap_no_underflow`                         |
| `BUG_COUNT_ERR` | `ap_push_increments_by_one`, `ap_count_bounded` |
| `BUG_FLAG_INV`  | `ap_reset_state`, `ap_full_correct`, `ap_empty_correct` |

---

### Handshake (`handshake_formal_props.sv`)

| ID  | Name                       | Category     | Fires when                              |
|-----|----------------------------|--------------|-----------------------------------------|
| P1  | `ap_snk_valid_persist`     | Protocol     | `valid` drops before `ready`            |
| P2  | `ap_snk_data_stable`       | Protocol     | data changes while `valid && !ready`    |
| P3  | `ap_no_spurious_valid`     | Protocol     | output valid with no upstream source    |
| P4  | `ap_mux_correct_src0/1`    | Protocol     | data mux routes wrong source            |
| A1  | `ap_ready_mutex`           | Arbitration  | both `src_ready` simultaneously asserted |
| A2  | `ap_src0/1_ready_gated`    | Arbitration  | `src_ready` without sink handshake      |
| A3  | `ap_rr_advances_on_grant`  | Arbitration  | round-robin doesn't toggle              |
| R1  | `ap_reset_rr_zero`         | Reset        | `rr_sel_q` wrong after reset            |
| R2  | `ap_reset_no_valid`        | Reset        | output valid asserted during reset      |
| L1  | `ap_src0/1_served_bounded` | Liveness     | source stalls > MAX_WAIT cycles         |
| L2  | `ap_fairness_src0/1`       | Liveness     | source starves under contention         |

**Bug-to-assertion map:**

| Bug mode          | Fires                                     |
|-------------------|-------------------------------------------|
| `BUG_VALID_DROP`  | `ap_snk_valid_persist`, `ap_src*_served_bounded` |
| `BUG_DATA_CHANGE` | `ap_snk_data_stable`                      |

---

### Deadlock (`deadlock_formal_props.sv`)

| ID  | Name                       | Category     | Fires when                              |
|-----|----------------------------|--------------|-----------------------------------------|
| D1  | `ap_no_deadlock`           | Deadlock     | all 4 agents in `HOLD1` simultaneously  |
| D2  | `ap_no_3way_deadlock_*`    | Deadlock     | any 3 agents in `HOLD1` simultaneously  |
| M1  | `ap_mutex_agents01/12/23/03` | Mutex      | two resource-sharing agents both in CS  |
| M2  | `ap_res_held_cs_agent*`    | Consistency  | CS agent's resources not in `res_held`  |
| L1  | `ap_agent*_progress`       | Liveness     | agent not granted within MAX_WAIT       |
| B1  | `ap_grant_implies_release*`| Bounded hold | agent holds CS > MAX_WAIT cycles        |
| R1  | `ap_reset_all_idle`        | Reset        | agents not IDLE after reset             |

**Configuration-to-result map:**

| `BUG_DEADLOCK` | Expected outcome                                        |
|----------------|---------------------------------------------------------|
| `0` (safe)     | All properties PASS — Coffman ordering prevents deadlock |
| `1` (buggy)    | `ap_no_deadlock`, `ap_agent*_progress` FAIL at depth 3  |

---

## Formal Techniques Demonstrated

### 1. Safety Properties
The FIFO and handshake modules focus on safety: "a bad event never occurs."
Properties use invariants (`always`) and implication (`|->`, `|=>`) to capture
pointer coherence, flag correctness, and protocol compliance.

### 2. Liveness Properties
The handshake fairness and deadlock liveness properties use bounded liveness:
```
trigger |-> ##[1:MAX_WAIT] result
```
The bound `MAX_WAIT` makes properties finitely checkable by BMC while still
exercising worst-case back-pressure and scheduling scenarios.

### 3. Assumptions (`assume property`)
Upstream sources are constrained to be AXI-stream compliant using `assume`.
This prunes unreachable counterexamples and focuses the proof on controller
correctness, not environment misbehaviour.

### 4. Bind Directives
All property modules are attached non-intrusively:
```systemverilog
bind sync_fifo fifo_formal_props #(.DEPTH(DEPTH)) u_props ( .* );
```
The DUT source is never modified — a key discipline for taping out designs.

### 5. Ghost Variables / Cover Properties
`cp_*` cover properties prove reachability — if they fail, assumptions
over-constrain the model. Every safety-critical path (full FIFO drain,
complete handshake, all agents in CS) has a cover obligation.

### 6. Deadlock Detection via Liveness
The Dining Philosophers deadlock is proved by liveness failure:
with `BUG_DEADLOCK=1`, `ap_agent*_progress` finds a 3-cycle witness
(IDLE→WAIT1→HOLD1) where all agents permanently stall.

---

## Tool Usage

### JasperGold (Cadence)
```bash
jg -no_gui -tcl scripts/run_jasper.tcl -proj jg_fv_work
```

### Questa Formal (Siemens EDA)
```bash
qformal -do scripts/run_questa.do
```

### Simulation (assertion monitoring)
```bash
# FIFO bug testbench
vlog -sv fifo/sync_fifo.sv fifo/fifo_formal_props.sv tb/fifo_bug_tb.sv
vsim -c fifo_bug_tb -do "run -all; quit"

# Deadlock demonstration
vlog -sv deadlock/resource_allocator.sv deadlock/deadlock_formal_props.sv tb/deadlock_bug_tb.sv
vsim -c deadlock_tb    -do "run -all; quit"   # Shows deadlock
vsim -c safe_tb        -do "run -all; quit"   # Shows safe ordering
```

---

## Key Formal Verification Concepts

**Invariant vs Safety**: An invariant holds in every reachable state; a safety
property says a specific bad event never occurs. In this repo, I1–I5 are
invariants, S1–S6 are safety properties, though both use `assert property`.

**`|->` vs `|=>`**: Overlapping implication (`|->`) checks the consequent in
the same cycle as the end of the antecedent. Non-overlapping (`|=>`) checks
one cycle later. Use `|=>` when checking registered (clocked) output changes.

**Vacuity**: An assertion that is never triggered (antecedent never true) passes
trivially — a *vacuous* proof. Cover properties guard against this by proving
the antecedent is reachable.

**Coffman Conditions**: Deadlock requires all four simultaneously:
mutual exclusion, hold-and-wait, no preemption, and circular wait.
The safe allocator breaks circular wait via resource ordering.

---

*Compatibility: SystemVerilog IEEE 1800-2012, Icarus Verilog 12 (simulation only — no formal), JasperGold 2023.x, Questa Formal 2023.x, VC Formal 2023.x*
