// =============================================================================
// RESOURCE ALLOCATOR  (Dining Philosophers, N = 4)
// File   : deadlock/resource_allocator.sv
// Purpose: Four-agent, four-resource mutual-exclusion allocator that models
//          the classic Dining Philosophers deadlock scenario. Each agent
//          requires exactly two adjacent resources to enter its critical section.
//
// Architecture:
//   Each agent i needs resource[i] and resource[(i+1) % 4].
//   A two-phase acquisition protocol acquires the first resource then the second.
//   Priority arbitration (lower agent index = higher priority) prevents two agents
//   from simultaneously acquiring the same free resource.
//
// The "waits-for" graph:
//
//   Safe (BUG_DEADLOCK=0)      —  Coffman resource-ordering condition:
//     Agent 0: first=res0, second=res1   Agent 0 → Agent 1
//     Agent 1: first=res1, second=res2   Agent 1 → Agent 2
//     Agent 2: first=res2, second=res3   Agent 2 → Agent 3
//     Agent 3: first=res0, second=res3   Agent 3 → Agent 0  ← same as Agent 0!
//                                                              No cycle → SAFE.
//
//   Buggy (BUG_DEADLOCK=1)  — naive "grab left fork first":
//     Agent 0: first=res0, second=res1   0 → 1
//     Agent 1: first=res1, second=res2   1 → 2
//     Agent 2: first=res2, second=res3   2 → 3
//     Agent 3: first=res3, second=res0   3 → 0  ← cycle! → DEADLOCK.
//
//   Deadlock trace (BUG_DEADLOCK=1, all agents request simultaneously):
//     Cycle 0: all in IDLE, req[3:0] = 4'b1111
//     Cycle 1: all in WAIT1
//     Cycle 2: all transition WAIT1→HOLD1 (each gets its first resource)
//              resource = 4'b1111 (res0–res3 all held)
//     Cycle 3: all in HOLD1, resource[second] = 1 for all → STUCK
//              Agent 0 wants res1 (held by Agent 1)
//              Agent 1 wants res2 (held by Agent 2)
//              Agent 2 wants res3 (held by Agent 3)
//              Agent 3 wants res0 (held by Agent 0)  ← circular wait
//     Cycle ∞: no progress — all agents deadlocked forever.
//
// Bug injection:
//   BUG_DEADLOCK = 1'b0  (default) — safe resource ordering
//   BUG_DEADLOCK = 1'b1            — circular-wait ordering
// =============================================================================
module resource_allocator #(
  parameter int  N           = 4,     // Number of agents = number of resources
  parameter bit  BUG_DEADLOCK = 1'b0  // 0 = safe ordering, 1 = deadlock-prone
)(
  input  logic         clk,
  input  logic         rst_n,
  input  logic [N-1:0] req,        // Level: agent i wants critical section
  input  logic [N-1:0] release_r,  // Pulse: agent i is done, release resources
  output logic [N-1:0] grant,      // Agent i is in CS (holds both resources)
  output logic [N-1:0] waiting,    // Agent i is blocked waiting for a resource
  output logic [N-1:0] res_held    // Resource j is currently allocated
);

  // ---- Agent state encoding ----
  localparam logic [2:0] ST_IDLE  = 3'b000; // Not requesting
  localparam logic [2:0] ST_WAIT1 = 3'b001; // Seeking first resource
  localparam logic [2:0] ST_HOLD1 = 3'b010; // Hold first, seeking second
  localparam logic [2:0] ST_CS    = 3'b011; // Critical section — holds both
  localparam logic [2:0] ST_FREE  = 3'b100; // Releasing — returns IDLE next cycle

  logic [2:0] state_q [N], state_d [N];

  // ---- Resource pair constants ----
  // Safe: res_a always < res_b (total resource ordering breaks cycles).
  // Bug:  Agent 3's first resource is res3 (> res0 second) — completes cycle.
  //
  // These are compile-time constants. Synthesisers and formal tools treat
  // generate-selected assigns as constants after parameter elaboration.
  localparam int RA0 = 0; localparam int RB0 = 1;
  localparam int RA1 = 1; localparam int RB1 = 2;
  localparam int RA2 = 2; localparam int RB2 = 3;
  // Agent 3 resource pair depends on BUG_DEADLOCK:
  localparam int RA3 = BUG_DEADLOCK ? 3 : 0;   // first  resource for agent 3
  localparam int RB3 = BUG_DEADLOCK ? 0 : 3;   // second resource for agent 3

  // ---- Combinatorial: resource occupancy ----
  // resource[j] = 1 if resource j is held by any agent in HOLD1 or CS.
  // HOLD1 holds res_a[i]; CS holds both res_a[i] and res_b[i].
  // Release is implicit: when an agent leaves CS/HOLD1, resource[j] drops.
  logic [N-1:0] resource;

  always_comb begin
    resource = '0;
    // Agent 0
    if (state_q[0] == ST_HOLD1 || state_q[0] == ST_CS) resource[RA0] = 1'b1;
    if (state_q[0] == ST_CS)                            resource[RB0] = 1'b1;
    // Agent 1
    if (state_q[1] == ST_HOLD1 || state_q[1] == ST_CS) resource[RA1] = 1'b1;
    if (state_q[1] == ST_CS)                            resource[RB1] = 1'b1;
    // Agent 2
    if (state_q[2] == ST_HOLD1 || state_q[2] == ST_CS) resource[RA2] = 1'b1;
    if (state_q[2] == ST_CS)                            resource[RB2] = 1'b1;
    // Agent 3 (resource indices depend on BUG_DEADLOCK parameter)
    if (state_q[3] == ST_HOLD1 || state_q[3] == ST_CS) resource[RA3] = 1'b1;
    if (state_q[3] == ST_CS)                            resource[RB3] = 1'b1;
  end

  assign res_held = resource;

  // ---- Combinatorial: priority arbitration ----
  // Lower agent index = higher priority.
  // prio_a_ok[i] = 1 iff no lower-priority agent is also in WAIT1 wanting res_a[i].
  // prio_b_ok[i] = 1 iff no lower-priority agent is also in HOLD1/WAIT1 wanting res_b[i].
  //
  // Formal reasoning: without priority arbitration, two agents in WAIT1 seeing
  // the same free resource could both transition to HOLD1 simultaneously —
  // a mutual-exclusion violation. Fixed priority prevents this race.
  logic prio_a_ok [N], prio_b_ok [N];

  always_comb begin
    // Default: all priorities clear
    for (int i = 0; i < N; i++) begin
      prio_a_ok[i] = 1'b1;
      prio_b_ok[i] = 1'b1;
    end

    // Agent 0 has highest priority — no lower-index agents to block it.
    // (loops below: j < i, so when i=0 no iterations occur)

    // Agent 1: blocked if agent 0 competes for the same resource
    if (state_q[0] == ST_WAIT1 && RA0 == RA1) prio_a_ok[1] = 1'b0;
    if (state_q[0] == ST_HOLD1 && RB0 == RB1) prio_b_ok[1] = 1'b0;

    // Agent 2
    if (state_q[0] == ST_WAIT1 && RA0 == RA2) prio_a_ok[2] = 1'b0;
    if (state_q[1] == ST_WAIT1 && RA1 == RA2) prio_a_ok[2] = 1'b0;
    if (state_q[0] == ST_HOLD1 && RB0 == RB2) prio_b_ok[2] = 1'b0;
    if (state_q[1] == ST_HOLD1 && RB1 == RB2) prio_b_ok[2] = 1'b0;

    // Agent 3
    if (state_q[0] == ST_WAIT1 && RA0 == RA3) prio_a_ok[3] = 1'b0;
    if (state_q[1] == ST_WAIT1 && RA1 == RA3) prio_a_ok[3] = 1'b0;
    if (state_q[2] == ST_WAIT1 && RA2 == RA3) prio_a_ok[3] = 1'b0;
    if (state_q[0] == ST_HOLD1 && RB0 == RB3) prio_b_ok[3] = 1'b0;
    if (state_q[1] == ST_HOLD1 && RB1 == RB3) prio_b_ok[3] = 1'b0;
    if (state_q[2] == ST_HOLD1 && RB2 == RB3) prio_b_ok[3] = 1'b0;
  end

  // ---- Next-state logic ----
  // Combinatorial computation of next agent states.
  // Key insight: `resource[]` is derived from registered `state_q[]`, so
  // there is no combinational loop — resource reflects last-cycle occupancy.
  always_comb begin
    for (int i = 0; i < N; i++) begin
      state_d[i] = state_q[i];
      grant[i]   = (state_q[i] == ST_CS);
      waiting[i] = (state_q[i] == ST_WAIT1 || state_q[i] == ST_HOLD1);
    end

    // --- Agent 0 ---
    case (state_q[0])
      ST_IDLE:  if (req[0])                            state_d[0] = ST_WAIT1;
      ST_WAIT1: if (!resource[RA0] && prio_a_ok[0])   state_d[0] = ST_HOLD1;
      ST_HOLD1: if (!resource[RB0] && prio_b_ok[0])   state_d[0] = ST_CS;
      ST_CS:    if (release_r[0])                      state_d[0] = ST_FREE;
      ST_FREE:                                          state_d[0] = ST_IDLE;
      default:                                          state_d[0] = ST_IDLE;
    endcase

    // --- Agent 1 ---
    case (state_q[1])
      ST_IDLE:  if (req[1])                            state_d[1] = ST_WAIT1;
      ST_WAIT1: if (!resource[RA1] && prio_a_ok[1])   state_d[1] = ST_HOLD1;
      ST_HOLD1: if (!resource[RB1] && prio_b_ok[1])   state_d[1] = ST_CS;
      ST_CS:    if (release_r[1])                      state_d[1] = ST_FREE;
      ST_FREE:                                          state_d[1] = ST_IDLE;
      default:                                          state_d[1] = ST_IDLE;
    endcase

    // --- Agent 2 ---
    case (state_q[2])
      ST_IDLE:  if (req[2])                            state_d[2] = ST_WAIT1;
      ST_WAIT1: if (!resource[RA2] && prio_a_ok[2])   state_d[2] = ST_HOLD1;
      ST_HOLD1: if (!resource[RB2] && prio_b_ok[2])   state_d[2] = ST_CS;
      ST_CS:    if (release_r[2])                      state_d[2] = ST_FREE;
      ST_FREE:                                          state_d[2] = ST_IDLE;
      default:                                          state_d[2] = ST_IDLE;
    endcase

    // --- Agent 3 ---
    // THIS IS THE CRITICAL AGENT.
    // Safe  (BUG_DEADLOCK=0): RA3=0, RB3=3 → requests res0 first, breaking
    //   the cycle because Agent 0 also wants res0, so Agent 3 must wait for
    //   Agent 0 rather than both grabbing their respective "left forks."
    //
    // Buggy (BUG_DEADLOCK=1): RA3=3, RB3=0 → requests res3 first.
    //   If all agents simultaneously enter HOLD1 (each holds their first
    //   resource), the second-resource they each want is held by the next
    //   agent in the ring → circular wait → nobody can advance.
    case (state_q[3])
      ST_IDLE:  if (req[3])                            state_d[3] = ST_WAIT1;
      ST_WAIT1: if (!resource[RA3] && prio_a_ok[3])   state_d[3] = ST_HOLD1;
      ST_HOLD1: if (!resource[RB3] && prio_b_ok[3])   state_d[3] = ST_CS;
      ST_CS:    if (release_r[3])                      state_d[3] = ST_FREE;
      ST_FREE:                                          state_d[3] = ST_IDLE;
      default:                                          state_d[3] = ST_IDLE;
    endcase
  end

  // ---- State register ----
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < N; i++)
        state_q[i] <= ST_IDLE;
    end else begin
      for (int i = 0; i < N; i++)
        state_q[i] <= state_d[i];
    end
  end

endmodule
