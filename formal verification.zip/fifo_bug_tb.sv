// =============================================================================
// FIFO ASSERTION BREAK TESTBENCH
// File   : tb/fifo_bug_tb.sv
// Purpose: Simulation testbench that instantiates sync_fifo with each bug
//          mode enabled and drives stimulus designed to trigger the
//          corresponding formal property assertion failures.
//
// Each test case documents:
//   — The bug enabled
//   — The stimulus sequence
//   — Which assertion fires and why
//
// Run: questa sim -sv fifo_bug_tb.sv fifo/sync_fifo.sv fifo/fifo_formal_props.sv
// Expected: $error messages from each ap_* assert that is violated.
// =============================================================================
`timescale 1ns/1ps

module fifo_bug_tb;

  // ---- Common parameters ----
  localparam int DEPTH = 4;
  localparam int WIDTH = 8;
  localparam real CLK_PERIOD = 10.0;

  // ---- Shared signals ----
  logic             clk, rst_n;
  logic             wr_en, rd_en;
  logic [WIDTH-1:0] wr_data;
  logic             full, empty;
  logic [WIDTH-1:0] rd_data;
  logic [$clog2(DEPTH):0] count;

  // ---- Clock generator ----
  initial clk = 0;
  always #(CLK_PERIOD/2) clk = ~clk;

  // ---- Task: reset for 3 cycles ----
  task do_reset();
    rst_n = 1'b0; wr_en = 0; rd_en = 0; wr_data = '0;
    repeat(3) @(posedge clk);
    #1; rst_n = 1'b1;
    @(posedge clk);
  endtask

  // ---- Task: push N entries ----
  task push(input int n);
    for (int i = 0; i < n; i++) begin
      @(negedge clk);
      wr_en = 1'b1; wr_data = 8'(i + 1); rd_en = 0;
      @(posedge clk); #1;
      wr_en = 0;
    end
  endtask

  // ---- Task: pop N entries ----
  task pop(input int n);
    for (int i = 0; i < n; i++) begin
      @(negedge clk);
      rd_en = 1'b1; wr_en = 0;
      @(posedge clk); #1;
      rd_en = 0;
    end
  endtask

  // ==========================================================================
  // TEST 1: BUG_OVERFLOW
  //
  // Stimulus: fill FIFO to capacity (DEPTH=4 pushes), then push one more.
  // Bug:      wr_ptr advances even when full_real=1 (BUG_OVERFLOW=1).
  //
  // Expected assertion failure:
  //   ap_no_overflow [S1]:
  //     (full && wr_en && !rd_en) |=> (count == $past(count))
  //   The extra push changes count from 4 to 5 (> DEPTH).
  //
  //   ap_count_bounded [I2]:
  //     count <= DEPTH_VAL
  //   count = 5 violates the upper bound.
  // ==========================================================================
  initial begin
    $display("=== TEST 1: BUG_OVERFLOW ===");
    $display("Expecting: ap_no_overflow, ap_count_bounded failures");
  end

  sync_fifo #(.DEPTH(DEPTH), .WIDTH(WIDTH), .BUG_OVERFLOW(1'b1)) u_overflow (
    .clk(clk), .rst_n(rst_n), .wr_en(wr_en), .wr_data(wr_data),
    .full(full), .rd_en(rd_en), .rd_data(rd_data), .empty(empty), .count(count)
  );

  initial begin
    do_reset();
    $display("[BUG_OVERFLOW] Filling FIFO to capacity (%0d entries)...", DEPTH);
    push(DEPTH);  // FIFO is now full
    @(posedge clk);

    $display("[BUG_OVERFLOW] full=%b, count=%0d — now pushing to FULL FIFO", full, count);
    @(negedge clk);
    // *** This push should be blocked (full=1) but BUG_OVERFLOW allows it ***
    wr_en = 1'b1; wr_data = 8'hFF; rd_en = 0;
    @(posedge clk); #1;
    // ASSERTION FIRES HERE: ap_no_overflow, ap_count_bounded
    $display("[BUG_OVERFLOW] After illegal push: count=%0d full=%b (CORRUPTION)", count, full);
    wr_en = 0;

    repeat(4) @(posedge clk);
    $display("=== TEST 1 COMPLETE ===\n");
    $finish;
  end

endmodule

// =============================================================================
// TEST 2: BUG_UNDERFLOW (separate top-level to avoid port conflict)
// =============================================================================
module fifo_underflow_tb;
  localparam int DEPTH = 4;
  localparam int WIDTH = 8;
  logic clk, rst_n, wr_en, rd_en;
  logic [WIDTH-1:0] wr_data, rd_data;
  logic full, empty;
  logic [$clog2(DEPTH):0] count;

  initial clk = 0;
  always #5 clk = ~clk;

  sync_fifo #(.DEPTH(DEPTH), .WIDTH(WIDTH), .BUG_UNDERFLOW(1'b1)) u_underflow (
    .clk(clk), .rst_n(rst_n), .wr_en(wr_en), .wr_data(wr_data),
    .full(full), .rd_en(rd_en), .rd_data(rd_data), .empty(empty), .count(count)
  );

  initial begin
    $display("=== TEST 2: BUG_UNDERFLOW ===");
    $display("Expecting: ap_no_underflow failure");

    rst_n = 0; wr_en = 0; rd_en = 0; wr_data = 0;
    repeat(3) @(posedge clk);
    #1; rst_n = 1;
    @(posedge clk);

    $display("[BUG_UNDERFLOW] FIFO empty=%b, count=%0d — now reading from EMPTY FIFO", empty, count);
    @(negedge clk);
    // *** This read should be blocked (empty=1) but BUG_UNDERFLOW allows it ***
    rd_en = 1'b1; wr_en = 0;
    @(posedge clk); #1;
    // ASSERTION FIRES HERE: ap_no_underflow
    $display("[BUG_UNDERFLOW] After illegal read: count=%0d empty=%b rd_data=%0h (CORRUPTION)",
             count, empty, rd_data);
    rd_en = 0;

    // Now push some data — count claims FIFO is 'full' due to corrupted rd_ptr
    @(negedge clk); wr_en = 1; wr_data = 8'hAA;
    @(posedge clk); #1;
    $display("[BUG_UNDERFLOW] After push: count=%0d full=%b (ptr corruption visible)", count, full);
    wr_en = 0;

    repeat(4) @(posedge clk);
    $display("=== TEST 2 COMPLETE ===\n");
    $finish;
  end
endmodule

// =============================================================================
// TEST 3: BUG_COUNT_ERR
// =============================================================================
module fifo_count_tb;
  localparam int DEPTH = 8;
  localparam int WIDTH = 8;
  logic clk, rst_n, wr_en, rd_en;
  logic [WIDTH-1:0] wr_data, rd_data;
  logic full, empty;
  logic [$clog2(DEPTH):0] count;

  initial clk = 0;
  always #5 clk = ~clk;

  sync_fifo #(.DEPTH(DEPTH), .WIDTH(WIDTH), .BUG_COUNT_ERR(1'b1)) u_count (
    .clk(clk), .rst_n(rst_n), .wr_en(wr_en), .wr_data(wr_data),
    .full(full), .rd_en(rd_en), .rd_data(rd_data), .empty(empty), .count(count)
  );

  initial begin
    $display("=== TEST 3: BUG_COUNT_ERR ===");
    $display("Expecting: ap_push_increments_by_one, ap_count_bounded failures");

    rst_n = 0; wr_en = 0; rd_en = 0; wr_data = 0;
    repeat(3) @(posedge clk);
    #1; rst_n = 1;
    @(posedge clk);

    // Push 4 times. Bug: count increments by 2 each time.
    // After 4 pushes: real count=4, reported count=8 = DEPTH
    for (int i = 0; i < 4; i++) begin
      @(negedge clk); wr_en = 1; wr_data = 8'(i+1);
      @(posedge clk); #1;
      $display("[BUG_COUNT_ERR] push %0d: count=%0d (expected %0d, got %0d — double counting!)",
               i+1, count, i+1, count);
      // ASSERTION FIRES: ap_push_increments_by_one (count jumped by 2, not 1)
      wr_en = 0;
    end

    $display("[BUG_COUNT_ERR] Final: count=%0d full=%b (FIFO half full but reports full!)",
             count, full);

    repeat(4) @(posedge clk);
    $display("=== TEST 3 COMPLETE ===\n");
    $finish;
  end
endmodule

// =============================================================================
// TEST 4: BUG_FLAG_INV
// =============================================================================
module fifo_flag_tb;
  localparam int DEPTH = 4;
  localparam int WIDTH = 8;
  logic clk, rst_n, wr_en, rd_en;
  logic [WIDTH-1:0] wr_data, rd_data;
  logic full, empty;
  logic [$clog2(DEPTH):0] count;

  initial clk = 0;
  always #5 clk = ~clk;

  sync_fifo #(.DEPTH(DEPTH), .WIDTH(WIDTH), .BUG_FLAG_INV(1'b1)) u_flags (
    .clk(clk), .rst_n(rst_n), .wr_en(wr_en), .wr_data(wr_data),
    .full(full), .rd_en(rd_en), .rd_data(rd_data), .empty(empty), .count(count)
  );

  initial begin
    $display("=== TEST 4: BUG_FLAG_INV ===");
    $display("Expecting: ap_reset_state, ap_full_correct, ap_empty_correct failures");

    rst_n = 0; wr_en = 0; rd_en = 0; wr_data = 0;
    repeat(3) @(posedge clk);
    #1; rst_n = 1;
    @(posedge clk);

    // ASSERTION FIRES IMMEDIATELY after reset:
    // ap_reset_state: empty=0, full=1 (inverted from expected 1,0)
    $display("[BUG_FLAG_INV] After reset: empty=%b full=%b count=%0d",
             empty, full, count);
    $display("[BUG_FLAG_INV]   Expected:  empty=1  full=0  (FLAGS ARE INVERTED!)");

    // A push when "full" (which is actually empty with inverted flags)
    @(negedge clk); wr_en = 1; wr_data = 8'hAB;
    @(posedge clk); #1;
    $display("[BUG_FLAG_INV] After push: empty=%b full=%b count=%0d", empty, full, count);
    wr_en = 0;

    repeat(4) @(posedge clk);
    $display("=== TEST 4 COMPLETE ===\n");
    $finish;
  end
endmodule
