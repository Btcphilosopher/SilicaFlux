// =============================================================================
// DEADLOCK ASSERTION BREAK TESTBENCH
// File   : tb/deadlock_bug_tb.sv
// Purpose: Simulation testbench demonstrating the Dining Philosophers deadlock.
//          With BUG_DEADLOCK=1, all four agents simultaneously request their
//          critical sections and reach a circular hold-and-wait state from
//          which no progress is ever possible.
//
// Deadlock trace (3 cycles after all-req assertion):
//   T=0: state[3:0] = IDLE,IDLE,IDLE,IDLE    req=1111
//   T=1: state[3:0] = WAIT1,WAIT1,WAIT1,WAIT1
//   T=2: state[3:0] = HOLD1,HOLD1,HOLD1,HOLD1  resource=4'b1111
//   T=3: all blocked — res_b of each agent is held by the next agent
//   T=∞: no progress
//
// Run: questa sim -sv deadlock_bug_tb.sv
//                    deadlock/resource_allocator.sv
//                    deadlock/deadlock_formal_props.sv
//
// Expected assertion failures (with BUG_DEADLOCK=1):
//   ap_no_deadlock  [D1] — all four agents in HOLD1 simultaneously
//   ap_agent*_progress [L1] — agents never reach ST_CS within MAX_WAIT
// =============================================================================
`timescale 1ns/1ps

// =============================================================================
// DEADLOCK DEMONSTRATION
// =============================================================================
module deadlock_tb;
  localparam int N = 4;

  logic         clk, rst_n;
  logic [N-1:0] req, release_r;
  logic [N-1:0] grant, waiting, res_held;

  initial clk = 0;
  always #5 clk = ~clk;

  // Internal state signals (accessed via hierarchical references in display)
  // In a formal run these would be observed via the bind-attached prop module.

  // ---- DUT: BUGGY resource allocator (circular wait enabled) ----
  resource_allocator #(.N(N), .BUG_DEADLOCK(1'b1)) u_buggy (
    .clk(clk), .rst_n(rst_n),
    .req(req), .release_r(release_r),
    .grant(grant), .waiting(waiting), .res_held(res_held)
  );

  // ---- Monitor: print state every cycle ----
  always @(posedge clk) begin
    if (rst_n) begin
      $display("  T=%0t | req=%b grant=%b wait=%b res=%b | states: %0d %0d %0d %0d",
        $time, req, grant, waiting, res_held,
        u_buggy.state_q[0], u_buggy.state_q[1],
        u_buggy.state_q[2], u_buggy.state_q[3]);
    end
  end

  initial begin
    $display("=== DEADLOCK TEST: BUG_DEADLOCK=1 ===");
    $display("State encoding: 0=IDLE 1=WAIT1 2=HOLD1 3=CS 4=FREE");
    $display("Resource pairs (BUG): A0=(0,1) A1=(1,2) A2=(2,3) A3=(3,0)");
    $display("--------------------------------------------------------------");

    rst_n = 0; req = 0; release_r = 0;
    repeat(3) @(posedge clk); #1;
    rst_n = 1; repeat(2) @(posedge clk);

    $display("\n[DEADLOCK] All 4 agents simultaneously request (T=%0t):", $time);
    @(negedge clk);
    req = 4'b1111;   // All agents want their critical section NOW
    release_r = 4'b0000;

    // Watch the deadlock unfold over 10 cycles
    repeat(10) @(posedge clk);

    // By now all agents should be stuck in HOLD1 (state=2) with res_held=4'b1111
    $display("\n[DEADLOCK] Final state analysis:");
    $display("  grant   = %b  (expected 1111 — NONE ever granted)", grant);
    $display("  waiting = %b  (expected 1111 — all blocked)", waiting);
    $display("  res_held= %b  (4 resources locked, nobody can advance)", res_held);

    if (waiting == 4'b1111 && grant == 4'b0000)
      $display("  *** DEADLOCK CONFIRMED: circular hold-and-wait detected ***");

    // -----------------------------------------------------------------------
    // Show what the waits-for graph looks like at this point:
    //   Agent 0 holds res0, waits for res1 (held by Agent 1)
    //   Agent 1 holds res1, waits for res2 (held by Agent 2)
    //   Agent 2 holds res2, waits for res3 (held by Agent 3)
    //   Agent 3 holds res3, waits for res0 (held by Agent 0)
    //   → cycle: 0→1→2→3→0 — Coffman condition 4 satisfied
    // -----------------------------------------------------------------------
    $display("\n  Waits-for graph (buggy ordering):");
    $display("    Agent0(hold res0) → waiting for res1 → held by Agent1");
    $display("    Agent1(hold res1) → waiting for res2 → held by Agent2");
    $display("    Agent2(hold res2) → waiting for res3 → held by Agent3");
    $display("    Agent3(hold res3) → waiting for res0 → held by Agent0");
    $display("    CYCLE: 0 → 1 → 2 → 3 → 0  (deadlock!)");

    repeat(4) @(posedge clk);
    $display("=== DEADLOCK TEST COMPLETE ===\n");
    $finish;
  end
endmodule

// =============================================================================
// SAFE REFERENCE RUN
// Exactly the same stimulus on the safe allocator (BUG_DEADLOCK=0).
// All agents should reach CS and release, proving deadlock freedom.
//
// Expected: all ap_agent*_progress liveness assertions pass.
// =============================================================================
module safe_tb;
  localparam int N = 4;
  localparam int MAX_CYCLES = 50;

  logic         clk, rst_n;
  logic [N-1:0] req, release_r;
  logic [N-1:0] grant, waiting, res_held;
  int           cycle;

  initial clk = 0;
  always #5 clk = ~clk;

  resource_allocator #(.N(N), .BUG_DEADLOCK(1'b0)) u_safe (
    .clk(clk), .rst_n(rst_n),
    .req(req), .release_r(release_r),
    .grant(grant), .waiting(waiting), .res_held(res_held)
  );

  // Automatically release after one cycle in CS
  always_ff @(posedge clk) begin
    release_r <= grant;  // Release one cycle after being granted
  end

  initial begin
    $display("=== SAFE REFERENCE: BUG_DEADLOCK=0 ===");
    $display("State encoding: 0=IDLE 1=WAIT1 2=HOLD1 3=CS 4=FREE");
    $display("Resource pairs (SAFE): A0=(0,1) A1=(1,2) A2=(2,3) A3=(0,3)");
    $display("--------------------------------------------------------------");

    rst_n = 0; req = 0; release_r = 0; cycle = 0;
    repeat(3) @(posedge clk); #1;
    rst_n = 1; repeat(2) @(posedge clk);

    $display("\n[SAFE] All 4 agents simultaneously request:");
    @(negedge clk); req = 4'b1111;

    fork
      // Watchdog
      begin
        repeat(MAX_CYCLES) @(posedge clk);
        $display("[SAFE] Watchdog: completed %0d cycles", MAX_CYCLES);
      end

      // Wait until all agents have been granted at least once
      begin
        logic [N-1:0] ever_granted;
        ever_granted = '0;
        while (ever_granted != 4'b1111) begin
          @(posedge clk);
          cycle++;
          ever_granted |= grant;
          $display("  T=%0d | grant=%b wait=%b res=%b | states: %0d %0d %0d %0d",
            cycle, grant, waiting, res_held,
            u_safe.state_q[0], u_safe.state_q[1],
            u_safe.state_q[2], u_safe.state_q[3]);
        end
        $display("\n[SAFE] ALL agents granted within %0d cycles — NO deadlock!", cycle);
        $display("[SAFE] Agent 3 safe ordering (res0 before res3) broke the cycle.");
      end
    join_any

    repeat(4) @(posedge clk);
    $display("=== SAFE REFERENCE COMPLETE ===\n");
    $finish;
  end
endmodule
