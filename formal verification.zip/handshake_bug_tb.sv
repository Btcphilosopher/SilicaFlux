// =============================================================================
// HANDSHAKE ASSERTION BREAK TESTBENCH
// File   : tb/handshake_bug_tb.sv
// Purpose: Simulation testbench that drives handshake_controller with each
//          bug mode enabled and exercises scenarios that trigger the
//          corresponding formal property assertion failures.
//
// Each test section documents which assertion fires and the precise
// formal reasoning behind the failure.
//
// Run: questa sim -sv handshake_bug_tb.sv
//                    handshake/handshake_controller.sv
//                    handshake/handshake_formal_props.sv
// =============================================================================
`timescale 1ns/1ps

// =============================================================================
// TEST 1: BUG_VALID_DROP
// The sink applies persistent back-pressure (snk_ready=0 for TIMEOUT cycles).
// Once the internal timeout counter expires, snk_valid is forcibly deasserted
// even though the source still has valid data to send.
//
// Assertion failure: ap_snk_valid_persist [P1]
//   (snk_valid && !snk_ready) |=> snk_valid
//   Fails on the cycle snk_valid drops while snk_ready was never seen.
// =============================================================================
module hs_valid_drop_tb;
  localparam int DATA_W  = 8;
  localparam int TIMEOUT = 4;   // Must match DUT parameter

  logic              clk, rst_n;
  logic              src0_valid, src1_valid, snk_ready;
  logic [DATA_W-1:0] src0_data, src1_data;
  logic              src0_ready, src1_ready, snk_valid;
  logic [DATA_W-1:0] snk_data;

  initial clk = 0;
  always #5 clk = ~clk;

  // Instantiate controller with BUG_VALID_DROP enabled
  handshake_controller #(
    .DATA_W         (DATA_W),
    .TIMEOUT        (TIMEOUT),
    .BUG_VALID_DROP (1'b1),
    .BUG_DATA_CHANGE(1'b0)
  ) u_dut (
    .clk       (clk),
    .rst_n     (rst_n),
    .src0_valid(src0_valid),
    .src0_data (src0_data),
    .src0_ready(src0_ready),
    .src1_valid(src1_valid),
    .src1_data (src1_data),
    .src1_ready(src1_ready),
    .snk_valid (snk_valid),
    .snk_data  (snk_data),
    .snk_ready (snk_ready)
  );

  initial begin
    $display("=== TEST 1: BUG_VALID_DROP ===");
    $display("Expecting: ap_snk_valid_persist [P1] failure at cycle ~%0d", TIMEOUT+4);

    // Reset
    rst_n = 0; src0_valid = 0; src1_valid = 0;
    src0_data = 0; src1_data = 0; snk_ready = 0;
    repeat(3) @(posedge clk); #1;
    rst_n = 1;
    repeat(2) @(posedge clk);

    // Source 0 asserts valid and holds it (persistent sender)
    $display("[VALID_DROP] Asserting src0_valid. src0_data=0xAB");
    src0_valid = 1; src0_data = 8'hAB;

    // Sink applies PERSISTENT back-pressure — snk_ready stays low.
    // The AXI-stream contract requires snk_valid to remain high until ready.
    snk_ready = 0;

    // Monitor each cycle while waiting for the bug to manifest
    repeat(TIMEOUT + 3) begin
      @(posedge clk);
      $display("[VALID_DROP] cycle: snk_valid=%b snk_ready=%b snk_data=%0h",
               snk_valid, snk_ready, snk_data);
    end
    // ASSERTION ap_snk_valid_persist FIRES HERE:
    // snk_valid drops to 0 while snk_ready was never asserted.
    // src0_valid is still 1 — the controller silently dropped the transfer.

    @(posedge clk);
    $display("[VALID_DROP] After timeout: snk_valid=%b (should be 1 — PROTOCOL VIOLATION!)",
             snk_valid);
    $display("[VALID_DROP] src0_valid=%b (still waiting — data LOST)", src0_valid);

    repeat(2) @(posedge clk);
    $display("=== TEST 1 COMPLETE ===\n");
    $finish;
  end
endmodule

// =============================================================================
// TEST 2: BUG_DATA_CHANGE
// Source 0 presents valid data. Sink holds back-pressure for several cycles.
// On each stall cycle, the buggy controller increments snk_data.
//
// Assertion failure: ap_snk_data_stable [P2]
//   (snk_valid && !snk_ready) |=> $stable(snk_data)
//   Fires every cycle that snk_data changes while snk_valid is pending.
// =============================================================================
module hs_data_change_tb;
  localparam int DATA_W  = 8;
  localparam int TIMEOUT = 8;

  logic              clk, rst_n;
  logic              src0_valid, src1_valid, snk_ready;
  logic [DATA_W-1:0] src0_data, src1_data;
  logic              src0_ready, src1_ready, snk_valid;
  logic [DATA_W-1:0] snk_data;

  initial clk = 0;
  always #5 clk = ~clk;

  handshake_controller #(
    .DATA_W         (DATA_W),
    .TIMEOUT        (TIMEOUT),
    .BUG_VALID_DROP (1'b0),
    .BUG_DATA_CHANGE(1'b1)
  ) u_dut (
    .clk(clk), .rst_n(rst_n),
    .src0_valid(src0_valid), .src0_data(src0_data), .src0_ready(src0_ready),
    .src1_valid(src1_valid), .src1_data(src1_data), .src1_ready(src1_ready),
    .snk_valid(snk_valid), .snk_data(snk_data), .snk_ready(snk_ready)
  );

  initial begin
    $display("=== TEST 2: BUG_DATA_CHANGE ===");
    $display("Expecting: ap_snk_data_stable [P2] failure on every stall cycle");

    rst_n = 0; src0_valid = 0; src1_valid = 0;
    src0_data = 0; src1_data = 0; snk_ready = 0;
    repeat(3) @(posedge clk); #1;
    rst_n = 1; repeat(2) @(posedge clk);

    // Source presents constant data 0x55
    src0_valid = 1; src0_data = 8'h55;
    snk_ready = 0;   // Back-pressure — observe data changing

    $display("[DATA_CHANGE] src0_data=0x55 constant. Watching snk_data under back-pressure:");
    repeat(6) begin
      @(posedge clk);
      $display("[DATA_CHANGE]  snk_valid=%b snk_ready=%b snk_data=%0h (expected 0x55)",
               snk_valid, snk_ready, snk_data);
      // ASSERTION ap_snk_data_stable FIRES REPEATEDLY:
      // snk_data changes from 0x55 → 0x56 → 0x57 → ... each stall cycle.
    end

    // Now let the handshake complete — data will be incorrect
    @(negedge clk); snk_ready = 1;
    @(posedge clk); #1;
    $display("[DATA_CHANGE] Handshake: snk_data=%0h (CORRUPTED — should be 0x55!)", snk_data);
    snk_ready = 0; src0_valid = 0;

    repeat(2) @(posedge clk);
    $display("=== TEST 2 COMPLETE ===\n");
    $finish;
  end
endmodule

// =============================================================================
// TEST 3: BOTH BUGS SIMULTANEOUSLY
// Maximum chaos mode — drop valid AND corrupt data.
//
// Expected: ap_snk_valid_persist, ap_snk_data_stable, ap_src0_served_bounded
//           all fire within a short window.
// =============================================================================
module hs_both_bugs_tb;
  localparam int DATA_W  = 8;
  localparam int TIMEOUT = 3;

  logic              clk, rst_n;
  logic              src0_valid, src1_valid, snk_ready;
  logic [DATA_W-1:0] src0_data, src1_data;
  logic              src0_ready, src1_ready, snk_valid;
  logic [DATA_W-1:0] snk_data;
  int cycle_count;

  initial clk = 0;
  always #5 clk = ~clk;
  always @(posedge clk) cycle_count++;

  handshake_controller #(
    .DATA_W         (DATA_W),
    .TIMEOUT        (TIMEOUT),
    .BUG_VALID_DROP (1'b1),   // Drop valid after TIMEOUT stall cycles
    .BUG_DATA_CHANGE(1'b1)    // Also corrupt data on every stall cycle
  ) u_dut (
    .clk(clk), .rst_n(rst_n),
    .src0_valid(src0_valid), .src0_data(src0_data), .src0_ready(src0_ready),
    .src1_valid(src1_valid), .src1_data(src1_data), .src1_ready(src1_ready),
    .snk_valid(snk_valid), .snk_data(snk_data), .snk_ready(snk_ready)
  );

  initial begin
    cycle_count = 0;
    $display("=== TEST 3: BOTH BUGS ACTIVE ===");
    $display("Expecting: [P1],[P2],[L1] assertion failures");

    rst_n = 0; src0_valid = 0; src1_valid = 0;
    src0_data = 0; src1_data = 0; snk_ready = 0;
    repeat(3) @(posedge clk); #1;
    rst_n = 1; repeat(2) @(posedge clk);

    // Both sources valid with persistent back-pressure
    src0_valid = 1; src0_data = 8'hCC;
    src1_valid = 1; src1_data = 8'hDD;
    snk_ready = 0;

    repeat(TIMEOUT + 5) begin
      @(posedge clk);
      $display("[BOTH BUGS] cycle %0d: snk_v=%b snk_d=%0h src0_r=%b src1_r=%b",
               cycle_count, snk_valid, snk_data, src0_ready, src1_ready);
    end

    $display("[BOTH BUGS] Result: data corrupted AND valid dropped — complete protocol failure");
    $display("  Sources src0_valid=%b src1_valid=%b (stranded, never served)",
             src0_valid, src1_valid);

    repeat(2) @(posedge clk);
    $display("=== TEST 3 COMPLETE ===\n");
    $finish;
  end
endmodule
