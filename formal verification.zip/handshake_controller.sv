// =============================================================================
// HANDSHAKE ARBITER / MUX CONTROLLER
// File   : handshake/handshake_controller.sv
// Purpose: Two-input AXI-stream round-robin arbiter. Accepts data from two
//          upstream sources and forwards to a single downstream sink, obeying
//          the AXI-stream valid/ready handshake protocol on every port.
//
// Normal operation:
//   When both sources are valid, the arbiter alternates between them using
//   a 1-bit round-robin pointer (rr_sel_q). If only one source is valid it
//   is immediately forwarded. A transfer completes when both snk_valid and
//   snk_ready are simultaneously asserted; the originating source then
//   receives its src_ready pulse.
//
// Bug injection parameters:
//
//   BUG_VALID_DROP (default 0):
//     After TIMEOUT stall cycles (snk_valid=1, snk_ready=0), snk_valid is
//     forcibly deasserted. The upstream source's valid remains asserted but
//     the controller has silently abandoned the transfer.
//     Breaks: ap_snk_valid_persist — the cardinal AXI-stream safety rule.
//
//   BUG_DATA_CHANGE (default 0):
//     On every stall cycle, an incrementing offset is added to snk_data.
//     Data changes while snk_valid is pending, corrupting the transfer value.
//     Breaks: ap_snk_data_stable.
// =============================================================================
module handshake_controller #(
  parameter int  DATA_W          = 8,
  parameter int  TIMEOUT         = 4,      // BUG_VALID_DROP stall threshold
  parameter bit  BUG_VALID_DROP  = 1'b0,
  parameter bit  BUG_DATA_CHANGE = 1'b0
)(
  input  logic              clk,
  input  logic              rst_n,
  // ---- Upstream source 0 ----
  input  logic              src0_valid,
  input  logic [DATA_W-1:0] src0_data,
  output logic              src0_ready,
  // ---- Upstream source 1 ----
  input  logic              src1_valid,
  input  logic [DATA_W-1:0] src1_data,
  output logic              src1_ready,
  // ---- Downstream sink ----
  output logic              snk_valid,
  output logic [DATA_W-1:0] snk_data,
  input  logic              snk_ready
);

  // ---- Round-robin selection register ----
  // rr_sel_q = 0: src0 has priority when both are valid.
  // rr_sel_q = 1: src1 has priority when both are valid.
  // Toggles on every completed downstream handshake.
  logic rr_sel_q;

  // ---- Combinatorial source selection ----
  // sel_valid: the selected source's valid signal
  // sel_data:  the selected source's data
  // sel_idx:   0 = src0 selected, 1 = src1 selected
  logic              sel_valid;
  logic [DATA_W-1:0] sel_data;
  logic              sel_idx;

  always_comb begin
    // Prefer the source indicated by rr_sel_q when both are valid.
    // Fall through to the other source if the preferred one is idle.
    if (src0_valid && (rr_sel_q == 1'b0 || !src1_valid)) begin
      sel_valid = 1'b1;
      sel_data  = src0_data;
      sel_idx   = 1'b0;
    end else begin
      sel_valid = src1_valid;
      sel_data  = src1_data;
      sel_idx   = 1'b1;
    end
  end

  // ---- BUG_VALID_DROP: stall timeout counter ----
  // Counts consecutive cycles where snk_valid=1 but snk_ready=0.
  // Once timeout_q reaches TIMEOUT, snk_valid is suppressed.
  logic [$clog2(TIMEOUT+2)-1:0] timeout_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      timeout_q <= '0;
    end else if (snk_valid && !snk_ready) begin
      // Saturate at TIMEOUT to avoid wrap-around
      if (timeout_q < TIMEOUT[$clog2(TIMEOUT+2)-1:0])
        timeout_q <= timeout_q + 1'b1;
    end else begin
      timeout_q <= '0;
    end
  end

  // ---- BUG_DATA_CHANGE: incrementing corruption offset ----
  // Adds 1 per stall cycle to snk_data, guaranteeing it changes
  // while the handshake is pending. Resets when no stall is active.
  logic [DATA_W-1:0] corrupt_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      corrupt_q <= '0;
    end else if (snk_valid && !snk_ready) begin
      corrupt_q <= corrupt_q + 1'b1;
    end else begin
      corrupt_q <= '0;
    end
  end

  // ---- Output: snk_valid ----
  // Normal:           follows sel_valid (the chosen source's valid).
  // BUG_VALID_DROP:   deasserted once the stall counter expires.
  //   Consequence: source still holds valid (its data is stranded),
  //   the sink never sees the transfer, and the controller pretends
  //   there is nothing to send — a silent data loss.
  logic valid_pre;
  assign valid_pre = sel_valid;
  assign snk_valid = BUG_VALID_DROP
                     ? (valid_pre && (timeout_q < TIMEOUT[$clog2(TIMEOUT+2)-1:0]))
                     : valid_pre;

  // ---- Output: snk_data ----
  // Normal:           routes sel_data straight through.
  // BUG_DATA_CHANGE:  adds an incrementing offset — data drifts every stall cycle.
  assign snk_data = BUG_DATA_CHANGE
                    ? (sel_data + corrupt_q)
                    : sel_data;

  // ---- Output: src_ready signals ----
  // A source receives ready only when the downstream handshake completes
  // AND that source was the selected one. The two readys are mutually
  // exclusive by construction (sel_idx is one-hot).
  assign src0_ready = snk_valid && snk_ready && (sel_idx == 1'b0);
  assign src1_ready = snk_valid && snk_ready && (sel_idx == 1'b1);

  // ---- Round-robin update ----
  // Toggle on every completed handshake to ensure fair alternation.
  // With fairness: each source serves at most one extra transfer before
  // the other gets its turn (assuming both are always valid).
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rr_sel_q <= 1'b0;
    end else begin
      if (snk_valid && snk_ready)
        rr_sel_q <= ~rr_sel_q;
    end
  end

endmodule
