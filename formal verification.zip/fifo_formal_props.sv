// =============================================================================
// FIFO FORMAL PROPERTY MODULE
// File   : fifo/fifo_formal_props.sv
// Purpose: Formal verification properties for sync_fifo.sv.
//          Bound to the DUT via the `bind` directive at the bottom of this file.
//
// Property naming:
//   ap_*  — assert property  (safety / correctness invariants)
//   asm_* — assume property  (legal input constraints)
//   cp_*  — cover  property  (reachability / completeness)
//
// Property categories:
//   [I]  Invariants    — must hold in every reachable state
//   [S]  Safety        — a bad event must never occur
//   [R]  Reset         — correct state after reset deassertion
//   [L]  Liveness      — progress is always achievable
//   [C]  Cover         — reachability proof obligations
//
// Formal tool usage:
//   JasperGold: analyze -sv fifo_formal_props.sv; elaborate -bbox_m sync_fifo
//   Questa:     vlog fifo_formal_props.sv; formal compile -d sync_fifo
// =============================================================================
module fifo_formal_props #(
  parameter int DEPTH = 8,
  parameter int WIDTH = 8
)(
  input logic             clk,
  input logic             rst_n,
  // DUT primary interface
  input logic             wr_en,
  input logic [WIDTH-1:0] wr_data,
  input logic             full,
  input logic             rd_en,
  input logic [WIDTH-1:0] rd_data,
  input logic             empty,
  input logic [$clog2(DEPTH):0] count,
  // DUT internal signals (exposed for deep structural checks)
  input logic [$clog2(DEPTH):0] wr_ptr_q,
  input logic [$clog2(DEPTH):0] rd_ptr_q
);

  localparam int PTR_W = $clog2(DEPTH) + 1;
  localparam logic [PTR_W-1:0] DEPTH_VAL = PTR_W'(DEPTH);

  // =========================================================================
  // INPUT ASSUMPTIONS
  //
  // Formal reasoning: assumptions define the "environment contract." The tool
  // only needs to verify correctness for inputs satisfying these constraints.
  // Overly tight assumptions risk vacuous proofs; too loose and the tool
  // explores impossible scenarios.
  //
  // Here we only constrain that wr_data is never X. We intentionally leave
  // wr_en/rd_en unconstrained to allow the tool to try all combinations,
  // including simultaneous push+pop (which should be valid).
  // =========================================================================
  asm_no_x_data: assume property (
    @(posedge clk) disable iff (!rst_n)
    !$isunknown(wr_data)
  );

  // =========================================================================
  // [I1] INVARIANT: count equals the pointer difference
  //
  // Formal reasoning: this is the fundamental FIFO invariant. count is
  // defined as wr_ptr - rd_ptr in unsigned arithmetic. Any divergence from
  // this relationship indicates corruption of either the count register or
  // the pointer registers — an impossible state in a correct implementation.
  // All downstream properties (full, empty, overflow, underflow) follow from
  // this single invariant.
  // =========================================================================
  ap_count_ptr_coherent: assert property (
    @(posedge clk) disable iff (!rst_n)
    count == (wr_ptr_q - rd_ptr_q)
  ) else $error("[I1] count=%0d != wr_ptr(%0d)-rd_ptr(%0d)=%0d",
                count, wr_ptr_q, rd_ptr_q, wr_ptr_q - rd_ptr_q);

  // =========================================================================
  // [I2] INVARIANT: count is always within the range [0, DEPTH]
  //
  // Formal reasoning: count is unsigned. DEPTH+1 representable values exist
  // in PTR_W bits, but count > DEPTH means the FIFO has "more entries than
  // capacity," which is physically impossible. This invariant catches both
  // pointer arithmetic errors and the BUG_COUNT_ERR injection.
  // =========================================================================
  ap_count_bounded: assert property (
    @(posedge clk) disable iff (!rst_n)
    count <= DEPTH_VAL
  ) else $error("[I2] count=%0d exceeds DEPTH=%0d (overflow corruption)", count, DEPTH);

  // =========================================================================
  // [I3] INVARIANT: full flag is correct iff count == DEPTH
  //
  // Formal reasoning: full must be asserted when, and only when, the FIFO
  // contains exactly DEPTH entries. Under-assertion causes overflow (controller
  // will push to a full FIFO); over-assertion starves the producer.
  // =========================================================================
  ap_full_correct: assert property (
    @(posedge clk) disable iff (!rst_n)
    full == (count == DEPTH_VAL)
  ) else $error("[I3] full=%b but count=%0d (expected full iff count==%0d)",
                full, count, DEPTH);

  // =========================================================================
  // [I4] INVARIANT: empty flag is correct iff count == 0
  //
  // Formal reasoning: symmetric to [I3]. Over-asserting empty starves the
  // consumer; under-asserting causes reads of stale/uninitialised data.
  // =========================================================================
  ap_empty_correct: assert property (
    @(posedge clk) disable iff (!rst_n)
    empty == (count == '0)
  ) else $error("[I4] empty=%b but count=%0d (expected empty iff count==0)", empty, count);

  // =========================================================================
  // [I5] INVARIANT: full and empty are mutually exclusive
  //
  // Formal reasoning: full ⟺ count==DEPTH, empty ⟺ count==0.
  // For DEPTH > 1 these conditions are disjoint. If both flags fire together,
  // the FIFO control logic would simultaneously allow and block both push and
  // pop — a deadlock for any attached pipeline.
  // =========================================================================
  ap_full_empty_mutex: assert property (
    @(posedge clk) disable iff (!rst_n)
    !(full && empty)
  ) else $error("[I5] full && empty simultaneously — impossible occupancy state");

  // =========================================================================
  // [S1] SAFETY: No overflow — pushing to a full FIFO must not advance wr_ptr
  //
  // Formal reasoning: if wr_ptr advances when full, it collides with rd_ptr.
  // The generation bits now match, making the FIFO appear empty. Subsequent
  // reads return stale overwritten data, breaking FIFO ordering entirely.
  // Checked as a next-cycle implication: if we were full + pushing (and not
  // simultaneously popping), count must be unchanged on the next clock.
  // =========================================================================
  ap_no_overflow: assert property (
    @(posedge clk) disable iff (!rst_n)
    (full && wr_en && !rd_en) |=> (count == $past(count))
  ) else $error("[S1] OVERFLOW: count changed while full (wr_en=%b, rd_en=%b)",
                $past(wr_en), $past(rd_en));

  // =========================================================================
  // [S2] SAFETY: No underflow — reading from empty FIFO must not advance rd_ptr
  //
  // Formal reasoning: if rd_ptr advances when empty, it leaps past wr_ptr in
  // the extended pointer space. The difference wraps around to DEPTH (FIFO
  // appears full), and subsequent full/empty checks return garbage. This is
  // the read-side dual of the overflow hazard.
  // =========================================================================
  ap_no_underflow: assert property (
    @(posedge clk) disable iff (!rst_n)
    (empty && rd_en && !wr_en) |=> (count == $past(count))
  ) else $error("[S2] UNDERFLOW: count changed while empty (wr_en=%b, rd_en=%b)",
                $past(wr_en), $past(rd_en));

  // =========================================================================
  // [S3] SAFETY: Single push increments count by exactly one
  //
  // Formal reasoning: BUG_COUNT_ERR causes +2 per push. This property catches
  // any count arithmetic error on a push-only cycle, ensuring the pointer
  // and the count output remain in step.
  // =========================================================================
  ap_push_increments_by_one: assert property (
    @(posedge clk) disable iff (!rst_n)
    (wr_en && !rd_en && !full) |=> (count == ($past(count) + 1'b1))
  ) else $error("[S3] push: count went %0d→%0d (expected +1)", $past(count), count);

  // =========================================================================
  // [S4] SAFETY: Single pop decrements count by exactly one
  // =========================================================================
  ap_pop_decrements_by_one: assert property (
    @(posedge clk) disable iff (!rst_n)
    (!wr_en && rd_en && !empty) |=> (count == ($past(count) - 1'b1))
  ) else $error("[S4] pop: count went %0d→%0d (expected -1)", $past(count), count);

  // =========================================================================
  // [S5] SAFETY: Simultaneous push + pop leaves count unchanged
  //
  // Formal reasoning: one entry enters and one exits in the same cycle.
  // Net delta = 0. This verifies that the FIFO does not have a priority
  // bug where push or pop takes precedence instead of both executing.
  // =========================================================================
  ap_push_pop_net_zero: assert property (
    @(posedge clk) disable iff (!rst_n)
    (wr_en && rd_en && !full && !empty) |=> (count == $past(count))
  ) else $error("[S5] simultaneous push+pop: count=%0d, was=%0d (expected equal)",
                count, $past(count));

  // =========================================================================
  // [S6] SAFETY: rd_data is stable while idle (no reads, no writes)
  //
  // Formal reasoning: if rd_ptr has not advanced and no write has overwritten
  // the head-of-queue slot, the output data must remain constant. A spurious
  // change would indicate a read-path mux or memory hold bug.
  // =========================================================================
  ap_rddata_stable_when_idle: assert property (
    @(posedge clk) disable iff (!rst_n)
    (!rd_en && !wr_en && !empty) |=> $stable(rd_data)
  ) else $error("[S6] rd_data changed without any push or pop activity");

  // =========================================================================
  // [R1] RESET: Correct initial state after reset deasserts
  //
  // Formal reasoning: both pointers are zeroed on reset. After the first
  // posedge following rst_n deassertion, the derived flags must reflect the
  // empty-FIFO state: count=0, empty=1, full=0.
  // =========================================================================
  ap_reset_state: assert property (
    @(posedge clk)
    $rose(rst_n) |=> (empty && !full && (count == '0))
  ) else $error("[R1] post-reset state: empty=%b full=%b count=%0d (expected 1,0,0)",
                empty, full, count);

  // =========================================================================
  // [R2] RESET: Both pointers are zero while rst_n is asserted
  //
  // Formal reasoning: asynchronous reset zeros both pointers immediately.
  // Any non-zero pointer during reset means the reset path is broken.
  // =========================================================================
  ap_reset_ptrs_zero: assert property (
    @(posedge clk)
    !rst_n |-> (wr_ptr_q == '0 && rd_ptr_q == '0)
  ) else $error("[R2] pointers non-zero during reset: wr=%0d rd=%0d",
                wr_ptr_q, rd_ptr_q);

  // =========================================================================
  // [C1] COVER: empty FIFO fills to full
  //
  // Formal reasoning: if the tool cannot find a trace from empty→full, the
  // assumptions over-constrain wr_en or the push logic is unreachable.
  // =========================================================================
  cp_empty_to_full: cover property (
    @(posedge clk) empty ##[1:DEPTH+2] full
  );

  // =========================================================================
  // [C2] COVER: full FIFO drains to empty
  // =========================================================================
  cp_full_to_empty: cover property (
    @(posedge clk) full ##[1:DEPTH+2] empty
  );

  // =========================================================================
  // [C3] COVER: single-entry round-trip (push one, pop one)
  //
  // Formal reasoning: the most basic FIFO scenario. Verifies that push and
  // pop are individually reachable in sequence.
  // =========================================================================
  cp_single_roundtrip: cover property (
    @(posedge clk)
    (empty && wr_en && !rd_en)         // Push to empty
    ##1 (!empty && rd_en && !wr_en)    // Pop the entry
    ##1 empty                           // Back to empty
  );

  // =========================================================================
  // [C4] COVER: simultaneous push+pop while non-empty, non-full
  // =========================================================================
  cp_simultaneous_push_pop: cover property (
    @(posedge clk) wr_en && rd_en && !full && !empty
  );

endmodule

// =============================================================================
// BIND DIRECTIVE
//
// Attaches fifo_formal_props to every instance of sync_fifo automatically.
// In a JasperGold session: analyze -sv fifo_formal_props.sv (includes bind).
// In Questa Formal:        vlog fifo_formal_props.sv
//
// The bind grants the property module full visibility into sync_fifo's
// internal signals (wr_ptr_q, rd_ptr_q) without modifying the DUT source.
// =============================================================================
bind sync_fifo fifo_formal_props #(
  .DEPTH(DEPTH),
  .WIDTH(WIDTH)
) u_fifo_formal_props (
  .clk      (clk),
  .rst_n    (rst_n),
  .wr_en    (wr_en),
  .wr_data  (wr_data),
  .full     (full),
  .rd_en    (rd_en),
  .rd_data  (rd_data),
  .empty    (empty),
  .count    (count),
  .wr_ptr_q (wr_ptr_q),
  .rd_ptr_q (rd_ptr_q)
);
