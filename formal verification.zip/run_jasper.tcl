# =============================================================================
# JASPERGOLD FORMAL VERIFICATION SCRIPT
# File   : scripts/run_jasper.tcl
# Purpose: Automated formal verification flow for all three DUTs.
#          Runs property checking (prove), bounded model checking (bmc),
#          and cover analysis.
#
# Usage:
#   jg -no_gui -tcl scripts/run_jasper.tcl -proj jg_fv_work
#
# Targets:
#   FIFO:        sync_fifo        + fifo_formal_props
#   Handshake:   handshake_controller + handshake_formal_props
#   Deadlock:    resource_allocator (safe)  + deadlock_formal_props
#   Deadlock bug:resource_allocator (buggy) + deadlock_formal_props
# =============================================================================

# ---- Global settings ----
set_app_var allow_bind_to_unresolved 1

# =============================================================================
# PROC: run_fv — analyse, elaborate, and prove a single configuration
# =============================================================================
proc run_fv {label dut_file props_file top_module params {bmc_depth 20}} {
  puts "============================================================"
  puts " STARTING: $label"
  puts "============================================================"

  # ---- Analysis ----
  # Analyse the DUT and the property module (which includes the bind directive)
  analyze -sv09 -f [list $dut_file $props_file]

  # ---- Elaboration ----
  # The bind directive in props_file automatically attaches properties to DUT.
  # Override parameters here to test specific configurations.
  eval elaborate -top $top_module $params

  # ---- Clock and Reset ----
  clock clk -both_edges
  reset -expression {!rst_n}

  # ---- Prove mode: unbounded property checking ----
  puts "\n--- PROVE (safety + liveness) ---"
  prove -all

  # Print results
  puts "\nResults for $label:"
  report -results

  # ---- BMC mode: bounded model checking up to bmc_depth cycles ----
  # BMC is faster and finds shallow bugs; useful for liveness counterexamples
  puts "\n--- BMC (depth=$bmc_depth) ---"
  set_prove_time_limit 120s
  prove -bmc -depth $bmc_depth

  # ---- Cover analysis: prove reachability ----
  puts "\n--- COVER (reachability) ---"
  prove -cover

  report -cover
  report -results -all > "results_${label}.txt"

  puts "Results written to results_${label}.txt"
  clear_assume
  clear_assertion
}

# =============================================================================
# CONFIGURATION 1: FIFO — correct implementation (no bugs)
# Expected: all ap_* PASS, all cp_* REACHED
# =============================================================================
run_fv \
  "fifo_correct" \
  "fifo/sync_fifo.sv" \
  "fifo/fifo_formal_props.sv" \
  "sync_fifo" \
  "-parameter DEPTH 8 -parameter WIDTH 8 \
   -parameter BUG_OVERFLOW 0 -parameter BUG_UNDERFLOW 0 \
   -parameter BUG_COUNT_ERR 0 -parameter BUG_FLAG_INV 0" \
  20

# =============================================================================
# CONFIGURATION 2: FIFO — BUG_OVERFLOW enabled
# Expected: ap_no_overflow FAIL, ap_count_bounded FAIL
# BMC trace length: ~3 cycles (fill to full, push again)
# =============================================================================
run_fv \
  "fifo_overflow_bug" \
  "fifo/sync_fifo.sv" \
  "fifo/fifo_formal_props.sv" \
  "sync_fifo" \
  "-parameter DEPTH 4 -parameter WIDTH 8 \
   -parameter BUG_OVERFLOW 1 -parameter BUG_UNDERFLOW 0 \
   -parameter BUG_COUNT_ERR 0 -parameter BUG_FLAG_INV 0" \
  10

# =============================================================================
# CONFIGURATION 3: FIFO — BUG_UNDERFLOW enabled
# Expected: ap_no_underflow FAIL
# BMC trace: 2 cycles (empty at start, rd_en immediately)
# =============================================================================
run_fv \
  "fifo_underflow_bug" \
  "fifo/sync_fifo.sv" \
  "fifo/fifo_formal_props.sv" \
  "sync_fifo" \
  "-parameter DEPTH 4 -parameter WIDTH 8 \
   -parameter BUG_OVERFLOW 0 -parameter BUG_UNDERFLOW 1 \
   -parameter BUG_COUNT_ERR 0 -parameter BUG_FLAG_INV 0" \
  6

# =============================================================================
# CONFIGURATION 4: Handshake — correct implementation
# Expected: all ap_* PASS (given asm_* hold), all cp_* REACHED
# =============================================================================
run_fv \
  "handshake_correct" \
  "handshake/handshake_controller.sv" \
  "handshake/handshake_formal_props.sv" \
  "handshake_controller" \
  "-parameter DATA_W 8 -parameter TIMEOUT 8 \
   -parameter BUG_VALID_DROP 0 -parameter BUG_DATA_CHANGE 0" \
  40

# =============================================================================
# CONFIGURATION 5: Handshake — BUG_VALID_DROP enabled
# Expected: ap_snk_valid_persist FAIL
# BMC trace: TIMEOUT+2 cycles
# =============================================================================
run_fv \
  "handshake_valid_drop" \
  "handshake/handshake_controller.sv" \
  "handshake/handshake_formal_props.sv" \
  "handshake_controller" \
  "-parameter DATA_W 8 -parameter TIMEOUT 4 \
   -parameter BUG_VALID_DROP 1 -parameter BUG_DATA_CHANGE 0" \
  12

# =============================================================================
# CONFIGURATION 6: Deadlock allocator — safe ordering (BUG_DEADLOCK=0)
# Expected: all deadlock/liveness properties PASS
# =============================================================================
run_fv \
  "deadlock_safe" \
  "deadlock/resource_allocator.sv" \
  "deadlock/deadlock_formal_props.sv" \
  "resource_allocator" \
  "-parameter N 4 -parameter BUG_DEADLOCK 0" \
  80

# =============================================================================
# CONFIGURATION 7: Deadlock allocator — circular wait enabled (BUG_DEADLOCK=1)
# Expected:
#   ap_no_deadlock FAIL (3-cycle counterexample)
#   ap_agent*_progress FAIL (liveness violation)
# =============================================================================
run_fv \
  "deadlock_buggy" \
  "deadlock/resource_allocator.sv" \
  "deadlock/deadlock_formal_props.sv" \
  "resource_allocator" \
  "-parameter N 4 -parameter BUG_DEADLOCK 1" \
  10

puts "============================================================"
puts " ALL CONFIGURATIONS COMPLETE"
puts "============================================================"
exit
