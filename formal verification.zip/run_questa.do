# =============================================================================
# QUESTA FORMAL VERIFICATION SCRIPT
# File   : scripts/run_questa.do
# Purpose: Automated formal verification flow for Mentor/Siemens Questa Formal.
#          Compiles all DUTs + property modules, then runs prove/bmc/cover
#          for each configuration.
#
# Usage:
#   qformal -do scripts/run_questa.do
#   or from GUI: File → Run Script → scripts/run_questa.do
#
# Output:
#   qformal_work/   — compiled design library
#   *_results.txt   — per-configuration assertion reports
# =============================================================================

# ---- Workspace setup ----
if { [file exists qformal_work] } { file delete -force qformal_work }
vlib qformal_work
vmap work qformal_work

# =============================================================================
# PROC: compile_all — compile all RTL and property files
# =============================================================================
proc compile_all {} {
  # Assertion library (included via `include — not separately compiled)
  # Include path passed to vlog via +incdir

  puts "--- Compiling FIFO ---"
  vlog -sv -O5 +incdir+lib \
    fifo/sync_fifo.sv \
    fifo/fifo_formal_props.sv

  puts "--- Compiling Handshake Controller ---"
  vlog -sv -O5 +incdir+lib \
    handshake/handshake_controller.sv \
    handshake/handshake_formal_props.sv

  puts "--- Compiling Resource Allocator ---"
  vlog -sv -O5 +incdir+lib \
    deadlock/resource_allocator.sv \
    deadlock/deadlock_formal_props.sv

  puts "Compilation complete."
}

compile_all

# =============================================================================
# PROC: run_questa_fv — elaborate, set constraints, prove, report
# =============================================================================
proc run_questa_fv {label top generics {bmc_depth 20}} {
  puts "============================================================"
  puts " QUESTA FORMAL: $label"
  puts "============================================================"

  # ---- Formal compilation / elaboration ----
  # -work         : use compiled library
  # -d            : design top
  # -generics     : parameter overrides
  # -sva          : enable SVA processing
  # -assert       : enable assertion coverage
  eval formal compile -work qformal_work \
    -d $top \
    -sva \
    -assert \
    $generics

  # ---- Clocks and resets ----
  # Questa Formal requires clock and reset declarations before prove
  formal clock  -add clk -edge posedge
  formal reset  -add {!rst_n}

  # ---- Safety prove (unbounded K-induction) ----
  puts "\n-- SAFETY (k-induction) --"
  formal verify \
    -init {{rst_n 0}} \
    -effort high \
    -timeout 300

  # ---- BMC (shallow bug hunting) ----
  puts "\n-- BMC (depth=$bmc_depth) --"
  formal verify \
    -bmc -depth $bmc_depth \
    -init {{rst_n 0}} \
    -timeout 120

  # ---- Cover (reachability) ----
  puts "\n-- COVER --"
  formal verify \
    -cover \
    -depth [expr {$bmc_depth * 3}] \
    -timeout 120

  # ---- Report ----
  formal report -summary > "results_${label}.txt"
  formal report -detail  >> "results_${label}.txt"
  puts "Report written to results_${label}.txt"

  # Print summary to console
  formal report -summary

  # Cleanup for next run
  formal reset_design
}

# =============================================================================
# RUN 1: FIFO — correct (no bugs)
# =============================================================================
run_questa_fv \
  "fifo_correct" \
  "sync_fifo" \
  "-generics {DEPTH=8 WIDTH=8 BUG_OVERFLOW=0 BUG_UNDERFLOW=0 BUG_COUNT_ERR=0 BUG_FLAG_INV=0}" \
  20

# =============================================================================
# RUN 2: FIFO — overflow bug
# =============================================================================
run_questa_fv \
  "fifo_overflow" \
  "sync_fifo" \
  "-generics {DEPTH=4 WIDTH=8 BUG_OVERFLOW=1 BUG_UNDERFLOW=0 BUG_COUNT_ERR=0 BUG_FLAG_INV=0}" \
  10

# =============================================================================
# RUN 3: FIFO — underflow bug
# =============================================================================
run_questa_fv \
  "fifo_underflow" \
  "sync_fifo" \
  "-generics {DEPTH=4 WIDTH=8 BUG_OVERFLOW=0 BUG_UNDERFLOW=1 BUG_COUNT_ERR=0 BUG_FLAG_INV=0}" \
  8

# =============================================================================
# RUN 4: FIFO — count error bug
# =============================================================================
run_questa_fv \
  "fifo_count_err" \
  "sync_fifo" \
  "-generics {DEPTH=8 WIDTH=8 BUG_OVERFLOW=0 BUG_UNDERFLOW=0 BUG_COUNT_ERR=1 BUG_FLAG_INV=0}" \
  12

# =============================================================================
# RUN 5: Handshake — correct
# =============================================================================
run_questa_fv \
  "handshake_correct" \
  "handshake_controller" \
  "-generics {DATA_W=8 TIMEOUT=8 BUG_VALID_DROP=0 BUG_DATA_CHANGE=0}" \
  40

# =============================================================================
# RUN 6: Handshake — valid drop bug
# =============================================================================
run_questa_fv \
  "handshake_valid_drop" \
  "handshake_controller" \
  "-generics {DATA_W=8 TIMEOUT=4 BUG_VALID_DROP=1 BUG_DATA_CHANGE=0}" \
  12

# =============================================================================
# RUN 7: Handshake — data change bug
# =============================================================================
run_questa_fv \
  "handshake_data_change" \
  "handshake_controller" \
  "-generics {DATA_W=8 TIMEOUT=8 BUG_VALID_DROP=0 BUG_DATA_CHANGE=1}" \
  10

# =============================================================================
# RUN 8: Deadlock — safe ordering (should PASS all liveness properties)
# =============================================================================
run_questa_fv \
  "deadlock_safe" \
  "resource_allocator" \
  "-generics {N=4 BUG_DEADLOCK=0}" \
  80

# =============================================================================
# RUN 9: Deadlock — circular wait bug (should FAIL ap_no_deadlock, liveness)
# =============================================================================
run_questa_fv \
  "deadlock_buggy" \
  "resource_allocator" \
  "-generics {N=4 BUG_DEADLOCK=1}" \
  10

puts "============================================================"
puts " QUESTA FORMAL: ALL RUNS COMPLETE"
puts " Summary reports written to results_*.txt"
puts "============================================================"

quit -f
