// =============================================================================
// SVA ASSERTION LIBRARY
// File   : lib/sva_assertion_lib.sv
// Purpose: Reusable SystemVerilog Assertion macros, named sequences, and
//          standalone bindable checker modules for formal and simulation-based
//          verification.
//
// Formal verification roles:
//   ASSERT — safety properties the design must never violate
//   ASSUME — constraints on inputs (formal engine treats as axioms)
//   COVER  — reachability goals (proves a scenario is achievable)
//
// Usage:
//   `include "sva_assertion_lib.sv"
//   in any module that needs these macros.
//
// Compatibility: JasperGold 2023.x, Questa Formal 2023.x, VC Formal 2023.x
// =============================================================================

`ifndef SVA_ASSERTION_LIB_SV
`define SVA_ASSERTION_LIB_SV

// =============================================================================
// SECTION 1 — PARAMETRIC ASSERTION MACROS
//
// All macros assume local signals: clk (clock) and rst_n (active-low reset).
//
// Formal note on `disable iff (!rst_n)`:
//   This clause vacuously satisfies any assertion while rst_n=0, suppressing
//   false failures during the reset phase. Without it, a formal tool would
//   explore reset states as potential counterexamples for properties that
//   are only meaningful in normal operation.
// =============================================================================

// Assert that PROP holds on every active clock edge.
// Role: safety — a bad thing must never happen.
`define ASSERT_ALWAYS(NAME, PROP) \
  NAME: assert property (@(posedge clk) disable iff (!rst_n) (PROP)) \
    else $error("[ASSERT:FAIL] %-40s  @ %0t ns", `"NAME`", $realtime);

// Constrain the formal input space — the tool treats this as an axiom.
// Role: environment assumption — prune unreachable / illegal inputs.
`define ASSUME_ALWAYS(NAME, PROP) \
  NAME: assume property (@(posedge clk) disable iff (!rst_n) (PROP));

// Prove this scenario is reachable.
// Role: completeness — if cover fails, assumptions over-constrain the model.
`define COVER_PROP(NAME, PROP) \
  NAME: cover property (@(posedge clk) (PROP));

// Same-cycle implication: TRIGGER |-> RESULT (overlapping)
// Formal note: |-> is checked starting at the same cycle as the end of TRIGGER.
`define ASSERT_IMPLIES(NAME, TRIGGER, RESULT) \
  NAME: assert property (@(posedge clk) disable iff (!rst_n) \
    (TRIGGER) |-> (RESULT)) \
    else $error("[ASSERT:FAIL] %-40s  (implies) @ %0t ns", `"NAME`", $realtime);

// Next-cycle implication: TRIGGER |=> RESULT (non-overlapping, equiv to ##1)
// Formal note: |=> ≡ |-> ##1. Use when checking the cycle after the trigger.
`define ASSERT_NEXT(NAME, TRIGGER, RESULT) \
  NAME: assert property (@(posedge clk) disable iff (!rst_n) \
    (TRIGGER) |=> (RESULT)) \
    else $error("[ASSERT:FAIL] %-40s  (next) @ %0t ns", `"NAME`", $realtime);

// Bounded liveness: TRIGGER implies RESULT within [1:MAX] cycles.
// Formal note: unbounded ##[1:$] makes formal non-terminating for most engines.
//   MAX must be finite. Choose it based on worst-case pipeline depth.
`define ASSERT_EVENTUALLY(NAME, TRIGGER, RESULT, MAX) \
  NAME: assert property (@(posedge clk) disable iff (!rst_n) \
    (TRIGGER) |-> ##[1:MAX] (RESULT)) \
    else $error("[ASSERT:FAIL] %-40s  (liveness) @ %0t ns", `"NAME`", $realtime);

// Mutual exclusion: SIG_A and SIG_B never simultaneously high.
`define ASSERT_MUTEX(NAME, SIG_A, SIG_B) \
  NAME: assert property (@(posedge clk) disable iff (!rst_n) \
    !((SIG_A) && (SIG_B))) \
    else $error("[ASSERT:FAIL] %-40s  (mutex) @ %0t ns", `"NAME`", $realtime);

// One-hot-or-zero encoding check.
// Formal note: $onehot0 returns true if at most one bit is set (zero included).
`define ASSERT_ONEHOT0(NAME, SIG) \
  NAME: assert property (@(posedge clk) disable iff (!rst_n) \
    ($onehot0(SIG))) \
    else $error("[ASSERT:FAIL] %-40s  (onehot0) @ %0t ns", `"NAME`", $realtime);

// No unknowns: signal must never carry X or Z.
// Critical in formal: X values silently satisfy all comparisons.
`define ASSERT_NO_X(NAME, SIG) \
  NAME: assert property (@(posedge clk) disable iff (!rst_n) \
    (!$isunknown(SIG))) \
    else $error("[ASSERT:FAIL] %-40s  (no-X) @ %0t ns", `"NAME`", $realtime);

// Stability check: SIG must not change on the cycle following COND.
// Formal note: |=> is non-overlapping — checks the cycle AFTER COND is true.
//   Using $stable(SIG) on the COND cycle itself is trivially true.
`define ASSERT_STABLE_WHILE(NAME, SIG, COND) \
  NAME: assert property (@(posedge clk) disable iff (!rst_n) \
    (COND) |=> $stable(SIG)) \
    else $error("[ASSERT:FAIL] %-40s  (stable) @ %0t ns", `"NAME`", $realtime);

// Reset recovery: one cycle after rst_n deasserts, SIG must equal RESET_VAL.
// Does NOT use disable iff — the assertion ONLY fires on reset deassertion.
`define ASSERT_RESET_VALUE(NAME, SIG, RESET_VAL) \
  NAME: assert property (@(posedge clk) \
    $rose(rst_n) |=> ((SIG) === (RESET_VAL))) \
    else $error("[ASSERT:FAIL] %-40s  (reset-val) @ %0t ns", `"NAME`", $realtime);


// =============================================================================
// SECTION 2 — GRAY CODE CHECKER  (bindable module)
//
// Bind to any module exposing a Gray-coded pointer output.
//
// Formal reasoning:
//   In asynchronous FIFOs, write/read pointers cross clock domains. To prevent
//   metastability from propagating to the receiving logic, the pointer is
//   Gray-coded: only one bit changes per count step. If two bits flip together,
//   the CDC synchroniser can capture a spurious intermediate value that
//   corresponds to neither the old nor new count — corrupting full/empty flags.
//
// Example bind:
//   bind my_async_fifo sva_gray_check #(.WIDTH(5)) u_gc (
//     .clk(wr_clk), .rst_n(rst_n), .ptr(wr_ptr_gray));
// =============================================================================
module sva_gray_check #(
  parameter int WIDTH = 4
)(
  input logic             clk,
  input logic             rst_n,
  input logic [WIDTH-1:0] ptr
);
  // At most one bit must change between consecutive cycles.
  // XOR of consecutive values has at most one bit set → $countones ≤ 1.
  ap_gray_transition: assert property (
    @(posedge clk) disable iff (!rst_n)
    $countones(ptr ^ $past(ptr)) <= 1
  ) else $error("[GRAY] ptr %0b → %0b : >1-bit change — CDC hazard!", $past(ptr), ptr);

  // Prove a full wrap-around is reachable (all-zeros seen twice).
  cp_full_traverse: cover property (
    @(posedge clk) (ptr == '0) ##[1:2**WIDTH] (ptr == '0)
  );
endmodule


// =============================================================================
// SECTION 3 — AXI-STREAM HANDSHAKE CHECKER  (bindable module)
//
// Bind to any valid/ready interface pair for instant protocol compliance
// checking without modifying the DUT.
//
// Formal reasoning:
//   The AXI-stream spec §2.2.1 states:
//   1. Once TVALID is asserted it must stay asserted until TREADY is seen.
//   2. TDATA must not change while TVALID is held before the handshake.
//   3. A valid sender must not stall indefinitely (liveness, bounded by MAX_WAIT).
//
// Example bind:
//   bind my_dma sva_handshake_check #(.DATA_W(64), .MAX_WAIT(16)) u_hs (
//     .clk(clk), .rst_n(rst_n),
//     .valid(m_axis_tvalid), .ready(m_axis_tready), .data(m_axis_tdata));
// =============================================================================
module sva_handshake_check #(
  parameter int DATA_W   = 8,
  parameter int MAX_WAIT = 32    // Formal-friendly stall timeout (finite bound)
)(
  input logic              clk,
  input logic              rst_n,
  input logic              valid,
  input logic              ready,
  input logic [DATA_W-1:0] data
);
  // ---- SAFETY: valid must persist until ready ----
  // Formal reasoning: a source that drops valid before ready leaves the
  // receiver in a permanently stalled state — a protocol-level livelock.
  ap_valid_no_drop: assert property (
    @(posedge clk) disable iff (!rst_n)
    (valid && !ready) |=> valid
  ) else $error("[HS:P1] valid deasserted before ready — AXI-stream violation");

  // ---- SAFETY: data stable while valid && !ready ----
  // Formal reasoning: the receiver may sample data on ANY cycle where ready
  // is high. Data that changes between valid assertion and the handshake
  // makes the transferred value non-deterministic.
  ap_data_stable: assert property (
    @(posedge clk) disable iff (!rst_n)
    (valid && !ready) |=> $stable(data)
  ) else $error("[HS:P2] data changed during a pending handshake — data corruption");

  // ---- LIVENESS: valid must be acknowledged within MAX_WAIT cycles ----
  // Formal reasoning: an unanswered valid represents a protocol deadlock.
  // Bounding to MAX_WAIT ensures the property is finitely checkable by BMC.
  ap_ready_bounded: assert property (
    @(posedge clk) disable iff (!rst_n)
    valid |-> ##[0:MAX_WAIT] ready
  ) else $error("[HS:L1] valid stalled >%0d cycles — potential deadlock", MAX_WAIT);

  // ---- COVER: single-cycle (zero back-pressure) handshake ----
  cp_fast_handshake: cover property (@(posedge clk) valid && ready);

  // ---- COVER: back-pressure scenario (valid waits for ready) ----
  cp_backpressure: cover property (
    @(posedge clk) (valid && !ready) ##[1:MAX_WAIT] (valid && ready)
  );
endmodule

`endif // SVA_ASSERTION_LIB_SV
