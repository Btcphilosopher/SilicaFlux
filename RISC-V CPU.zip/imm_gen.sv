// =============================================================================
// imm_gen.sv  —  Immediate Value Generator
// Reconstructs and sign-extends all five RV32I immediate formats
// Target : Icarus Verilog 12  (-g2012)
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

import rv32i_pkg::*;

module imm_gen (
  input  logic [31:0] instr,     // Full 32-bit instruction word
  input  logic [2:0]  imm_sel,   // Format select (IMM_I/S/B/U/J)
  output logic [31:0] imm_out    // Sign-extended immediate
);

  always_comb begin : proc_imm
    case (imm_sel)
      //  I-type: [31:20] sign-extended
      IMM_I : imm_out = {{20{instr[31]}}, instr[31:20]};

      //  S-type: [31:25] | [11:7] sign-extended (stores)
      IMM_S : imm_out = {{20{instr[31]}}, instr[31:25], instr[11:7]};

      //  B-type: PC-relative branch — bit shuffle, bit 0 always 0
      //           [12|10:5] in upper, [4:1|11] in lower
      IMM_B : imm_out = {{19{instr[31]}}, instr[31], instr[7],
                         instr[30:25], instr[11:8], 1'b0};

      //  U-type: upper 20 bits, lower 12 zero (LUI / AUIPC)
      IMM_U : imm_out = {instr[31:12], 12'b0};

      //  J-type: PC-relative jump — bit shuffle, bit 0 always 0
      //           [20|10:1|11|19:12]
      IMM_J : imm_out = {{11{instr[31]}}, instr[31], instr[19:12],
                         instr[20], instr[30:21], 1'b0};

      default : imm_out = 32'b0;
    endcase
  end

endmodule
