// =============================================================================
// rv32i_pkg.sv  —  Package: opcodes, ALU codes, control encodings
// Target : Icarus Verilog 12  (-g2012)
// =============================================================================
package rv32i_pkg;

  // ── RV32I Base Opcodes ──────────────────────────────────────────────────────
  localparam logic [6:0] OPCODE_LOAD    = 7'b000_0011;
  localparam logic [6:0] OPCODE_STORE   = 7'b010_0011;
  localparam logic [6:0] OPCODE_BRANCH  = 7'b110_0011;
  localparam logic [6:0] OPCODE_JALR    = 7'b110_0111;
  localparam logic [6:0] OPCODE_JAL     = 7'b110_1111;
  localparam logic [6:0] OPCODE_AUIPC   = 7'b001_0111;
  localparam logic [6:0] OPCODE_LUI     = 7'b011_0111;
  localparam logic [6:0] OPCODE_OP_IMM  = 7'b001_0011;
  localparam logic [6:0] OPCODE_OP_REG  = 7'b011_0011;
  localparam logic [6:0] OPCODE_SYSTEM  = 7'b111_0011;

  // ── ALU Operation Codes ─────────────────────────────────────────────────────
  localparam logic [3:0] ALU_ADD  = 4'd0;
  localparam logic [3:0] ALU_SUB  = 4'd1;
  localparam logic [3:0] ALU_AND  = 4'd2;
  localparam logic [3:0] ALU_OR   = 4'd3;
  localparam logic [3:0] ALU_XOR  = 4'd4;
  localparam logic [3:0] ALU_SLL  = 4'd5;
  localparam logic [3:0] ALU_SRL  = 4'd6;
  localparam logic [3:0] ALU_SRA  = 4'd7;
  localparam logic [3:0] ALU_SLT  = 4'd8;
  localparam logic [3:0] ALU_SLTU = 4'd9;
  localparam logic [3:0] ALU_PASS = 4'd10;   // Pass operand B (LUI)

  // ── Immediate Format Select ─────────────────────────────────────────────────
  localparam logic [2:0] IMM_I = 3'd0;   // sign-ext 12-bit
  localparam logic [2:0] IMM_S = 3'd1;   // sign-ext 12-bit split (stores)
  localparam logic [2:0] IMM_B = 3'd2;   // sign-ext 13-bit PC-rel (branches)
  localparam logic [2:0] IMM_U = 3'd3;   // upper 20-bit (LUI / AUIPC)
  localparam logic [2:0] IMM_J = 3'd4;   // sign-ext 21-bit PC-rel (JAL)

  // ── ALU Operand-A Source ────────────────────────────────────────────────────
  localparam logic [1:0] ALUA_RS1  = 2'd0;   // Register rs1
  localparam logic [1:0] ALUA_PC   = 2'd1;   // Program counter (AUIPC / JAL)
  localparam logic [1:0] ALUA_ZERO = 2'd2;   // Constant zero  (LUI)

  // ── ALU Operand-B Source ────────────────────────────────────────────────────
  localparam logic ALUB_RS2 = 1'b0;
  localparam logic ALUB_IMM = 1'b1;

  // ── Write-Back Data Source ──────────────────────────────────────────────────
  localparam logic [1:0] WB_ALU = 2'd0;   // ALU result
  localparam logic [1:0] WB_MEM = 2'd1;   // Memory read
  localparam logic [1:0] WB_PC4 = 2'd2;   // PC+4 link address (JAL/JALR)

  // ── Branch funct3 ───────────────────────────────────────────────────────────
  localparam logic [2:0] FUNCT3_BEQ  = 3'b000;
  localparam logic [2:0] FUNCT3_BNE  = 3'b001;
  localparam logic [2:0] FUNCT3_BLT  = 3'b100;
  localparam logic [2:0] FUNCT3_BGE  = 3'b101;
  localparam logic [2:0] FUNCT3_BLTU = 3'b110;
  localparam logic [2:0] FUNCT3_BGEU = 3'b111;

  // ── Load funct3 ─────────────────────────────────────────────────────────────
  localparam logic [2:0] FUNCT3_LB   = 3'b000;
  localparam logic [2:0] FUNCT3_LH   = 3'b001;
  localparam logic [2:0] FUNCT3_LW   = 3'b010;
  localparam logic [2:0] FUNCT3_LBU  = 3'b100;
  localparam logic [2:0] FUNCT3_LHU  = 3'b101;

endpackage
