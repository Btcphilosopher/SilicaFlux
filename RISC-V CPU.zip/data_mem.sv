// =============================================================================
// data_mem.sv  —  Byte-Addressable Data Memory
// Supports byte / halfword / word loads and stores.
// Synchronous write, asynchronous read (standard for single-cycle / pipeline).
// Target : Icarus Verilog 12  (-g2012)
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

import rv32i_pkg::*;

module data_mem #(
  parameter integer MEM_DEPTH = 4096   // Bytes
) (
  input  logic        clk,
  input  logic [31:0] addr,        // Byte address
  input  logic [31:0] wr_data,     // Data to write
  input  logic        mem_read,    // Load enable
  input  logic        mem_write,   // Store enable
  input  logic [2:0]  funct3,      // Access width / sign
  output logic [31:0] rd_data      // Load result
);

  logic [7:0] mem [0:MEM_DEPTH-1];

  integer j;

  initial begin
    for (j = 0; j < MEM_DEPTH; j = j + 1)
      mem[j] = 8'h00;
  end

  // ── Synchronous Write ─────────────────────────────────────────────────────
  always_ff @(posedge clk) begin
    if (mem_write) begin
      case (funct3[1:0])
        2'b00 : begin   // SB — byte
          mem[addr] <= wr_data[7:0];
        end
        2'b01 : begin   // SH — halfword (little-endian)
          mem[addr    ] <= wr_data[7:0];
          mem[addr + 1] <= wr_data[15:8];
        end
        2'b10 : begin   // SW — word (little-endian)
          mem[addr    ] <= wr_data[7:0];
          mem[addr + 1] <= wr_data[15:8];
          mem[addr + 2] <= wr_data[23:16];
          mem[addr + 3] <= wr_data[31:24];
        end
        default: ; // no-op
      endcase
    end
  end

  // ── Asynchronous Read ─────────────────────────────────────────────────────
  always_comb begin : proc_read
    rd_data = 32'b0;
    if (mem_read) begin
      case (funct3)
        FUNCT3_LB  : rd_data = {{24{mem[addr][7]}},   mem[addr]};
        FUNCT3_LH  : rd_data = {{16{mem[addr+1][7]}}, mem[addr+1], mem[addr]};
        FUNCT3_LW  : rd_data = {mem[addr+3], mem[addr+2], mem[addr+1], mem[addr]};
        FUNCT3_LBU : rd_data = {24'b0, mem[addr]};
        FUNCT3_LHU : rd_data = {16'b0, mem[addr+1], mem[addr]};
        default    : rd_data = 32'b0;
      endcase
    end
  end

endmodule
