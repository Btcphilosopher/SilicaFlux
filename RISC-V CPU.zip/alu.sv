// =============================================================================
// alu.sv  —  32-bit Arithmetic Logic Unit
// Implements all RV32I computational operations
// Target : Icarus Verilog 12  (-g2012)
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

import rv32i_pkg::*;

module alu (
  input  logic [31:0] a,        // Operand A
  input  logic [31:0] b,        // Operand B
  input  logic [3:0]  alu_op,   // Operation select
  output logic [31:0] result,   // Result
  output logic        zero      // Zero flag  (result == 0)
);

  always_comb begin : proc_alu
    case (alu_op)
      ALU_ADD  : result = a + b;
      ALU_SUB  : result = a - b;
      ALU_AND  : result = a & b;
      ALU_OR   : result = a | b;
      ALU_XOR  : result = a ^ b;
      ALU_SLL  : result = a << b[4:0];
      ALU_SRL  : result = a >> b[4:0];
      ALU_SRA  : result = $signed(a) >>> b[4:0];
      ALU_SLT  : result = {31'b0, ($signed(a) < $signed(b))};
      ALU_SLTU : result = {31'b0, (a < b)};
      ALU_PASS : result = b;            // Passthrough for LUI
      default  : result = 32'b0;
    endcase
  end

  assign zero = (result == 32'b0);

endmodule
