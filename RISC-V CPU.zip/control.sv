// =============================================================================
// control.sv  —  Main Control Unit
// Decodes the 7-bit opcode into all pipeline control signals.
// Does NOT decode funct3/funct7; that is delegated to alu_control.sv.
// Target : Icarus Verilog 12  (-g2012)
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

import rv32i_pkg::*;

module control (
  input  logic [6:0]  opcode,
  // Immediate / ALU source
  output logic [2:0]  imm_sel,
  output logic [1:0]  alu_a_sel,  // rs1 / PC / zero
  output logic        alu_b_sel,  // rs2 / imm
  // Register file
  output logic        reg_write,
  // Memory
  output logic        mem_read,
  output logic        mem_write,
  // Write-back mux
  output logic [1:0]  wb_sel,
  // Jump / branch type indicators
  output logic        is_branch,
  output logic        is_jal,
  output logic        is_jalr
);

  always_comb begin : proc_ctrl
    // Safe defaults — equivalent to a NOP bubble
    imm_sel    = IMM_I;
    alu_a_sel  = ALUA_RS1;
    alu_b_sel  = ALUB_RS2;
    reg_write  = 1'b0;
    mem_read   = 1'b0;
    mem_write  = 1'b0;
    wb_sel     = WB_ALU;
    is_branch  = 1'b0;
    is_jal     = 1'b0;
    is_jalr    = 1'b0;

    case (opcode)
      // ── R-type (ADD SUB AND OR XOR SLL SRL SRA SLT SLTU) ─────────────────
      OPCODE_OP_REG: begin
        alu_a_sel = ALUA_RS1;
        alu_b_sel = ALUB_RS2;
        reg_write = 1'b1;
        wb_sel    = WB_ALU;
      end

      // ── I-type ALU (ADDI SLTI SLTIU XORI ORI ANDI SLLI SRLI SRAI) ────────
      OPCODE_OP_IMM: begin
        imm_sel   = IMM_I;
        alu_a_sel = ALUA_RS1;
        alu_b_sel = ALUB_IMM;
        reg_write = 1'b1;
        wb_sel    = WB_ALU;
      end

      // ── Loads (LB LH LW LBU LHU) ─────────────────────────────────────────
      OPCODE_LOAD: begin
        imm_sel   = IMM_I;
        alu_a_sel = ALUA_RS1;
        alu_b_sel = ALUB_IMM;
        reg_write = 1'b1;
        mem_read  = 1'b1;
        wb_sel    = WB_MEM;
      end

      // ── Stores (SB SH SW) ─────────────────────────────────────────────────
      OPCODE_STORE: begin
        imm_sel   = IMM_S;
        alu_a_sel = ALUA_RS1;
        alu_b_sel = ALUB_IMM;
        mem_write = 1'b1;
      end

      // ── Branches (BEQ BNE BLT BGE BLTU BGEU) ─────────────────────────────
      OPCODE_BRANCH: begin
        imm_sel   = IMM_B;
        alu_a_sel = ALUA_RS1;
        alu_b_sel = ALUB_RS2;   // ALU compares rs1 op rs2
        is_branch = 1'b1;
      end

      // ── LUI ───────────────────────────────────────────────────────────────
      OPCODE_LUI: begin
        imm_sel   = IMM_U;
        alu_a_sel = ALUA_ZERO;  // 0 + imm → imm
        alu_b_sel = ALUB_IMM;
        reg_write = 1'b1;
        wb_sel    = WB_ALU;
      end

      // ── AUIPC ─────────────────────────────────────────────────────────────
      OPCODE_AUIPC: begin
        imm_sel   = IMM_U;
        alu_a_sel = ALUA_PC;    // PC + imm
        alu_b_sel = ALUB_IMM;
        reg_write = 1'b1;
        wb_sel    = WB_ALU;
      end

      // ── JAL ───────────────────────────────────────────────────────────────
      OPCODE_JAL: begin
        imm_sel   = IMM_J;
        alu_a_sel = ALUA_PC;
        alu_b_sel = ALUB_IMM;
        reg_write = 1'b1;
        wb_sel    = WB_PC4;     // rd = PC+4 (link)
        is_jal    = 1'b1;
      end

      // ── JALR ──────────────────────────────────────────────────────────────
      OPCODE_JALR: begin
        imm_sel   = IMM_I;
        alu_a_sel = ALUA_RS1;   // target = rs1 + imm, LSB cleared
        alu_b_sel = ALUB_IMM;
        reg_write = 1'b1;
        wb_sel    = WB_PC4;
        is_jalr   = 1'b1;
      end

      default: ; // NOP / unimplemented — all signals remain at safe defaults
    endcase
  end

endmodule
