// =============================================================================
// regfile.sv  —  32 × 32 Integer Register File
//
// * x0 hardwired to zero
// * Synchronous write, asynchronous read
// * Internal write-first bypass: if WB writes a reg while ID reads it in the
//   same cycle, the bypass returns the write data — eliminating the MEM/WB→EX
//   forwarding gap for the 2-cycle-distance hazard case.
// Target : Icarus Verilog 12  (-g2012)
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module regfile (
  input  logic        clk,
  input  logic        rst_n,
  // Read ports (ID stage)
  input  logic [4:0]  rs1_addr,
  input  logic [4:0]  rs2_addr,
  output logic [31:0] rs1_data,
  output logic [31:0] rs2_data,
  // Write port (WB stage)
  input  logic        we,
  input  logic [4:0]  rd_addr,
  input  logic [31:0] rd_data
);

  logic [31:0] regs [0:31];

  integer i;

  // Synchronous write (x0 is never overwritten)
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (i = 0; i < 32; i = i + 1)
        regs[i] <= 32'b0;
    end else if (we && (rd_addr != 5'b0)) begin
      regs[rd_addr] <= rd_data;
    end
  end

  // Asynchronous read with write-first bypass and x0 hardwired to zero.
  // Bypass ensures the ID stage sees a value written in the same cycle (WB
  // completing while this instruction is in ID), removing a latency class.
  assign rs1_data = (rs1_addr == 5'b0)                          ? 32'b0
                  : (we && rd_addr == rs1_addr && rd_addr != 5'b0) ? rd_data
                  :                                                 regs[rs1_addr];

  assign rs2_data = (rs2_addr == 5'b0)                          ? 32'b0
                  : (we && rd_addr == rs2_addr && rd_addr != 5'b0) ? rd_data
                  :                                                 regs[rs2_addr];

endmodule
