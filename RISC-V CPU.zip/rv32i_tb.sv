// =============================================================================
// rv32i_tb.sv  —  Testbench for rv32i_core
// =============================================================================
//
//  Test program (assembled below in program.hex)
//  ─────────────────────────────────────────────
//  0x00  ADDI x1,  x0, 5       ; x1  = 5
//  0x04  ADDI x2,  x0, 3       ; x2  = 3
//  0x08  ADD  x3,  x1, x2      ; x3  = 8    (EX/MEM fwd on x2, MEM/WB on x1)
//  0x0C  SUB  x4,  x1, x2      ; x4  = 2    (bypass / fwd on x1 and x2)
//  0x10  AND  x5,  x1, x2      ; x5  = 1
//  0x14  OR   x6,  x1, x2      ; x6  = 7
//  0x18  XOR  x7,  x1, x2      ; x7  = 6
//  0x1C  SLL  x8,  x1, x2      ; x8  = 40  (5 << 3)
//  0x20  SRL  x9,  x8, x2      ; x9  = 5   (40 >> 3)  — EX/MEM fwd on x8
//  0x24  SLLI x10, x1, 2       ; x10 = 20
//  0x28  SW   x3,  0(x0)       ; mem[0]=8
//  0x2C  LW   x11, 0(x0)       ; x11 = 8   — load-use stall exercised
//  0x30  SLTI x12, x1, 10      ; x12 = 1
//  0x34  BEQ  x1,  x2, 8       ; NOT taken (5 ≠ 3) — branch not-taken path
//  0x38  ADDI x13, x0, 10      ; x13 = 10  — executes (branch not taken)
//  0x3C  BEQ  x1,  x1, 8       ; TAKEN  (5 == 5) → PC = 0x44
//  0x40  ADDI x14, x0, 99      ; SKIPPED (x14 must remain 0)
//  0x44  ADDI x15, x0, 42      ; x15 = 42
//  0x48  JAL  x0,  0           ; halt (infinite self-loop)
//
//  Expected final registers:
//  x1=5  x2=3  x3=8   x4=2  x5=1   x6=7  x7=6
//  x8=40 x9=5  x10=20 x11=8 x12=1  x13=10 x14=0 x15=42
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module rv32i_tb;

  localparam CLK_HALF  = 5;     // 10 ns clock period
  localparam SIM_CYCLES = 200;  // Enough for all instructions to complete

  // ── DUT signals ──────────────────────────────────────────────────────────────
  logic clk, rst_n;

  rv32i_core dut (
    .clk   (clk),
    .rst_n (rst_n)
  );

  // ── Clock ────────────────────────────────────────────────────────────────────
  initial clk = 1'b0;
  always  #CLK_HALF clk = ~clk;

  // ── Pipeline monitor task ─────────────────────────────────────────────────────
  task automatic print_pipeline_state;
    $display("  %-6s PC=%08h  INSTR=%08h  WB_rd=x%-2d  WB_data=%08h  we=%b",
             "CYCLE", dut.pc_reg,
             dut.if_id_instr,
             dut.mem_wb_rd,
             dut.wb_result,
             dut.mem_wb_reg_write);
  endtask

  // ── Stimulus ──────────────────────────────────────────────────────────────────
  integer cyc;
  integer pass;

  initial begin
    $dumpfile("rv32i.vcd");
    $dumpvars(0, rv32i_tb);

    $display("");
    $display("╔══════════════════════════════════════════════════════╗");
    $display("║       RV32I 5-Stage Pipeline — Simulation Start      ║");
    $display("╚══════════════════════════════════════════════════════╝");

    // ── Reset ────────────────────────────────────────────────────────────────
    rst_n = 1'b0;
    repeat (4) @(posedge clk);
    @(negedge clk);    // Release reset on a negedge for clean setup
    rst_n = 1'b1;
    $display("[RST]  Reset released at time %0t ns", $time);

    // ── Run ──────────────────────────────────────────────────────────────────
    $display("[RUN]  Executing %0d cycles …", SIM_CYCLES);
    for (cyc = 0; cyc < SIM_CYCLES; cyc = cyc + 1) begin
      @(posedge clk);
      #1;   // Let combinational signals settle after posedge

      // Optional per-cycle trace (comment out for quiet run)
      if (cyc < 60)
        $display("  [%03d] pc=%08h  if_id=%08h  id_ex_rd=x%02d  ex_mem_rd=x%02d  wb_rd=x%02d  wb=%08h",
                 cyc, dut.pc_reg, dut.if_id_instr,
                 dut.id_ex_rd, dut.ex_mem_rd,
                 dut.mem_wb_rd, dut.wb_result);
    end

    // ── Check registers ───────────────────────────────────────────────────────
    $display("");
    $display("╔══════════════════════════════════════════════════════╗");
    $display("║               Final Register File Dump               ║");
    $display("╠══════════════════════════════════════════════════════╣");
    $display("║  x0  (zero)= %-10d                             ║", dut.u_regfile.regs[0]);
    $display("║  x1  (ra)  = %-10d  expected 5                ║", dut.u_regfile.regs[1]);
    $display("║  x2  (sp)  = %-10d  expected 3                ║", dut.u_regfile.regs[2]);
    $display("║  x3  (gp)  = %-10d  expected 8  (ADD)         ║", dut.u_regfile.regs[3]);
    $display("║  x4  (tp)  = %-10d  expected 2  (SUB)         ║", dut.u_regfile.regs[4]);
    $display("║  x5  (t0)  = %-10d  expected 1  (AND)         ║", dut.u_regfile.regs[5]);
    $display("║  x6  (t1)  = %-10d  expected 7  (OR)          ║", dut.u_regfile.regs[6]);
    $display("║  x7  (t2)  = %-10d  expected 6  (XOR)         ║", dut.u_regfile.regs[7]);
    $display("║  x8  (s0)  = %-10d  expected 40 (SLL 3)       ║", dut.u_regfile.regs[8]);
    $display("║  x9  (s1)  = %-10d  expected 5  (SRL 3)       ║", dut.u_regfile.regs[9]);
    $display("║  x10 (a0)  = %-10d  expected 20 (SLLI 2)      ║", dut.u_regfile.regs[10]);
    $display("║  x11 (a1)  = %-10d  expected 8  (LW via SW)   ║", dut.u_regfile.regs[11]);
    $display("║  x12 (a2)  = %-10d  expected 1  (SLTI 10)     ║", dut.u_regfile.regs[12]);
    $display("║  x13 (a3)  = %-10d  expected 10 (branch NT)   ║", dut.u_regfile.regs[13]);
    $display("║  x14 (a4)  = %-10d  expected 0  (skipped)     ║", dut.u_regfile.regs[14]);
    $display("║  x15 (a5)  = %-10d  expected 42               ║", dut.u_regfile.regs[15]);
    $display("╠══════════════════════════════════════════════════════╣");

    // ── Data memory spot-check ────────────────────────────────────────────────
    $display("║  dmem[0]   = %-10d  expected 8  (SW x3)       ║",
             {dut.u_dmem.mem[3], dut.u_dmem.mem[2],
              dut.u_dmem.mem[1], dut.u_dmem.mem[0]});
    $display("╠══════════════════════════════════════════════════════╣");

    // ── Pass / Fail ───────────────────────────────────────────────────────────
    pass = 1;
    if (dut.u_regfile.regs[1]  !== 32'd5 ) begin $display("║  FAIL x1  : got %0d", dut.u_regfile.regs[1] ); pass=0; end
    if (dut.u_regfile.regs[2]  !== 32'd3 ) begin $display("║  FAIL x2  : got %0d", dut.u_regfile.regs[2] ); pass=0; end
    if (dut.u_regfile.regs[3]  !== 32'd8 ) begin $display("║  FAIL x3  : got %0d", dut.u_regfile.regs[3] ); pass=0; end
    if (dut.u_regfile.regs[4]  !== 32'd2 ) begin $display("║  FAIL x4  : got %0d", dut.u_regfile.regs[4] ); pass=0; end
    if (dut.u_regfile.regs[5]  !== 32'd1 ) begin $display("║  FAIL x5  : got %0d", dut.u_regfile.regs[5] ); pass=0; end
    if (dut.u_regfile.regs[6]  !== 32'd7 ) begin $display("║  FAIL x6  : got %0d", dut.u_regfile.regs[6] ); pass=0; end
    if (dut.u_regfile.regs[7]  !== 32'd6 ) begin $display("║  FAIL x7  : got %0d", dut.u_regfile.regs[7] ); pass=0; end
    if (dut.u_regfile.regs[8]  !== 32'd40) begin $display("║  FAIL x8  : got %0d", dut.u_regfile.regs[8] ); pass=0; end
    if (dut.u_regfile.regs[9]  !== 32'd5 ) begin $display("║  FAIL x9  : got %0d", dut.u_regfile.regs[9] ); pass=0; end
    if (dut.u_regfile.regs[10] !== 32'd20) begin $display("║  FAIL x10 : got %0d", dut.u_regfile.regs[10]); pass=0; end
    if (dut.u_regfile.regs[11] !== 32'd8 ) begin $display("║  FAIL x11 : got %0d", dut.u_regfile.regs[11]); pass=0; end
    if (dut.u_regfile.regs[12] !== 32'd1 ) begin $display("║  FAIL x12 : got %0d", dut.u_regfile.regs[12]); pass=0; end
    if (dut.u_regfile.regs[13] !== 32'd10) begin $display("║  FAIL x13 : got %0d", dut.u_regfile.regs[13]); pass=0; end
    if (dut.u_regfile.regs[14] !== 32'd0 ) begin $display("║  FAIL x14 : got %0d", dut.u_regfile.regs[14]); pass=0; end
    if (dut.u_regfile.regs[15] !== 32'd42) begin $display("║  FAIL x15 : got %0d", dut.u_regfile.regs[15]); pass=0; end

    if (pass)
      $display("║  *** ALL CHECKS PASSED — PIPELINE CORRECT ***        ║");
    else
      $display("║  *** FAILURES DETECTED — check pipeline trace ***     ║");

    $display("╚══════════════════════════════════════════════════════╝");
    $finish;
  end

endmodule
