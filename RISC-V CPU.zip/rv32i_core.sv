// =============================================================================
// rv32i_core.sv  —  5-Stage Pipelined RV32I CPU Core  (top-level)
// =============================================================================
//
//  Pipeline stages
//  ───────────────
//   IF   Instruction Fetch      — read IMEM, advance PC
//   ID   Instruction Decode     — register read, immediate gen, control decode
//   EX   Execute                — ALU, branch evaluation, address compute
//   MEM  Memory Access          — load / store via DMEM
//   WB   Write-Back             — select result, write register file
//
//  Hazard mitigation
//  ─────────────────
//   ● Full forwarding  EX/MEM→EX  (fwd_a/b=10)
//   ● Full forwarding  MEM/WB→EX  (fwd_a/b=01) + regfile write-first bypass
//   ● Load-use stall   (1 cycle)  when load result is needed by next instr
//   ● Branch/JAL/JALR flush       (2-cycle penalty, resolved in EX stage)
//
//  Extension notes
//  ───────────────
//   To add RV32M: extend alu_control with mul/div opcodes and add a multi-
//     cycle multiplier unit between EX and MEM with a ready/stall handshake.
//   To add interrupts: add a CSR file and trap controller that inject a MRET/
//     ECALL flush and redirect the PC to mtvec.
//
// Target : Icarus Verilog 12  (-g2012)
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

import rv32i_pkg::*;

module rv32i_core (
  input logic clk,
  input logic rst_n
);

  // ===========================================================================
  // ██  SIGNAL DECLARATIONS
  // ===========================================================================

  // ── PC ──────────────────────────────────────────────────────────────────────
  logic [31:0] pc_reg;
  logic [31:0] pc_next;

  // ── IF outputs ──────────────────────────────────────────────────────────────
  logic [31:0] if_instr;

  // ── IF/ID pipeline register ──────────────────────────────────────────────────
  logic [31:0] if_id_pc;
  logic [31:0] if_id_instr;

  // ── ID: instruction field wires ──────────────────────────────────────────────
  logic [6:0]  id_opcode;
  logic [4:0]  id_rd;
  logic [2:0]  id_funct3;
  logic [4:0]  id_rs1;
  logic [4:0]  id_rs2;
  logic [6:0]  id_funct7;

  // ── ID: datapath outputs ─────────────────────────────────────────────────────
  logic [31:0] id_rs1_data, id_rs2_data;
  logic [31:0] id_imm;

  // ── ID: control signals ──────────────────────────────────────────────────────
  logic [2:0]  id_imm_sel;
  logic [1:0]  id_alu_a_sel;
  logic        id_alu_b_sel;
  logic        id_reg_write;
  logic        id_mem_read;
  logic        id_mem_write;
  logic [1:0]  id_wb_sel;
  logic        id_is_branch;
  logic        id_is_jal;
  logic        id_is_jalr;
  logic [3:0]  id_alu_op;

  // ── ID/EX pipeline register ──────────────────────────────────────────────────
  logic [31:0] id_ex_pc;
  logic [31:0] id_ex_rs1_data, id_ex_rs2_data;
  logic [31:0] id_ex_imm;
  logic [4:0]  id_ex_rd;
  logic [4:0]  id_ex_rs1,  id_ex_rs2;
  logic [2:0]  id_ex_funct3;
  logic [3:0]  id_ex_alu_op;
  logic [1:0]  id_ex_alu_a_sel;
  logic        id_ex_alu_b_sel;
  logic        id_ex_reg_write;
  logic        id_ex_mem_read;
  logic        id_ex_mem_write;
  logic [1:0]  id_ex_wb_sel;
  logic        id_ex_is_branch;
  logic        id_ex_is_jal;
  logic        id_ex_is_jalr;

  // ── EX: forwarding + ALU ────────────────────────────────────────────────────
  logic [1:0]  fwd_a, fwd_b;
  logic [31:0] ex_rs1_fwd, ex_rs2_fwd;
  logic [31:0] ex_alu_a,   ex_alu_b;
  logic [31:0] ex_alu_result;
  logic        ex_zero;

  // ── EX: branch / jump ────────────────────────────────────────────────────────
  logic        ex_branch_cond;
  logic [31:0] ex_branch_target;   // PC + imm_b/j
  logic [31:0] ex_jalr_target;     // (rs1 + imm_i) & ~1
  logic [31:0] ex_pc_plus4;
  logic [31:0] branch_target;      // → PC mux
  logic        branch_taken;       // → hazard unit + PC mux

  // ── EX/MEM pipeline register ─────────────────────────────────────────────────
  logic [31:0] ex_mem_pc_plus4;
  logic [31:0] ex_mem_alu_result;
  logic [31:0] ex_mem_rs2_data;
  logic [4:0]  ex_mem_rd;
  logic [2:0]  ex_mem_funct3;
  logic        ex_mem_reg_write;
  logic        ex_mem_mem_read;
  logic        ex_mem_mem_write;
  logic [1:0]  ex_mem_wb_sel;

  // ── MEM: data read ────────────────────────────────────────────────────────────
  logic [31:0] mem_rd_data;

  // ── MEM/WB pipeline register ─────────────────────────────────────────────────
  logic [31:0] mem_wb_alu_result;
  logic [31:0] mem_wb_mem_rd_data;
  logic [31:0] mem_wb_pc_plus4;
  logic [4:0]  mem_wb_rd;
  logic        mem_wb_reg_write;
  logic [1:0]  mem_wb_wb_sel;

  // ── WB: result ───────────────────────────────────────────────────────────────
  logic [31:0] wb_result;

  // ── Hazard / stall / flush ───────────────────────────────────────────────────
  logic stall_if,      stall_id;
  logic flush_if_id,   flush_id_ex,   flush_id_ex_br;

  // ===========================================================================
  // ██  SUB-MODULE INSTANTIATIONS
  // ===========================================================================

  instr_mem #(.MEM_DEPTH(1024)) u_imem (
    .addr  (pc_reg),
    .instr (if_instr)
  );

  control u_ctrl (
    .opcode    (id_opcode),
    .imm_sel   (id_imm_sel),
    .alu_a_sel (id_alu_a_sel),
    .alu_b_sel (id_alu_b_sel),
    .reg_write (id_reg_write),
    .mem_read  (id_mem_read),
    .mem_write (id_mem_write),
    .wb_sel    (id_wb_sel),
    .is_branch (id_is_branch),
    .is_jal    (id_is_jal),
    .is_jalr   (id_is_jalr)
  );

  alu_control u_aluctrl (
    .opcode  (id_opcode),
    .funct3  (id_funct3),
    .funct7  (id_funct7),
    .alu_op  (id_alu_op)
  );

  imm_gen u_immgen (
    .instr   (if_id_instr),
    .imm_sel (id_imm_sel),
    .imm_out (id_imm)
  );

  // Register file — write port driven from WB stage
  regfile u_regfile (
    .clk     (clk),
    .rst_n   (rst_n),
    .rs1_addr(id_rs1),
    .rs2_addr(id_rs2),
    .rs1_data(id_rs1_data),
    .rs2_data(id_rs2_data),
    .we      (mem_wb_reg_write),
    .rd_addr (mem_wb_rd),
    .rd_data (wb_result)
  );

  alu u_alu (
    .a       (ex_alu_a),
    .b       (ex_alu_b),
    .alu_op  (id_ex_alu_op),
    .result  (ex_alu_result),
    .zero    (ex_zero)
  );

  data_mem #(.MEM_DEPTH(4096)) u_dmem (
    .clk      (clk),
    .addr     (ex_mem_alu_result),
    .wr_data  (ex_mem_rs2_data),
    .mem_read (ex_mem_mem_read),
    .mem_write(ex_mem_mem_write),
    .funct3   (ex_mem_funct3),
    .rd_data  (mem_rd_data)
  );

  hazard_unit u_hazard (
    .id_ex_rs1        (id_ex_rs1),
    .id_ex_rs2        (id_ex_rs2),
    .ex_mem_rd        (ex_mem_rd),
    .ex_mem_reg_write (ex_mem_reg_write),
    .mem_wb_rd        (mem_wb_rd),
    .mem_wb_reg_write (mem_wb_reg_write),
    .id_ex_rd         (id_ex_rd),
    .id_ex_mem_read   (id_ex_mem_read),
    .if_id_rs1        (id_rs1),
    .if_id_rs2        (id_rs2),
    .branch_taken     (branch_taken),
    .stall_if         (stall_if),
    .stall_id         (stall_id),
    .flush_id_ex      (flush_id_ex),
    .flush_if_id      (flush_if_id),
    .flush_id_ex_br   (flush_id_ex_br),
    .fwd_a            (fwd_a),
    .fwd_b            (fwd_b)
  );

  // ===========================================================================
  // ██  STAGE 1 — INSTRUCTION FETCH  (IF)
  // ===========================================================================

  // PC-next mux: branch/jump target or sequential PC+4
  assign pc_next = branch_taken ? branch_target : (pc_reg + 32'd4);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)
      pc_reg <= 32'h0000_0000;
    else if (!stall_if)
      pc_reg <= pc_next;
  end

  // IF/ID pipeline register
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      if_id_pc    <= 32'h0;
      if_id_instr <= 32'h0000_0013;   // NOP
    end else if (flush_if_id) begin
      if_id_pc    <= 32'h0;
      if_id_instr <= 32'h0000_0013;   // Bubble
    end else if (!stall_id) begin
      if_id_pc    <= pc_reg;
      if_id_instr <= if_instr;
    end
    // Stall: hold current value (implicit — no else branch)
  end

  // ===========================================================================
  // ██  STAGE 2 — INSTRUCTION DECODE  (ID)
  // ===========================================================================

  // Field extraction
  assign id_opcode = if_id_instr[6:0];
  assign id_rd     = if_id_instr[11:7];
  assign id_funct3 = if_id_instr[14:12];
  assign id_rs1    = if_id_instr[19:15];
  assign id_rs2    = if_id_instr[24:20];
  assign id_funct7 = if_id_instr[31:25];
  // (control / alu_control / imm_gen / regfile driven by above)

  // ID/EX pipeline register
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n || flush_id_ex || flush_id_ex_br) begin
      // ── Bubble ──────────────────────────────────────────────────────────
      id_ex_pc         <= 32'h0;
      id_ex_rs1_data   <= 32'h0;
      id_ex_rs2_data   <= 32'h0;
      id_ex_imm        <= 32'h0;
      id_ex_rd         <= 5'h0;
      id_ex_rs1        <= 5'h0;
      id_ex_rs2        <= 5'h0;
      id_ex_funct3     <= 3'h0;
      id_ex_alu_op     <= ALU_ADD;
      id_ex_alu_a_sel  <= ALUA_RS1;
      id_ex_alu_b_sel  <= ALUB_RS2;
      id_ex_reg_write  <= 1'b0;
      id_ex_mem_read   <= 1'b0;
      id_ex_mem_write  <= 1'b0;
      id_ex_wb_sel     <= WB_ALU;
      id_ex_is_branch  <= 1'b0;
      id_ex_is_jal     <= 1'b0;
      id_ex_is_jalr    <= 1'b0;
    end else begin
      // ── Normal latch ────────────────────────────────────────────────────
      id_ex_pc         <= if_id_pc;
      id_ex_rs1_data   <= id_rs1_data;
      id_ex_rs2_data   <= id_rs2_data;
      id_ex_imm        <= id_imm;
      id_ex_rd         <= id_rd;
      id_ex_rs1        <= id_rs1;
      id_ex_rs2        <= id_rs2;
      id_ex_funct3     <= id_funct3;
      id_ex_alu_op     <= id_alu_op;
      id_ex_alu_a_sel  <= id_alu_a_sel;
      id_ex_alu_b_sel  <= id_alu_b_sel;
      id_ex_reg_write  <= id_reg_write;
      id_ex_mem_read   <= id_mem_read;
      id_ex_mem_write  <= id_mem_write;
      id_ex_wb_sel     <= id_wb_sel;
      id_ex_is_branch  <= id_is_branch;
      id_ex_is_jal     <= id_is_jal;
      id_ex_is_jalr    <= id_is_jalr;
    end
  end

  // ===========================================================================
  // ██  STAGE 3 — EXECUTE  (EX)
  // ===========================================================================

  // Forwarding mux — operand A (rs1)
  always_comb begin : proc_fwd_mux_a
    case (fwd_a)
      2'b10   : ex_rs1_fwd = ex_mem_alu_result;   // EX/MEM
      2'b01   : ex_rs1_fwd = wb_result;            // MEM/WB
      default : ex_rs1_fwd = id_ex_rs1_data;       // Register file
    endcase
  end

  // Forwarding mux — operand B (rs2)
  always_comb begin : proc_fwd_mux_b
    case (fwd_b)
      2'b10   : ex_rs2_fwd = ex_mem_alu_result;
      2'b01   : ex_rs2_fwd = wb_result;
      default : ex_rs2_fwd = id_ex_rs2_data;
    endcase
  end

  // ALU operand-A mux (rs1 / PC / zero)
  always_comb begin : proc_alu_a_mux
    case (id_ex_alu_a_sel)
      ALUA_PC   : ex_alu_a = id_ex_pc;
      ALUA_ZERO : ex_alu_a = 32'h0;
      default   : ex_alu_a = ex_rs1_fwd;
    endcase
  end

  // ALU operand-B mux (rs2 / immediate)
  assign ex_alu_b = (id_ex_alu_b_sel == ALUB_IMM) ? id_ex_imm : ex_rs2_fwd;

  // Branch condition evaluation
  // BEQ/BNE  : ALU computed (rs1 − rs2), zero flag → equality test
  // BLT/BGE  : ALU computed SLT(rs1,rs2), result[0] → signed-less-than
  // BLTU/BGEU: ALU computed SLTU(rs1,rs2), result[0] → unsigned-less-than
  always_comb begin : proc_branch_cond
    case (id_ex_funct3)
      FUNCT3_BEQ  : ex_branch_cond =  ex_zero;
      FUNCT3_BNE  : ex_branch_cond = ~ex_zero;
      FUNCT3_BLT  : ex_branch_cond =  ex_alu_result[0];
      FUNCT3_BGE  : ex_branch_cond = ~ex_alu_result[0];
      FUNCT3_BLTU : ex_branch_cond =  ex_alu_result[0];
      FUNCT3_BGEU : ex_branch_cond = ~ex_alu_result[0];
      default     : ex_branch_cond = 1'b0;
    endcase
  end

  // Branch / JAL target:  PC + sign-extended-imm (B-type or J-type)
  assign ex_branch_target = id_ex_pc + id_ex_imm;

  // JALR target:  (rs1 + sign-ext-imm) with LSB cleared (per spec)
  assign ex_jalr_target   = (ex_rs1_fwd + id_ex_imm) & ~32'h1;

  // PC+4 — link address written to rd by JAL / JALR
  assign ex_pc_plus4 = id_ex_pc + 32'd4;

  // Branch taken / target mux
  assign branch_taken  = (id_ex_is_branch & ex_branch_cond)
                        | id_ex_is_jal
                        | id_ex_is_jalr;

  assign branch_target = id_ex_is_jalr ? ex_jalr_target : ex_branch_target;

  // EX/MEM pipeline register
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ex_mem_pc_plus4   <= 32'h0;
      ex_mem_alu_result <= 32'h0;
      ex_mem_rs2_data   <= 32'h0;
      ex_mem_rd         <= 5'h0;
      ex_mem_funct3     <= 3'h0;
      ex_mem_reg_write  <= 1'b0;
      ex_mem_mem_read   <= 1'b0;
      ex_mem_mem_write  <= 1'b0;
      ex_mem_wb_sel     <= WB_ALU;
    end else begin
      ex_mem_pc_plus4   <= ex_pc_plus4;
      ex_mem_alu_result <= ex_alu_result;
      ex_mem_rs2_data   <= ex_rs2_fwd;     // Forwarded store data
      ex_mem_rd         <= id_ex_rd;
      ex_mem_funct3     <= id_ex_funct3;
      ex_mem_reg_write  <= id_ex_reg_write;
      ex_mem_mem_read   <= id_ex_mem_read;
      ex_mem_mem_write  <= id_ex_mem_write;
      ex_mem_wb_sel     <= id_ex_wb_sel;
    end
  end

  // ===========================================================================
  // ██  STAGE 4 — MEMORY ACCESS  (MEM)
  // ===========================================================================
  // data_mem instantiated above drives mem_rd_data.

  // MEM/WB pipeline register
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mem_wb_alu_result  <= 32'h0;
      mem_wb_mem_rd_data <= 32'h0;
      mem_wb_pc_plus4    <= 32'h0;
      mem_wb_rd          <= 5'h0;
      mem_wb_reg_write   <= 1'b0;
      mem_wb_wb_sel      <= WB_ALU;
    end else begin
      mem_wb_alu_result  <= ex_mem_alu_result;
      mem_wb_mem_rd_data <= mem_rd_data;
      mem_wb_pc_plus4    <= ex_mem_pc_plus4;
      mem_wb_rd          <= ex_mem_rd;
      mem_wb_reg_write   <= ex_mem_reg_write;
      mem_wb_wb_sel      <= ex_mem_wb_sel;
    end
  end

  // ===========================================================================
  // ██  STAGE 5 — WRITE BACK  (WB)
  // ===========================================================================

  always_comb begin : proc_wb_mux
    case (mem_wb_wb_sel)
      WB_MEM  : wb_result = mem_wb_mem_rd_data;
      WB_PC4  : wb_result = mem_wb_pc_plus4;
      default : wb_result = mem_wb_alu_result;   // WB_ALU
    endcase
  end
  // wb_result → regfile.rd_data (instantiated above)
  // mem_wb_reg_write → regfile.we
  // mem_wb_rd        → regfile.rd_addr

endmodule
