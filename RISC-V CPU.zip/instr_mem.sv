// =============================================================================
// instr_mem.sv  —  Instruction Memory (synchronous ROM)
// Word-addressed: mem[addr[31:2]] → 32-bit instruction
// Initialised from program.hex via $readmemh
// Target : Icarus Verilog 12  (-g2012)
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module instr_mem #(
  parameter integer MEM_DEPTH = 1024   // Number of 32-bit words
) (
  input  logic [31:0] addr,    // Byte address (PC)
  output logic [31:0] instr    // Fetched 32-bit instruction
);

  logic [31:0] mem [0:MEM_DEPTH-1];

  integer k;

  initial begin : load_program
    // Pre-fill with NOPs so unwritten locations are safe
    for (k = 0; k < MEM_DEPTH; k = k + 1)
      mem[k] = 32'h0000_0013;    // ADDI x0, x0, 0 (NOP)
    $readmemh("program.hex", mem);
    $display("[IMEM] program.hex loaded — mem[0]=%h  mem[1]=%h  mem[2]=%h",
             mem[0], mem[1], mem[2]);
  end

  // Combinational (async) read — word-addressed
  assign instr = mem[addr[31:2]];

endmodule
