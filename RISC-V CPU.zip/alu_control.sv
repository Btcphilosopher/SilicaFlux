// =============================================================================
// alu_control.sv  —  ALU Control Unit
// Derives the 4-bit alu_op from opcode + funct3 + funct7[5]
// funct7[5] is the only funct7 bit that matters for RV32I (SUB / SRA).
// Target : Icarus Verilog 12  (-g2012)
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

import rv32i_pkg::*;

module alu_control (
  input  logic [6:0]  opcode,
  input  logic [2:0]  funct3,
  input  logic [6:0]  funct7,
  output logic [3:0]  alu_op
);

  always_comb begin : proc_alu_ctrl
    alu_op = ALU_ADD;   // safe default

    case (opcode)
      // ── R-type ─────────────────────────────────────────────────────────────
      OPCODE_OP_REG: begin
        case (funct3)
          3'b000 : alu_op = funct7[5] ? ALU_SUB : ALU_ADD; // ADD / SUB
          3'b001 : alu_op = ALU_SLL;
          3'b010 : alu_op = ALU_SLT;
          3'b011 : alu_op = ALU_SLTU;
          3'b100 : alu_op = ALU_XOR;
          3'b101 : alu_op = funct7[5] ? ALU_SRA : ALU_SRL; // SRL / SRA
          3'b110 : alu_op = ALU_OR;
          3'b111 : alu_op = ALU_AND;
          default: alu_op = ALU_ADD;
        endcase
      end

      // ── I-type ALU ─────────────────────────────────────────────────────────
      OPCODE_OP_IMM: begin
        case (funct3)
          3'b000 : alu_op = ALU_ADD;                        // ADDI
          3'b001 : alu_op = ALU_SLL;                        // SLLI
          3'b010 : alu_op = ALU_SLT;                        // SLTI
          3'b011 : alu_op = ALU_SLTU;                       // SLTIU
          3'b100 : alu_op = ALU_XOR;                        // XORI
          3'b101 : alu_op = funct7[5] ? ALU_SRA : ALU_SRL; // SRLI / SRAI
          3'b110 : alu_op = ALU_OR;                         // ORI
          3'b111 : alu_op = ALU_AND;                        // ANDI
          default: alu_op = ALU_ADD;
        endcase
      end

      // ── Loads / Stores / JALR — address = base + offset ───────────────────
      OPCODE_LOAD,
      OPCODE_STORE,
      OPCODE_JALR  : alu_op = ALU_ADD;

      // ── LUI — pass immediate unchanged ─────────────────────────────────────
      OPCODE_LUI   : alu_op = ALU_PASS;

      // ── AUIPC / JAL — PC + imm ─────────────────────────────────────────────
      OPCODE_AUIPC,
      OPCODE_JAL   : alu_op = ALU_ADD;

      // ── Branches — compare rs1 op rs2 ─────────────────────────────────────
      //   BEQ/BNE  → ALU_SUB  (zero flag tells equality)
      //   BLT/BGE  → ALU_SLT  (bit[0] is signed-less-than)
      //   BLTU/BGEU→ ALU_SLTU (bit[0] is unsigned-less-than)
      OPCODE_BRANCH: begin
        case (funct3)
          FUNCT3_BEQ,
          FUNCT3_BNE  : alu_op = ALU_SUB;
          FUNCT3_BLT,
          FUNCT3_BGE  : alu_op = ALU_SLT;
          FUNCT3_BLTU,
          FUNCT3_BGEU : alu_op = ALU_SLTU;
          default      : alu_op = ALU_SUB;
        endcase
      end

      default: alu_op = ALU_ADD;
    endcase
  end

endmodule
