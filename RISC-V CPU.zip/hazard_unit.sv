// =============================================================================
// hazard_unit.sv  —  Hazard Detection + Forwarding Unit
//
// Forwarding paths covered:
//   EX/MEM → EX  (fwd_a/b = 2'b10)  —  result 1 cycle old
//   MEM/WB → EX  (fwd_a/b = 2'b01)  —  result 2 cycles old
//   (regfile write-first bypass handles the 2-cycle case in simulation,
//    but the explicit MEM/WB path is kept for synthesis correctness)
//
// Stalls:
//   Load-use: load in EX, dependent instruction in ID → stall 1 cycle
//
// Flushes:
//   Branch/JAL/JALR taken → flush IF/ID and ID/EX (2-cycle penalty)
// Target : Icarus Verilog 12  (-g2012)
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module hazard_unit (
  // ── EX stage source registers (for forwarding) ───────────────────────────
  input  logic [4:0]  id_ex_rs1,
  input  logic [4:0]  id_ex_rs2,

  // ── EX/MEM register (1-cycle-old result) ────────────────────────────────
  input  logic [4:0]  ex_mem_rd,
  input  logic        ex_mem_reg_write,

  // ── MEM/WB register (2-cycle-old result) ────────────────────────────────
  input  logic [4:0]  mem_wb_rd,
  input  logic        mem_wb_reg_write,

  // ── Load-use hazard detection ────────────────────────────────────────────
  input  logic [4:0]  id_ex_rd,
  input  logic        id_ex_mem_read,    // Is instruction in EX a load?
  input  logic [4:0]  if_id_rs1,         // Source regs of instruction in ID
  input  logic [4:0]  if_id_rs2,

  // ── Branch/jump flush trigger ────────────────────────────────────────────
  input  logic        branch_taken,

  // ── Stall outputs ────────────────────────────────────────────────────────
  output logic        stall_if,          // Hold IF stage (PC + IMEM)
  output logic        stall_id,          // Hold ID stage (IF/ID register)
  output logic        flush_id_ex,       // Insert bubble into ID/EX (load-use)

  // ── Flush outputs (branch / jump) ────────────────────────────────────────
  output logic        flush_if_id,       // Flush IF/ID register
  output logic        flush_id_ex_br,    // Flush ID/EX register

  // ── Forwarding mux selects ────────────────────────────────────────────────
  output logic [1:0]  fwd_a,            // 00=none  10=EX/MEM  01=MEM/WB
  output logic [1:0]  fwd_b
);

  // ── Forwarding: operand A (rs1) ──────────────────────────────────────────
  always_comb begin : proc_fwd_a
    if (ex_mem_reg_write && (ex_mem_rd != 5'b0) && (ex_mem_rd == id_ex_rs1))
      fwd_a = 2'b10;
    else if (mem_wb_reg_write && (mem_wb_rd != 5'b0) && (mem_wb_rd == id_ex_rs1))
      fwd_a = 2'b01;
    else
      fwd_a = 2'b00;
  end

  // ── Forwarding: operand B (rs2) ──────────────────────────────────────────
  always_comb begin : proc_fwd_b
    if (ex_mem_reg_write && (ex_mem_rd != 5'b0) && (ex_mem_rd == id_ex_rs2))
      fwd_b = 2'b10;
    else if (mem_wb_reg_write && (mem_wb_rd != 5'b0) && (mem_wb_rd == id_ex_rs2))
      fwd_b = 2'b01;
    else
      fwd_b = 2'b00;
  end

  // ── Load-use hazard ───────────────────────────────────────────────────────
  // A load is in EX and the next instruction (now in ID) needs its result.
  // There is no forwarding path for this case — a 1-cycle stall is required.
  logic load_use;
  assign load_use = id_ex_mem_read
                    && (id_ex_rd != 5'b0)
                    && ((id_ex_rd == if_id_rs1) || (id_ex_rd == if_id_rs2));

  assign stall_if    = load_use;
  assign stall_id    = load_use;
  assign flush_id_ex = load_use;

  // ── Branch / jump flush ───────────────────────────────────────────────────
  // branch_taken is resolved at end of EX, so two speculatively-fetched
  // instructions (now in IF/ID and ID/EX) must be turned into bubbles.
  assign flush_if_id    = branch_taken;
  assign flush_id_ex_br = branch_taken;

endmodule
