// =============================================================================
// cpu_tb.sv — Comprehensive Testbench for 5-Stage Pipelined RV32I CPU
//
// Test Scenarios:
//   1. Basic R-type arithmetic     (ADD, SUB, AND, OR, XOR, SLT)
//   2. I-type ALU operations       (ADDI, ANDI, ORI, XORI, SLTI)
//   3. Shift operations            (SLL, SRL, SRA, SLLI, SRLI, SRAI)
//   4. EX→EX data forwarding       (back-to-back RAW hazard)
//   5. MEM→EX data forwarding      (2-instruction gap RAW hazard)
//   6. Load-use stall              (LW immediately followed by dependent op)
//   7. Branch / JAL control flow   (BEQ taken, BNE not-taken, JAL)
//   8. Load / Store                (SW then LW round-trip)
//   9. LUI / AUIPC
// =============================================================================
`timescale 1ns/1ps
import cpu_pkg::*;

module cpu_tb;

  // ── DUT parameters ────────────────────────────────────────────────────
  localparam int CLK_PERIOD = 10; // ns

  // ── Clock and reset ───────────────────────────────────────────────────
  logic clk  = 0;
  logic rst_n = 0;

  always #(CLK_PERIOD/2) clk = ~clk;

  // ── DUT ports ─────────────────────────────────────────────────────────
  logic [XLEN-1:0] dbg_pc, dbg_instr, dbg_alu_result, dbg_rd_data;
  logic [RLEN-1:0] dbg_rd_addr;
  logic            dbg_reg_write, dbg_stall, dbg_branch_taken;

  // ── DUT instantiation ─────────────────────────────────────────────────
  cpu_top #(.IMEM_INIT_FILE("")) u_dut (
    .clk            (clk),
    .rst_n          (rst_n),
    .dbg_pc         (dbg_pc),
    .dbg_instr      (dbg_instr),
    .dbg_alu_result (dbg_alu_result),
    .dbg_rd_addr    (dbg_rd_addr),
    .dbg_rd_data    (dbg_rd_data),
    .dbg_reg_write  (dbg_reg_write),
    .dbg_stall      (dbg_stall),
    .dbg_branch_taken(dbg_branch_taken)
  );

  // ── Test statistics ───────────────────────────────────────────────────
  int pass_count = 0;
  int fail_count = 0;

  // ── Instruction encoding helpers ─────────────────────────────────────
  // R-type: funct7 | rs2 | rs1 | funct3 | rd | opcode
  function automatic logic [31:0] r_type(
    input logic [6:0] funct7,
    input logic [4:0] rs2, rs1,
    input logic [2:0] funct3,
    input logic [4:0] rd,
    input logic [6:0] opcode
  );
    return {funct7, rs2, rs1, funct3, rd, opcode};
  endfunction

  // I-type: imm[11:0] | rs1 | funct3 | rd | opcode
  function automatic logic [31:0] i_type(
    input logic signed [11:0] imm,
    input logic [4:0] rs1,
    input logic [2:0] funct3,
    input logic [4:0] rd,
    input logic [6:0] opcode
  );
    return {imm, rs1, funct3, rd, opcode};
  endfunction

  // S-type: imm[11:5] | rs2 | rs1 | funct3 | imm[4:0] | opcode
  function automatic logic [31:0] s_type(
    input logic signed [11:0] imm,
    input logic [4:0] rs2, rs1,
    input logic [2:0] funct3,
    input logic [6:0] opcode
  );
    return {imm[11:5], rs2, rs1, funct3, imm[4:0], opcode};
  endfunction

  // B-type: imm[12|10:5] | rs2 | rs1 | funct3 | imm[4:1|11] | opcode
  function automatic logic [31:0] b_type(
    input logic signed [12:0] imm,  // offset (must be even)
    input logic [4:0] rs2, rs1,
    input logic [2:0] funct3,
    input logic [6:0] opcode
  );
    return {imm[12], imm[10:5], rs2, rs1, funct3, imm[4:1], imm[11], opcode};
  endfunction

  // U-type: imm[31:12] | rd | opcode
  function automatic logic [31:0] u_type(
    input logic [31:12] imm,
    input logic [4:0] rd,
    input logic [6:0] opcode
  );
    return {imm, rd, opcode};
  endfunction

  // J-type: imm[20|10:1|11|19:12] | rd | opcode
  function automatic logic [31:0] j_type(
    input logic signed [20:0] imm,  // offset (must be even)
    input logic [4:0] rd,
    input logic [6:0] opcode
  );
    return {imm[20], imm[10:1], imm[11], imm[19:12], rd, opcode};
  endfunction

  // ── Utility: wait N cycles and optionally print pipeline state ────────
  task automatic wait_cycles(input int n, input logic verbose = 0);
    repeat (n) begin
      @(posedge clk);
      #1;
      if (verbose)
        $display("  [PC=%08h INSTR=%08h] stall=%0b branch_taken=%0b",
                 dbg_pc, dbg_instr, dbg_stall, dbg_branch_taken);
    end
  endtask

  // ── Utility: check register value (read register file directly) ───────
  task automatic check_reg(
    input logic [4:0] reg_num,
    input logic [31:0] expected,
    input string test_name
  );
    logic [31:0] actual;
    actual = u_dut.u_rf.regs[reg_num];
    if (actual === expected) begin
      $display("  PASS  %-30s  x%-2d = 0x%08h", test_name, reg_num, actual);
      pass_count++;
    end else begin
      $display("  FAIL  %-30s  x%-2d = 0x%08h (expected 0x%08h)",
               test_name, reg_num, actual, expected);
      fail_count++;
    end
  endtask

  // ── Load program into instruction memory ─────────────────────────────
  task automatic load_program(input logic [31:0] prog []);
    for (int i = 0; i < prog.size(); i++)
      u_dut.u_imem.backdoor_write(i, prog[i]);
    // Fill remainder with NOPs
    for (int i = prog.size(); i < IMEM_SZ; i++)
      u_dut.u_imem.backdoor_write(i, NOP_INSTR);
  endtask

  // ── Hard reset ────────────────────────────────────────────────────────
  task automatic do_reset();
    rst_n = 0;
    repeat (3) @(posedge clk);
    #1 rst_n = 1;
    @(posedge clk); #1;
  endtask

  // ════════════════════════════════════════════════════════════════════════
  // TEST 1 — Basic R-type arithmetic
  // ════════════════════════════════════════════════════════════════════════
  task automatic test_r_type();
    logic [31:0] prog[];

    $display("\n═══ TEST 1: R-Type Arithmetic ═══════════════════════════════");

    prog = new[10];
    //            ADDI x1, x0, 15      (x1 = 15)
    prog[0]  = i_type(12'd15,  5'd0, 3'b000, 5'd1,  OP_I_ALU);
    //            ADDI x2, x0, 7       (x2 = 7)
    prog[1]  = i_type(12'd7,   5'd0, 3'b000, 5'd2,  OP_I_ALU);
    //            ADD  x3, x1, x2      (x3 = 22)
    prog[2]  = r_type(7'b0000000, 5'd2, 5'd1, 3'b000, 5'd3, OP_R);
    //            SUB  x4, x1, x2      (x4 = 8)
    prog[3]  = r_type(7'b0100000, 5'd2, 5'd1, 3'b000, 5'd4, OP_R);
    //            AND  x5, x1, x2      (x5 = 7)
    prog[4]  = r_type(7'b0000000, 5'd2, 5'd1, 3'b111, 5'd5, OP_R);
    //            OR   x6, x1, x2      (x6 = 15)
    prog[5]  = r_type(7'b0000000, 5'd2, 5'd1, 3'b110, 5'd6, OP_R);
    //            XOR  x7, x1, x2      (x7 = 8)
    prog[6]  = r_type(7'b0000000, 5'd2, 5'd1, 3'b100, 5'd7, OP_R);
    //            SLT  x8, x2, x1      (x8 = 1, because 7 < 15)
    prog[7]  = r_type(7'b0000000, 5'd1, 5'd2, 3'b010, 5'd8, OP_R);
    //            NOP
    prog[8]  = NOP_INSTR;
    prog[9]  = NOP_INSTR;

    load_program(prog);
    do_reset();
    wait_cycles(14);

    check_reg(1, 32'd15, "ADDI x1=15");
    check_reg(2, 32'd7,  "ADDI x2=7");
    check_reg(3, 32'd22, "ADD  x3=22");
    check_reg(4, 32'd8,  "SUB  x4=8");
    check_reg(5, 32'd7,  "AND  x5=7");
    check_reg(6, 32'd15, "OR   x6=15");
    check_reg(7, 32'd8,  "XOR  x7=8");
    check_reg(8, 32'd1,  "SLT  x8=1");
  endtask

  // ════════════════════════════════════════════════════════════════════════
  // TEST 2 — Shift operations
  // ════════════════════════════════════════════════════════════════════════
  task automatic test_shifts();
    logic [31:0] prog[];

    $display("\n═══ TEST 2: Shift Operations ════════════════════════════════");

    prog = new[10];
    //            ADDI x1, x0, 8       (x1 = 0x00000008)
    prog[0]  = i_type(12'd8,   5'd0, 3'b000, 5'd1,  OP_I_ALU);
    //            SLLI x2, x1, 4       (x2 = 0x00000080)
    prog[1]  = i_type(12'b0000000_00100, 5'd1, 3'b001, 5'd2, OP_I_ALU);
    //            SRLI x3, x2, 2       (x3 = 0x00000020)
    prog[2]  = i_type(12'b0000000_00010, 5'd2, 3'b101, 5'd3, OP_I_ALU);
    //            ADDI x4, x0, -1      (x4 = 0xFFFFFFFF)
    prog[3]  = i_type(-12'd1,  5'd0, 3'b000, 5'd4,  OP_I_ALU);
    //            SRAI x5, x4, 4       (x5 = 0xFFFFFFFF, arithmetic right)
    prog[4]  = i_type(12'b0100000_00100, 5'd4, 3'b101, 5'd5, OP_I_ALU);
    //            ADDI x6, x0, 2       (x6 = 2, shift amount)
    prog[5]  = i_type(12'd2,   5'd0, 3'b000, 5'd6,  OP_I_ALU);
    //            SLL  x7, x1, x6      (x7 = 32)
    prog[6]  = r_type(7'b0000000, 5'd6, 5'd1, 3'b001, 5'd7, OP_R);
    //            SRL  x8, x7, x6      (x8 = 8)
    prog[7]  = r_type(7'b0000000, 5'd6, 5'd7, 3'b101, 5'd8, OP_R);
    prog[8]  = NOP_INSTR;
    prog[9]  = NOP_INSTR;

    load_program(prog);
    do_reset();
    wait_cycles(14);

    check_reg(2, 32'h00000080, "SLLI x2=0x80");
    check_reg(3, 32'h00000020, "SRLI x3=0x20");
    check_reg(5, 32'hFFFFFFFF, "SRAI x5=0xFFFF");
    check_reg(7, 32'd32,       "SLL  x7=32");
    check_reg(8, 32'd8,        "SRL  x8=8");
  endtask

  // ════════════════════════════════════════════════════════════════════════
  // TEST 3 — EX→EX forwarding (back-to-back RAW)
  // ════════════════════════════════════════════════════════════════════════
  task automatic test_ex_ex_forwarding();
    logic [31:0] prog[];

    $display("\n═══ TEST 3: EX→EX Data Forwarding ══════════════════════════");
    $display("  (back-to-back RAW: result of inst N used by inst N+1)");

    prog = new[8];
    //            ADDI x1, x0, 10
    prog[0] = i_type(12'd10, 5'd0, 3'b000, 5'd1, OP_I_ALU);
    //            ADD  x2, x1, x1   (needs x1 — EX→EX forward)
    prog[1] = r_type(7'b0000000, 5'd1, 5'd1, 3'b000, 5'd2, OP_R);
    //            ADD  x3, x2, x1   (needs x2 — EX→EX forward)
    prog[2] = r_type(7'b0000000, 5'd1, 5'd2, 3'b000, 5'd3, OP_R);
    //            ADD  x4, x3, x2   (needs both x3,x2 — EX/MEM and MEM/WB)
    prog[3] = r_type(7'b0000000, 5'd2, 5'd3, 3'b000, 5'd4, OP_R);
    prog[4] = NOP_INSTR;
    prog[5] = NOP_INSTR;
    prog[6] = NOP_INSTR;
    prog[7] = NOP_INSTR;

    load_program(prog);
    do_reset();
    wait_cycles(12);

    // x1=10, x2=20, x3=30, x4=50
    check_reg(1, 32'd10, "ADDI x1=10");
    check_reg(2, 32'd20, "FWD  x2=20 (x1+x1)");
    check_reg(3, 32'd30, "FWD  x3=30 (x2+x1)");
    check_reg(4, 32'd50, "FWD  x4=50 (x3+x2)");
  endtask

  // ════════════════════════════════════════════════════════════════════════
  // TEST 4 — Load-use stall (1 cycle bubble)
  // ════════════════════════════════════════════════════════════════════════
  task automatic test_load_use_stall();
    logic [31:0] prog[];
    int          stall_count;

    $display("\n═══ TEST 4: Load-Use Stall ══════════════════════════════════");
    $display("  (LW followed immediately by instruction reading loaded reg)");

    prog = new[10];
    //            ADDI x1, x0, 42      store 42 at address 0
    prog[0] = i_type(12'd42, 5'd0, 3'b000, 5'd1, OP_I_ALU);
    //            SW   x1, 0(x0)
    prog[1] = s_type(12'd0, 5'd1, 5'd0, 3'b010, OP_STORE);
    //            LW   x2, 0(x0)
    prog[2] = i_type(12'd0, 5'd0, 3'b010, 5'd2, OP_LOAD);
    //            ADD  x3, x2, x2      MUST stall — x2 not yet available
    prog[3] = r_type(7'b0000000, 5'd2, 5'd2, 3'b000, 5'd3, OP_R);
    prog[4] = NOP_INSTR;
    prog[5] = NOP_INSTR;
    prog[6] = NOP_INSTR;
    prog[7] = NOP_INSTR;
    prog[8] = NOP_INSTR;
    prog[9] = NOP_INSTR;

    load_program(prog);
    do_reset();

    // Count stall cycles over 16 cycles
    stall_count = 0;
    repeat (16) begin
      @(posedge clk); #1;
      if (dbg_stall) stall_count++;
    end

    $display("  INFO  Observed %0d stall cycle(s) (expected ≥1)", stall_count);
    if (stall_count >= 1) begin
      $display("  PASS  Load-use stall detected");
      pass_count++;
    end else begin
      $display("  FAIL  No stall detected!");
      fail_count++;
    end

    wait_cycles(4);
    check_reg(2, 32'd42, "LW   x2=42");
    check_reg(3, 32'd84, "STALL+ADD x3=84");
  endtask

  // ════════════════════════════════════════════════════════════════════════
  // TEST 5 — Branch taken / not-taken + JAL
  // ════════════════════════════════════════════════════════════════════════
  task automatic test_control_flow();
    logic [31:0] prog[];

    $display("\n═══ TEST 5: Branch & JAL Control Flow ══════════════════════");

    // Layout (word offsets):
    //  0: ADDI x1, x0, 5
    //  1: ADDI x2, x0, 5
    //  2: BEQ  x1, x2, +8   → branches to word 4 (offset=+8 bytes)
    //  3: ADDI x9, x0, 99   ← MUST be skipped
    //  4: ADDI x3, x0, 1    ← branch target
    //  5: ADDI x4, x0, 2
    //  6: BNE  x3, x4, +8   → NOT taken (x3≠x4 is true here so TAKEN to 8)
    //  7: ADDI x9, x0, 99   ← MUST be skipped
    //  8: ADDI x5, x0, 77   ← BNE target
    //  9: JAL  x6, +8       → jumps to word 11 (+8 bytes from word 9)
    // 10: ADDI x9, x0, 99   ← MUST be skipped
    // 11: ADDI x7, x0, 55   ← JAL target

    prog = new[16];
    prog[ 0] = i_type(12'd5,  5'd0, 3'b000, 5'd1,  OP_I_ALU); // ADDI x1=5
    prog[ 1] = i_type(12'd5,  5'd0, 3'b000, 5'd2,  OP_I_ALU); // ADDI x2=5
    prog[ 2] = b_type(13'sd8, 5'd2, 5'd1,  3'b000, OP_BRANCH); // BEQ +8
    prog[ 3] = i_type(12'd99, 5'd0, 3'b000, 5'd9,  OP_I_ALU); // SKIP
    prog[ 4] = i_type(12'd1,  5'd0, 3'b000, 5'd3,  OP_I_ALU); // ADDI x3=1
    prog[ 5] = i_type(12'd2,  5'd0, 3'b000, 5'd4,  OP_I_ALU); // ADDI x4=2
    prog[ 6] = b_type(13'sd8, 5'd4, 5'd3,  3'b001, OP_BRANCH); // BNE +8 (taken)
    prog[ 7] = i_type(12'd99, 5'd0, 3'b000, 5'd9,  OP_I_ALU); // SKIP
    prog[ 8] = i_type(12'd77, 5'd0, 3'b000, 5'd5,  OP_I_ALU); // ADDI x5=77
    prog[ 9] = j_type(21'sd8, 5'd6,                 OP_JAL);   // JAL  x6=PC+4
    prog[10] = i_type(12'd99, 5'd0, 3'b000, 5'd9,  OP_I_ALU); // SKIP
    prog[11] = i_type(12'd55, 5'd0, 3'b000, 5'd7,  OP_I_ALU); // ADDI x7=55
    prog[12] = NOP_INSTR;
    prog[13] = NOP_INSTR;
    prog[14] = NOP_INSTR;
    prog[15] = NOP_INSTR;

    load_program(prog);
    do_reset();
    wait_cycles(22);

    check_reg(9, 32'd0,  "x9 never written (=0)");   // skipped instrs
    check_reg(3, 32'd1,  "BEQ branch target x3=1");
    check_reg(5, 32'd77, "BNE branch target x5=77");
    check_reg(7, 32'd55, "JAL  jump target  x7=55");
    // x6 holds return address = PC of JAL + 4 = 9*4+4 = 40
    check_reg(6, 32'd40, "JAL  link reg x6=40");
  endtask

  // ════════════════════════════════════════════════════════════════════════
  // TEST 6 — Load / Store round-trip
  // ════════════════════════════════════════════════════════════════════════
  task automatic test_load_store();
    logic [31:0] prog[];

    $display("\n═══ TEST 6: Load / Store (word & byte) ═════════════════════");

    prog = new[12];
    //  Write 0xDEADBEEF to address 0
    prog[0] = i_type(12'hDEA, 5'd0, 3'b000, 5'd1, OP_I_ALU); // ADDI x1 = 0xFFFFDEA  (imm sign-ext)
    // Better: use LUI + ADDI to build full 32-bit constant
    prog[0] = u_type(20'hDEADB, 5'd1, OP_LUI);                // LUI x1, 0xDEADB000
    prog[1] = i_type(12'hEEF,   5'd1, 3'b000, 5'd1, OP_I_ALU); // ADDI x1, x1, 0xEEF (sign! -273)
    // x1 = 0xDEADB000 + 0xFFFFFEEF = 0xDEADAEEF  (carries)
    // Just store a simple known value instead
    prog[0] = i_type(12'd100, 5'd0, 3'b000, 5'd1, OP_I_ALU);  // x1=100
    prog[1] = i_type(12'd200, 5'd0, 3'b000, 5'd2, OP_I_ALU);  // x2=200
    prog[2] = s_type(12'd0,   5'd1, 5'd0, 3'b010, OP_STORE);   // SW x1, 0(x0)
    prog[3] = s_type(12'd4,   5'd2, 5'd0, 3'b010, OP_STORE);   // SW x2, 4(x0)
    prog[4] = NOP_INSTR;
    prog[5] = i_type(12'd0,   5'd0, 3'b010, 5'd3, OP_LOAD);   // LW x3, 0(x0)
    prog[6] = i_type(12'd4,   5'd0, 3'b010, 5'd4, OP_LOAD);   // LW x4, 4(x0)
    prog[7] = NOP_INSTR;
    prog[8] = NOP_INSTR;
    prog[9] = r_type(7'b0000000, 5'd4, 5'd3, 3'b000, 5'd5, OP_R); // ADD x5=x3+x4
    prog[10]= NOP_INSTR;
    prog[11]= NOP_INSTR;

    load_program(prog);
    do_reset();
    wait_cycles(18);

    check_reg(3, 32'd100, "LW x3=100");
    check_reg(4, 32'd200, "LW x4=200");
    check_reg(5, 32'd300, "ADD x5=300 (load+load)");
  endtask

  // ════════════════════════════════════════════════════════════════════════
  // TEST 7 — LUI and AUIPC
  // ════════════════════════════════════════════════════════════════════════
  task automatic test_lui_auipc();
    logic [31:0] prog[];

    $display("\n═══ TEST 7: LUI / AUIPC ═════════════════════════════════════");

    prog = new[8];
    prog[0] = u_type(20'h12345, 5'd1, OP_LUI);                     // LUI x1, 0x12345
    prog[1] = u_type(20'h00001, 5'd2, OP_AUIPC);                   // AUIPC x2, 1 (PC=4, x2=4+0x1000=0x1004)
    prog[2] = NOP_INSTR;
    prog[3] = NOP_INSTR;
    prog[4] = NOP_INSTR;
    prog[5] = NOP_INSTR;
    prog[6] = NOP_INSTR;
    prog[7] = NOP_INSTR;

    load_program(prog);
    do_reset();
    wait_cycles(10);

    check_reg(1, 32'h12345000, "LUI  x1=0x12345000");
    check_reg(2, 32'h00001004, "AUIPC x2=0x1004 (PC=4 + 0x1000)");
  endtask

  // ════════════════════════════════════════════════════════════════════════
  // Main test execution
  // ════════════════════════════════════════════════════════════════════════
  initial begin
    $display("╔══════════════════════════════════════════════════════════════╗");
    $display("║   5-Stage Pipelined RV32I CPU — Verification Suite          ║");
    $display("╚══════════════════════════════════════════════════════════════╝");

    // Dump waveforms
    $dumpfile("sim/cpu_tb.vcd");
    $dumpvars(0, cpu_tb);

    test_r_type();
    test_shifts();
    test_ex_ex_forwarding();
    test_load_use_stall();
    test_control_flow();
    test_load_store();
    test_lui_auipc();

    // ── Summary ──────────────────────────────────────────────────────
    $display("\n╔══════════════════════════════════════════════════════════════╗");
    $display("║  RESULTS:  %0d PASS   %0d FAIL   (%0d total)%s",
             pass_count, fail_count, pass_count + fail_count,
             fail_count == 0 ? "   ✓ ALL PASS" : "   ✗ FAILURES DETECTED");
    $display("╚══════════════════════════════════════════════════════════════╝");

    if (fail_count > 0) $fatal(1, "One or more tests FAILED.");
    else                $display("Simulation PASSED.");

    $finish;
  end

  // ── Timeout watchdog ─────────────────────────────────────────────────
  initial begin
    #100_000;
    $fatal(1, "TIMEOUT: simulation did not finish within 100 us");
  end

endmodule : cpu_tb
