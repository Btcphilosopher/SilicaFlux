// =============================================================================
// if_stage.sv — Instruction Fetch Stage
//
// Responsibilities:
//   • Maintains the Program Counter (PC)
//   • Selects next PC: PC+4 | branch target | jump target
//   • Drives the instruction memory address
//   • PC stalls on load-use hazard (stall_if asserted by hazard unit)
// =============================================================================
`timescale 1ns/1ps
import cpu_pkg::*;

module if_stage (
  input  logic               clk,
  input  logic               rst_n,

  // ── Hazard / flush control ────────────────────────────────────────────
  input  logic               stall_if,      // freeze PC (load-use stall)
  input  logic               flush_if,      // flush IF/ID register (branch taken / JAL)

  // ── Branch / jump resolution (from EX stage) ─────────────────────────
  input  logic               branch_taken,  // branch condition resolved true
  input  logic               jump,          // unconditional jump
  input  logic [XLEN-1:0]   branch_target, // computed target address

  // ── Outputs to IF/ID pipeline register ───────────────────────────────
  output logic [XLEN-1:0]   pc_out,        // current PC (registered)
  output logic [XLEN-1:0]   pc_plus4       // PC+4 (for link-register)
);

  logic [XLEN-1:0] pc_reg;
  logic [XLEN-1:0] pc_next;

  // ── Next-PC mux ───────────────────────────────────────────────────────
  // Priority: branch/jump > sequential
  always_comb begin
    if (branch_taken || jump)
      pc_next = branch_target;
    else
      pc_next = pc_reg + 32'd4;
  end

  // ── PC register ───────────────────────────────────────────────────────
  always_ff @(posedge clk or negedge rst_n) begin
    if      (!rst_n)    pc_reg <= '0;
    else if (!stall_if) pc_reg <= pc_next;
  end

  assign pc_out    = pc_reg;
  assign pc_plus4  = pc_reg + 32'd4;

endmodule : if_stage
