// =============================================================================
// ex_stage.sv — Execute Stage
//
// Responsibilities:
//   • Apply forwarding mux to operand A and B
//   • Select ALU operand B: forwarded rs2 or sign-extended immediate
//   • Compute effective address / ALU result
//   • Resolve branch condition (flags from ALU)
//   • Compute branch / jump target address
//   • Generate branch_taken and jump signals back to IF stage
// =============================================================================
`timescale 1ns/1ps
import cpu_pkg::*;

module ex_stage (
  // ── Register read values from ID/EX register ─────────────────────────
  input  logic [XLEN-1:0]   rs1_data,
  input  logic [XLEN-1:0]   rs2_data,
  input  logic [XLEN-1:0]   immediate,
  input  logic [XLEN-1:0]   pc_id_ex,  // PC at this instruction (for AUIPC/JAL)

  // ── Control ───────────────────────────────────────────────────────────
  input  ctrl_t              ctrl,
  input  logic [2:0]         funct3,   // branch type

  // ── Forwarding inputs ─────────────────────────────────────────────────
  input  fwd_sel_t           fwd_a,    // forwarding select for operand A
  input  fwd_sel_t           fwd_b,    // forwarding select for operand B
  input  logic [XLEN-1:0]   ex_mem_result,   // forward from EX/MEM
  input  logic [XLEN-1:0]   mem_wb_result,   // forward from MEM/WB

  // ── Outputs ───────────────────────────────────────────────────────────
  output logic [XLEN-1:0]   alu_result,
  output logic [XLEN-1:0]   rs2_forwarded,   // forwarded store data
  output logic               branch_taken,
  output logic               jump_out,
  output logic [XLEN-1:0]   branch_target
);

  // ── Forwarding muxes ─────────────────────────────────────────────────
  logic [XLEN-1:0] op_a_raw, op_b_raw;

  always_comb begin
    unique case (fwd_a)
      FWD_EX_MEM: op_a_raw = ex_mem_result;
      FWD_MEM_WB: op_a_raw = mem_wb_result;
      default    : op_a_raw = rs1_data;
    endcase

    unique case (fwd_b)
      FWD_EX_MEM: op_b_raw = ex_mem_result;
      FWD_MEM_WB: op_b_raw = mem_wb_result;
      default    : op_b_raw = rs2_data;
    endcase
  end

  assign rs2_forwarded = op_b_raw;  // forwarded store data (to MEM stage)

  // ── ALU operand A: rs1 OR PC (AUIPC / JAL) ────────────────────────────
  logic [XLEN-1:0] alu_op_a;
  assign alu_op_a = (ctrl.auipc || ctrl.jump && !ctrl.jalr)
                  ? pc_id_ex
                  : op_a_raw;

  // ── ALU operand B: forwarded rs2 OR immediate ────────────────────────
  logic [XLEN-1:0] alu_op_b;
  assign alu_op_b = ctrl.alu_src ? immediate : op_b_raw;

  // ── ALU instantiation ─────────────────────────────────────────────────
  logic            alu_zero, alu_neg, alu_overflow;

  alu u_alu (
    .operand_a  (alu_op_a),
    .operand_b  (alu_op_b),
    .alu_op     (ctrl.alu_op),
    .result     (alu_result),
    .zero       (alu_zero),
    .negative   (alu_neg),
    .overflow   (alu_overflow)
  );

  // ── Branch condition evaluation ───────────────────────────────────────
  logic branch_cond;

  always_comb begin
    unique case (funct3)
      F3_BEQ : branch_cond =  alu_zero;
      F3_BNE : branch_cond = ~alu_zero;
      F3_BLT : branch_cond =  (alu_neg ^ alu_overflow);
      F3_BGE : branch_cond = ~(alu_neg ^ alu_overflow);
      F3_BLTU: branch_cond =  (op_a_raw <  op_b_raw); // unsigned
      F3_BGEU: branch_cond = ~(op_a_raw <  op_b_raw);
      default : branch_cond = 1'b0;
    endcase
  end

  assign branch_taken = ctrl.branch & branch_cond;
  assign jump_out     = ctrl.jump;

  // ── Branch / jump target ─────────────────────────────────────────────
  // JALR: (rs1 + imm) & ~1   |   branches / JAL: PC + imm
  always_comb begin
    if (ctrl.jalr)
      branch_target = {alu_result[XLEN-1:1], 1'b0};
    else if (ctrl.jump)
      branch_target = pc_id_ex + immediate;     // JAL
    else
      branch_target = pc_id_ex + immediate;     // branch
  end

endmodule : ex_stage
