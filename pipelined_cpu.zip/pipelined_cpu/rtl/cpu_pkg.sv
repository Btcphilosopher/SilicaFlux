// =============================================================================
// cpu_pkg.sv — Shared types, enumerations, and constants for RV32I pipeline
// =============================================================================
package cpu_pkg;

  // ── Datapath widths ───────────────────────────────────────────────────────
  localparam int XLEN     = 32;   // data/address width
  localparam int ILEN     = 32;   // instruction width
  localparam int RLEN     = 5;    // register address width
  localparam int REGS     = 32;   // number of architectural registers
  localparam int IMEM_SZ  = 1024; // instruction memory words
  localparam int DMEM_SZ  = 1024; // data memory words

  // ── RV32I Opcodes ─────────────────────────────────────────────────────────
  localparam logic [6:0] OP_R      = 7'b011_0011; // R-type  (add, sub, …)
  localparam logic [6:0] OP_I_ALU  = 7'b001_0011; // I-type  (addi, ori, …)
  localparam logic [6:0] OP_LOAD   = 7'b000_0011; // loads   (lw, lh, lb …)
  localparam logic [6:0] OP_STORE  = 7'b010_0011; // stores  (sw, sh, sb …)
  localparam logic [6:0] OP_BRANCH = 7'b110_0011; // branches(beq, bne, …)
  localparam logic [6:0] OP_JAL    = 7'b110_1111; // JAL
  localparam logic [6:0] OP_JALR   = 7'b110_0111; // JALR
  localparam logic [6:0] OP_LUI    = 7'b011_0111; // LUI
  localparam logic [6:0] OP_AUIPC  = 7'b001_0111; // AUIPC

  // ── funct3 codes (selected) ───────────────────────────────────────────────
  localparam logic [2:0] F3_ADD_SUB = 3'b000;
  localparam logic [2:0] F3_SLL     = 3'b001;
  localparam logic [2:0] F3_SLT     = 3'b010;
  localparam logic [2:0] F3_SLTU    = 3'b011;
  localparam logic [2:0] F3_XOR     = 3'b100;
  localparam logic [2:0] F3_SR      = 3'b101;
  localparam logic [2:0] F3_OR      = 3'b110;
  localparam logic [2:0] F3_AND     = 3'b111;
  localparam logic [2:0] F3_BEQ     = 3'b000;
  localparam logic [2:0] F3_BNE     = 3'b001;
  localparam logic [2:0] F3_BLT     = 3'b100;
  localparam logic [2:0] F3_BGE     = 3'b101;
  localparam logic [2:0] F3_BLTU    = 3'b110;
  localparam logic [2:0] F3_BGEU    = 3'b111;

  // ── ALU operation encoding ────────────────────────────────────────────────
  typedef enum logic [3:0] {
    ALU_ADD  = 4'd0,
    ALU_SUB  = 4'd1,
    ALU_AND  = 4'd2,
    ALU_OR   = 4'd3,
    ALU_XOR  = 4'd4,
    ALU_SLL  = 4'd5,
    ALU_SRL  = 4'd6,
    ALU_SRA  = 4'd7,
    ALU_SLT  = 4'd8,
    ALU_SLTU = 4'd9,
    ALU_PASS = 4'd10,  // pass operand A (for LUI)
    ALU_NOP  = 4'd15
  } alu_op_t;

  // ── Immediate format selector ─────────────────────────────────────────────
  typedef enum logic [2:0] {
    IMM_I = 3'd0,  // sign-extended 12-bit
    IMM_S = 3'd1,  // store offset
    IMM_B = 3'd2,  // branch offset  (×2)
    IMM_U = 3'd3,  // upper 20 bits  (<<12)
    IMM_J = 3'd4,  // jump offset    (×2)
    IMM_R = 3'd5,  // R-type (no immediate used)
    IMM_Z = 3'd6   // zero / don't-care
  } imm_type_t;

  // ── Forwarding mux select ─────────────────────────────────────────────────
  typedef enum logic [1:0] {
    FWD_NONE   = 2'b00,  // use pipeline register value
    FWD_EX_MEM = 2'b01,  // forward from EX/MEM stage
    FWD_MEM_WB = 2'b10   // forward from MEM/WB stage
  } fwd_sel_t;

  // ── Decoded control word ──────────────────────────────────────────────────
  // Flows through ID→EX→MEM→WB pipeline registers.
  typedef struct packed {
    // WB group
    logic      reg_write;   // write result to rd
    logic      mem_to_reg;  // 0 = ALU result, 1 = memory data
    // MEM group
    logic      mem_read;    // assert for loads
    logic      mem_write;   // assert for stores
    logic [2:0] mem_width;  // funct3 encodes byte/half/word + sign
    // EX group
    logic      alu_src;     // 0 = rs2, 1 = immediate
    alu_op_t   alu_op;
    imm_type_t imm_type;
    // Branch / jump
    logic      branch;      // conditional branch
    logic      jump;        // unconditional jump (JAL / JALR)
    logic      jalr;        // JALR (use rs1 as base for target)
    logic      auipc;       // add PC to upper immediate
  } ctrl_t;

  // ── Bubble / NOP control word ─────────────────────────────────────────────
  // All control signals de-asserted; used by hazard unit to insert stalls.
  function automatic ctrl_t ctrl_nop();
    ctrl_t c;
    c = '0;
    c.alu_op = ALU_NOP;
    return c;
  endfunction

  // ── NOP instruction (ADDI x0, x0, 0) ─────────────────────────────────────
  localparam logic [ILEN-1:0] NOP_INSTR = 32'h0000_0013;

endpackage : cpu_pkg
