// =============================================================================
// hazard_unit.sv — Hazard Detection Unit
//
// Detects and resolves pipeline hazards:
//
//  ┌──────────────────────────────────────────────────────────────────────┐
//  │  LOAD-USE DATA HAZARD                                                │
//  │  Occurs when an instruction immediately following a load reads the   │
//  │  same register the load writes.  The pipeline must stall one cycle   │
//  │  because the data is not available until after the MEM stage.        │
//  │                                                                      │
//  │  Detection:  ID/EX.mem_read  == 1  AND                               │
//  │              (ID/EX.rd == IF/ID.rs1 OR ID/EX.rd == IF/ID.rs2)       │
//  │                                                                      │
//  │  Resolution: stall_if  = 1  → freeze PC                             │
//  │              stall_id  = 1  → freeze IF/ID register                 │
//  │              flush_ex  = 1  → insert NOP bubble into ID/EX          │
//  ├──────────────────────────────────────────────────────────────────────┤
//  │  CONTROL HAZARD (branch / jump taken)                                │
//  │  Branch condition is resolved at end of EX stage.  The two          │
//  │  instructions already fetched behind the branch must be squashed.   │
//  │                                                                      │
//  │  Resolution: flush_if  = 1  → flush IF/ID register                  │
//  │              flush_id  = 1  → flush ID/EX register                  │
//  └──────────────────────────────────────────────────────────────────────┘
// =============================================================================
`timescale 1ns/1ps
import cpu_pkg::*;

module hazard_unit (
  // ── ID/EX register fields ─────────────────────────────────────────────
  input  logic               id_ex_mem_read,  // load in EX stage
  input  logic [RLEN-1:0]   id_ex_rd,         // destination of EX instruction

  // ── IF/ID register fields ─────────────────────────────────────────────
  input  logic [RLEN-1:0]   if_id_rs1,        // source regs of ID instruction
  input  logic [RLEN-1:0]   if_id_rs2,

  // ── Branch / jump from EX stage ──────────────────────────────────────
  input  logic               branch_taken,
  input  logic               jump,

  // ── Hazard control outputs ────────────────────────────────────────────
  output logic               stall_if,        // freeze PC & IF/ID reg
  output logic               stall_id,        // same as stall_if
  output logic               flush_ex,        // NOP bubble into ID/EX
  output logic               flush_if,        // squash IF/ID  (branch/jump)
  output logic               flush_id         // squash ID/EX  (branch/jump)
);

  // ── Load-use hazard ───────────────────────────────────────────────────
  logic load_use_hazard;

  assign load_use_hazard = id_ex_mem_read &&
                           (id_ex_rd != '0) &&
                           ((id_ex_rd == if_id_rs1) ||
                            (id_ex_rd == if_id_rs2));

  // ── Stall signals (one bubble inserted into EX) ───────────────────────
  assign stall_if = load_use_hazard;
  assign stall_id = load_use_hazard;
  assign flush_ex = load_use_hazard;  // zero the control word entering EX

  // ── Control hazard flush (squash two wrong-path instructions) ────────
  // Branch / jump target becomes available at the end of EX, so we must
  // flush both the IF/ID and ID/EX pipeline registers.
  assign flush_if = (branch_taken || jump) && !load_use_hazard;
  assign flush_id = (branch_taken || jump) && !load_use_hazard;

endmodule : hazard_unit
