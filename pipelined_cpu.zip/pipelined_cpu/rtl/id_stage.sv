// =============================================================================
// id_stage.sv — Instruction Decode Stage
//
// Responsibilities:
//   • Decode instruction fields (opcode, funct3, funct7, rs1, rs2, rd)
//   • Generate all control signals (ctrl_t)
//   • Generate sign-extended immediate value
//   • Initiate register file reads (handled in top-level, wired here)
// =============================================================================
`timescale 1ns/1ps
import cpu_pkg::*;

module id_stage (
  // ── Instruction from IF/ID register ──────────────────────────────────
  input  logic [ILEN-1:0]   instruction,

  // ── Decoded fields (to pipeline register) ────────────────────────────
  output logic [RLEN-1:0]   rs1_addr,
  output logic [RLEN-1:0]   rs2_addr,
  output logic [RLEN-1:0]   rd_addr,
  output logic [XLEN-1:0]   immediate,
  output ctrl_t              ctrl,

  // ── Raw funct fields (needed by forwarding / hazard units) ───────────
  output logic [2:0]         funct3,
  output logic [6:0]         funct7
);

  // ── Field extraction ─────────────────────────────────────────────────
  logic [6:0] opcode;

  assign opcode   = instruction[6:0];
  assign rd_addr  = instruction[11:7];
  assign funct3   = instruction[14:12];
  assign rs1_addr = instruction[19:15];
  assign rs2_addr = instruction[24:20];
  assign funct7   = instruction[31:25];

  // ── Immediate generation ──────────────────────────────────────────────
  logic [XLEN-1:0] imm_i, imm_s, imm_b, imm_u, imm_j;

  assign imm_i = {{20{instruction[31]}}, instruction[31:20]};

  assign imm_s = {{20{instruction[31]}},
                   instruction[31:25],
                   instruction[11:7]};

  assign imm_b = {{19{instruction[31]}},
                   instruction[31],
                   instruction[7],
                   instruction[30:25],
                   instruction[11:8],
                   1'b0};

  assign imm_u = {instruction[31:12], 12'b0};

  assign imm_j = {{11{instruction[31]}},
                   instruction[31],
                   instruction[19:12],
                   instruction[20],
                   instruction[30:21],
                   1'b0};

  // ── Immediate mux (driven by control) ────────────────────────────────
  always_comb begin
    unique case (ctrl.imm_type)
      IMM_I:   immediate = imm_i;
      IMM_S:   immediate = imm_s;
      IMM_B:   immediate = imm_b;
      IMM_U:   immediate = imm_u;
      IMM_J:   immediate = imm_j;
      default: immediate = '0;
    endcase
  end

  // ── Control unit ──────────────────────────────────────────────────────
  always_comb begin
    // Safe defaults (NOP)
    ctrl = ctrl_nop();

    unique case (opcode)
      // ── R-type ─────────────────────────────────────────────────────
      OP_R: begin
        ctrl.reg_write = 1'b1;
        ctrl.alu_src   = 1'b0;
        ctrl.imm_type  = IMM_R;
        unique case ({funct7[5], funct3})
          {1'b0, F3_ADD_SUB}: ctrl.alu_op = ALU_ADD;
          {1'b1, F3_ADD_SUB}: ctrl.alu_op = ALU_SUB;
          {1'b0, F3_AND}    : ctrl.alu_op = ALU_AND;
          {1'b0, F3_OR}     : ctrl.alu_op = ALU_OR;
          {1'b0, F3_XOR}    : ctrl.alu_op = ALU_XOR;
          {1'b0, F3_SLL}    : ctrl.alu_op = ALU_SLL;
          {1'b0, F3_SR}     : ctrl.alu_op = ALU_SRL;
          {1'b1, F3_SR}     : ctrl.alu_op = ALU_SRA;
          {1'b0, F3_SLT}    : ctrl.alu_op = ALU_SLT;
          {1'b0, F3_SLTU}   : ctrl.alu_op = ALU_SLTU;
          default            : ctrl.alu_op = ALU_NOP;
        endcase
      end

      // ── I-type ALU ─────────────────────────────────────────────────
      OP_I_ALU: begin
        ctrl.reg_write = 1'b1;
        ctrl.alu_src   = 1'b1;
        ctrl.imm_type  = IMM_I;
        unique case (funct3)
          F3_ADD_SUB: ctrl.alu_op = ALU_ADD;   // ADDI
          F3_AND    : ctrl.alu_op = ALU_AND;
          F3_OR     : ctrl.alu_op = ALU_OR;
          F3_XOR    : ctrl.alu_op = ALU_XOR;
          F3_SLT    : ctrl.alu_op = ALU_SLT;
          F3_SLTU   : ctrl.alu_op = ALU_SLTU;
          F3_SLL    : ctrl.alu_op = ALU_SLL;
          F3_SR     : ctrl.alu_op = funct7[5] ? ALU_SRA : ALU_SRL;
          default   : ctrl.alu_op = ALU_NOP;
        endcase
      end

      // ── Loads ──────────────────────────────────────────────────────
      OP_LOAD: begin
        ctrl.reg_write  = 1'b1;
        ctrl.mem_read   = 1'b1;
        ctrl.mem_to_reg = 1'b1;
        ctrl.alu_src    = 1'b1;
        ctrl.alu_op     = ALU_ADD;
        ctrl.imm_type   = IMM_I;
        ctrl.mem_width  = funct3;
      end

      // ── Stores ─────────────────────────────────────────────────────
      OP_STORE: begin
        ctrl.mem_write = 1'b1;
        ctrl.alu_src   = 1'b1;
        ctrl.alu_op    = ALU_ADD;
        ctrl.imm_type  = IMM_S;
        ctrl.mem_width = funct3;
      end

      // ── Branches ───────────────────────────────────────────────────
      OP_BRANCH: begin
        ctrl.branch   = 1'b1;
        ctrl.alu_src  = 1'b0;
        ctrl.alu_op   = ALU_SUB;  // EX resolves condition via flags
        ctrl.imm_type = IMM_B;
      end

      // ── JAL ────────────────────────────────────────────────────────
      OP_JAL: begin
        ctrl.reg_write = 1'b1;
        ctrl.jump      = 1'b1;
        ctrl.alu_op    = ALU_ADD; // PC + imm computed in EX
        ctrl.imm_type  = IMM_J;
      end

      // ── JALR ───────────────────────────────────────────────────────
      OP_JALR: begin
        ctrl.reg_write = 1'b1;
        ctrl.jump      = 1'b1;
        ctrl.jalr      = 1'b1;
        ctrl.alu_src   = 1'b1;
        ctrl.alu_op    = ALU_ADD;
        ctrl.imm_type  = IMM_I;
      end

      // ── LUI ────────────────────────────────────────────────────────
      OP_LUI: begin
        ctrl.reg_write = 1'b1;
        ctrl.alu_src   = 1'b1;
        ctrl.alu_op    = ALU_PASS;
        ctrl.imm_type  = IMM_U;
      end

      // ── AUIPC ──────────────────────────────────────────────────────
      OP_AUIPC: begin
        ctrl.reg_write = 1'b1;
        ctrl.alu_op    = ALU_ADD;
        ctrl.alu_src   = 1'b1;
        ctrl.auipc     = 1'b1;
        ctrl.imm_type  = IMM_U;
      end

      default: ctrl = ctrl_nop();
    endcase
  end

endmodule : id_stage
