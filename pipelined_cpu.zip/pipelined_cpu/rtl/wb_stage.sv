// =============================================================================
// wb_stage.sv — Write-Back Stage
//
// Responsibilities:
//   • Select write-back data: ALU result, memory read data, or PC+4 (link)
//   • Drive register file write port
// =============================================================================
`timescale 1ns/1ps
import cpu_pkg::*;

module wb_stage (
  // ── From MEM/WB register ─────────────────────────────────────────────
  input  logic [XLEN-1:0]   alu_result,
  input  logic [XLEN-1:0]   mem_read_data,
  input  logic [XLEN-1:0]   pc_plus4,     // for JAL/JALR link register
  input  ctrl_t              ctrl,

  // ── Register file write port ──────────────────────────────────────────
  output logic [XLEN-1:0]   rd_data,      // value to write
  output logic               reg_write_out // pass-through enable
);

  // 2-to-1 (extended to 3-to-1 for jump link)
  always_comb begin
    if (ctrl.jump)
      rd_data = pc_plus4;          // JAL / JALR: write return address
    else if (ctrl.mem_to_reg)
      rd_data = mem_read_data;     // load instruction
    else
      rd_data = alu_result;        // arithmetic / logical / LUI / AUIPC
  end

  assign reg_write_out = ctrl.reg_write;

endmodule : wb_stage
