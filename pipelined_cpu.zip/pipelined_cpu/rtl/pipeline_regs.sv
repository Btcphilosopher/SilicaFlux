// =============================================================================
// pipeline_regs.sv — Four inter-stage pipeline registers
//
//  IF/ID  : holds fetched instruction + PC
//  ID/EX  : holds decoded fields, immediate, control word, PC
//  EX/MEM : holds ALU result, forwarded store data, control, rd
//  MEM/WB : holds ALU/mem data, PC+4 (link), control, rd
//
// Flush (synchronous clear to NOP) and Stall (hold current value) are
// supported on every register as required by the hazard unit.
// =============================================================================
`timescale 1ns/1ps
import cpu_pkg::*;

// ─────────────────────────────────────────────────────────────────────────────
// IF/ID  pipeline register
// ─────────────────────────────────────────────────────────────────────────────
module if_id_reg (
  input  logic               clk,
  input  logic               rst_n,
  input  logic               stall,   // hold current value
  input  logic               flush,   // insert NOP bubble

  // Write ports
  input  logic [XLEN-1:0]   in_pc,
  input  logic [XLEN-1:0]   in_pc_plus4,
  input  logic [ILEN-1:0]   in_instr,

  // Read ports
  output logic [XLEN-1:0]   out_pc,
  output logic [XLEN-1:0]   out_pc_plus4,
  output logic [ILEN-1:0]   out_instr
);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n || flush) begin
      out_pc       <= '0;
      out_pc_plus4 <= '0;
      out_instr    <= NOP_INSTR;
    end else if (!stall) begin
      out_pc       <= in_pc;
      out_pc_plus4 <= in_pc_plus4;
      out_instr    <= in_instr;
    end
  end

endmodule : if_id_reg


// ─────────────────────────────────────────────────────────────────────────────
// ID/EX  pipeline register
// ─────────────────────────────────────────────────────────────────────────────
module id_ex_reg (
  input  logic               clk,
  input  logic               rst_n,
  input  logic               stall,
  input  logic               flush,

  // Decoded instruction fields
  input  logic [XLEN-1:0]   in_pc,
  input  logic [XLEN-1:0]   in_pc_plus4,
  input  logic [XLEN-1:0]   in_rs1_data,
  input  logic [XLEN-1:0]   in_rs2_data,
  input  logic [RLEN-1:0]   in_rs1_addr,  // for forwarding comparisons
  input  logic [RLEN-1:0]   in_rs2_addr,
  input  logic [RLEN-1:0]   in_rd_addr,
  input  logic [XLEN-1:0]   in_immediate,
  input  logic [2:0]         in_funct3,
  input  ctrl_t              in_ctrl,

  output logic [XLEN-1:0]   out_pc,
  output logic [XLEN-1:0]   out_pc_plus4,
  output logic [XLEN-1:0]   out_rs1_data,
  output logic [XLEN-1:0]   out_rs2_data,
  output logic [RLEN-1:0]   out_rs1_addr,
  output logic [RLEN-1:0]   out_rs2_addr,
  output logic [RLEN-1:0]   out_rd_addr,
  output logic [XLEN-1:0]   out_immediate,
  output logic [2:0]         out_funct3,
  output ctrl_t              out_ctrl
);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n || flush) begin
      out_pc        <= '0;
      out_pc_plus4  <= '0;
      out_rs1_data  <= '0;
      out_rs2_data  <= '0;
      out_rs1_addr  <= '0;
      out_rs2_addr  <= '0;
      out_rd_addr   <= '0;
      out_immediate <= '0;
      out_funct3    <= '0;
      out_ctrl      <= ctrl_nop();
    end else if (!stall) begin
      out_pc        <= in_pc;
      out_pc_plus4  <= in_pc_plus4;
      out_rs1_data  <= in_rs1_data;
      out_rs2_data  <= in_rs2_data;
      out_rs1_addr  <= in_rs1_addr;
      out_rs2_addr  <= in_rs2_addr;
      out_rd_addr   <= in_rd_addr;
      out_immediate <= in_immediate;
      out_funct3    <= in_funct3;
      out_ctrl      <= in_ctrl;
    end
  end

endmodule : id_ex_reg


// ─────────────────────────────────────────────────────────────────────────────
// EX/MEM  pipeline register
// ─────────────────────────────────────────────────────────────────────────────
module ex_mem_reg (
  input  logic               clk,
  input  logic               rst_n,
  input  logic               flush,   // branch flush

  input  logic [XLEN-1:0]   in_alu_result,
  input  logic [XLEN-1:0]   in_rs2_data,   // forwarded store data
  input  logic [RLEN-1:0]   in_rd_addr,
  input  logic [XLEN-1:0]   in_pc_plus4,
  input  ctrl_t              in_ctrl,

  output logic [XLEN-1:0]   out_alu_result,
  output logic [XLEN-1:0]   out_rs2_data,
  output logic [RLEN-1:0]   out_rd_addr,
  output logic [XLEN-1:0]   out_pc_plus4,
  output ctrl_t              out_ctrl
);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n || flush) begin
      out_alu_result <= '0;
      out_rs2_data   <= '0;
      out_rd_addr    <= '0;
      out_pc_plus4   <= '0;
      out_ctrl       <= ctrl_nop();
    end else begin
      out_alu_result <= in_alu_result;
      out_rs2_data   <= in_rs2_data;
      out_rd_addr    <= in_rd_addr;
      out_pc_plus4   <= in_pc_plus4;
      out_ctrl       <= in_ctrl;
    end
  end

endmodule : ex_mem_reg


// ─────────────────────────────────────────────────────────────────────────────
// MEM/WB  pipeline register
// ─────────────────────────────────────────────────────────────────────────────
module mem_wb_reg (
  input  logic               clk,
  input  logic               rst_n,

  input  logic [XLEN-1:0]   in_alu_result,
  input  logic [XLEN-1:0]   in_mem_read_data,
  input  logic [RLEN-1:0]   in_rd_addr,
  input  logic [XLEN-1:0]   in_pc_plus4,
  input  ctrl_t              in_ctrl,

  output logic [XLEN-1:0]   out_alu_result,
  output logic [XLEN-1:0]   out_mem_read_data,
  output logic [RLEN-1:0]   out_rd_addr,
  output logic [XLEN-1:0]   out_pc_plus4,
  output ctrl_t              out_ctrl
);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      out_alu_result    <= '0;
      out_mem_read_data <= '0;
      out_rd_addr       <= '0;
      out_pc_plus4      <= '0;
      out_ctrl          <= ctrl_nop();
    end else begin
      out_alu_result    <= in_alu_result;
      out_mem_read_data <= in_mem_read_data;
      out_rd_addr       <= in_rd_addr;
      out_pc_plus4      <= in_pc_plus4;
      out_ctrl          <= in_ctrl;
    end
  end

endmodule : mem_wb_reg
