// =============================================================================
// forwarding_unit.sv — Operand Forwarding Unit
//
// Eliminates RAW (Read-After-Write) data hazards by forwarding results from
// later pipeline stages back to the EX stage multiplexers.
//
// Two forwarding paths are implemented:
//
//  ┌─────────────────────────────────────────────────────────────────────┐
//  │  EX → EX  (EX/MEM forward)                                         │
//  │  When: EX/MEM.reg_write  == 1  AND                                  │
//  │        EX/MEM.rd         != 0  AND                                  │
//  │        EX/MEM.rd         == ID/EX.rs1 (or rs2)                     │
//  │  Forward: EX/MEM ALU result into current EX operand                 │
//  ├─────────────────────────────────────────────────────────────────────┤
//  │  MEM → EX  (MEM/WB forward)                                        │
//  │  When: MEM/WB.reg_write  == 1  AND                                  │
//  │        MEM/WB.rd         != 0  AND                                  │
//  │        MEM/WB.rd         == ID/EX.rs1 (or rs2)  AND                │
//  │        NOT already covered by EX/MEM forward                        │
//  │  Forward: MEM/WB result (ALU or memory data) into current EX operand│
//  └─────────────────────────────────────────────────────────────────────┘
//
// Note: the WB→ID forwarding path is handled by the register file's built-in
// write-through behaviour, so no additional logic is required here.
// =============================================================================
`timescale 1ns/1ps
import cpu_pkg::*;

module forwarding_unit (
  // ── ID/EX register: sources of current instruction ───────────────────
  input  logic [RLEN-1:0]   id_ex_rs1,
  input  logic [RLEN-1:0]   id_ex_rs2,

  // ── EX/MEM register: result of instruction one stage ahead ───────────
  input  logic               ex_mem_reg_write,
  input  logic [RLEN-1:0]   ex_mem_rd,

  // ── MEM/WB register: result of instruction two stages ahead ──────────
  input  logic               mem_wb_reg_write,
  input  logic [RLEN-1:0]   mem_wb_rd,

  // ── Forwarding select outputs (fed to EX stage muxes) ────────────────
  output fwd_sel_t            fwd_a,   // select for ALU operand A (rs1)
  output fwd_sel_t            fwd_b    // select for ALU operand B (rs2)
);

  // ── Operand A forwarding ──────────────────────────────────────────────
  always_comb begin
    if (ex_mem_reg_write && (ex_mem_rd != '0) && (ex_mem_rd == id_ex_rs1))
      fwd_a = FWD_EX_MEM;
    else if (mem_wb_reg_write && (mem_wb_rd != '0) && (mem_wb_rd == id_ex_rs1))
      fwd_a = FWD_MEM_WB;
    else
      fwd_a = FWD_NONE;
  end

  // ── Operand B forwarding ──────────────────────────────────────────────
  always_comb begin
    if (ex_mem_reg_write && (ex_mem_rd != '0) && (ex_mem_rd == id_ex_rs2))
      fwd_b = FWD_EX_MEM;
    else if (mem_wb_reg_write && (mem_wb_rd != '0) && (mem_wb_rd == id_ex_rs2))
      fwd_b = FWD_MEM_WB;
    else
      fwd_b = FWD_NONE;
  end

endmodule : forwarding_unit
