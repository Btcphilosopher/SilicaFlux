// =============================================================================
// register_file.sv — 32×32 register file (x0 hardwired to 0)
//
// • Two asynchronous read ports (rs1, rs2)
// • One synchronous write port  (rd)
// • Write-through: if rd == rs1/rs2 and reg_write, read returns new value
//   (eliminates the need for an extra WB→ID forwarding path in the hazard
//    unit; the forwarding unit still handles EX/MEM and MEM/WB cases)
// =============================================================================
`timescale 1ns/1ps
import cpu_pkg::*;

module register_file (
  input  logic                clk,
  input  logic                rst_n,

  // Read port A
  input  logic [RLEN-1:0]     rs1_addr,
  output logic [XLEN-1:0]     rs1_data,

  // Read port B
  input  logic [RLEN-1:0]     rs2_addr,
  output logic [XLEN-1:0]     rs2_data,

  // Write port
  input  logic [RLEN-1:0]     rd_addr,
  input  logic [XLEN-1:0]     rd_data,
  input  logic                reg_write
);

  // ── Storage ───────────────────────────────────────────────────────────────
  logic [XLEN-1:0] regs [0:REGS-1];

  // ── Synchronous write (x0 stays 0) ───────────────────────────────────────
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < REGS; i++) regs[i] <= '0;
    end else begin
      if (reg_write && (rd_addr != '0))
        regs[rd_addr] <= rd_data;
    end
  end

  // ── Asynchronous read with write-through ─────────────────────────────────
  // If the write port addresses the same register being read (and reg_write
  // is asserted), return the new write value rather than the stale stored
  // value.  x0 always reads as zero.

  assign rs1_data = (rs1_addr == '0) ? '0 :
                    (reg_write && (rd_addr == rs1_addr)) ? rd_data :
                    regs[rs1_addr];

  assign rs2_data = (rs2_addr == '0) ? '0 :
                    (reg_write && (rd_addr == rs2_addr)) ? rd_data :
                    regs[rs2_addr];

endmodule : register_file
