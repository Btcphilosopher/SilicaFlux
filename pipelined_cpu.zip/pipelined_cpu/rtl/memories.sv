// =============================================================================
// memories.sv — Instruction ROM and Data RAM for simulation
//
// instruction_memory : synchronous read, word-addressed
//                      initialised via $readmemh / parameter array
// data_memory        : byte-addressable word RAM with byte/half/word access
// =============================================================================
`timescale 1ns/1ps
import cpu_pkg::*;

// ─────────────────────────────────────────────────────────────────────────────
// Instruction Memory (ROM)
// ─────────────────────────────────────────────────────────────────────────────
module instruction_memory #(
  parameter string INIT_FILE = ""           // optional $readmemh file
) (
  input  logic                clk,
  input  logic                rst_n,
  input  logic [XLEN-1:0]     pc,           // byte address (PC)
  output logic [ILEN-1:0]     instruction
);

  logic [ILEN-1:0] mem [0:IMEM_SZ-1];

  // ── Optional initialisation from hex file ──────────────────────────────
  initial begin
    for (int i = 0; i < IMEM_SZ; i++) mem[i] = NOP_INSTR;
    if (INIT_FILE != "") $readmemh(INIT_FILE, mem);
  end

  // ── Synchronous fetch (1-cycle latency) ───────────────────────────────
  // Word-aligned; lower 2 bits of PC ignored.
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) instruction <= NOP_INSTR;
    else        instruction <= mem[pc[XLEN-1:2]];
  end

  // ── Backdoor write port for testbench use ────────────────────────────
  task automatic backdoor_write(input int word_addr,
                                input logic [ILEN-1:0] data);
    mem[word_addr] = data;
  endtask

endmodule : instruction_memory


// ─────────────────────────────────────────────────────────────────────────────
// Data Memory (RAM)  — supports byte (lb/sb), halfword (lh/sh), word (lw/sw)
// ─────────────────────────────────────────────────────────────────────────────
module data_memory (
  input  logic               clk,
  input  logic               rst_n,

  // Address & control
  input  logic [XLEN-1:0]   addr,
  input  logic [2:0]         width,     // funct3: 000=byte 001=half 010=word
  input  logic               mem_read,
  input  logic               mem_write,

  // Data
  input  logic [XLEN-1:0]   write_data,
  output logic [XLEN-1:0]   read_data
);

  // Byte-addressed storage (word granularity internally)
  logic [7:0] mem [0:DMEM_SZ*4-1];

  initial begin
    for (int i = 0; i < DMEM_SZ*4; i++) mem[i] = 8'h00;
  end

  // ── Synchronous write ────────────────────────────────────────────────
  always_ff @(posedge clk) begin
    if (mem_write) begin
      unique case (width[1:0])
        2'b00: begin  // byte
          mem[addr]   <= write_data[7:0];
        end
        2'b01: begin  // halfword
          mem[addr]   <= write_data[7:0];
          mem[addr+1] <= write_data[15:8];
        end
        2'b10: begin  // word
          mem[addr]   <= write_data[7:0];
          mem[addr+1] <= write_data[15:8];
          mem[addr+2] <= write_data[23:16];
          mem[addr+3] <= write_data[31:24];
        end
        default: ; // no-op
      endcase
    end
  end

  // ── Combinational read (registered address, immediate data) ──────────
  // Sign extension controlled by width[2] (0=signed, 1=unsigned)
  logic [XLEN-1:0] rd_raw;

  always_comb begin
    rd_raw = '0;
    if (mem_read) begin
      unique case (width[1:0])
        2'b00: rd_raw = width[2]
          ? {{24{1'b0}}, mem[addr]}          // LBU
          : {{24{mem[addr][7]}}, mem[addr]}; // LB
        2'b01: rd_raw = width[2]
          ? {{16{1'b0}}, mem[addr+1], mem[addr]}
          : {{16{mem[addr+1][7]}}, mem[addr+1], mem[addr]};
        2'b10: rd_raw = {mem[addr+3], mem[addr+2], mem[addr+1], mem[addr]};
        default: rd_raw = '0;
      endcase
    end
  end

  assign read_data = rd_raw;

endmodule : data_memory
