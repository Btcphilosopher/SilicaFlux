// =============================================================================
// cpu_top.sv — Top-Level 5-Stage Pipelined RV32I CPU
//
//  Pipeline stages:
//  ┌────┐   ┌────┐   ┌────┐   ┌─────┐   ┌────┐
//  │ IF │──▶│ ID │──▶│ EX │──▶│ MEM │──▶│ WB │
//  └────┘   └────┘   └────┘   └─────┘   └────┘
//     ▲         │       │         │         │
//     └─ Hazard ┘       │   Fwding│         │ WB→RF
//     └──────── Forwarding Unit ──┘
//
//  Forwarding:   EX/MEM → EX  and  MEM/WB → EX
//  Hazard:       load-use stall (1 cycle)
//                branch/jump flush (2 cycles squashed)
// =============================================================================
`timescale 1ns/1ps
import cpu_pkg::*;

module cpu_top #(
  parameter string IMEM_INIT_FILE = ""
) (
  input  logic clk,
  input  logic rst_n,

  // ── Debug / observation ports ─────────────────────────────────────────
  output logic [XLEN-1:0] dbg_pc,
  output logic [XLEN-1:0] dbg_instr,
  output logic [XLEN-1:0] dbg_alu_result,
  output logic [RLEN-1:0] dbg_rd_addr,
  output logic [XLEN-1:0] dbg_rd_data,
  output logic             dbg_reg_write,
  output logic             dbg_stall,
  output logic             dbg_branch_taken
);

  // ══════════════════════════════════════════════════════════════════════
  // Internal signal declarations
  // ══════════════════════════════════════════════════════════════════════

  // ── Hazard / flush control ────────────────────────────────────────────
  logic stall_if, stall_id, flush_ex, flush_if, flush_id;
  logic branch_taken, jump_signal;
  logic [XLEN-1:0] branch_target;

  // ── IF stage ──────────────────────────────────────────────────────────
  logic [XLEN-1:0] if_pc, if_pc_plus4;

  // ── IF/ID register ────────────────────────────────────────────────────
  logic [XLEN-1:0] ifid_pc, ifid_pc_plus4;
  logic [ILEN-1:0] ifid_instr;

  // ── ID stage ──────────────────────────────────────────────────────────
  logic [RLEN-1:0] id_rs1_addr, id_rs2_addr, id_rd_addr;
  logic [XLEN-1:0] id_immediate;
  logic [2:0]      id_funct3;
  logic [6:0]      id_funct7;
  ctrl_t           id_ctrl;

  // ── Register file outputs ─────────────────────────────────────────────
  logic [XLEN-1:0] rf_rs1_data, rf_rs2_data;

  // ── ID/EX register ────────────────────────────────────────────────────
  logic [XLEN-1:0] idex_pc, idex_pc_plus4;
  logic [XLEN-1:0] idex_rs1_data, idex_rs2_data;
  logic [RLEN-1:0] idex_rs1_addr, idex_rs2_addr, idex_rd_addr;
  logic [XLEN-1:0] idex_immediate;
  logic [2:0]      idex_funct3;
  ctrl_t           idex_ctrl;

  // ── EX stage ──────────────────────────────────────────────────────────
  logic [XLEN-1:0] ex_alu_result, ex_rs2_fwd;
  fwd_sel_t        fwd_a, fwd_b;

  // ── EX/MEM register ───────────────────────────────────────────────────
  logic [XLEN-1:0] exmem_alu_result, exmem_rs2_data, exmem_pc_plus4;
  logic [RLEN-1:0] exmem_rd_addr;
  ctrl_t           exmem_ctrl;

  // ── MEM stage ─────────────────────────────────────────────────────────
  logic [XLEN-1:0] dmem_addr, dmem_wdata, dmem_rdata;
  logic            dmem_mr, dmem_mw;
  logic [2:0]      dmem_width;
  logic [XLEN-1:0] mem_alu_out, mem_rdata_out;

  // ── MEM/WB register ───────────────────────────────────────────────────
  logic [XLEN-1:0] memwb_alu_result, memwb_mem_rdata, memwb_pc_plus4;
  logic [RLEN-1:0] memwb_rd_addr;
  ctrl_t           memwb_ctrl;

  // ── WB stage ──────────────────────────────────────────────────────────
  logic [XLEN-1:0] wb_rd_data;
  logic            wb_reg_write;

  // ── MEM/WB forwarding result (ALU or load data) ───────────────────────
  logic [XLEN-1:0] memwb_result;   // what WB would write back
  assign memwb_result = memwb_ctrl.mem_to_reg ? memwb_mem_rdata : memwb_alu_result;

  // ══════════════════════════════════════════════════════════════════════
  // Stage & module instantiations
  // ══════════════════════════════════════════════════════════════════════

  // ── IF stage ──────────────────────────────────────────────────────────
  if_stage u_if (
    .clk            (clk),
    .rst_n          (rst_n),
    .stall_if       (stall_if),
    .flush_if       (flush_if),
    .branch_taken   (branch_taken),
    .jump           (jump_signal),
    .branch_target  (branch_target),
    .pc_out         (if_pc),
    .pc_plus4       (if_pc_plus4)
  );

  // ── Instruction memory ────────────────────────────────────────────────
  logic [ILEN-1:0] imem_instr;

  instruction_memory #(.INIT_FILE(IMEM_INIT_FILE)) u_imem (
    .clk         (clk),
    .rst_n       (rst_n),
    .pc          (if_pc),
    .instruction (imem_instr)
  );

  // ── IF/ID register ────────────────────────────────────────────────────
  if_id_reg u_ifid (
    .clk          (clk),
    .rst_n        (rst_n),
    .stall        (stall_id),
    .flush        (flush_if),
    .in_pc        (if_pc),
    .in_pc_plus4  (if_pc_plus4),
    .in_instr     (imem_instr),
    .out_pc       (ifid_pc),
    .out_pc_plus4 (ifid_pc_plus4),
    .out_instr    (ifid_instr)
  );

  // ── ID stage ──────────────────────────────────────────────────────────
  id_stage u_id (
    .instruction  (ifid_instr),
    .rs1_addr     (id_rs1_addr),
    .rs2_addr     (id_rs2_addr),
    .rd_addr      (id_rd_addr),
    .immediate    (id_immediate),
    .ctrl         (id_ctrl),
    .funct3       (id_funct3),
    .funct7       (id_funct7)
  );

  // ── Register file ─────────────────────────────────────────────────────
  register_file u_rf (
    .clk       (clk),
    .rst_n     (rst_n),
    .rs1_addr  (id_rs1_addr),
    .rs1_data  (rf_rs1_data),
    .rs2_addr  (id_rs2_addr),
    .rs2_data  (rf_rs2_data),
    .rd_addr   (memwb_rd_addr),
    .rd_data   (wb_rd_data),
    .reg_write (wb_reg_write)
  );

  // ── ID/EX register ────────────────────────────────────────────────────
  id_ex_reg u_idex (
    .clk          (clk),
    .rst_n        (rst_n),
    .stall        (1'b0),       // ID/EX never stalls (only flushed)
    .flush        (flush_ex || flush_id),
    .in_pc        (ifid_pc),
    .in_pc_plus4  (ifid_pc_plus4),
    .in_rs1_data  (rf_rs1_data),
    .in_rs2_data  (rf_rs2_data),
    .in_rs1_addr  (id_rs1_addr),
    .in_rs2_addr  (id_rs2_addr),
    .in_rd_addr   (id_rd_addr),
    .in_immediate (id_immediate),
    .in_funct3    (id_funct3),
    .in_ctrl      (id_ctrl),
    .out_pc       (idex_pc),
    .out_pc_plus4 (idex_pc_plus4),
    .out_rs1_data (idex_rs1_data),
    .out_rs2_data (idex_rs2_data),
    .out_rs1_addr (idex_rs1_addr),
    .out_rs2_addr (idex_rs2_addr),
    .out_rd_addr  (idex_rd_addr),
    .out_immediate(idex_immediate),
    .out_funct3   (idex_funct3),
    .out_ctrl     (idex_ctrl)
  );

  // ── Forwarding unit ───────────────────────────────────────────────────
  forwarding_unit u_fwd (
    .id_ex_rs1         (idex_rs1_addr),
    .id_ex_rs2         (idex_rs2_addr),
    .ex_mem_reg_write  (exmem_ctrl.reg_write),
    .ex_mem_rd         (exmem_rd_addr),
    .mem_wb_reg_write  (memwb_ctrl.reg_write),
    .mem_wb_rd         (memwb_rd_addr),
    .fwd_a             (fwd_a),
    .fwd_b             (fwd_b)
  );

  // ── EX stage ──────────────────────────────────────────────────────────
  ex_stage u_ex (
    .rs1_data       (idex_rs1_data),
    .rs2_data       (idex_rs2_data),
    .immediate      (idex_immediate),
    .pc_id_ex       (idex_pc),
    .ctrl           (idex_ctrl),
    .funct3         (idex_funct3),
    .fwd_a          (fwd_a),
    .fwd_b          (fwd_b),
    .ex_mem_result  (exmem_alu_result),
    .mem_wb_result  (memwb_result),
    .alu_result     (ex_alu_result),
    .rs2_forwarded  (ex_rs2_fwd),
    .branch_taken   (branch_taken),
    .jump_out       (jump_signal),
    .branch_target  (branch_target)
  );

  // ── EX/MEM register ───────────────────────────────────────────────────
  ex_mem_reg u_exmem (
    .clk            (clk),
    .rst_n          (rst_n),
    .flush          (1'b0),     // EX/MEM never flushed (branch resolved in EX)
    .in_alu_result  (ex_alu_result),
    .in_rs2_data    (ex_rs2_fwd),
    .in_rd_addr     (idex_rd_addr),
    .in_pc_plus4    (idex_pc_plus4),
    .in_ctrl        (idex_ctrl),
    .out_alu_result (exmem_alu_result),
    .out_rs2_data   (exmem_rs2_data),
    .out_rd_addr    (exmem_rd_addr),
    .out_pc_plus4   (exmem_pc_plus4),
    .out_ctrl       (exmem_ctrl)
  );

  // ── Hazard detection unit ─────────────────────────────────────────────
  hazard_unit u_hazard (
    .id_ex_mem_read  (idex_ctrl.mem_read),
    .id_ex_rd        (idex_rd_addr),
    .if_id_rs1       (id_rs1_addr),
    .if_id_rs2       (id_rs2_addr),
    .branch_taken    (branch_taken),
    .jump            (jump_signal),
    .stall_if        (stall_if),
    .stall_id        (stall_id),
    .flush_ex        (flush_ex),
    .flush_if        (flush_if),
    .flush_id        (flush_id)
  );

  // ── MEM stage ─────────────────────────────────────────────────────────
  mem_stage u_mem (
    .alu_result       (exmem_alu_result),
    .rs2_data         (exmem_rs2_data),
    .ctrl             (exmem_ctrl),
    .dmem_addr        (dmem_addr),
    .dmem_write_data  (dmem_wdata),
    .dmem_mem_read    (dmem_mr),
    .dmem_mem_write   (dmem_mw),
    .dmem_width       (dmem_width),
    .dmem_read_data   (dmem_rdata),
    .mem_read_data    (mem_rdata_out),
    .alu_result_out   (mem_alu_out)
  );

  // ── Data memory ───────────────────────────────────────────────────────
  data_memory u_dmem (
    .clk        (clk),
    .rst_n      (rst_n),
    .addr       (dmem_addr),
    .width      (dmem_width),
    .mem_read   (dmem_mr),
    .mem_write  (dmem_mw),
    .write_data (dmem_wdata),
    .read_data  (dmem_rdata)
  );

  // ── MEM/WB register ───────────────────────────────────────────────────
  mem_wb_reg u_memwb (
    .clk               (clk),
    .rst_n             (rst_n),
    .in_alu_result     (mem_alu_out),
    .in_mem_read_data  (mem_rdata_out),
    .in_rd_addr        (exmem_rd_addr),
    .in_pc_plus4       (exmem_pc_plus4),
    .in_ctrl           (exmem_ctrl),
    .out_alu_result    (memwb_alu_result),
    .out_mem_read_data (memwb_mem_rdata),
    .out_rd_addr       (memwb_rd_addr),
    .out_pc_plus4      (memwb_pc_plus4),
    .out_ctrl          (memwb_ctrl)
  );

  // ── WB stage ──────────────────────────────────────────────────────────
  wb_stage u_wb (
    .alu_result    (memwb_alu_result),
    .mem_read_data (memwb_mem_rdata),
    .pc_plus4      (memwb_pc_plus4),
    .ctrl          (memwb_ctrl),
    .rd_data       (wb_rd_data),
    .reg_write_out (wb_reg_write)
  );

  // ══════════════════════════════════════════════════════════════════════
  // Debug observation outputs
  // ══════════════════════════════════════════════════════════════════════
  assign dbg_pc           = if_pc;
  assign dbg_instr        = ifid_instr;
  assign dbg_alu_result   = ex_alu_result;
  assign dbg_rd_addr      = memwb_rd_addr;
  assign dbg_rd_data      = wb_rd_data;
  assign dbg_reg_write    = wb_reg_write;
  assign dbg_stall        = stall_if;
  assign dbg_branch_taken = branch_taken;

endmodule : cpu_top
