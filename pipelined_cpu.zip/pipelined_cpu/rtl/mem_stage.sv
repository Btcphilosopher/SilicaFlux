// =============================================================================
// mem_stage.sv — Memory Access Stage
//
// Responsibilities:
//   • Route ALU result as memory address for loads/stores
//   • Route forwarded rs2 as store data
//   • Present read data from data memory to WB stage
//   • Pass-through ALU result for non-memory instructions
// =============================================================================
`timescale 1ns/1ps
import cpu_pkg::*;

module mem_stage (
  // ── From EX/MEM register ─────────────────────────────────────────────
  input  logic [XLEN-1:0]   alu_result,     // address or arithmetic result
  input  logic [XLEN-1:0]   rs2_data,       // store data (already forwarded)
  input  ctrl_t              ctrl,

  // ── Data memory interface ─────────────────────────────────────────────
  output logic [XLEN-1:0]   dmem_addr,
  output logic [XLEN-1:0]   dmem_write_data,
  output logic               dmem_mem_read,
  output logic               dmem_mem_write,
  output logic [2:0]         dmem_width,

  // ── Read data back from data_memory (combinational) ───────────────────
  input  logic [XLEN-1:0]   dmem_read_data,

  // ── Outputs to MEM/WB register ───────────────────────────────────────
  output logic [XLEN-1:0]   mem_read_data,
  output logic [XLEN-1:0]   alu_result_out
);

  // Wire up memory control signals
  assign dmem_addr        = alu_result;
  assign dmem_write_data  = rs2_data;
  assign dmem_mem_read    = ctrl.mem_read;
  assign dmem_mem_write   = ctrl.mem_write;
  assign dmem_width       = ctrl.mem_width;

  // Pass results to pipeline register
  assign mem_read_data  = dmem_read_data;
  assign alu_result_out = alu_result;

endmodule : mem_stage
