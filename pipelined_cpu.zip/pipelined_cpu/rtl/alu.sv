// =============================================================================
// alu.sv — 32-bit Arithmetic Logic Unit
//
// Supports all RV32I computational operations.  Purely combinational.
// Zero flag used by branch logic in the EX stage.
// =============================================================================
`timescale 1ns/1ps
import cpu_pkg::*;

module alu (
  input  logic [XLEN-1:0] operand_a,  // rs1 (or PC for AUIPC/JAL)
  input  logic [XLEN-1:0] operand_b,  // rs2 or immediate
  input  alu_op_t         alu_op,

  output logic [XLEN-1:0] result,
  output logic            zero,       // result == 0 (branch condition)
  output logic            negative,   // result[31]  (signed compare)
  output logic            overflow    // signed arithmetic overflow
);

  logic [XLEN:0]   add_ext;   // one extra bit for carry
  logic [XLEN-1:0] sub_res;
  logic            borrow;

  // ── Shared adder/subtractor ────────────────────────────────────────────
  assign add_ext = {1'b0, operand_a} + {1'b0, operand_b};
  assign {borrow, sub_res} = {1'b0, operand_a} - {1'b0, operand_b};

  // ── Overflow detection (signed ADD/SUB) ───────────────────────────────
  assign overflow = (alu_op == ALU_ADD)
    ? (operand_a[XLEN-1] == operand_b[XLEN-1]) && (result[XLEN-1] != operand_a[XLEN-1])
    : (operand_a[XLEN-1] != operand_b[XLEN-1]) && (result[XLEN-1] != operand_a[XLEN-1]);

  // ── Main operation mux ────────────────────────────────────────────────
  always_comb begin
    unique case (alu_op)
      ALU_ADD  : result = add_ext[XLEN-1:0];
      ALU_SUB  : result = sub_res;
      ALU_AND  : result = operand_a & operand_b;
      ALU_OR   : result = operand_a | operand_b;
      ALU_XOR  : result = operand_a ^ operand_b;
      ALU_SLL  : result = operand_a << operand_b[4:0];
      ALU_SRL  : result = operand_a >> operand_b[4:0];
      ALU_SRA  : result = $signed(operand_a) >>> operand_b[4:0];
      ALU_SLT  : result = {{(XLEN-1){1'b0}},
                            $signed(operand_a) < $signed(operand_b)};
      ALU_SLTU : result = {{(XLEN-1){1'b0}},
                            operand_a < operand_b};
      ALU_PASS : result = operand_b;          // LUI: pass immediate
      default  : result = '0;
    endcase
  end

  assign zero     = (result == '0);
  assign negative = result[XLEN-1];

endmodule : alu
