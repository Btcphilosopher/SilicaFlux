# Pipelined RV32I CPU — SystemVerilog Implementation

A fully-modular, 5-stage pipelined processor implementing a subset of the
RISC-V RV32I instruction set, written in synthesisable SystemVerilog.

---

## Architecture Overview

```
        ┌──────────────────────────────────────────────────────────────────────┐
        │                  5-Stage Pipeline                                    │
        │                                                                      │
  ┌─────┴─────┐  IF/ID  ┌─────────┐  ID/EX  ┌─────────┐  EX/MEM  ┌────────┐│
  │     IF    │════════▶│   ID    │════════▶│   EX    │══════════▶│  MEM  ││
  │  Fetch +  │         │ Decode  │         │  ALU +  │           │ R/W   ││
  │  PC logic │         │ Control │         │  Fwd Mx │           │ Data  ││
  └─────┬─────┘         └────┬────┘         └────┬────┘           └───┬───┘│
        │                    │                   │                     │    │
        │          ┌─────────┴──────────────────▼──────────────────── │ ──▶│
        │          │         Forwarding Unit (EX/MEM → EX, MEM/WB → EX)   │
        │          │                                                        │
        ◀──────────┴─── Hazard Unit (load-use stall, branch flush) ────────▶│
        └──────────────────────────────────────────────────────────────────┘
                                                           │  MEM/WB
                                                      ┌────▼────┐
                                                      │   WB    │
                                                      │ Writeback│
                                                      └─────────┘
```

### Data Hazard Resolution

```
  Instruction    IF    ID    EX   MEM    WB
  ─────────────────────────────────────────
  ADD x3,x1,x2   1     2     3     4     5
  ADD x4,x3,x5         1     2     3     4   ← needs x3 from EX/MEM → forward
  ADD x5,x3,x6               1     2     3   ← needs x3 from MEM/WB → forward
```

**Load-Use Stall (1 bubble):**

```
  Instruction    IF    ID    EX   MEM    WB
  ─────────────────────────────────────────
  LW  x3, 0(x1)  1     2     3     4     5
  ADD x4,x3,x5         1    [stall] 3   4    ← bubble inserted; x3 ready after MEM
```

**Branch/Jump Flush (2 squashed instructions):**

```
  Instruction    IF    ID    EX   MEM    WB
  ─────────────────────────────────────────
  BEQ x1,x2,tgt  1     2     3     4     5   ← branch resolved at end of EX
  (wrong path)         ×     ×              ← squashed (flushed)
  tgt: ADDI …               1     2     3
```

---

## File Structure

```
pipelined_cpu/
├── rtl/
│   ├── cpu_pkg.sv          Shared types, enumerations, constants
│   ├── cpu_top.sv          Top-level integration
│   ├── if_stage.sv         Instruction Fetch (PC + next-PC mux)
│   ├── id_stage.sv         Decode + Control Unit + Immediate generator
│   ├── ex_stage.sv         Execute (forwarding muxes + ALU + branch)
│   ├── mem_stage.sv        Memory Access (address/data routing)
│   ├── wb_stage.sv         Write-Back (result mux → register file)
│   ├── pipeline_regs.sv    IF/ID, ID/EX, EX/MEM, MEM/WB registers
│   ├── register_file.sv    32×32 RF with write-through read ports
│   ├── alu.sv              32-bit ALU (all RV32I ops)
│   ├── memories.sv         Instruction ROM + byte-addressed Data RAM
│   ├── hazard_unit.sv      Load-use stall + branch/jump flush
│   └── forwarding_unit.sv  EX/MEM→EX and MEM/WB→EX forwarding
├── tb/
│   └── cpu_tb.sv           Self-checking testbench (7 test groups)
├── sim/                    Generated simulation artefacts
├── Makefile
└── README.md
```

---

## Supported Instructions

| Category     | Instructions                                     |
|------------- |--------------------------------------------------|
| R-type       | ADD, SUB, AND, OR, XOR, SLL, SRL, SRA, SLT, SLTU|
| I-type ALU   | ADDI, ANDI, ORI, XORI, SLTI, SLTIU, SLLI, SRLI, SRAI |
| Loads        | LW, LH, LB, LHU, LBU                            |
| Stores       | SW, SH, SB                                       |
| Branches     | BEQ, BNE, BLT, BGE, BLTU, BGEU                  |
| Jumps        | JAL, JALR                                        |
| Upper imm    | LUI, AUIPC                                       |

---

## Hazard Handling Summary

| Hazard Type         | Detection                              | Resolution              |
|---------------------|----------------------------------------|-------------------------|
| EX→EX RAW           | `EX/MEM.rd == ID/EX.rs1/rs2`          | Forward EX/MEM result   |
| MEM→EX RAW          | `MEM/WB.rd == ID/EX.rs1/rs2`          | Forward MEM/WB result   |
| Load-use            | `ID/EX.mem_read && ID/EX.rd == rs1/2` | Stall 1 cycle + bubble  |
| Branch/Jump taken   | Resolved at end of EX stage            | Flush IF/ID, ID/EX      |
| WB→ID RAW           | `WB.rd == ID.rs1/rs2`                  | Register file write-through |

---

## Quick Start

### Prerequisites

- [Verilator](https://verilator.org) ≥ 5.0 (default)
- OR Synopsys VCS, Cadence Xcelium, or Icarus Verilog

### Simulate

```bash
# Default: Verilator
make sim

# Icarus Verilog
make iverilog

# Lint check only
make lint

# Open waveforms
make waves
```

### Expected Output

```
╔══════════════════════════════════════════════════════════════╗
║   5-Stage Pipelined RV32I CPU — Verification Suite          ║
╚══════════════════════════════════════════════════════════════╝

═══ TEST 1: R-Type Arithmetic ═══════════════════════════════
  PASS  ADDI x1=15                       x1  = 0x0000000f
  PASS  ADDI x2=7                        x2  = 0x00000007
  PASS  ADD  x3=22                       x3  = 0x00000016
  ...
═══ TEST 3: EX→EX Data Forwarding ══════════════════════════
  (back-to-back RAW: result of inst N used by inst N+1)
  PASS  FWD  x2=20 (x1+x1)              x2  = 0x00000014
  ...
═══ TEST 4: Load-Use Stall ══════════════════════════════════
  INFO  Observed 1 stall cycle(s) (expected ≥1)
  PASS  Load-use stall detected
  ...

╔══════════════════════════════════════════════════════════════╗
║  RESULTS:  28 PASS   0 FAIL   (28 total)   ✓ ALL PASS      ║
╚══════════════════════════════════════════════════════════════╝
```

---

## Extending the Design

### Adding a new instruction
1. Add opcode/funct constants in `cpu_pkg.sv`
2. Add decode logic in `id_stage.sv` `always_comb` block
3. Add ALU operation in `alu.sv` if needed
4. Add test case in `cpu_tb.sv`

### Adding a CSR file (Zicsr extension)
- Add `csr_file.sv` module
- Extend `ctrl_t` with `csr_op` field
- Wire read/write port into `ex_stage.sv`

### Adding a multiply/divide unit (M extension)
- Add `mul_div_unit.sv` (multi-cycle or pipelined)
- Extend hazard unit to stall while unit is busy
- Add result bypass into forwarding unit

### Pipeline depth increase
- Insert additional pipeline registers in `pipeline_regs.sv`
- Adjust hazard detection window in `hazard_unit.sv`
- Adjust forwarding comparisons in `forwarding_unit.sv`

---

## Design Notes

- **Synchronous instruction memory** introduces 1-cycle fetch latency (realistic
  for SRAM; change to async for FPGA block RAM inference if needed).
- **Branch resolution in EX** causes a 2-cycle penalty on taken branches.
  Moving resolution to ID (for BEQ/BNE only) would reduce this to 1.
- **Register file write-through** eliminates the WB→ID forwarding path,
  simplifying the hazard unit at the cost of a slightly more complex RF.
- All pipeline registers support independent `stall` and `flush` controls,
  making the design straightforward to extend.
