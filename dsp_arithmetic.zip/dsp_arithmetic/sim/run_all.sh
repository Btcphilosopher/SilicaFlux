#!/usr/bin/env bash
# =============================================================================
# sim/run_all.sh
# Simulation runner for DSP Arithmetic repository
#
# Supports: Icarus Verilog (iverilog) and Synopsys VCS
# Usage:
#   ./run_all.sh             – run all testbenches with iverilog
#   ./run_all.sh vcs         – run all testbenches with VCS
#   ./run_all.sh <tb_name>   – run single testbench (e.g. tb_mac_unit)
# =============================================================================

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RTL_DIR="$REPO_ROOT/rtl"
TB_DIR="$REPO_ROOT/tb"
OUT_DIR="$REPO_ROOT/sim/out"
mkdir -p "$OUT_DIR"

# ─────────────────────────────────────────────────────────────────────────────
# Colour helpers
# ─────────────────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

pass_total=0
fail_total=0
skipped=0

# ─────────────────────────────────────────────────────────────────────────────
# Tool detection
# ─────────────────────────────────────────────────────────────────────────────
SIM="${1:-iverilog}"

if [[ "$SIM" == "vcs" ]]; then
  if ! command -v vcs &>/dev/null; then
    echo -e "${RED}ERROR: vcs not found on PATH${NC}"
    exit 1
  fi
  echo -e "${CYAN}Simulator: Synopsys VCS${NC}"
else
  if ! command -v iverilog &>/dev/null; then
    echo -e "${RED}ERROR: iverilog not found. Install with: sudo apt-get install iverilog${NC}"
    exit 1
  fi
  SIM="iverilog"
  echo -e "${CYAN}Simulator: Icarus Verilog $(iverilog -V 2>&1 | head -1)${NC}"
fi

# ─────────────────────────────────────────────────────────────────────────────
# Testbench list: name → source files (relative to repo root)
# ─────────────────────────────────────────────────────────────────────────────
declare -A TB_SRCS
TB_SRCS=(
  [tb_fixed_point]="rtl/fixed_point_pkg.sv tb/tb_fixed_point.sv"
  [tb_sat_arith]="rtl/fixed_point_pkg.sv rtl/sat_arith.sv tb/tb_sat_arith.sv"
  [tb_mac_unit]="rtl/fixed_point_pkg.sv rtl/mac_unit.sv tb/tb_mac_unit.sv"
  [tb_fir_filter]="rtl/fixed_point_pkg.sv rtl/fir_filter.sv tb/tb_fir_filter.sv"
  [tb_fft_butterfly]="rtl/fixed_point_pkg.sv rtl/fft_butterfly_r2.sv tb/tb_fft_butterfly.sv"
)

# ─────────────────────────────────────────────────────────────────────────────
# If a specific testbench was requested, override list
# ─────────────────────────────────────────────────────────────────────────────
if [[ -n "${2:-}" ]]; then
  tb_arg="${2}"
  if [[ -z "${TB_SRCS[$tb_arg]:-}" ]]; then
    echo -e "${RED}Unknown testbench: $tb_arg${NC}"
    echo "Available: ${!TB_SRCS[*]}"
    exit 1
  fi
  declare -A TB_RUN
  TB_RUN=( [$tb_arg]="${TB_SRCS[$tb_arg]}" )
else
  declare -A TB_RUN
  for k in "${!TB_SRCS[@]}"; do TB_RUN[$k]="${TB_SRCS[$k]}"; done
fi

# ─────────────────────────────────────────────────────────────────────────────
# Run function
# ─────────────────────────────────────────────────────────────────────────────
run_tb() {
  local name="$1"
  local srcs="$2"
  local logfile="$OUT_DIR/${name}.log"
  local result=0

  echo -e "\n${BOLD}▶  Running ${name}${NC}"
  echo "   Sources: $srcs"

  # Build absolute paths
  abs_srcs=""
  for s in $srcs; do
    abs_srcs="$abs_srcs $REPO_ROOT/$s"
  done

  if [[ "$SIM" == "iverilog" ]]; then
    # Compile
    if iverilog -g2012 -Wall                          \
        -I"$RTL_DIR"                                   \
        -o "$OUT_DIR/${name}.out"                      \
        $abs_srcs                                      \
        > "$logfile" 2>&1 ; then
      # Simulate
      cd "$OUT_DIR"
      if vvp "${name}.out" >> "$logfile" 2>&1 ; then
        result=0
      else
        result=1
      fi
      cd "$REPO_ROOT"
    else
      result=1
    fi
  else
    # VCS compile + simulate
    if vcs -sverilog -full64 -timescale=1ns/1ps       \
        +incdir+"$RTL_DIR"                             \
        -l "$logfile"                                  \
        -o "$OUT_DIR/${name}.simv"                     \
        $abs_srcs                                      \
        > /dev/null 2>&1 ; then
      "$OUT_DIR/${name}.simv" >> "$logfile" 2>&1 || result=1
    else
      result=1
    fi
  fi

  # Parse pass/fail from log
  local p f
  p=$(grep -c "\[PASS\]" "$logfile" 2>/dev/null || true)
  f=$(grep -c "\[FAIL\]" "$logfile" 2>/dev/null || true)
  pass_total=$((pass_total + p))
  fail_total=$((fail_total + f))

  # Show last summary line from log
  tail -5 "$logfile" | grep -E "(PASS|FAIL|RESULTS)" || true

  if [[ $result -eq 0 && $f -eq 0 ]]; then
    echo -e "   ${GREEN}✔  PASSED${NC}  ($p assertions)"
  else
    echo -e "   ${RED}✘  FAILED${NC}  ($p pass, $f fail)"
    echo -e "   Log: $logfile"
  fi

  return $result
}

# ─────────────────────────────────────────────────────────────────────────────
# Main loop
# ─────────────────────────────────────────────────────────────────────────────
echo -e "\n${BOLD}═══════════════════════════════════════════════"
echo -e " DSP Arithmetic – Regression Suite"
echo -e "═══════════════════════════════════════════════${NC}"

overall=0
for tb in "${!TB_RUN[@]}"; do
  run_tb "$tb" "${TB_RUN[$tb]}" || overall=1
done

# ─────────────────────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────────────────────
echo -e "\n${BOLD}═══════════════════════════════════════════════"
echo -e " Regression Summary"
echo -e "═══════════════════════════════════════════════${NC}"
echo -e "  Testbenches : $(echo "${!TB_RUN[@]}" | wc -w)"
echo -e "  Assertions  : ${GREEN}$pass_total PASS${NC}  /  ${RED}$fail_total FAIL${NC}"

if [[ $overall -eq 0 && $fail_total -eq 0 ]]; then
  echo -e "\n  ${GREEN}${BOLD}ALL TESTS PASSED${NC}"
else
  echo -e "\n  ${RED}${BOLD}FAILURES DETECTED – check logs in $OUT_DIR/${NC}"
fi
echo ""
exit $overall
