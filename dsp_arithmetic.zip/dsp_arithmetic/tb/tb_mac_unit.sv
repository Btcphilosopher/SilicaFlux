// =============================================================================
// tb_mac_unit.sv
// Testbench – MAC Unit
//
// Test sequences:
//   1. Single accumulation: load one product, read result
//   2. Dot-product: N consecutive a×b pairs, compare to golden model
//   3. Clear-and-restart: verify clr zeroes accumulator correctly
//   4. Overflow accumulation: drive inputs that should saturate
//   5. Back-to-back clr: rapid alternating accumulations
//   6. Latency check: verify vld arrives exactly LATENCY cycles after en
// =============================================================================

`timescale 1ns/1ps
`include "../rtl/fixed_point_pkg.sv"
`include "../rtl/mac_unit.sv"

import fixed_point_pkg::*;

module tb_mac_unit;

  // -------------------------------------------------------------------------
  // Clocking
  // -------------------------------------------------------------------------
  localparam real CLK_PERIOD = 10.0;
  logic clk = 0;
  logic rst_n = 0;
  always #(CLK_PERIOD/2) clk = ~clk;

  // -------------------------------------------------------------------------
  // DUT parameters
  // -------------------------------------------------------------------------
  localparam int DATA_W      = 16;
  localparam int FRAC_W      = 8;
  localparam int ACC_EXTRA_W = 8;
  localparam int REG_IN      = 1;
  localparam int LATENCY     = REG_IN + 3;

  // -------------------------------------------------------------------------
  // DUT I/O
  // -------------------------------------------------------------------------
  logic                                   en, clr;
  logic signed [DATA_W-1:0]               a_in, b_in;
  logic signed [DATA_W-1:0]               result;
  logic signed [DATA_W+ACC_EXTRA_W-1:0]   acc_out;
  logic                                   vld, ovf;

  mac_unit #(
    .DATA_W          (DATA_W),
    .FRAC_W          (FRAC_W),
    .ACC_EXTRA_W     (ACC_EXTRA_W),
    .REGISTER_INPUTS (REG_IN),
    .SATURATE        (1)
  ) dut (
    .clk     (clk),
    .rst_n   (rst_n),
    .en      (en),
    .clr     (clr),
    .a       (a_in),
    .b       (b_in),
    .result  (result),
    .acc_out (acc_out),
    .vld     (vld),
    .ovf     (ovf)
  );

  // -------------------------------------------------------------------------
  // Test infrastructure
  // -------------------------------------------------------------------------
  int pass_cnt = 0;
  int fail_cnt = 0;

  // Golden accumulator model (full 64-bit, no saturation for reference)
  real gold_acc;

  // Convert fixed-point Q(DATA_W-FRAC_W).FRAC_W to real
  function automatic real fp_to_real(input logic signed [DATA_W-1:0] v);
    return real'($signed(v)) / (2.0**FRAC_W);
  endfunction

  // Expected accumulation of a×b (both in Q(DATA_W-FRAC_W).FRAC_W)
  function automatic real fp_mul_real(
    input logic signed [DATA_W-1:0] a,
    input logic signed [DATA_W-1:0] b
  );
    longint prod;
    prod = longint'($signed(a)) * longint'($signed(b));
    return real'(prod) / (2.0**(2*FRAC_W));
  endfunction

  task automatic clock_cycle(input int n = 1);
    repeat(n) @(posedge clk);
    #1;
  endtask

  // Apply one MAC beat (a × b, optional clear)
  task automatic mac_beat(
    input logic signed [DATA_W-1:0] a,
    input logic signed [DATA_W-1:0] b,
    input logic                     do_clr
  );
    @(negedge clk);
    en = 1; a_in = a; b_in = b; clr = do_clr;
    @(posedge clk); #1;
    en = 0; clr = 0;
  endtask

  // Wait for valid output and capture it
  task automatic wait_vld(output logic signed [DATA_W-1:0] out_result);
    while (!vld) @(posedge clk);
    #1;
    out_result = result;
  endtask

  // -------------------------------------------------------------------------
  // Stimulus
  // -------------------------------------------------------------------------
  initial begin
    en = 0; clr = 0; a_in = 0; b_in = 0;
    rst_n = 0;
    repeat(4) @(posedge clk);
    rst_n = 1;
    repeat(2) @(posedge clk);

    // -----------------------------------------------------------------------
    // Test 1: Single multiply-accumulate
    //   a = 0.5  (Q8.8 = 128), b = 0.5 → product = 0.25 (Q8.8 = 64)
    // -----------------------------------------------------------------------
    $display("\n--- Test 1: Single MAC ---");
    begin
      logic signed [DATA_W-1:0] a_val, b_val, got;
      a_val = 16'sd128;   // +0.5 in Q8.8
      b_val = 16'sd128;   // +0.5 in Q8.8
      mac_beat(a_val, b_val, 1'b1);  // clr=1 starts fresh
      clock_cycle(LATENCY + 1);
      got = result;
      // Expected: 0.5×0.5 = 0.25 → Q8.8 = 64
      if ($signed(got) == 16'sd64) begin
        $display("[PASS] Test1: 0.5 × 0.5 = 0.25 (got %0d, exp 64)", $signed(got));
        pass_cnt++;
      end else begin
        $display("[FAIL] Test1: got %0d, expected 64", $signed(got));
        fail_cnt++;
      end
    end

    // -----------------------------------------------------------------------
    // Test 2: Dot-product  (8 MAC operations, compare to golden)
    //   a = [1.0, 0.5, -0.25, 0.125, 1.0, -1.0, 0.75, -0.5]
    //   b = [1.0, 2.0,  1.0, -4.0,   0.5,  0.5, 0.25, -0.5]
    //   dot = 1.0 + 1.0 - 0.25 - 0.5 + 0.5 - 0.5 + 0.1875 + 0.25 = 1.6875
    // -----------------------------------------------------------------------
    $display("\n--- Test 2: 8-tap Dot Product ---");
    begin
      localparam int N = 8;
      logic signed [DATA_W-1:0] va [0:N-1] = '{
        16'sd256, 16'sd128, -16'sd64, 16'sd32,
        16'sd256, -16'sd256, 16'sd192, -16'sd128
      };
      logic signed [DATA_W-1:0] vb [0:N-1] = '{
        16'sd256, 16'sd512, 16'sd256, -16'sd1024,
        16'sd128, 16'sd128, 16'sd64, -16'sd128
      };
      real gold = 0.0;
      real got_real;
      logic signed [DATA_W-1:0] got;

      gold_acc = 0.0;
      for (int i = 0; i < N; i++) begin
        gold += fp_mul_real(va[i], vb[i]);
      end

      // Feed first sample with clr=1 to reset accumulator
      mac_beat(va[0], vb[0], 1'b1);
      for (int i = 1; i < N; i++) begin
        mac_beat(va[i], vb[i], 1'b0);
      end

      clock_cycle(LATENCY + 2);
      got = result;
      got_real = fp_to_real(got);

      $display("  Gold = %f", gold);
      $display("  Got  = %f (raw Q8.8 = %0d)", got_real, $signed(got));

      // Allow ±1 LSB tolerance for rounding
      if ($abs(gold - got_real) <= (1.0/(2.0**FRAC_W)) + 0.001) begin
        $display("[PASS] Test2: dot-product within tolerance");
        pass_cnt++;
      end else begin
        $display("[FAIL] Test2: mismatch gold=%f got=%f", gold, got_real);
        fail_cnt++;
      end
    end

    // -----------------------------------------------------------------------
    // Test 3: Clear and restart
    // -----------------------------------------------------------------------
    $display("\n--- Test 3: CLR Behaviour ---");
    begin
      logic signed [DATA_W-1:0] got;

      // Accumulate some value
      mac_beat(16'sd1000, 16'sd256, 1'b1);
      mac_beat(16'sd500,  16'sd256, 1'b0);
      clock_cycle(LATENCY + 1);

      // Now clear and accumulate just one value
      mac_beat(16'sd256, 16'sd256, 1'b1);  // clr=1 → acc should = 1.0×1.0 = 1.0
      clock_cycle(LATENCY + 2);
      got = result;
      // 256 × 256 >> 8 = 256  (1.0 × 1.0 = 1.0 in Q8.8)
      if ($signed(got) == 16'sd256) begin
        $display("[PASS] Test3: CLR reset accumulator correctly (got %0d)", $signed(got));
        pass_cnt++;
      end else begin
        $display("[FAIL] Test3: after CLR expected 256 got %0d", $signed(got));
        fail_cnt++;
      end
    end

    // -----------------------------------------------------------------------
    // Test 4: Overflow saturation
    //   Accumulate MAX_POS/2 × 2.0 many times
    // -----------------------------------------------------------------------
    $display("\n--- Test 4: Overflow Saturation ---");
    begin
      logic signed [DATA_W-1:0] a_ovf, b_ovf, got;
      a_ovf = 16'sd16384;   // large positive value
      b_ovf = 16'sd16384;

      mac_beat(a_ovf, b_ovf, 1'b1);
      for (int i = 1; i < 20; i++) begin
        mac_beat(a_ovf, b_ovf, 1'b0);
      end
      clock_cycle(LATENCY + 2);
      got = result;
      // Must be MAX_POS (saturated)
      if (got == {1'b0, {(DATA_W-1){1'b1}}}) begin
        $display("[PASS] Test4: saturated at MAX_POS = %0d", $signed(got));
        pass_cnt++;
      end else begin
        // Check at least that ovf was raised and result is large
        if (ovf) begin
          $display("[PASS] Test4: overflow flag asserted, result=%0d", $signed(got));
          pass_cnt++;
        end else begin
          $display("[FAIL] Test4: no saturation/overflow, got %0d", $signed(got));
          fail_cnt++;
        end
      end
    end

    // -----------------------------------------------------------------------
    // Test 5: Latency verification
    //   en pulses at cycle N, vld must arrive at cycle N + LATENCY
    // -----------------------------------------------------------------------
    $display("\n--- Test 5: Latency Verification (expected %0d cycles) ---", LATENCY);
    begin
      int start_cycle, vld_cycle, measured_lat;
      logic saw_vld;

      // Wait for vld to deassert
      while (vld) @(posedge clk);
      #1;

      @(negedge clk);
      en = 1; a_in = 16'sd256; b_in = 16'sd256; clr = 1'b1;
      @(posedge clk);
      start_cycle = $time;
      en = 0; clr = 0;

      saw_vld = 0;
      for (int t = 0; t < LATENCY + 5; t++) begin
        @(posedge clk); #1;
        if (vld && !saw_vld) begin
          vld_cycle    = $time;
          saw_vld      = 1;
        end
      end

      measured_lat = (vld_cycle - start_cycle) / CLK_PERIOD;
      if (measured_lat == LATENCY) begin
        $display("[PASS] Test5: latency = %0d cycles", measured_lat);
        pass_cnt++;
      end else begin
        $display("[FAIL] Test5: latency = %0d, expected %0d", measured_lat, LATENCY);
        fail_cnt++;
      end
    end

    // -----------------------------------------------------------------------
    // Test 6: Zero operands
    // -----------------------------------------------------------------------
    $display("\n--- Test 6: Zero Operands ---");
    begin
      logic signed [DATA_W-1:0] got;
      mac_beat(16'sd0, 16'sd1234, 1'b1);
      clock_cycle(LATENCY + 1);
      got = result;
      if ($signed(got) == 0) begin
        $display("[PASS] Test6: 0 × x = 0");
        pass_cnt++;
      end else begin
        $display("[FAIL] Test6: got %0d, expected 0", $signed(got));
        fail_cnt++;
      end
    end

    // -----------------------------------------------------------------------
    // Summary
    // -----------------------------------------------------------------------
    repeat(4) @(posedge clk);
    $display("\n========================================");
    $display("  MAC_UNIT TB RESULTS: %0d PASS / %0d FAIL", pass_cnt, fail_cnt);
    $display("========================================\n");
    if (fail_cnt == 0) $display("ALL TESTS PASSED");
    else               $display("*** FAILURES DETECTED ***");
    $finish;
  end

  initial begin
    #1000000;
    $display("[TIMEOUT]");
    $finish;
  end

  initial begin
    $dumpfile("tb_mac_unit.vcd");
    $dumpvars(0, tb_mac_unit);
  end

endmodule
