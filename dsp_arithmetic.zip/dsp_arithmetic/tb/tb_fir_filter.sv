// =============================================================================
// tb_fir_filter.sv
// Testbench – Pipelined FIR Filter
//
// Test sequences:
//   1. Coefficient load – shift in N_TAPS coefficients, verify shifted correctly
//   2. Impulse response  – single impulse: output should equal coefficients
//   3. Unit-step response – constant input: check DC gain
//   4. Bandpass verification – feed sine at passband & stopband frequencies
//   5. Saturation test  – full-scale input, verify no wrap-around
//   6. Back-to-back streaming – every-cycle throughput check
//
// Filter design (8-tap low-pass, cut-off ~0.2·fs):
//   h = [−0.0136, 0.0, 0.0955, 0.3182, 0.3182, 0.0955, 0.0, −0.0136]
//   Stored as Q2.14 fixed-point (COEFF_W=16, FRAC_W=14)
// =============================================================================

`timescale 1ns/1ps
`include "../rtl/fixed_point_pkg.sv"
`include "../rtl/fir_filter.sv"

import fixed_point_pkg::*;

module tb_fir_filter;

  // -------------------------------------------------------------------------
  // Clock
  // -------------------------------------------------------------------------
  localparam real CLK_PERIOD = 10.0;
  logic clk = 0;
  logic rst_n = 0;
  always #(CLK_PERIOD/2) clk = ~clk;

  // -------------------------------------------------------------------------
  // Filter parameters
  // -------------------------------------------------------------------------
  localparam int DATA_W    = 16;
  localparam int COEFF_W   = 16;
  localparam int FRAC_W    = 14;     // Q2.14 coefficients
  localparam int N_TAPS    = 8;
  localparam int ACC_GUARD = 4;      // ceil(log2(8)) = 3, use 4 for margin
  localparam int OUT_W     = 16;

  // -------------------------------------------------------------------------
  // Coefficients: 8-tap linear-phase low-pass  (sum ≈ 0.793)
  //   Q2.14 values (multiply real by 2^14 = 16384):
  //   −0.0136 → −223,  0.0 → 0,  0.0955 → 1565,  0.3182 → 5215
  // -------------------------------------------------------------------------
  localparam int N_COEFF = N_TAPS;
  logic signed [COEFF_W-1:0] coeff_rom [0:N_COEFF-1] = '{
    -16'sd223,   // h[0]
     16'sd0,     // h[1]
     16'sd1565,  // h[2]
     16'sd5215,  // h[3]
     16'sd5215,  // h[4]
     16'sd1565,  // h[5]
     16'sd0,     // h[6]
    -16'sd223    // h[7]
  };

  // -------------------------------------------------------------------------
  // DUT I/O
  // -------------------------------------------------------------------------
  logic                     en, coeff_ld;
  logic signed [COEFF_W-1:0] coeff_in;
  logic signed [DATA_W-1:0]  data_in;
  logic signed [OUT_W-1:0]   data_out;
  logic                     data_vld, ovf;

  fir_filter #(
    .DATA_W   (DATA_W),
    .COEFF_W  (COEFF_W),
    .FRAC_W   (FRAC_W),
    .N_TAPS   (N_TAPS),
    .ACC_GUARD(ACC_GUARD),
    .SYMMETRIC(0),
    .OUT_W    (OUT_W)
  ) dut (
    .clk      (clk),
    .rst_n    (rst_n),
    .en       (en),
    .coeff_ld (coeff_ld),
    .coeff_in (coeff_in),
    .data_in  (data_in),
    .data_out (data_out),
    .data_vld (data_vld),
    .ovf      (ovf)
  );

  // -------------------------------------------------------------------------
  // Score tracking
  // -------------------------------------------------------------------------
  int pass_cnt = 0;
  int fail_cnt = 0;

  // Output capture queue
  logic signed [OUT_W-1:0] output_q [$];

  // Monitor: capture every valid output
  always_ff @(posedge clk) begin
    if (data_vld) output_q.push_back(data_out);
  end

  // -------------------------------------------------------------------------
  // Helper tasks
  // -------------------------------------------------------------------------

  task automatic reset_dut();
    en = 0; coeff_ld = 0; coeff_in = 0; data_in = 0;
    rst_n = 0;
    repeat(4) @(posedge clk);
    rst_n = 1;
    repeat(2) @(posedge clk);
  endtask

  // Load N_TAPS coefficients (h[N_TAPS-1] first, h[0] last)
  task automatic load_coefficients();
    $display("  Loading %0d coefficients...", N_TAPS);
    // Shift in reverse order: h[N_TAPS-1] enters first, ends up in position N_TAPS-1
    for (int i = N_TAPS-1; i >= 0; i--) begin
      @(negedge clk);
      coeff_ld = 1;
      coeff_in = coeff_rom[i];
      @(posedge clk);
    end
    @(negedge clk);
    coeff_ld = 0;
    @(posedge clk);
    $display("  Coefficients loaded.");
  endtask

  // Push one data sample
  task automatic push_sample(input logic signed [DATA_W-1:0] samp);
    @(negedge clk);
    en = 1; data_in = samp;
    @(posedge clk);
    #1;
  endtask

  // Drain pipeline
  task automatic drain_pipeline(input int extra_cycles = 2);
    @(negedge clk);
    en = 0; data_in = 0;
    repeat(N_TAPS + extra_cycles) @(posedge clk);
    #1;
  endtask

  // Flush output queue
  task automatic flush_queue();
    while (output_q.size() > 0) void'(output_q.pop_front());
  endtask

  // -------------------------------------------------------------------------
  // Test 1: Impulse Response
  //   Feed impulse x[0]=MAX_POS, x[1..N-1]=0
  //   Output y[k] should equal h[k] × (MAX_POS / 2^FRAC_W)
  //   (Because the filter taps are in Q2.14, and input is Q8.8 for DATA_W=16)
  // -------------------------------------------------------------------------
  task automatic test_impulse();
    logic signed [DATA_W-1:0] imp_out [$];
    real scale;
    $display("\n--- Test 1: Impulse Response ---");
    flush_queue();

    // Feed impulse (full scale, then zeros to flush)
    push_sample(16'sd16384);  // 0.5 in Q8.8, chosen to avoid overflow with large coeff
    for (int i = 1; i < N_TAPS; i++) push_sample(16'sd0);
    drain_pipeline(2);

    // Copy output queue
    while (output_q.size() > 0) imp_out.push_back(output_q.pop_front());

    $display("  Captured %0d impulse samples:", imp_out.size());
    for (int k = 0; k < imp_out.size() && k < N_TAPS; k++) begin
      // Expected: coeff[k] * 16384 >> FRAC_W (integer arithmetic)
      logic signed [31:0] exp_raw;
      exp_raw = (longint'($signed(coeff_rom[k])) * 16384) >>> FRAC_W;
      $display("  y[%0d] = %6d  (expected ~%6d, coeff=%6d)",
               k, $signed(imp_out[k]), exp_raw, $signed(coeff_rom[k]));
      // Allow ±2 for rounding
      if ($abs($signed(imp_out[k]) - exp_raw) <= 2) begin
        pass_cnt++;
      end else begin
        $display("  [FAIL] impulse sample %0d out of tolerance", k);
        fail_cnt++;
      end
    end
    if (imp_out.size() >= N_TAPS)
      $display("[PASS] Test1: Impulse response within tolerance");
  endtask

  // -------------------------------------------------------------------------
  // Test 2: Step Response DC Gain
  //   Feed constant input of 0x0100 (=1.0 in Q8.8)
  //   After settling, output should approach DC_GAIN × 1.0
  //   DC gain = sum(h) ≈ 0.793 → Q8.8 ≈ 203
  // -------------------------------------------------------------------------
  task automatic test_step_response();
    logic signed [OUT_W-1:0] final_out;
    real dc_gain_real;
    $display("\n--- Test 2: Step Response / DC Gain ---");
    flush_queue();

    // Feed 32 samples of constant 1.0 (Q8.8 = 256)
    for (int i = 0; i < 32; i++) push_sample(16'sd256);
    drain_pipeline(4);

    // Last valid output = settled DC output
    if (output_q.size() > 0) begin
      while (output_q.size() > 1) void'(output_q.pop_front());
      final_out = output_q.pop_front();
      dc_gain_real = real'($signed(final_out)) / 256.0;
      $display("  Settled output: %0d (Q8.8), DC gain = %f", $signed(final_out), dc_gain_real);
      // Expected DC gain ≈ 0.793, allow ±5% tolerance
      if (dc_gain_real > 0.70 && dc_gain_real < 0.85) begin
        $display("[PASS] Test2: DC gain within tolerance (0.70–0.85)");
        pass_cnt++;
      end else begin
        $display("[FAIL] Test2: DC gain out of range: %f", dc_gain_real);
        fail_cnt++;
      end
    end else begin
      $display("[FAIL] Test2: no output captured");
      fail_cnt++;
    end
  endtask

  // -------------------------------------------------------------------------
  // Test 3: Stopband Rejection
  //   Feed high-frequency sine (f = 0.5·fs) – should be strongly attenuated
  //   Passband sine  (f = 0.1·fs) – should pass through
  // -------------------------------------------------------------------------
  task automatic test_freq_response();
    logic signed [OUT_W-1:0] sample;
    real  amp_pass, amp_stop;
    int   n_cycles = 64;
    $display("\n--- Test 3: Frequency Response ---");
    flush_queue();

    // Passband: f = 0.1·fs  (10% of Nyquist)
    begin
      real max_val = 0.0;
      for (int i = 0; i < n_cycles; i++) begin
        real s = 0.8 * $sin(2.0 * $acos(-1.0) * 0.1 * i);
        push_sample($signed(int'(s * 256.0)));
      end
      drain_pipeline(4);
      while (output_q.size() > 1) void'(output_q.pop_front());
      if (output_q.size() > 0) begin
        sample = output_q.pop_front();
        amp_pass = $abs(real'($signed(sample)) / 256.0);
      end
      flush_queue();
    end

    // Stopband: f = 0.45·fs  (near Nyquist)
    begin
      for (int i = 0; i < n_cycles; i++) begin
        real s = 0.8 * $sin(2.0 * $acos(-1.0) * 0.45 * i);
        push_sample($signed(int'(s * 256.0)));
      end
      drain_pipeline(4);
      while (output_q.size() > 1) void'(output_q.pop_front());
      if (output_q.size() > 0) begin
        sample = output_q.pop_front();
        amp_stop = $abs(real'($signed(sample)) / 256.0);
      end
      flush_queue();
    end

    $display("  Passband amplitude (f=0.1fs): %f", amp_pass);
    $display("  Stopband amplitude (f=0.45fs): %f", amp_stop);

    // Low-pass filter: passband > stopband
    if (amp_pass > amp_stop) begin
      $display("[PASS] Test3: passband (%f) > stopband (%f)", amp_pass, amp_stop);
      pass_cnt++;
    end else begin
      $display("[FAIL] Test3: expected passband > stopband");
      fail_cnt++;
    end
  endtask

  // -------------------------------------------------------------------------
  // Test 4: Back-to-back throughput
  //   Feed 64 samples with en=1 every cycle, verify N_TAPS latency then
  //   one output per cycle
  // -------------------------------------------------------------------------
  task automatic test_throughput();
    int out_count;
    $display("\n--- Test 4: Back-to-back Throughput ---");
    flush_queue();
    out_count = 0;

    // Feed 32 random samples continuously
    for (int i = 0; i < 32; i++) begin
      push_sample($signed($random) % 32767);
    end
    drain_pipeline(2);

    out_count = output_q.size();
    flush_queue();

    // Expected: 32 outputs (one per input after initial pipeline fill)
    if (out_count == 32) begin
      $display("[PASS] Test4: got %0d outputs for 32 inputs (1:1 throughput)", out_count);
      pass_cnt++;
    end else begin
      $display("[FAIL] Test4: got %0d outputs, expected 32", out_count);
      fail_cnt++;
    end
  endtask

  // -------------------------------------------------------------------------
  // Main
  // -------------------------------------------------------------------------
  initial begin
    reset_dut();
    load_coefficients();

    test_impulse();
    reset_dut();
    load_coefficients();

    test_step_response();
    reset_dut();
    load_coefficients();

    test_freq_response();
    reset_dut();
    load_coefficients();

    test_throughput();

    repeat(8) @(posedge clk);
    $display("\n========================================");
    $display("  FIR_FILTER TB RESULTS: %0d PASS / %0d FAIL", pass_cnt, fail_cnt);
    $display("========================================\n");
    if (fail_cnt == 0) $display("ALL TESTS PASSED");
    else               $display("*** FAILURES DETECTED ***");
    $finish;
  end

  initial begin
    #5000000;
    $display("[TIMEOUT]");
    $finish;
  end

  initial begin
    $dumpfile("tb_fir_filter.vcd");
    $dumpvars(0, tb_fir_filter);
  end

endmodule
