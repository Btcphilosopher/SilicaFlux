// =============================================================================
// tb_fixed_point.sv
// Testbench – Fixed-Point Arithmetic Package Functions
//
// Exercises all package functions via a simple SystemVerilog initial block.
// No DUT instantiation needed – pure function-level checking.
// =============================================================================

`timescale 1ns/1ps
`include "../rtl/fixed_point_pkg.sv"

import fixed_point_pkg::*;

module tb_fixed_point;

  int pass_cnt = 0;
  int fail_cnt = 0;

  task automatic check(
    input string label,
    input logic signed [63:0] got,
    input logic signed [63:0] exp
  );
    if (got === exp) begin
      $display("[PASS] %-45s  got=%0d", label, $signed(got));
      pass_cnt++;
    end else begin
      $display("[FAIL] %-45s  got=%0d  exp=%0d", label, $signed(got), $signed(exp));
      fail_cnt++;
    end
  endtask

  task automatic check_flag(
    input string label,
    input logic got,
    input logic exp
  );
    if (got === exp) begin
      $display("[PASS] %-45s  flag=%b", label, got);
      pass_cnt++;
    end else begin
      $display("[FAIL] %-45s  flag=%b  exp=%b", label, got, exp);
      fail_cnt++;
    end
  endtask

  initial begin

    $display("\n=========================================================");
    $display(" fixed_point_pkg.sv  –  Unit Tests");
    $display("=========================================================\n");

    // -----------------------------------------------------------------------
    // fp_max_pos / fp_max_neg
    // -----------------------------------------------------------------------
    $display("--- Range helpers ---");
    check("fp_max_pos(8)",   fp_max_pos(8),   64'sd127);
    check("fp_max_pos(16)",  fp_max_pos(16),  64'sd32767);
    check("fp_max_neg(8)",   fp_max_neg(8),  -64'sd128);
    check("fp_max_neg(16)",  fp_max_neg(16), -64'sd32768);

    // -----------------------------------------------------------------------
    // fp_saturate
    // -----------------------------------------------------------------------
    $display("\n--- fp_saturate ---");
    check("sat: 100 in 8-bit",     fp_saturate(64'sd100,   8),   64'sd100);
    check("sat: 200 → 127 (8b)",   fp_saturate(64'sd200,   8),   64'sd127);
    check("sat: -200 → -128 (8b)", fp_saturate(-64'sd200,  8),  -64'sd128);
    check("sat: 32768 → 32767(16)",fp_saturate(64'sd32768, 16),  64'sd32767);
    check("sat: -32769 → -32768",  fp_saturate(-64'sd32769,16), -64'sd32768);
    check("sat: 0 in 16-bit",      fp_saturate(64'sd0,     16),  64'sd0);

    // -----------------------------------------------------------------------
    // fp_add / fp_sub
    // -----------------------------------------------------------------------
    $display("\n--- fp_add / fp_sub ---");
    check("add:  50 +  30 =  80",  fp_add(64'sd50,   64'sd30),  64'sd80);
    check("add: -50 + -30 = -80",  fp_add(-64'sd50, -64'sd30), -64'sd80);
    check("add: MAX_16 + 1",       fp_add(64'sd32767, 64'sd1),  64'sd32768); // no sat here
    check("sub: 100 - 40 = 60",    fp_sub(64'sd100,  64'sd40),  64'sd60);
    check("sub:  0  -  1 = -1",    fp_sub(64'sd0,    64'sd1),  -64'sd1);

    // -----------------------------------------------------------------------
    // fp_mul + fp_mul_reformat
    // -----------------------------------------------------------------------
    $display("\n--- fp_mul / fp_mul_reformat ---");
    begin
      logic signed [63:0] p;
      // Q8.8: 1.0 = 256, 0.5 = 128
      // 1.0 × 1.0 = 65536; re-align >> 8 = 256  (1.0)
      p = fp_mul(64'sd256, 64'sd256);
      check("fp_mul(256,256) raw", p, 64'sd65536);
      check("fp_mul_reformat →256", fp_mul_reformat(p, 8, 16), 64'sd256);

      // 0.5 × 0.5 = 16384; >> 8 = 64
      p = fp_mul(64'sd128, 64'sd128);
      check("fp_mul_reformat 0.5×0.5=0.25", fp_mul_reformat(p, 8, 16), 64'sd64);

      // Overflow: large × large, saturate to 16-bit
      p = fp_mul(64'sd32767, 64'sd32767);
      check("fp_mul_reformat saturate",
            fp_mul_reformat(p, 8, 16), fp_max_pos(16));
    end

    // -----------------------------------------------------------------------
    // fp_negate
    // -----------------------------------------------------------------------
    $display("\n--- fp_negate ---");
    check("negate(100, 16)",       fp_negate(64'sd100,    16), -64'sd100);
    check("negate(0, 8)",          fp_negate(64'sd0,       8),  64'sd0);
    check("negate(127, 8)",        fp_negate(64'sd127,     8), -64'sd127);
    check("negate(MAX_NEG_8, 8) saturate",
           fp_negate(fp_max_neg(8), 8), fp_max_pos(8));

    // -----------------------------------------------------------------------
    // fp_abs
    // -----------------------------------------------------------------------
    $display("\n--- fp_abs ---");
    check("abs(50, 8)",   fp_abs(64'sd50,  8),  64'sd50);
    check("abs(-50, 8)",  fp_abs(-64'sd50, 8),  64'sd50);
    check("abs(0, 8)",    fp_abs(64'sd0,   8),  64'sd0);
    check("abs(MAX_NEG_8) → MAX_POS_8",
          fp_abs(fp_max_neg(8), 8), fp_max_pos(8));

    // -----------------------------------------------------------------------
    // fp_round
    // -----------------------------------------------------------------------
    $display("\n--- fp_round ---");
    begin
      // Round toward -inf (truncate): 0b1010.1100 drop 4 bits → 0b1010 = 10
      check("TRUNC:  0xAC >> 4 → 10",
            fp_round(64'shAC, 4, ROUND_TRUNC),   64'sd10);

      // Round nearest: 0b1010_1000 = 168, drop 4 = 10.5 → 11 (guard=1,sticky=0,lsb=0)
      // ties-to-even: lsb=0 → truncate → 10
      check("NEAREST: 0xA8 >> 4 → 10 (ties even)",
            fp_round(64'shA8, 4, ROUND_NEAREST),  64'sd10);

      // Round nearest: 0b1010_1001 = 169, drop 4 = 10 + 9/16 → round to 11
      check("NEAREST: 0xA9 >> 4 → 11",
            fp_round(64'shA9, 4, ROUND_NEAREST),  64'sd11);

      // Ceiling: any remainder rounds up
      check("CEIL: 0xA1 >> 4 → 11",
            fp_round(64'shA1, 4, ROUND_CEIL),     64'sd11);
      check("CEIL: 0xA0 >> 4 → 10 (exact)",
            fp_round(64'shA0, 4, ROUND_CEIL),     64'sd10);
    end

    // -----------------------------------------------------------------------
    // int_to_fp
    // -----------------------------------------------------------------------
    $display("\n--- int_to_fp ---");
    check("int_to_fp(1, 8) = 256",    int_to_fp(32'sd1,  8),  64'sd256);
    check("int_to_fp(5, 4) = 80",     int_to_fp(32'sd5,  4),  64'sd80);
    check("int_to_fp(-3, 8) = -768",  int_to_fp(-32'sd3, 8), -64'sd768);

    // -----------------------------------------------------------------------
    // fp_from_real
    // -----------------------------------------------------------------------
    $display("\n--- fp_from_real ---");
    begin
      logic signed [63:0] v;
      v = fp_from_real(1.0, 8, 8);
      check("fp_from_real(1.0,Q8.8)=256",   v, 64'sd256);
      v = fp_from_real(0.5, 8, 8);
      check("fp_from_real(0.5,Q8.8)=128",   v, 64'sd128);
      v = fp_from_real(-0.25, 8, 8);
      check("fp_from_real(-0.25,Q8.8)=-64", v, -64'sd64);
      v = fp_from_real(0.0, 8, 8);
      check("fp_from_real(0.0)=0",          v, 64'sd0);
    end

    // -----------------------------------------------------------------------
    // fp_overflow
    // -----------------------------------------------------------------------
    $display("\n--- fp_overflow ---");
    check_flag("ovf: 100 in 8b → false",  fp_overflow(64'sd100,  8), 1'b0);
    check_flag("ovf: 128 in 8b → true",   fp_overflow(64'sd128,  8), 1'b1);
    check_flag("ovf: -128 in 8b → false", fp_overflow(-64'sd128, 8), 1'b0);
    check_flag("ovf: -129 in 8b → true",  fp_overflow(-64'sd129, 8), 1'b1);
    check_flag("ovf: 0 in 8b → false",    fp_overflow(64'sd0,    8), 1'b0);

    // -----------------------------------------------------------------------
    // fp_add_overflow
    // -----------------------------------------------------------------------
    $display("\n--- fp_add_overflow ---");
    check_flag("add_ovf: 100+20 8b → false",
               fp_add_overflow(64'sd100, 64'sd20, 8),  1'b0);
    check_flag("add_ovf: 100+100 8b → true",
               fp_add_overflow(64'sd100, 64'sd100, 8), 1'b1);
    check_flag("add_ovf: -100+-100 8b → true",
               fp_add_overflow(-64'sd100, -64'sd100, 8), 1'b1);
    check_flag("add_ovf: 50+-50 8b → false",
               fp_add_overflow(64'sd50, -64'sd50, 8), 1'b0);

    // -----------------------------------------------------------------------
    // Summary
    // -----------------------------------------------------------------------
    #10;
    $display("\n=========================================================");
    $display("  FIXED_POINT PKG RESULTS: %0d PASS / %0d FAIL", pass_cnt, fail_cnt);
    $display("=========================================================\n");
    if (fail_cnt == 0) $display("ALL TESTS PASSED");
    else               $display("*** FAILURES DETECTED ***");
    $finish;
  end

  initial begin
    $dumpfile("tb_fixed_point.vcd");
    $dumpvars(0, tb_fixed_point);
  end

endmodule
