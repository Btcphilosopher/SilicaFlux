// =============================================================================
// tb_sat_arith.sv
// Testbench – Saturating Arithmetic Units
//
// Tests: sat_add, sat_sub, sat_mul, sat_abs, sat_neg, sat_shift
// Coverage:
//   • Normal operation across operand range
//   • Positive overflow boundary
//   • Negative overflow boundary
//   • Zero inputs
//   • Max positive + Max positive  (must saturate)
//   • Max negative + Max negative  (must saturate)
//   • Min negative ABS / NEG       (saturation edge case)
//   • All shift amounts for sat_shift (left and right)
// =============================================================================

`timescale 1ns/1ps
`include "../rtl/fixed_point_pkg.sv"
`include "../rtl/sat_arith.sv"

import fixed_point_pkg::*;

module tb_sat_arith;

  // -------------------------------------------------------------------------
  // Clock and reset
  // -------------------------------------------------------------------------
  localparam real CLK_PERIOD = 10.0;  // 100 MHz

  logic clk   = 0;
  logic rst_n = 0;
  always #(CLK_PERIOD/2) clk = ~clk;

  // -------------------------------------------------------------------------
  // Parameters under test
  // -------------------------------------------------------------------------
  localparam int W      = 16;
  localparam int FRAC   = 8;
  localparam int SHIFT_W = 4;

  // Saturating limits
  localparam logic signed [W-1:0] MAX_POS = {1'b0, {(W-1){1'b1}}};
  localparam logic signed [W-1:0] MAX_NEG = {1'b1, {(W-1){1'b0}}};

  // -------------------------------------------------------------------------
  // DUT signals
  // -------------------------------------------------------------------------
  // --- sat_add ---
  logic                    add_en;
  logic signed [W-1:0]     add_a, add_b, add_result;
  logic                    add_ovf;

  sat_add #(.WIDTH(W)) u_sat_add (
    .clk(clk), .rst_n(rst_n), .en(add_en),
    .a(add_a), .b(add_b),
    .result(add_result), .ovf(add_ovf)
  );

  // --- sat_sub ---
  logic                    sub_en;
  logic signed [W-1:0]     sub_a, sub_b, sub_result;
  logic                    sub_ovf;

  sat_sub #(.WIDTH(W)) u_sat_sub (
    .clk(clk), .rst_n(rst_n), .en(sub_en),
    .a(sub_a), .b(sub_b),
    .result(sub_result), .ovf(sub_ovf)
  );

  // --- sat_mul ---
  logic                    mul_en;
  logic signed [W-1:0]     mul_a, mul_b, mul_result;
  logic                    mul_ovf;

  sat_mul #(.WIDTH(W), .FRAC_W(FRAC), .STAGES(2)) u_sat_mul (
    .clk(clk), .rst_n(rst_n), .en(mul_en),
    .a(mul_a), .b(mul_b),
    .result(mul_result), .ovf(mul_ovf)
  );

  // --- sat_abs ---
  logic                    abs_en;
  logic signed [W-1:0]     abs_a, abs_result;
  logic                    abs_ovf;

  sat_abs #(.WIDTH(W)) u_sat_abs (
    .clk(clk), .rst_n(rst_n), .en(abs_en),
    .a(abs_a),
    .result(abs_result), .ovf(abs_ovf)
  );

  // --- sat_neg ---
  logic                    neg_en;
  logic signed [W-1:0]     neg_a, neg_result;
  logic                    neg_ovf;

  sat_neg #(.WIDTH(W)) u_sat_neg (
    .clk(clk), .rst_n(rst_n), .en(neg_en),
    .a(neg_a),
    .result(neg_result), .ovf(neg_ovf)
  );

  // --- sat_shift ---
  logic                    sh_en, sh_dir;
  logic [SHIFT_W-1:0]      sh_amt;
  logic signed [W-1:0]     sh_a, sh_result;
  logic                    sh_ovf;

  sat_shift #(.WIDTH(W), .SHIFT_W(SHIFT_W)) u_sat_shift (
    .clk(clk), .rst_n(rst_n), .en(sh_en),
    .dir(sh_dir), .shamt(sh_amt), .a(sh_a),
    .result(sh_result), .ovf(sh_ovf)
  );

  // -------------------------------------------------------------------------
  // Scoreboard variables
  // -------------------------------------------------------------------------
  int pass_cnt = 0;
  int fail_cnt = 0;

  // -------------------------------------------------------------------------
  // Utility tasks
  // -------------------------------------------------------------------------

  // Apply one cycle of sat_add and check result
  task automatic check_add(
    input logic signed [W-1:0] a,
    input logic signed [W-1:0] b,
    input logic signed [W-1:0] expected,
    input logic                expect_ovf,
    input string               label
  );
    @(negedge clk);
    add_en = 1; add_a = a; add_b = b;
    @(posedge clk); #1;
    add_en = 0;
    @(posedge clk); #1;
    if (add_result !== expected || add_ovf !== expect_ovf) begin
      $display("[FAIL] ADD %-30s : a=%0d b=%0d | got=%0d ovf=%b | exp=%0d ovf=%b",
               label, $signed(a), $signed(b),
               $signed(add_result), add_ovf,
               $signed(expected),  expect_ovf);
      fail_cnt++;
    end else begin
      $display("[PASS] ADD %-30s", label);
      pass_cnt++;
    end
  endtask

  task automatic check_sub(
    input logic signed [W-1:0] a,
    input logic signed [W-1:0] b,
    input logic signed [W-1:0] expected,
    input logic                expect_ovf,
    input string               label
  );
    @(negedge clk);
    sub_en = 1; sub_a = a; sub_b = b;
    @(posedge clk); #1;
    sub_en = 0;
    @(posedge clk); #1;
    if (sub_result !== expected || sub_ovf !== expect_ovf) begin
      $display("[FAIL] SUB %-30s : a=%0d b=%0d | got=%0d ovf=%b | exp=%0d ovf=%b",
               label, $signed(a), $signed(b),
               $signed(sub_result), sub_ovf,
               $signed(expected),  expect_ovf);
      fail_cnt++;
    end else begin
      $display("[PASS] SUB %-30s", label);
      pass_cnt++;
    end
  endtask

  task automatic check_abs(
    input logic signed [W-1:0] a,
    input logic signed [W-1:0] expected,
    input logic                expect_ovf,
    input string               label
  );
    @(negedge clk);
    abs_en = 1; abs_a = a;
    @(posedge clk); #1;
    abs_en = 0;
    @(posedge clk); #1;
    if (abs_result !== expected || abs_ovf !== expect_ovf) begin
      $display("[FAIL] ABS %-30s : a=%0d | got=%0d ovf=%b | exp=%0d ovf=%b",
               label, $signed(a),
               $signed(abs_result), abs_ovf,
               $signed(expected),  expect_ovf);
      fail_cnt++;
    end else begin
      $display("[PASS] ABS %-30s", label);
      pass_cnt++;
    end
  endtask

  task automatic check_neg(
    input logic signed [W-1:0] a,
    input logic signed [W-1:0] expected,
    input logic                expect_ovf,
    input string               label
  );
    @(negedge clk);
    neg_en = 1; neg_a = a;
    @(posedge clk); #1;
    neg_en = 0;
    @(posedge clk); #1;
    if (neg_result !== expected || neg_ovf !== expect_ovf) begin
      $display("[FAIL] NEG %-30s : a=%0d | got=%0d ovf=%b | exp=%0d ovf=%b",
               label, $signed(a),
               $signed(neg_result), neg_ovf,
               $signed(expected),  expect_ovf);
      fail_cnt++;
    end else begin
      $display("[PASS] NEG %-30s", label);
      pass_cnt++;
    end
  endtask

  task automatic check_shift(
    input logic signed [W-1:0] a,
    input logic                dir,
    input logic [SHIFT_W-1:0]  amt,
    input logic signed [W-1:0] expected,
    input logic                expect_ovf,
    input string               label
  );
    @(negedge clk);
    sh_en = 1; sh_a = a; sh_dir = dir; sh_amt = amt;
    @(posedge clk); #1;
    sh_en = 0;
    @(posedge clk); #1;
    if (sh_result !== expected || sh_ovf !== expect_ovf) begin
      $display("[FAIL] SHF %-30s : a=%0d dir=%b amt=%0d | got=%0d ovf=%b | exp=%0d ovf=%b",
               label, $signed(a), dir, amt,
               $signed(sh_result), sh_ovf,
               $signed(expected),  expect_ovf);
      fail_cnt++;
    end else begin
      $display("[PASS] SHF %-30s", label);
      pass_cnt++;
    end
  endtask

  // -------------------------------------------------------------------------
  // Stimulus
  // -------------------------------------------------------------------------
  initial begin
    // Initialise all enables to 0
    add_en = 0; add_a = 0; add_b = 0;
    sub_en = 0; sub_a = 0; sub_b = 0;
    mul_en = 0; mul_a = 0; mul_b = 0;
    abs_en = 0; abs_a = 0;
    neg_en = 0; neg_a = 0;
    sh_en  = 0; sh_a  = 0; sh_dir = 0; sh_amt = 0;

    // Reset
    rst_n = 0;
    repeat(4) @(posedge clk);
    rst_n = 1;
    repeat(2) @(posedge clk);

    $display("\n=== SAT_ADD Tests ===");
    // Normal: 100 + 200 = 300
    check_add(16'sd100,   16'sd200,   16'sd300,         1'b0, "normal +100+200");
    // Normal: -100 + -200 = -300
    check_add(-16'sd100, -16'sd200,  -16'sd300,         1'b0, "normal -100-200");
    // Zero inputs
    check_add(16'sd0,     16'sd0,     16'sd0,           1'b0, "zero+zero");
    // MAX_POS + 1 = saturate
    check_add(MAX_POS,    16'sd1,     MAX_POS,          1'b1, "MAX_POS+1 saturate");
    // MAX_NEG + (-1) = saturate
    check_add(MAX_NEG,   -16'sd1,     MAX_NEG,          1'b1, "MAX_NEG-1 saturate");
    // MAX_POS + MAX_POS = saturate
    check_add(MAX_POS,    MAX_POS,    MAX_POS,          1'b1, "MAX_POS+MAX_POS");
    // MAX_NEG + MAX_NEG = saturate
    check_add(MAX_NEG,    MAX_NEG,    MAX_NEG,          1'b1, "MAX_NEG+MAX_NEG");
    // Positive + negative (no overflow)
    check_add(MAX_POS,    MAX_NEG,   -16'sd1,           1'b0, "MAX_POS+MAX_NEG");

    $display("\n=== SAT_SUB Tests ===");
    check_sub(16'sd500,   16'sd200,   16'sd300,         1'b0, "normal 500-200");
    check_sub(16'sd0,     16'sd0,     16'sd0,           1'b0, "zero-zero");
    // MAX_POS - (-1) overflows
    check_sub(MAX_POS,   -16'sd1,     MAX_POS,          1'b1, "MAX_POS-(-1) sat");
    // MAX_NEG - 1 underflows
    check_sub(MAX_NEG,    16'sd1,     MAX_NEG,          1'b1, "MAX_NEG-1 sat");
    // Symmetric: A - A = 0
    check_sub(16'sd12345, 16'sd12345, 16'sd0,           1'b0, "A-A=0");

    $display("\n=== SAT_ABS Tests ===");
    check_abs(16'sd500,   16'sd500,   1'b0, "abs(+500)");
    check_abs(-16'sd500,  16'sd500,   1'b0, "abs(-500)");
    check_abs(16'sd0,     16'sd0,     1'b0, "abs(0)");
    check_abs(MAX_POS,    MAX_POS,    1'b0, "abs(MAX_POS)");
    check_abs(MAX_NEG,    MAX_POS,    1'b1, "abs(MAX_NEG) saturate");

    $display("\n=== SAT_NEG Tests ===");
    check_neg(16'sd100,  -16'sd100,   1'b0, "neg(+100)");
    check_neg(-16'sd100,  16'sd100,   1'b0, "neg(-100)");
    check_neg(16'sd0,     16'sd0,     1'b0, "neg(0)");
    check_neg(MAX_POS,   -MAX_POS,    1'b0, "neg(MAX_POS)");
    check_neg(MAX_NEG,    MAX_POS,    1'b1, "neg(MAX_NEG) saturate");

    $display("\n=== SAT_SHIFT Tests ===");
    // Right shifts (no saturation possible)
    check_shift(16'sd1024, 0, 4'd1,  16'sd512,  1'b0, "right >>1");
    check_shift(16'sd1024, 0, 4'd2,  16'sd256,  1'b0, "right >>2");
    check_shift(16'sd1024, 0, 4'd4,  16'sd64,   1'b0, "right >>4");
    check_shift(-16'sd16,  0, 4'd2, -16'sd4,    1'b0, "right -16>>2 = -4");
    // Left shifts (may saturate)
    check_shift(16'sd1,    1, 4'd4,  16'sd16,   1'b0, "left 1<<4 = 16");
    check_shift(16'sd1,    1, 4'd8,  16'sd256,  1'b0, "left 1<<8 = 256");
    check_shift(16'sd1024, 1, 4'd6,  MAX_POS,   1'b1, "left 1024<<6 saturate");
    check_shift(16'sd0,    1, 4'd15, 16'sd0,    1'b0, "left 0<<15 = 0");

    // -----------------------------------------------------------------------
    // Continuous-flow test: stream back-to-back adds for 32 cycles
    // -----------------------------------------------------------------------
    $display("\n=== Back-to-back streaming (sat_add) ===");
    begin
      int stream_pass = 0;
      logic signed [W-1:0] sa, sb, sexp;
      for (int i = 0; i < 32; i++) begin
        sa   = $signed($random) % 200;
        sb   = $signed($random) % 200;
        sexp = sa + sb;  // within range for small values
        @(negedge clk);
        add_en = 1; add_a = sa; add_b = sb;
      end
      @(posedge clk); #1;
      add_en = 0;
      repeat(2) @(posedge clk);
      $display("[INFO] Streaming test complete – check waveform for continuity");
    end

    // -----------------------------------------------------------------------
    // Final summary
    // -----------------------------------------------------------------------
    repeat(4) @(posedge clk);
    $display("\n========================================");
    $display("  SAT_ARITH TB RESULTS: %0d PASS / %0d FAIL", pass_cnt, fail_cnt);
    $display("========================================\n");
    if (fail_cnt == 0)
      $display("ALL TESTS PASSED");
    else
      $display("*** FAILURES DETECTED ***");
    $finish;
  end

  // -------------------------------------------------------------------------
  // Timeout watchdog
  // -------------------------------------------------------------------------
  initial begin
    #500000;
    $display("[TIMEOUT] Simulation exceeded time limit");
    $finish;
  end

  // -------------------------------------------------------------------------
  // Waveform dump
  // -------------------------------------------------------------------------
  initial begin
    $dumpfile("tb_sat_arith.vcd");
    $dumpvars(0, tb_sat_arith);
  end

endmodule
