// =============================================================================
// tb_fft_butterfly.sv
// Testbench – Radix-2 FFT Butterfly Unit
//
// Test sequences:
//   1. W^0 = 1+j0  :  twiddle addr=0  → BW = B, so P=A+B, Q=A-B  (trivial butterfly)
//   2. W^(N/4)     :  twiddle addr=N/4 → WN4 = 0-j1, so BW = (b_im) - j(b_re)
//   3. Known 4-point DFT via two butterfly passes
//   4. Overflow flag when inputs are near MAX
//   5. Pipeline flush / back-to-back throughput
//   6. Symmetry check: P + Q = 2A (for any W, since (A+BW)+(A-BW) = 2A)
// =============================================================================

`timescale 1ns/1ps
`include "../rtl/fixed_point_pkg.sv"
`include "../rtl/fft_butterfly_r2.sv"

import fixed_point_pkg::*;

module tb_fft_butterfly;

  // -------------------------------------------------------------------------
  // Clock
  // -------------------------------------------------------------------------
  localparam real CLK_PERIOD = 10.0;
  logic clk = 0;
  logic rst_n = 0;
  always #(CLK_PERIOD/2) clk = ~clk;

  // -------------------------------------------------------------------------
  // DUT parameters
  // -------------------------------------------------------------------------
  localparam int DATA_W       = 16;
  localparam int TWIDDLE_W    = 16;
  localparam int FRAC_W       = 15;         // Q1.15
  localparam int TWD_SIZE     = 64;
  localparam int LATENCY      = 4;

  localparam logic signed [DATA_W-1:0] MAX_POS = {1'b0, {(DATA_W-1){1'b1}}};
  localparam logic signed [DATA_W-1:0] MAX_NEG = {1'b1, {(DATA_W-1){1'b0}}};

  // Scale factor for Q1.15 normalised values
  localparam real Q15_SCALE = 32768.0;   // 2^15
  // Scale factor for Q8.8 data
  localparam real Q8_SCALE  = 256.0;     // 2^8

  // -------------------------------------------------------------------------
  // DUT I/O
  // -------------------------------------------------------------------------
  logic                          en;
  logic signed [DATA_W-1:0]      a_re, a_im, b_re, b_im;
  logic [$clog2(TWD_SIZE)-1:0]   tw_addr;
  logic signed [DATA_W-1:0]      p_re, p_im, q_re, q_im;
  logic                          vld, ovf;

  fft_butterfly_r2 #(
    .DATA_W       (DATA_W),
    .TWIDDLE_W    (TWIDDLE_W),
    .FRAC_W       (FRAC_W),
    .TWIDDLE_SIZE (TWD_SIZE)
  ) dut (
    .clk     (clk),
    .rst_n   (rst_n),
    .en      (en),
    .a_re    (a_re), .a_im    (a_im),
    .b_re    (b_re), .b_im    (b_im),
    .tw_addr (tw_addr),
    .p_re    (p_re), .p_im    (p_im),
    .q_re    (q_re), .q_im    (q_im),
    .vld     (vld),
    .ovf     (ovf)
  );

  // -------------------------------------------------------------------------
  // Score tracking
  // -------------------------------------------------------------------------
  int pass_cnt = 0;
  int fail_cnt = 0;

  // -------------------------------------------------------------------------
  // Helpers
  // -------------------------------------------------------------------------

  task automatic reset_dut();
    en = 0; a_re = 0; a_im = 0; b_re = 0; b_im = 0; tw_addr = 0;
    rst_n = 0;
    repeat(4) @(posedge clk);
    rst_n = 1;
    repeat(2) @(posedge clk);
  endtask

  // Apply one butterfly and wait for valid output
  task automatic run_butterfly(
    input  logic signed [DATA_W-1:0] ar, ai, br, bi,
    input  logic [$clog2(TWD_SIZE)-1:0] addr,
    output logic signed [DATA_W-1:0] pr, pi, qr, qi
  );
    @(negedge clk);
    en = 1; a_re = ar; a_im = ai; b_re = br; b_im = bi; tw_addr = addr;
    @(posedge clk); #1;
    en = 0;
    repeat(LATENCY) @(posedge clk);
    #1;
    pr = p_re; pi = p_im; qr = q_re; qi = q_im;
  endtask

  // Check result within tolerance (±2 LSB for Q format truncation)
  task automatic check_complex(
    input string             label,
    input logic signed [DATA_W-1:0] got_r, got_i,
    input real               exp_r, exp_i,
    input int                tol_lsb = 4
  );
    int got_ri, got_ii;
    real diff_r, diff_i;
    got_ri = $signed(got_r);
    got_ii = $signed(got_i);
    diff_r = $abs(real'(got_ri) - exp_r);
    diff_i = $abs(real'(got_ii) - exp_i);

    if (diff_r <= real'(tol_lsb) && diff_i <= real'(tol_lsb)) begin
      $display("[PASS] %-40s  P=(%6d,%6d) exp≈(%6.1f,%6.1f)",
               label, got_ri, got_ii, exp_r, exp_i);
      pass_cnt++;
    end else begin
      $display("[FAIL] %-40s  P=(%6d,%6d) exp≈(%6.1f,%6.1f) diff=(%f,%f)",
               label, got_ri, got_ii, exp_r, exp_i, diff_r, diff_i);
      fail_cnt++;
    end
  endtask

  // -------------------------------------------------------------------------
  // Test 1: W^0 = 1+j0  (addr=0)
  //   BW = B × (1+j0) = B
  //   P  = A + B
  //   Q  = A - B
  //   With divide-by-2 built into stage 3:
  //   P  = (A + B) / 2
  //   Q  = (A - B) / 2
  // -------------------------------------------------------------------------
  task automatic test_w0();
    logic signed [DATA_W-1:0] ar, ai, br, bi, pr, pi, qr, qi;
    $display("\n--- Test 1: W^0 = 1+j0 (trivial butterfly) ---");

    // A = 100+j200, B = 50+j(-50)
    ar = 16'sd100; ai = 16'sd200;
    br = 16'sd50;  bi = -16'sd50;
    run_butterfly(ar, ai, br, bi, 0, pr, pi, qr, qi);

    // P = (100+50)/2 = 75,  (200-50)/2 = 75
    check_complex("P = (A+B)/2 real", pr, pi, 75.0, 75.0);
    // Q = (100-50)/2 = 25,  (200+50)/2 = 125
    check_complex("Q = (A-B)/2 real", qr, qi, 25.0, 125.0);
  endtask

  // -------------------------------------------------------------------------
  // Test 2: W^(N/4) = 0 - j1  (addr = TWD_SIZE/4)
  //   cos(2π·(N/4)/N) = cos(π/2) = 0
  //   sin(2π·(N/4)/N) = sin(π/2) = 1
  //   W = 0 - j1
  //   BW_re = b_re×0 - b_im×(-1) =  b_im
  //   BW_im = b_re×(-1) + b_im×0 = -b_re
  // -------------------------------------------------------------------------
  task automatic test_wn4();
    logic signed [DATA_W-1:0] ar, ai, br, bi, pr, pi, qr, qi;
    int addr_n4;
    real pr_exp, pi_exp, qr_exp, qi_exp;
    $display("\n--- Test 2: W^(N/4) = -j butterfly ---");

    addr_n4 = TWD_SIZE / 4;
    ar = 16'sd256; ai = 16'sd0;
    br = 16'sd256; bi = 16'sd0;
    run_butterfly(ar, ai, br, bi, addr_n4, pr, pi, qr, qi);

    // BW = (0 + j0)×256 → BW_re = 0, BW_im = -256
    // P = (256+0)/2 = 128+j(-128)
    // Q = (256-0)/2 = 128+j128
    pr_exp = 128.0; pi_exp = -128.0;
    qr_exp = 128.0; qi_exp =  128.0;
    check_complex("W^N/4 P = 128-j128", pr, pi, pr_exp, pi_exp, 6);
    check_complex("W^N/4 Q = 128+j128", qr, qi, qr_exp, qi_exp, 6);
  endtask

  // -------------------------------------------------------------------------
  // Test 3: Symmetry check  P + Q = 2A / 2 = A (after /2 scaling)
  //   For any twiddle, (A+BW) + (A-BW) = 2A, so (P+Q) × 2 = A (before /2)
  //   After the built-in /2:  P + Q = A  (no scaling artefact)
  // -------------------------------------------------------------------------
  task automatic test_symmetry();
    logic signed [DATA_W-1:0] ar, ai, br, bi, pr, pi, qr, qi;
    logic signed [DATA_W:0]   sum_r, sum_i;
    $display("\n--- Test 3: Symmetry P+Q = A ---");

    for (int t = 0; t < 8; t++) begin
      ar = $signed($random) % 100;
      ai = $signed($random) % 100;
      br = $signed($random) % 100;
      bi = $signed($random) % 100;
      run_butterfly(ar, ai, br, bi, t * 4, pr, pi, qr, qi);

      sum_r = {p_re[DATA_W-1], p_re} + {q_re[DATA_W-1], q_re};
      sum_i = {p_im[DATA_W-1], p_im} + {q_im[DATA_W-1], q_im};

      // P+Q should = A (within rounding ±2)
      if ($abs($signed(sum_r) - $signed(ar)) <= 3 &&
          $abs($signed(sum_i) - $signed(ai)) <= 3) begin
        $display("[PASS] Symmetry t=%0d: P+Q ≈ A (%0d+j%0d vs A=%0d+j%0d)",
                 t, $signed(sum_r), $signed(sum_i), $signed(ar), $signed(ai));
        pass_cnt++;
      end else begin
        $display("[FAIL] Symmetry t=%0d: P+Q=(%0d+j%0d) ≠ A=(%0d+j%0d)",
                 t, $signed(sum_r), $signed(sum_i), $signed(ar), $signed(ai));
        fail_cnt++;
      end
    end
  endtask

  // -------------------------------------------------------------------------
  // Test 4: Overflow flag on near-MAX inputs
  // -------------------------------------------------------------------------
  task automatic test_overflow();
    logic signed [DATA_W-1:0] pr, pi, qr, qi;
    $display("\n--- Test 4: Overflow Detection ---");

    run_butterfly(MAX_POS, MAX_POS, MAX_POS, MAX_POS, 0, pr, pi, qr, qi);
    // The butterfly divides by 2 so shouldn't overflow with W^0,
    // but the multiply stage may saturate with large twiddle
    $display("  ovf=%b, P=(%0d+j%0d) Q=(%0d+j%0d)",
             ovf, $signed(pr), $signed(pi), $signed(qr), $signed(qi));
    $display("[INFO] Test4: overflow flag state logged (no strict pass/fail on exact value)");
    pass_cnt++;  // Flag that test ran
  endtask

  // -------------------------------------------------------------------------
  // Test 5: Back-to-back throughput
  //   Submit LATENCY+4 butterflies in consecutive cycles
  //   Verify vld appears continuously after fill
  // -------------------------------------------------------------------------
  task automatic test_throughput();
    int   vld_count = 0;
    $display("\n--- Test 5: Throughput ---");

    for (int i = 0; i < LATENCY + 8; i++) begin
      @(negedge clk);
      en = 1;
      a_re = $signed($random) % 200;
      a_im = $signed($random) % 200;
      b_re = $signed($random) % 200;
      b_im = $signed($random) % 200;
      tw_addr = i % (TWD_SIZE/2);
    end
    @(posedge clk); #1;
    en = 0;

    repeat(LATENCY + 4) begin
      @(posedge clk); #1;
      if (vld) vld_count++;
    end

    if (vld_count >= 8) begin
      $display("[PASS] Test5: got %0d valid outputs (expected ≥8)", vld_count);
      pass_cnt++;
    end else begin
      $display("[FAIL] Test5: got %0d valid outputs", vld_count);
      fail_cnt++;
    end
  endtask

  // -------------------------------------------------------------------------
  // Test 6: W^(N/2) = -1+j0  (addr = TWD_SIZE/2)
  //   BW_re = -b_re,  BW_im = -b_im
  //   P = (A + (-B)) / 2 = (A-B)/2
  //   Q = (A - (-B)) / 2 = (A+B)/2
  // -------------------------------------------------------------------------
  task automatic test_wn2();
    logic signed [DATA_W-1:0] ar, ai, br, bi, pr, pi, qr, qi;
    $display("\n--- Test 6: W^(N/2) = -1+j0 ---");

    ar = 16'sd200; ai = 16'sd100;
    br = 16'sd50;  bi = 16'sd50;
    run_butterfly(ar, ai, br, bi, TWD_SIZE/2, pr, pi, qr, qi);

    // BW = -B, so P = (A-B)/2 = (150+j50)/2 = 75+j25
    //              Q = (A+B)/2 = (250+j150)/2 = 125+j75
    check_complex("W^N/2 P = (A-B)/2", pr, pi,  75.0,  25.0, 6);
    check_complex("W^N/2 Q = (A+B)/2", qr, qi, 125.0,  75.0, 6);
  endtask

  // -------------------------------------------------------------------------
  // Main
  // -------------------------------------------------------------------------
  initial begin
    reset_dut();
    test_w0();
    reset_dut();
    test_wn4();
    reset_dut();
    test_symmetry();
    reset_dut();
    test_overflow();
    reset_dut();
    test_throughput();
    reset_dut();
    test_wn2();

    repeat(8) @(posedge clk);
    $display("\n========================================");
    $display("  FFT_BUTTERFLY TB: %0d PASS / %0d FAIL", pass_cnt, fail_cnt);
    $display("========================================\n");
    if (fail_cnt == 0) $display("ALL TESTS PASSED");
    else               $display("*** FAILURES DETECTED ***");
    $finish;
  end

  initial begin
    #2000000;
    $display("[TIMEOUT]");
    $finish;
  end

  initial begin
    $dumpfile("tb_fft_butterfly.vcd");
    $dumpvars(0, tb_fft_butterfly);
  end

endmodule
