# DSP Arithmetic – SystemVerilog Repository

High-performance, synthesis-ready DSP arithmetic units in SystemVerilog.  
All modules are **fully pipelined**, **parameterisable in precision**, and ship with self-checking testbenches.

---

## Repository Layout

```
dsp_arithmetic/
├── rtl/
│   ├── fixed_point_pkg.sv      ← Core Q-format library (types + functions)
│   ├── sat_arith.sv            ← Saturating add, sub, mul, abs, neg, shift
│   ├── mac_unit.sv             ← Pipelined multiply-accumulate
│   ├── fir_filter.sv           ← Transposed direct-form FIR
│   └── fft_butterfly_r2.sv     ← Radix-2 DIT butterfly with twiddle ROM
├── tb/
│   ├── tb_fixed_point.sv       ← Package unit tests (function-level)
│   ├── tb_sat_arith.sv         ← Saturation edge-case + streaming tests
│   ├── tb_mac_unit.sv          ← Dot-product, overflow, latency verification
│   ├── tb_fir_filter.sv        ← Impulse/step/frequency/throughput tests
│   └── tb_fft_butterfly.sv     ← Twiddle angle, symmetry, overflow tests
├── sim/
│   ├── run_all.sh              ← Regression runner (iverilog / VCS)
│   └── out/                    ← Simulation outputs and logs (generated)
└── docs/
    └── README.md               ← This file
```

---

## Module Reference

### `fixed_point_pkg.sv`

Package providing Q-format helpers used throughout the library.

| Symbol | Description |
|--------|-------------|
| `sfixed_t` | Default Q8.8 signed typedef (16-bit) |
| `fp_max_pos(W)` | Maximum positive value for W-bit signed |
| `fp_max_neg(W)` | Most-negative value for W-bit signed |
| `fp_saturate(v, W)` | Clamp 64-bit value to W-bit signed range |
| `fp_add / fp_sub` | Full-width (no-sat) add/subtract |
| `fp_mul` | Raw full-width multiply |
| `fp_mul_reformat` | Re-align product, then saturate to target width |
| `fp_negate / fp_abs` | Saturating negate and absolute value |
| `fp_round` | Four rounding modes: TRUNC, NEAREST, CONV, CEIL |
| `fp_overflow` | Range check for W-bit signed |
| `fp_add_overflow` | Classic two-operand overflow detect |
| `int_to_fp` | Integer → fixed-point left-shift |
| `fp_from_real` | Compile-time real → Q-format bit pattern |

**Rounding modes** (`round_mode_e`):
- `ROUND_TRUNC` – truncate (floor toward −∞)
- `ROUND_NEAREST` – round half-up (ties to even)
- `ROUND_CONV` – convergent / banker's rounding
- `ROUND_CEIL` – ceiling (round toward +∞)

---

### `sat_arith.sv`

Six independent modules sharing a common interface pattern:

| Module | Latency | Key parameter |
|--------|---------|---------------|
| `sat_add` | 1 cycle | `WIDTH` |
| `sat_sub` | 1 cycle | `WIDTH` |
| `sat_mul` | 1 or 2 cycles | `WIDTH`, `FRAC_W`, `STAGES` |
| `sat_abs` | 1 cycle | `WIDTH` |
| `sat_neg` | 1 cycle | `WIDTH` |
| `sat_shift` | 1 cycle | `WIDTH`, `SHIFT_W` |

All modules expose an `ovf` overflow flag registered in phase with the output.

**`sat_mul` stage selection:**
```
STAGES=1 – multiply + saturate in a single registered stage (lower latency)
STAGES=2 – multiply in stage 1, saturate in stage 2 (higher Fmax)
```

**Example instantiation:**
```systemverilog
sat_add #(.WIDTH(24)) u_add (
  .clk(clk), .rst_n(rst_n), .en(en),
  .a(x_24), .b(y_24),
  .result(sum_24), .ovf(sum_ovf)
);
```

---

### `mac_unit.sv`

Pipelined Multiply-Accumulate with configurable accumulator headroom.

```
acc = acc + (a × b >>> FRAC_W)   [clr=0]
acc = (a × b >>> FRAC_W)          [clr=1]
```

**Pipeline stages** (when `REGISTER_INPUTS=1`):
```
Cycle 0 : Input register
Cycle 1 : Multiply  (a × b)
Cycle 2 : Re-align  (>>> FRAC_W)
Cycle 3 : Accumulate + saturate  → result
```
Total latency = `REGISTER_INPUTS + 3` cycles.

| Parameter | Default | Description |
|-----------|---------|-------------|
| `DATA_W` | 16 | Operand and output width |
| `FRAC_W` | 8 | Q-format fractional bits |
| `ACC_EXTRA_W` | 8 | Accumulator guard MSBs |
| `REGISTER_INPUTS` | 1 | 0/1 – register a/b at input |
| `SATURATE` | 1 | 0 = wrap, 1 = saturate |

`acc_out` exposes the full `DATA_W + ACC_EXTRA_W` accumulator value for chaining or inspection.

---

### `fir_filter.sv`

Transposed direct-form II FIR with serial coefficient loading.

**Architecture:**
```
Transposed form (right-to-left accumulator):

acc[k] = h[k]×x[n] + acc[k+1]_prev    (k = N_TAPS-1 downto 0)
y[n]   = acc[0]
```
This eliminates the long carry chain present in direct-form I and achieves full-rate throughput (one output per clock when `en=1`).

**Coefficient loading (serial shift-register):**
```
assert coeff_ld for N_TAPS cycles, presenting h[N_TAPS-1]..h[0]
on coeff_in MSB-first. Normal operation resumes when coeff_ld=0.
```

| Parameter | Default | Description |
|-----------|---------|-------------|
| `DATA_W` | 16 | Input sample width |
| `COEFF_W` | 16 | Coefficient width |
| `FRAC_W` | 14 | Q2.14 coefficient fractional bits |
| `N_TAPS` | 16 | Filter length |
| `ACC_GUARD` | 5 | Accumulator guard bits (≥ ⌈log₂(N_TAPS)⌉) |
| `SYMMETRIC` | 0 | 1 = linear-phase optimisation |
| `OUT_W` | 16 | Output width (with saturation) |

Output is rounded (round-nearest) and saturated to `OUT_W` bits.

---

### `fft_butterfly_r2.sv`

Radix-2 DIT butterfly with built-in twiddle-factor ROM.

```
P = (A + W_N^r × B) / 2    ← divide-by-2 prevents bit-growth across stages
Q = (A − W_N^r × B) / 2
```

**4-stage pipeline:**
```
Stage 0 : Input register + synchronous ROM read
Stage 1 : Complex multiply  (4 real multipliers)
Stage 2 : Combine products, re-align Q-format, saturate
Stage 3 : Butterfly add/subtract + divide-by-2
```
Latency = **4 cycles**.

**Twiddle ROM** is initialised via `$cos`/`$sin` at elaboration time and maps to BRAM or distributed RAM during synthesis.

| Parameter | Default | Description |
|-----------|---------|-------------|
| `DATA_W` | 16 | Complex operand width (per component) |
| `TWIDDLE_W` | 16 | Coefficient ROM width |
| `FRAC_W` | 15 | Q1.15 twiddle (range −1..+1) |
| `TWIDDLE_SIZE` | 64 | FFT point count N |

The `tw_addr` input selects twiddle factor r (0 ≤ r < N/2).

---

## Fixed-Point Format Convention

All modules use **Q(INT_W).(FRAC_W)** signed two's complement:

```
 Sign │  Integer bits   │  Fractional bits
  1b  │  (INT_W-1) bits │  FRAC_W bits

Value = raw_integer × 2^(−FRAC_W)
Range = [−2^(INT_W−1), 2^(INT_W−1) − 2^(−FRAC_W)]
```

**Common formats used in this library:**

| Format | INT_W | FRAC_W | Total | Range | Resolution |
|--------|-------|--------|-------|-------|-----------|
| Q8.8 | 8 | 8 | 16 | −128 .. +127.996 | 0.00390625 |
| Q2.14 | 2 | 14 | 16 | −2 .. +1.99994 | 6.1×10⁻⁵ |
| Q1.15 | 1 | 15 | 16 | −1 .. +0.99997 | 3.05×10⁻⁵ |
| Q8.24 | 8 | 24 | 32 | −128 .. +127.99 | 5.96×10⁻⁸ |

---

## Running Simulations

### Prerequisites

```bash
# Icarus Verilog (free, recommended for quick checks)
sudo apt-get install iverilog   # Debian/Ubuntu
brew install icarus-verilog      # macOS

# GTKWave (for waveform viewing)
sudo apt-get install gtkwave
```

### Run all testbenches

```bash
cd dsp_arithmetic
chmod +x sim/run_all.sh
./sim/run_all.sh
```

### Run a single testbench

```bash
./sim/run_all.sh iverilog tb_mac_unit
./sim/run_all.sh iverilog tb_fft_butterfly
```

### View waveforms

```bash
gtkwave sim/out/tb_fft_butterfly.vcd &
```

### Run with VCS

```bash
./sim/run_all.sh vcs
```

---

## Synthesis Guidelines

All RTL is synthesis-clean with the following recommendations:

**Target constraints:**
```
# Vivado XDC example (100 MHz, 16-bit path)
create_clock -period 10.0 [get_ports clk]
set_input_delay  2.0 -clock clk [all_inputs]
set_output_delay 2.0 -clock clk [all_outputs]
```

**Module resource estimates (Xilinx 7-series, 16-bit):**

| Module | LUTs | FFs | DSP48 | BRAM |
|--------|------|-----|-------|------|
| `sat_add` | 18 | 18 | 0 | 0 |
| `sat_mul` (STAGES=2) | 4 | 66 | 1 | 0 |
| `mac_unit` | 12 | 80 | 1 | 0 |
| `fir_filter` (N=16) | 64 | 320 | 16 | 0 |
| `fft_butterfly_r2` | 48 | 180 | 4 | 1 |

**Synthesis flags:**
- `keep_hierarchy = no` – allow flattening for better DSP inference
- Ensure `FRAC_W` matches your coefficient precision for correct `>>>` mapping
- For `fft_butterfly_r2`, set `TWIDDLE_SIZE` to a power-of-2 to guarantee ROM inference

---

## Extending the Library

**Adding a new filter type** (e.g. IIR biquad):
1. Import `fixed_point_pkg.sv`
2. Use `fp_mul_reformat` for Q-format product handling
3. Use `sat_add` / `sat_sub` for feedback accumulation
4. Export via the same `en / vld / ovf` handshake pattern

**Increasing precision:**
```systemverilog
// Change from Q8.8 to Q8.24 across a design:
fir_filter #(.DATA_W(32), .COEFF_W(32), .FRAC_W(24), .N_TAPS(32)) u_fir (...);
mac_unit   #(.DATA_W(32), .FRAC_W(24), .ACC_EXTRA_W(8))            u_mac (...);
```

**Building a complete FFT engine:**
Instantiate `fft_butterfly_r2` in a butterfly network.
Feed `tw_addr` from a separate address sequencer that walks the standard radix-2 DIT schedule.
Use the `/2` scaling built into each butterfly to prevent bit-growth across log₂(N) stages.

---

## Licence

MIT – free to use, modify, and incorporate in commercial or open-source designs.
