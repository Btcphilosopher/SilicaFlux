// =============================================================================
// sat_arith.sv
// Saturating Arithmetic Units
//
// Modules
//   sat_add   – signed saturating adder
//   sat_sub   – signed saturating subtractor
//   sat_mul   – signed saturating multiplier (pipelined, LATENCY=1 or 2)
//   sat_abs   – saturating absolute value
//   sat_neg   – saturating negation
//   sat_shift – arithmetic shift with saturation on left-shift
//
// All units are parameterisable in width and pipeline depth.
// Overflow flag is registered with the data path so it stays coherent.
// =============================================================================

`ifndef SAT_ARITH_SV
`define SAT_ARITH_SV

`include "fixed_point_pkg.sv"
import fixed_point_pkg::*;

// =============================================================================
// sat_add – pipelined saturating adder  (1-cycle latency)
//
//   out = clamp(a + b, MIN, MAX)
//   WIDTH : operand and result width (signed two's complement)
// =============================================================================
module sat_add #(
  parameter int WIDTH = 16
)(
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic                    en,
  input  logic signed [WIDTH-1:0] a,
  input  logic signed [WIDTH-1:0] b,
  output logic signed [WIDTH-1:0] result,
  output logic                    ovf        // overflow flag (registered)
);

  // Guard bit: carry the sum in WIDTH+1 bits, then saturate
  logic signed [WIDTH:0] sum_full;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      result   <= '0;
      ovf      <= 1'b0;
    end else if (en) begin
      sum_full  = {a[WIDTH-1], a} + {b[WIDTH-1], b}; // sign-extend then add

      // Saturation logic: if the two sign-extension bits differ the result
      // fits; if they match but differ from the true MSB we have overflowed.
      if (sum_full[WIDTH] != sum_full[WIDTH-1]) begin
        // Overflow – saturate
        result <= sum_full[WIDTH] ? {1'b1, {(WIDTH-1){1'b0}}}   // most-neg
                                  : {1'b0, {(WIDTH-1){1'b1}}};  // most-pos
        ovf    <= 1'b1;
      end else begin
        result <= sum_full[WIDTH-1:0];
        ovf    <= 1'b0;
      end
    end
  end

endmodule


// =============================================================================
// sat_sub – pipelined saturating subtractor  (1-cycle latency)
// =============================================================================
module sat_sub #(
  parameter int WIDTH = 16
)(
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic                    en,
  input  logic signed [WIDTH-1:0] a,
  input  logic signed [WIDTH-1:0] b,
  output logic signed [WIDTH-1:0] result,
  output logic                    ovf
);

  logic signed [WIDTH:0] diff_full;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      result <= '0;
      ovf    <= 1'b0;
    end else if (en) begin
      diff_full = {a[WIDTH-1], a} - {b[WIDTH-1], b};

      if (diff_full[WIDTH] != diff_full[WIDTH-1]) begin
        result <= diff_full[WIDTH] ? {1'b1, {(WIDTH-1){1'b0}}}
                                   : {1'b0, {(WIDTH-1){1'b1}}};
        ovf    <= 1'b1;
      end else begin
        result <= diff_full[WIDTH-1:0];
        ovf    <= 1'b0;
      end
    end
  end

endmodule


// =============================================================================
// sat_mul – pipelined saturating multiplier
//
//   FRAC_W : fractional bits – product is re-aligned before saturation
//   STAGES  : 1 = single FF stage; 2 = split multiply + reformat (better Fmax)
//
//   Full product width = 2*WIDTH bits; re-aligned to WIDTH with saturation.
// =============================================================================
module sat_mul #(
  parameter int WIDTH  = 16,
  parameter int FRAC_W = 8,
  parameter int STAGES = 2         // pipeline stages (1 or 2)
)(
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic                    en,
  input  logic signed [WIDTH-1:0] a,
  input  logic signed [WIDTH-1:0] b,
  output logic signed [WIDTH-1:0] result,
  output logic                    ovf
);

  localparam int PROD_W = 2 * WIDTH;

  logic signed [PROD_W-1:0] product_r;
  logic signed [PROD_W-1:0] shifted;

  // Stage 1 – multiply
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) product_r <= '0;
    else if (en) product_r <= a * b;
  end

  // Stage 2 (or combinatorial part of stage 1) – re-align + saturate
  generate
    if (STAGES == 2) begin : g_two_stage
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          result <= '0;
          ovf    <= 1'b0;
        end else if (en) begin
          shifted = product_r >>> FRAC_W;
          if (shifted > $signed({{(PROD_W-WIDTH){1'b0}},
                                  {1'b0, {(WIDTH-1){1'b1}}}}) ||
              shifted < $signed({{(PROD_W-WIDTH){1'b1}},
                                  {1'b1, {(WIDTH-1){1'b0}}}})) begin
            result <= shifted[PROD_W-1] ? {1'b1, {(WIDTH-1){1'b0}}}
                                        : {1'b0, {(WIDTH-1){1'b1}}};
            ovf    <= 1'b1;
          end else begin
            result <= shifted[WIDTH-1:0];
            ovf    <= 1'b0;
          end
        end
      end
    end else begin : g_one_stage
      // Combine multiply and saturation into one registered stage
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          result <= '0;
          ovf    <= 1'b0;
        end else if (en) begin
          automatic logic signed [PROD_W-1:0] p;
          automatic logic signed [PROD_W-1:0] s;
          p = a * b;
          s = p >>> FRAC_W;
          if (s > $signed({{(PROD_W-WIDTH){1'b0}},
                            {1'b0, {(WIDTH-1){1'b1}}}}) ||
              s < $signed({{(PROD_W-WIDTH){1'b1}},
                            {1'b1, {(WIDTH-1){1'b0}}}})) begin
            result <= s[PROD_W-1] ? {1'b1, {(WIDTH-1){1'b0}}}
                                  : {1'b0, {(WIDTH-1){1'b1}}};
            ovf    <= 1'b1;
          end else begin
            result <= s[WIDTH-1:0];
            ovf    <= 1'b0;
          end
        end
      end
    end
  endgenerate

endmodule


// =============================================================================
// sat_abs – saturating absolute value  (1-cycle latency)
//
//   Handles the special case ABS(MIN_NEG) → MAX_POS  (standard overflow rule)
// =============================================================================
module sat_abs #(
  parameter int WIDTH = 16
)(
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic                    en,
  input  logic signed [WIDTH-1:0] a,
  output logic signed [WIDTH-1:0] result,
  output logic                    ovf
);

  localparam logic signed [WIDTH-1:0] MIN_NEG = {1'b1, {(WIDTH-1){1'b0}}};
  localparam logic signed [WIDTH-1:0] MAX_POS = {1'b0, {(WIDTH-1){1'b1}}};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      result <= '0;
      ovf    <= 1'b0;
    end else if (en) begin
      if (a == MIN_NEG) begin
        result <= MAX_POS;   // saturate
        ovf    <= 1'b1;
      end else begin
        result <= a[WIDTH-1] ? -a : a;
        ovf    <= 1'b0;
      end
    end
  end

endmodule


// =============================================================================
// sat_neg – saturating negation  (1-cycle latency)
// =============================================================================
module sat_neg #(
  parameter int WIDTH = 16
)(
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic                    en,
  input  logic signed [WIDTH-1:0] a,
  output logic signed [WIDTH-1:0] result,
  output logic                    ovf
);

  localparam logic signed [WIDTH-1:0] MIN_NEG = {1'b1, {(WIDTH-1){1'b0}}};
  localparam logic signed [WIDTH-1:0] MAX_POS = {1'b0, {(WIDTH-1){1'b1}}};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      result <= '0;
      ovf    <= 1'b0;
    end else if (en) begin
      if (a == MIN_NEG) begin
        result <= MAX_POS;
        ovf    <= 1'b1;
      end else begin
        result <= -a;
        ovf    <= 1'b0;
      end
    end
  end

endmodule


// =============================================================================
// sat_shift – arithmetic left/right shift with saturation  (1-cycle latency)
//
//   DIR : 0 = right (arithmetic, no saturation possible)
//         1 = left  (may overflow, saturate)
//   SHIFT_W : bits needed to represent max shift amount
// =============================================================================
module sat_shift #(
  parameter int WIDTH   = 16,
  parameter int SHIFT_W = 4         // supports shifts 0 .. 2^SHIFT_W-1
)(
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic                    en,
  input  logic                    dir,         // 0=right, 1=left
  input  logic [SHIFT_W-1:0]      shamt,
  input  logic signed [WIDTH-1:0] a,
  output logic signed [WIDTH-1:0] result,
  output logic                    ovf
);

  // Extend to 2*WIDTH to detect left-shift overflow
  localparam int WIDE = 2 * WIDTH;
  logic signed [WIDE-1:0] wide_shift;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      result <= '0;
      ovf    <= 1'b0;
    end else if (en) begin
      if (!dir) begin
        // Arithmetic right shift – always representable
        result <= a >>> shamt;
        ovf    <= 1'b0;
      end else begin
        // Left shift – detect saturation needed
        wide_shift = WIDE'(signed'(a)) <<< shamt;
        if (wide_shift > $signed({{(WIDE-WIDTH){1'b0}},
                                   {1'b0, {(WIDTH-1){1'b1}}}}) ||
            wide_shift < $signed({{(WIDE-WIDTH){1'b1}},
                                   {1'b1, {(WIDTH-1){1'b0}}}})) begin
          result <= wide_shift[WIDE-1] ? {1'b1, {(WIDTH-1){1'b0}}}
                                       : {1'b0, {(WIDTH-1){1'b1}}};
          ovf    <= 1'b1;
        end else begin
          result <= wide_shift[WIDTH-1:0];
          ovf    <= 1'b0;
        end
      end
    end
  end

endmodule

`endif // SAT_ARITH_SV
