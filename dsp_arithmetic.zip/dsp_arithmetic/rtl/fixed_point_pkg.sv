// =============================================================================
// fixed_point_pkg.sv
// Fixed-Point Arithmetic Library Package
//
// Format: Q<INT_W>.<FRAC_W>  (signed two's complement)
//   Total width = INT_W + FRAC_W
//   INT_W includes the sign bit
//   Value range: -2^(INT_W-1) to 2^(INT_W-1) - 2^(-FRAC_W)
//   Resolution : 2^(-FRAC_W)
//
// Parameterisation: All functions accept INT_W / FRAC_W as parameters so
// they synthesise correctly for any precision target.
// =============================================================================

`ifndef FIXED_POINT_PKG_SV
`define FIXED_POINT_PKG_SV

package fixed_point_pkg;

  // ---------------------------------------------------------------------------
  // Common format aliases  (override in your top-level as needed)
  // ---------------------------------------------------------------------------
  localparam int DEFAULT_INT_W  = 8;   // integer bits (incl. sign)
  localparam int DEFAULT_FRAC_W = 8;   // fractional bits
  localparam int DEFAULT_W      = DEFAULT_INT_W + DEFAULT_FRAC_W;

  // ---------------------------------------------------------------------------
  // Type definition helpers (parameterised via macros – SV doesn't allow
  // parameterised typedefs directly, so we expose the width constant)
  // ---------------------------------------------------------------------------
  typedef logic signed [DEFAULT_W-1:0] sfixed_t;   // default Q8.8

  // ===========================================================================
  // SECTION 1 – Saturation helpers
  // ===========================================================================

  // Return max positive value for a WIDTH-bit signed number
  function automatic logic signed [63:0] fp_max_pos(input int WIDTH);
    return (64'sd1 <<< (WIDTH-1)) - 64'sd1;
  endfunction

  // Return max negative value (most-negative) for a WIDTH-bit signed number
  function automatic logic signed [63:0] fp_max_neg(input int WIDTH);
    return -(64'sd1 <<< (WIDTH-1));
  endfunction

  // Saturate a wide signed result to TARGET_W bits
  function automatic logic signed [63:0] fp_saturate(
    input  logic signed [63:0] value,
    input  int                  TARGET_W
  );
    logic signed [63:0] pos_lim, neg_lim;
    pos_lim = fp_max_pos(TARGET_W);
    neg_lim = fp_max_neg(TARGET_W);
    if (value > pos_lim) return pos_lim;
    if (value < neg_lim) return neg_lim;
    return value;
  endfunction

  // ===========================================================================
  // SECTION 2 – Arithmetic (returns 64-bit for caller to truncate / saturate)
  // ===========================================================================

  // Fixed-point add: identical formats, result has one guard bit
  function automatic logic signed [63:0] fp_add(
    input  logic signed [63:0] a,
    input  logic signed [63:0] b
  );
    return a + b;
  endfunction

  // Fixed-point subtract
  function automatic logic signed [63:0] fp_sub(
    input  logic signed [63:0] a,
    input  logic signed [63:0] b
  );
    return a - b;
  endfunction

  // Fixed-point multiply: Q(IW).(FW) × Q(IW).(FW) → Q(2*IW).(2*FW)
  // Caller must right-shift by FRAC_W to re-align, then truncate.
  function automatic logic signed [63:0] fp_mul(
    input  logic signed [63:0] a,
    input  logic signed [63:0] b
  );
    return a * b;
  endfunction

  // Re-align product: shift right by FRAC_W (arithmetic), then saturate to OUT_W
  function automatic logic signed [63:0] fp_mul_reformat(
    input  logic signed [63:0] product,
    input  int                  FRAC_W,
    input  int                  OUT_W
  );
    logic signed [63:0] shifted;
    shifted = product >>> FRAC_W;
    return fp_saturate(shifted, OUT_W);
  endfunction

  // Negate (two's complement) with saturation (handles min-negative edge case)
  function automatic logic signed [63:0] fp_negate(
    input  logic signed [63:0] value,
    input  int                  WIDTH
  );
    if (value == fp_max_neg(WIDTH))
      return fp_max_pos(WIDTH);   // saturate
    return -value;
  endfunction

  // Absolute value with saturation
  function automatic logic signed [63:0] fp_abs(
    input  logic signed [63:0] value,
    input  int                  WIDTH
  );
    if (value < 0) return fp_negate(value, WIDTH);
    return value;
  endfunction

  // ===========================================================================
  // SECTION 3 – Rounding modes
  // ===========================================================================

  typedef enum logic [1:0] {
    ROUND_TRUNC     = 2'b00,   // truncate (round toward -inf)
    ROUND_NEAREST   = 2'b01,   // round to nearest, ties to even
    ROUND_CONV      = 2'b10,   // convergent (banker's rounding)
    ROUND_CEIL      = 2'b11    // ceiling (round toward +inf)
  } round_mode_e;

  // Round and truncate a wide value down to OUT_W bits,
  // dropping DROP_BITS LSBs according to the chosen rounding mode.
  function automatic logic signed [63:0] fp_round(
    input  logic signed [63:0] value,
    input  int                  DROP_BITS,
    input  round_mode_e         mode
  );
    logic signed [63:0] truncated;
    logic              lsb, guard, sticky;
    logic signed [63:0] half;

    truncated = value >>> DROP_BITS;
    if (DROP_BITS == 0) return value;

    half    = 64'sd1 <<< (DROP_BITS - 1);
    lsb     = value[DROP_BITS];             // LSB of truncated result
    guard   = value[DROP_BITS-1];           // guard bit (first dropped)
    sticky  = |value[DROP_BITS-2:0];        // OR of remaining dropped bits

    case (mode)
      ROUND_TRUNC:   return truncated;
      ROUND_NEAREST: return (guard && (sticky || lsb)) ?
                              truncated + 64'sd1 : truncated;
      ROUND_CONV:    return (guard && sticky)  ? truncated + 64'sd1 :
                            (guard && !sticky) ? (lsb ? truncated + 64'sd1
                                                       : truncated) :
                                                  truncated;
      ROUND_CEIL:    return (|value[DROP_BITS-1:0]) ?
                              truncated + 64'sd1 : truncated;
      default:       return truncated;
    endcase
  endfunction

  // ===========================================================================
  // SECTION 4 – Conversion utilities
  // ===========================================================================

  // Integer → fixed-point (left-shift by FRAC_W)
  function automatic logic signed [63:0] int_to_fp(
    input  logic signed [31:0] int_val,
    input  int                  FRAC_W
  );
    return 64'(signed'(int_val)) <<< FRAC_W;
  endfunction

  // Real (compile-time) → fixed-point bit pattern  (use in parameter/localparam)
  // e.g. localparam signed [15:0] COEFF = fp_from_real(-0.75, 8, 8);
  function automatic logic signed [63:0] fp_from_real(
    input  real r,
    input  int  INT_W,
    input  int  FRAC_W
  );
    real        scale;
    longint     raw;
    scale = 2.0 ** FRAC_W;
    raw   = longint'(r * scale);
    // clamp to range
    if (raw >  ((1 <<< (INT_W + FRAC_W - 1)) - 1))
      raw = (1 <<< (INT_W + FRAC_W - 1)) - 1;
    if (raw < -(1 <<< (INT_W + FRAC_W - 1)))
      raw = -(1 <<< (INT_W + FRAC_W - 1));
    return raw;
  endfunction

  // ===========================================================================
  // SECTION 5 – Overflow detection
  // ===========================================================================

  // Returns 1 if |value| exceeds the representable range for WIDTH-bit signed
  function automatic logic fp_overflow(
    input  logic signed [63:0] value,
    input  int                  WIDTH
  );
    return (value > fp_max_pos(WIDTH)) || (value < fp_max_neg(WIDTH));
  endfunction

  // Carry/sign-bit overflow detect for add (inputs and result all WIDTH bits)
  function automatic logic fp_add_overflow(
    input  logic signed [63:0] a,
    input  logic signed [63:0] b,
    input  int                  WIDTH
  );
    logic signed [63:0] result;
    result = a + b;
    // Overflow if signs of a and b agree but differ from result
    return (a[WIDTH-1] == b[WIDTH-1]) && (result[WIDTH-1] != a[WIDTH-1]);
  endfunction

endpackage

`endif // FIXED_POINT_PKG_SV
