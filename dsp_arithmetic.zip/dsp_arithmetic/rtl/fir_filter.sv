// =============================================================================
// fir_filter.sv
// Pipelined Direct-Form FIR Filter
//
// Architecture: Transposed direct-form II  (transpose form)
//   - Eliminates long carry-chain on the critical path
//   - Each tap computes  h[k]*x[n]  then accumulates right-to-left
//   - Fully pipelined: one new sample accepted per clock when en=1
//
// Signal flow (N_TAPS = 4, example):
//   y[n] = h[0]*x[n] + h[1]*x[n-1] + h[2]*x[n-2] + h[3]*x[n-3]
//
//   Transposed form register chain:
//     acc[3] = h[3]*x[n]
//     acc[2] = h[2]*x[n] + acc[3]_prev
//     acc[1] = h[1]*x[n] + acc[2]_prev
//     acc[0] = h[0]*x[n] + acc[1]_prev  ← output
//
// Parameters
//   DATA_W    – input sample width (signed)
//   COEFF_W   – coefficient width (signed, Q(COEFF_W-FRAC_W).FRAC_W)
//   FRAC_W    – fractional bits in coefficient / product re-alignment
//   N_TAPS    – filter length (number of coefficients)
//   ACC_GUARD – extra MSBs on accumulator (≥ ceil(log2(N_TAPS)))
//   SYMMETRIC – 1 → exploit coefficient symmetry (halves multipliers for
//               linear-phase FIR; requires N_TAPS even and symmetric h[])
//   OUT_W     – output width after truncation (≤ DATA_W + ACC_GUARD)
//
// Latency: N_TAPS cycles (one stage per tap, direct form)
//
// Coefficient loading
//   Coefficients are loaded via a serial shift-register interface:
//     coeff_ld  : 1 = shift new coefficient into position 0
//     coeff_in  : coefficient data (COEFF_W bits)
//   Shift N_TAPS times to populate all positions [0..N_TAPS-1].
//   Normal operation resumes once coeff_ld deasserts.
// =============================================================================

`ifndef FIR_FILTER_SV
`define FIR_FILTER_SV

`include "fixed_point_pkg.sv"
import fixed_point_pkg::*;

module fir_filter #(
  parameter int DATA_W    = 16,
  parameter int COEFF_W   = 16,
  parameter int FRAC_W    = 14,       // Q2.14 coefficients (range -2..+2)
  parameter int N_TAPS    = 16,
  parameter int ACC_GUARD = 5,        // ceil(log2(32)) for up to 32 taps
  parameter int SYMMETRIC = 0,        // 1 = linear-phase symmetry optimisation
  parameter int OUT_W     = 16        // output word length
)(
  input  logic                     clk,
  input  logic                     rst_n,
  input  logic                     en,           // sample enable (one per cycle)

  // Coefficient load interface
  input  logic                     coeff_ld,
  input  logic signed [COEFF_W-1:0] coeff_in,

  // Data path
  input  logic signed [DATA_W-1:0] data_in,
  output logic signed [OUT_W-1:0]  data_out,
  output logic                     data_vld,
  output logic                     ovf           // accumulator overflow flag
);

  // ---------------------------------------------------------------------------
  // Local parameters
  // ---------------------------------------------------------------------------
  localparam int PROD_W  = DATA_W + COEFF_W;          // full multiply width
  localparam int ACC_W   = PROD_W + ACC_GUARD;         // accumulator width
  localparam int HALF    = N_TAPS / 2;                 // for symmetric mode

  // ---------------------------------------------------------------------------
  // Coefficient RAM (shift-register loadable)
  // ---------------------------------------------------------------------------
  logic signed [COEFF_W-1:0] coeff [0:N_TAPS-1];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < N_TAPS; i++) coeff[i] <= '0;
    end else if (coeff_ld) begin
      // Shift new coefficient into index 0, push rest up
      coeff[0] <= coeff_in;
      for (int i = 1; i < N_TAPS; i++) coeff[i] <= coeff[i-1];
    end
  end

  // ---------------------------------------------------------------------------
  // Sample delay line (x[n], x[n-1] .. x[n-(N_TAPS-1)])
  // ---------------------------------------------------------------------------
  logic signed [DATA_W-1:0] delay [0:N_TAPS-1];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < N_TAPS; i++) delay[i] <= '0;
    end else if (en && !coeff_ld) begin
      delay[0] <= data_in;
      for (int i = 1; i < N_TAPS; i++) delay[i] <= delay[i-1];
    end
  end

  // ---------------------------------------------------------------------------
  // Transposed-form accumulator chain
  //
  //  Non-symmetric path (SYMMETRIC=0):
  //    For k = N_TAPS-1 downto 0:
  //      partial[k] = coeff[k] * delay[k] + partial[k+1]   (registered)
  //    data_out = partial[0]   (after truncation)
  //
  //  Symmetric path (SYMMETRIC=1):
  //    Pre-add:  sym_add[k] = delay[k] + delay[N_TAPS-1-k]  (k=0..HALF-1)
  //    Then multiply each sym_add[k] by coeff[k]
  //    Coefficients: only first HALF values needed
  // ---------------------------------------------------------------------------

  generate
    if (!SYMMETRIC) begin : g_direct

      // Accumulator registers – N_TAPS stages
      logic signed [ACC_W-1:0] acc [0:N_TAPS];   // acc[N_TAPS] = 0 (seed)
      logic signed [PROD_W-1:0] prod_stage [0:N_TAPS-1];

      // Seed is always zero
      assign acc[N_TAPS] = '0;

      // Generate each tap stage (k = N_TAPS-1 downto 0)
      for (genvar k = N_TAPS-1; k >= 0; k--) begin : g_tap
        always_ff @(posedge clk or negedge rst_n) begin
          if (!rst_n) begin
            acc[k] <= '0;
          end else if (en && !coeff_ld) begin
            // Multiply then re-align, then accumulate
            automatic logic signed [PROD_W-1:0] p;
            automatic logic signed [ACC_W-1:0]  p_ext;
            automatic logic signed [ACC_W:0]    sum_guard;

            p       = delay[k] * coeff[k];
            p_ext   = ACC_W'(signed'(p >>> FRAC_W));   // re-align
            sum_guard = {p_ext[ACC_W-1], p_ext} +
                        {acc[k+1][ACC_W-1], acc[k+1]};
            // Saturate
            if (sum_guard[ACC_W] != sum_guard[ACC_W-1])
              acc[k] <= sum_guard[ACC_W] ? {1'b1, {(ACC_W-1){1'b0}}}
                                         : {1'b0, {(ACC_W-1){1'b1}}};
            else
              acc[k] <= sum_guard[ACC_W-1:0];
          end
        end
      end

      // Overflow detect: check guard bits on the final accumulator
      logic signed [ACC_GUARD:0] upper_chk;
      assign upper_chk = acc[0][ACC_W-1 -: ACC_GUARD+1];
      assign ovf       = ~(&upper_chk[ACC_GUARD:1]) && ~(~|upper_chk[ACC_GUARD:1]);

      // Output truncation with rounding (round-nearest)
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          data_out <= '0;
        end else if (en && !coeff_ld) begin
          automatic logic signed [ACC_W-1:0] rounded;
          automatic int DROP;
          DROP = ACC_W - OUT_W;

          // Round-nearest: add 0.5 at the truncation boundary
          if (DROP > 0)
            rounded = acc[0] + (ACC_W'(1) <<< (DROP - 1));
          else
            rounded = acc[0];

          // Saturate to OUT_W
          if (rounded > $signed(ACC_W'({1'b0,{(OUT_W-1){1'b1}}})) ||
              rounded < $signed(ACC_W'({1'b1,{(OUT_W-1){1'b0}}}))) begin
            data_out <= rounded[ACC_W-1] ? {1'b1, {(OUT_W-1){1'b0}}}
                                         : {1'b0, {(OUT_W-1){1'b1}}};
          end else begin
            data_out <= rounded[OUT_W-1:0];
          end
        end
      end

    end else begin : g_symmetric  // SYMMETRIC = 1

      // Only valid when N_TAPS is even
      // Symmetry: h[k] == h[N_TAPS-1-k], so we pre-add input pairs.
      localparam int HALF_TAPS = N_TAPS / 2;

      logic signed [DATA_W:0]    sym_add [0:HALF_TAPS-1];  // pre-adder (1 guard bit)
      logic signed [ACC_W-1:0]   acc     [0:HALF_TAPS];

      assign acc[HALF_TAPS] = '0;

      // Pre-adders: combinatorial
      always_comb begin
        for (int k = 0; k < HALF_TAPS; k++) begin
          sym_add[k] = {delay[k][DATA_W-1], delay[k]} +
                       {delay[N_TAPS-1-k][DATA_W-1], delay[N_TAPS-1-k]};
        end
      end

      // Tap stages
      for (genvar k = HALF_TAPS-1; k >= 0; k--) begin : g_sym_tap
        always_ff @(posedge clk or negedge rst_n) begin
          if (!rst_n) begin
            acc[k] <= '0;
          end else if (en && !coeff_ld) begin
            automatic logic signed [PROD_W:0]   p;
            automatic logic signed [ACC_W-1:0]  p_ext;
            automatic logic signed [ACC_W:0]    sum_guard;

            // sym_add is DATA_W+1 bits, multiply by COEFF_W → PROD_W+1
            p       = $signed({sym_add[k][DATA_W], sym_add[k]}) * $signed(coeff[k]);
            p_ext   = ACC_W'(signed'(p >>> FRAC_W));
            sum_guard = {p_ext[ACC_W-1], p_ext} +
                        {acc[k+1][ACC_W-1], acc[k+1]};
            if (sum_guard[ACC_W] != sum_guard[ACC_W-1])
              acc[k] <= sum_guard[ACC_W] ? {1'b1, {(ACC_W-1){1'b0}}}
                                         : {1'b0, {(ACC_W-1){1'b1}}};
            else
              acc[k] <= sum_guard[ACC_W-1:0];
          end
        end
      end

      // Overflow detect
      logic signed [ACC_GUARD:0] upper_chk;
      assign upper_chk = acc[0][ACC_W-1 -: ACC_GUARD+1];
      assign ovf       = ~(&upper_chk[ACC_GUARD:1]) && ~(~|upper_chk[ACC_GUARD:1]);

      // Output with saturation
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          data_out <= '0;
        end else if (en && !coeff_ld) begin
          automatic logic signed [ACC_W-1:0] rounded;
          automatic int DROP;
          DROP = ACC_W - OUT_W;
          rounded = (DROP > 0) ? acc[0] + (ACC_W'(1) <<< (DROP - 1)) : acc[0];
          if (rounded > $signed(ACC_W'({1'b0,{(OUT_W-1){1'b1}}})) ||
              rounded < $signed(ACC_W'({1'b1,{(OUT_W-1){1'b0}}})))
            data_out <= rounded[ACC_W-1] ? {1'b1, {(OUT_W-1){1'b0}}}
                                         : {1'b0, {(OUT_W-1){1'b1}}};
          else
            data_out <= rounded[OUT_W-1:0];
        end
      end

    end
  endgenerate

  // ---------------------------------------------------------------------------
  // Valid shift register: latency = N_TAPS cycles
  // ---------------------------------------------------------------------------
  logic [N_TAPS-1:0] vld_sr;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) vld_sr <= '0;
    else        vld_sr <= {vld_sr[N_TAPS-2:0], en & ~coeff_ld};
  end

  assign data_vld = vld_sr[N_TAPS-1];

endmodule

`endif // FIR_FILTER_SV
