// =============================================================================
// fft_butterfly_r2.sv
// Radix-2 FFT Butterfly Unit (DIT – Decimation-In-Time)
//
// Computes the radix-2 DIT butterfly:
//   X[k]        = A + W_N^r * B
//   X[k + N/2]  = A - W_N^r * B
//
// Where W_N^r = exp(-j * 2π * r / N) = cos(2πr/N) - j*sin(2πr/N)
//
// Architecture (3-stage pipeline):
//   Stage 1 : Complex multiply  B × W  (4 real multiplies, 2 adds)
//   Stage 2 : Twiddle product add/sub latency balancer
//   Stage 3 : Butterfly add/sub   A ± BW
//
// Twiddle factors
//   Stored in a read-only ROM (generated at elaboration time from TWIDDLE_SIZE).
//   Address is the radix-2 twiddle index r (0 .. TWIDDLE_SIZE/2 - 1).
//   TWIDDLE_SIZE = FFT point count N.
//
// Parameters
//   DATA_W       – width of real and imaginary parts of A and B (signed)
//   TWIDDLE_W    – coefficient width for twiddle ROM
//   FRAC_W       – fractional bits in twiddle factors (Q1.(TWIDDLE_W-1))
//   TWIDDLE_SIZE – total FFT size N (must be power-of-2)
//
// Fixed-point representation
//   All twiddle factors normalised to range (-1, +1), stored as
//   Q1.(TWIDDLE_W-1) signed.  e.g. TWIDDLE_W=16 → Q1.15, resolution 2^-15.
//
// Latency: 4 clock cycles
//
// Ports
//   a_re, a_im  – top butterfly input  (complex)
//   b_re, b_im  – bottom butterfly input (complex)
//   tw_addr     – twiddle factor index r (log2(TWIDDLE_SIZE)-1 bits)
//   p_re, p_im  – top output:     A + W*B
//   q_re, q_im  – bottom output:  A - W*B
// =============================================================================

`ifndef FFT_BUTTERFLY_R2_SV
`define FFT_BUTTERFLY_R2_SV

`include "fixed_point_pkg.sv"
import fixed_point_pkg::*;

module fft_butterfly_r2 #(
  parameter int DATA_W       = 16,
  parameter int TWIDDLE_W    = 16,
  parameter int FRAC_W       = 15,       // Q1.15 twiddle factors
  parameter int TWIDDLE_SIZE = 64        // FFT size N (number of twiddle entries)
)(
  input  logic                     clk,
  input  logic                     rst_n,
  input  logic                     en,

  // Top input: A
  input  logic signed [DATA_W-1:0] a_re,
  input  logic signed [DATA_W-1:0] a_im,

  // Bottom input: B
  input  logic signed [DATA_W-1:0] b_re,
  input  logic signed [DATA_W-1:0] b_im,

  // Twiddle index
  input  logic [$clog2(TWIDDLE_SIZE)-1:0] tw_addr,

  // Outputs
  output logic signed [DATA_W-1:0] p_re,   // A + W*B  (real)
  output logic signed [DATA_W-1:0] p_im,   // A + W*B  (imag)
  output logic signed [DATA_W-1:0] q_re,   // A - W*B  (real)
  output logic signed [DATA_W-1:0] q_im,   // A - W*B  (imag)

  output logic                     vld,
  output logic                     ovf
);

  // ---------------------------------------------------------------------------
  // Local parameters
  // ---------------------------------------------------------------------------
  localparam int PROD_W = DATA_W + TWIDDLE_W;    // multiply output width
  localparam int ACC_W  = PROD_W + 1;            // one guard bit for add
  localparam int HALF   = TWIDDLE_SIZE / 2;      // twiddle entries needed

  // ---------------------------------------------------------------------------
  // Twiddle-factor ROM
  // Generated using the formula:
  //   cos_table[r] = round(cos(2π*r/N) * 2^FRAC_W)
  //   sin_table[r] = round(sin(2π*r/N) * 2^FRAC_W)
  // ---------------------------------------------------------------------------
  logic signed [TWIDDLE_W-1:0] tw_cos [0:HALF-1];
  logic signed [TWIDDLE_W-1:0] tw_sin [0:HALF-1];

  // Initialise twiddle ROM at elaboration time
  // (In real synthesis this maps to distributed RAM or BRAMs)
  initial begin
    for (int r = 0; r < HALF; r++) begin
      tw_cos[r] = $signed($rtoi($cos(2.0 * $acos(-1.0) * r / TWIDDLE_SIZE)
                                * (2.0**FRAC_W)));
      tw_sin[r] = $signed($rtoi($sin(2.0 * $acos(-1.0) * r / TWIDDLE_SIZE)
                                * (2.0**FRAC_W)));
    end
  end

  // ---------------------------------------------------------------------------
  // Stage 0 – input registers + twiddle ROM read  (combinatorial ROM)
  // ---------------------------------------------------------------------------
  logic signed [DATA_W-1:0]   a_re_s0, a_im_s0, b_re_s0, b_im_s0;
  logic signed [TWIDDLE_W-1:0] wr_s0, wi_s0;
  logic en_s0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      a_re_s0 <= '0; a_im_s0 <= '0;
      b_re_s0 <= '0; b_im_s0 <= '0;
      wr_s0   <= '0; wi_s0   <= '0;
      en_s0   <= 1'b0;
    end else begin
      a_re_s0 <= a_re; a_im_s0 <= a_im;
      b_re_s0 <= b_re; b_im_s0 <= b_im;
      // ROM read (registered output = synchronous ROM, +1 cycle from addr)
      wr_s0   <=  tw_cos[tw_addr[$clog2(HALF)-1:0]];
      wi_s0   <= -tw_sin[tw_addr[$clog2(HALF)-1:0]];  // conjugate for DIT
      en_s0   <= en;
    end
  end

  // ---------------------------------------------------------------------------
  // Stage 1 – complex multiply: BW = (b_re + j*b_im) × (wr + j*wi)
  //
  //   BW_re = b_re*wr - b_im*wi
  //   BW_im = b_re*wi + b_im*wr
  //
  // Using 4-multiply form (synthesis may remap to 3-mult Karatsuba)
  // ---------------------------------------------------------------------------
  logic signed [PROD_W-1:0] mul_rr, mul_ri, mul_ir, mul_ii;
  logic signed [DATA_W-1:0] a_re_s1, a_im_s1;
  logic en_s1;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mul_rr  <= '0; mul_ri  <= '0;
      mul_ir  <= '0; mul_ii  <= '0;
      a_re_s1 <= '0; a_im_s1 <= '0;
      en_s1   <= 1'b0;
    end else begin
      mul_rr  <= b_re_s0 * wr_s0;   // b_re * cos
      mul_ii  <= b_im_s0 * wi_s0;   // b_im * (-sin)
      mul_ri  <= b_re_s0 * wi_s0;   // b_re * (-sin)
      mul_ir  <= b_im_s0 * wr_s0;   // b_im * cos
      a_re_s1 <= a_re_s0;
      a_im_s1 <= a_im_s0;
      en_s1   <= en_s0;
    end
  end

  // ---------------------------------------------------------------------------
  // Stage 2 – combine complex multiply (add/sub + re-align)
  // ---------------------------------------------------------------------------
  logic signed [DATA_W-1:0] bw_re_s2, bw_im_s2;
  logic signed [DATA_W-1:0] a_re_s2,  a_im_s2;
  logic en_s2;
  logic ovf_mul_re, ovf_mul_im;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      bw_re_s2    <= '0; bw_im_s2    <= '0;
      a_re_s2     <= '0; a_im_s2     <= '0;
      en_s2       <= 1'b0;
      ovf_mul_re  <= 1'b0; ovf_mul_im <= 1'b0;
    end else begin
      // BW_re = b_re*cos - b_im*(-sin) = mul_rr - mul_ii
      // BW_im = b_re*(-sin) + b_im*cos = mul_ri + mul_ir
      automatic logic signed [ACC_W-1:0] bw_re_full, bw_im_full;
      bw_re_full = ACC_W'(signed'(mul_rr)) - ACC_W'(signed'(mul_ii));
      bw_im_full = ACC_W'(signed'(mul_ri)) + ACC_W'(signed'(mul_ir));

      // Re-align: shift right by FRAC_W to restore Q format
      automatic logic signed [ACC_W-1:0] bw_re_al, bw_im_al;
      bw_re_al = bw_re_full >>> FRAC_W;
      bw_im_al = bw_im_full >>> FRAC_W;

      // Saturate to DATA_W
      if (bw_re_al > $signed(ACC_W'({1'b0,{(DATA_W-1){1'b1}}})) ||
          bw_re_al < $signed(ACC_W'({1'b1,{(DATA_W-1){1'b0}}}))) begin
        bw_re_s2   <= bw_re_al[ACC_W-1] ? {1'b1,{(DATA_W-1){1'b0}}}
                                         : {1'b0,{(DATA_W-1){1'b1}}};
        ovf_mul_re <= 1'b1;
      end else begin
        bw_re_s2   <= bw_re_al[DATA_W-1:0];
        ovf_mul_re <= 1'b0;
      end

      if (bw_im_al > $signed(ACC_W'({1'b0,{(DATA_W-1){1'b1}}})) ||
          bw_im_al < $signed(ACC_W'({1'b1,{(DATA_W-1){1'b0}}}))) begin
        bw_im_s2   <= bw_im_al[ACC_W-1] ? {1'b1,{(DATA_W-1){1'b0}}}
                                         : {1'b0,{(DATA_W-1){1'b1}}};
        ovf_mul_im <= 1'b1;
      end else begin
        bw_im_s2   <= bw_im_al[DATA_W-1:0];
        ovf_mul_im <= 1'b0;
      end

      a_re_s2 <= a_re_s1;
      a_im_s2 <= a_im_s1;
      en_s2   <= en_s1;
    end
  end

  // ---------------------------------------------------------------------------
  // Stage 3 – butterfly add/subtract   P = A + BW,   Q = A - BW
  //   Divide by 2 (right-shift 1) to prevent bit-growth across FFT stages
  // ---------------------------------------------------------------------------
  logic ovf_add;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      p_re <= '0; p_im <= '0;
      q_re <= '0; q_im <= '0;
      ovf  <= 1'b0;
    end else begin
      automatic logic signed [DATA_W:0] p_re_g, p_im_g, q_re_g, q_im_g;
      // Use one guard bit to catch any final overflow
      p_re_g = {a_re_s2[DATA_W-1], a_re_s2} + {bw_re_s2[DATA_W-1], bw_re_s2};
      p_im_g = {a_im_s2[DATA_W-1], a_im_s2} + {bw_im_s2[DATA_W-1], bw_im_s2};
      q_re_g = {a_re_s2[DATA_W-1], a_re_s2} - {bw_re_s2[DATA_W-1], bw_re_s2};
      q_im_g = {a_im_s2[DATA_W-1], a_im_s2} - {bw_im_s2[DATA_W-1], bw_im_s2};

      // Divide-by-2 to maintain scaling across stages (arithmetic right shift)
      p_re <= p_re_g[DATA_W:1];
      p_im <= p_im_g[DATA_W:1];
      q_re <= q_re_g[DATA_W:1];
      q_im <= q_im_g[DATA_W:1];

      ovf  <= ovf_mul_re | ovf_mul_im |
              (p_re_g[DATA_W] ^ p_re_g[DATA_W-1]) |
              (p_im_g[DATA_W] ^ p_im_g[DATA_W-1]) |
              (q_re_g[DATA_W] ^ q_re_g[DATA_W-1]) |
              (q_im_g[DATA_W] ^ q_im_g[DATA_W-1]);
    end
  end

  // ---------------------------------------------------------------------------
  // Valid pipeline – 4-cycle latency
  // ---------------------------------------------------------------------------
  logic [3:0] vld_sr;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) vld_sr <= '0;
    else        vld_sr <= {vld_sr[2:0], en};
  end

  assign vld = vld_sr[3];

endmodule

`endif // FFT_BUTTERFLY_R2_SV
