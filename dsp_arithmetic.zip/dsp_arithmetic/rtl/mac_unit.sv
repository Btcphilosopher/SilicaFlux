// =============================================================================
// mac_unit.sv
// Multiply-Accumulate (MAC) Unit
//
// Computes: acc = acc + (a × b)   or   acc = (a × b)  (when clr asserted)
//
// Architecture
//   Stage 0 : Input registers (optional, REGISTER_INPUTS=1)
//   Stage 1 : Multiply       (a × b → product[2*DATA_W-1:0])
//   Stage 2 : Re-align       (product >>> FRAC_W → aligned[DATA_W+GUARD_W-1:0])
//   Stage 3 : Accumulate     (acc += aligned, with saturation)
//
// Parameters
//   DATA_W         – width of a and b operands (signed)
//   FRAC_W         – fractional bits (for Q-format re-alignment)
//   ACC_EXTRA_W    – extra MSBs on accumulator above DATA_W (guard against
//                    long-sum overflow; typically ceil(log2(N_MACS)))
//   REGISTER_INPUTS – 1 = register a/b on clock edge (helps timing)
//   SATURATE        – 1 = saturate accumulator output; 0 = wrap
//
// Latency: REGISTER_INPUTS + 3 cycles  (inputs→mul→align→acc→q_result)
//
// Control
//   clr : synchronous clear – resets accumulator to zero on next rising edge
//         (also clears the pipeline so no stale partial product gets added)
//   en  : pipeline enable (all stages)
//   vld : output valid, asserted LATENCY cycles after en is first asserted
// =============================================================================

`ifndef MAC_UNIT_SV
`define MAC_UNIT_SV

`include "fixed_point_pkg.sv"
import fixed_point_pkg::*;

module mac_unit #(
  parameter int DATA_W          = 16,    // operand width
  parameter int FRAC_W          = 8,     // Q-format fractional bits
  parameter int ACC_EXTRA_W     = 8,     // accumulator guard bits
  parameter int REGISTER_INPUTS = 1,     // 0 or 1
  parameter int SATURATE        = 1      // saturate accumulator output
)(
  input  logic                     clk,
  input  logic                     rst_n,
  input  logic                     en,
  input  logic                     clr,           // synchronous accumulator clear
  input  logic signed [DATA_W-1:0] a,
  input  logic signed [DATA_W-1:0] b,
  output logic signed [DATA_W-1:0] result,        // saturated/truncated to DATA_W
  output logic signed [DATA_W+ACC_EXTRA_W-1:0] acc_out, // full accumulator value
  output logic                     vld,
  output logic                     ovf
);

  // ---------------------------------------------------------------------------
  // Local parameters
  // ---------------------------------------------------------------------------
  localparam int PROD_W  = 2 * DATA_W;
  localparam int ACC_W   = DATA_W + ACC_EXTRA_W;
  localparam int LATENCY = REGISTER_INPUTS + 3;

  // ---------------------------------------------------------------------------
  // Stage 0 – optional input registers
  // ---------------------------------------------------------------------------
  logic signed [DATA_W-1:0] a_s0, b_s0;
  logic                     clr_s0, en_s0;

  generate
    if (REGISTER_INPUTS) begin : g_in_reg
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          a_s0   <= '0;  b_s0   <= '0;
          clr_s0 <= 1'b0; en_s0 <= 1'b0;
        end else begin
          a_s0   <= a;   b_s0   <= b;
          clr_s0 <= clr; en_s0  <= en;
        end
      end
    end else begin : g_no_in_reg
      assign a_s0   = a;
      assign b_s0   = b;
      assign clr_s0 = clr;
      assign en_s0  = en;
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // Stage 1 – multiply
  // ---------------------------------------------------------------------------
  logic signed [PROD_W-1:0] product_s1;
  logic                     clr_s1, en_s1;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      product_s1 <= '0;
      clr_s1     <= 1'b0;
      en_s1      <= 1'b0;
    end else begin
      product_s1 <= a_s0 * b_s0;   // signed multiply
      clr_s1     <= clr_s0;
      en_s1      <= en_s0;
    end
  end

  // ---------------------------------------------------------------------------
  // Stage 2 – re-align (arithmetic right-shift by FRAC_W)
  //   Result width: PROD_W – FRAC_W = 2*DATA_W – FRAC_W
  //   We extend sign into ACC_W to feed the accumulator
  // ---------------------------------------------------------------------------
  logic signed [ACC_W-1:0] aligned_s2;
  logic                    clr_s2, en_s2;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      aligned_s2 <= '0;
      clr_s2     <= 1'b0;
      en_s2      <= 1'b0;
    end else begin
      aligned_s2 <= ACC_W'(signed'(product_s1 >>> FRAC_W));
      clr_s2     <= clr_s1;
      en_s2      <= en_s1;
    end
  end

  // ---------------------------------------------------------------------------
  // Stage 3 – accumulate  (with saturation / overflow detect)
  // ---------------------------------------------------------------------------
  logic signed [ACC_W-1:0] acc_reg;
  logic signed [ACC_W:0]   acc_sum;   // one extra guard bit for overflow detect
  logic                    acc_ovf;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      acc_reg <= '0;
      ovf     <= 1'b0;
    end else if (en_s2) begin
      if (clr_s2) begin
        // Clear: load current aligned value directly
        acc_reg <= aligned_s2;
        ovf     <= 1'b0;
      end else begin
        acc_sum  = {acc_reg[ACC_W-1], acc_reg} +
                   {aligned_s2[ACC_W-1], aligned_s2};
        acc_ovf  = acc_sum[ACC_W] ^ acc_sum[ACC_W-1]; // sign-bit overflow

        if (SATURATE && acc_ovf) begin
          acc_reg <= acc_sum[ACC_W] ? {1'b1, {(ACC_W-1){1'b0}}}
                                    : {1'b0, {(ACC_W-1){1'b1}}};
          ovf     <= 1'b1;
        end else begin
          acc_reg <= acc_sum[ACC_W-1:0];
          ovf     <= acc_ovf;
        end
      end
    end
  end

  // ---------------------------------------------------------------------------
  // Output truncation / saturation to DATA_W
  // ---------------------------------------------------------------------------
  always_comb begin
    acc_out = acc_reg;

    if (SATURATE) begin
      // Check whether upper ACC_EXTRA_W bits are all-same (no overflow)
      logic signed [ACC_EXTRA_W:0] upper;
      upper = acc_reg[ACC_W-1 -: ACC_EXTRA_W+1];
      if (&upper[ACC_EXTRA_W:1] || ~|upper[ACC_EXTRA_W:1]) begin
        // Upper bits uniform – safe to truncate
        result = acc_reg[DATA_W-1:0];
      end else begin
        // Overflow – saturate output
        result = acc_reg[ACC_W-1] ? {1'b1, {(DATA_W-1){1'b0}}}
                                  : {1'b0, {(DATA_W-1){1'b1}}};
      end
    end else begin
      result = acc_reg[DATA_W-1:0];  // wrap
    end
  end

  // ---------------------------------------------------------------------------
  // Valid signal – shift register tracks pipeline fill
  // ---------------------------------------------------------------------------
  logic [LATENCY-1:0] vld_sr;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) vld_sr <= '0;
    else        vld_sr <= {vld_sr[LATENCY-2:0], en};
  end

  assign vld = vld_sr[LATENCY-1];

endmodule

`endif // MAC_UNIT_SV
