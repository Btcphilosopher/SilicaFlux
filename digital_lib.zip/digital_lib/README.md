# digital_lib — Parameterised Digital Logic IP Library

Production-quality SystemVerilog components: fully parameterised, synthesisable
RTL with self-checking testbenches for every module.

---

## Repository structure

```
digital_lib/
├── rtl/
│   ├── primitives/          full_adder · half_adder
│   ├── adders/              ripple_carry · carry_lookahead · carry_select
│   ├── multipliers/         array_multiplier · wallace_tree_multiplier
│   ├── comparators/         comparator
│   ├── encoders/            priority_encoder
│   ├── mux/                 mux · demux
│   └── shifters/            barrel_shifter
├── tb/                      one testbench per module
└── sim/
    ├── Makefile             Questa/ModelSim targets
    └── run_all.sh           multi-simulator regression script
```

---

## Module reference

### Adders

| Module | Parameters | Key properties |
|--------|-----------|----------------|
| `ripple_carry_adder` | `WIDTH` | Carries `overflow` (signed); FA chain; depends on `full_adder` |
| `carry_lookahead_adder` | `WIDTH` (mult of 4) | 4-bit CLA blocks; full 2-level lookahead for ≤16-bit; `cla_block` sub-module |
| `carry_select_adder` | `WIDTH`, `BLOCK_SIZE` | Dual speculative RCA per block; 2:1 MUX final select |

All adders export `cout` and `overflow` (signed overflow via sign-bit comparison).

### Multipliers

| Module | Parameters | Notes |
|--------|-----------|-------|
| `array_multiplier` | `WIDTH`, `SIGNED` | Structural partial-product chain; 2's-complement sign extension for `SIGNED=1` |
| `wallace_tree_multiplier` | `WIDTH` ∈ {4,8,16} | CSA tree reduction; 2/4/6 stages; unsigned only |

**Signed multiplier correctness**: sign-extended partial products with negated MSB term — verified for `a=-128, b=-1 → 128`; `a=-128, b=-128 → 16384`.

### Comparators

`comparator #(.WIDTH(W), .SIGNED(S))` — structural MSB→LSB cascade.
Signed mode uses MSB-inversion trick: `a_cmp={~a[MSB],a[MSB-1:0]}` maps signed to unsigned ordering.

### Priority Encoder

`priority_encoder #(.WIDTH(W), .LSB_FIRST(L))` — `always_comb` loop unrolls to priority-MUX at synthesis. `LSB_FIRST=1` selects lowest set bit; `=0` selects highest.

### MUX / DEMUX

- `mux #(.NUM_INPUTS(N), .DATA_WIDTH(W))` — binary tree of 2:1 cells; `N` must be power of 2.
- `demux #(.NUM_OUTPUTS(N), .DATA_WIDTH(W))` — decoder selects one output; others zero.

### Barrel Shifter

`barrel_shifter #(.WIDTH(W))` — three parallel shift chains (left-logical, right-logical, right-arithmetic) with runtime `direction`/`arithmetic` selection. Binary decomposition gives O(log₂ W) gate depth.

---

## Design constraints

| Rule | Rationale |
|------|-----------|
| No vendor primitives | Portable across Xilinx, Intel, Lattice, ASIC |
| `logic` everywhere | Avoids `wire`/`reg` ambiguity |
| `generate` for structural replication | Parameterised without unrolled code |
| `always_comb` for combinational logic | Latch-free by construction |
| `$clog2` for address widths | Correct for any power-of-2 parameter |
| `// synthesis translate_off/on` guards | Runtime checks stripped from netlist |

---

## Simulation

### Questa / ModelSim
```bash
cd sim
make TB=tb_ripple_carry_adder    # single test
make all                         # all tests
```

### Icarus Verilog
```bash
cd sim
./run_all.sh iverilog
```

### VCS
```bash
cd sim
./run_all.sh vcs
```

---

## Testbench strategy

Each testbench applies three test tiers:

1. **Directed corners** — zero, max, all-ones, known overflow / boundary conditions
2. **Exhaustive sweep** — full input space for ≤ 6-bit widths (or 4-bit sub-instantiation)
3. **Pseudo-random** — 500–2000 vectors with fixed seed; checked against behavioural reference

All testbenches include:
- **Immediate assertions** (`assert ... else $error`) after each stimulus application
- **Concurrent SVA properties** (`assert property`) sampled on a free-running clock
- Pass/fail counter with `$display` summary line (`ALL TESTS PASSED` or `*** FAILURES DETECTED ***`)

---

## Parameters quick-reference

```
ripple_carry_adder      WIDTH=8
carry_lookahead_adder   WIDTH=16   (4, 8, 12, 16, 20, ... multiples of 4)
carry_select_adder      WIDTH=16   BLOCK_SIZE=4
array_multiplier        WIDTH=8    SIGNED=0|1
wallace_tree_multiplier WIDTH=8    (4, 8, 16 only)
comparator              WIDTH=8    SIGNED=0|1
priority_encoder        WIDTH=8    LSB_FIRST=0|1
mux                     NUM_INPUTS=4  DATA_WIDTH=8  (NUM_INPUTS must be power of 2)
demux                   NUM_OUTPUTS=4 DATA_WIDTH=8
barrel_shifter          WIDTH=8    (power of 2)
```
