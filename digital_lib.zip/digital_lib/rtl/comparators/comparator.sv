`timescale 1ns/1ps
// =============================================================================
// Parameterised Comparator  (unsigned or signed 2's-complement)
//
// Structural cascade from MSB to LSB using generate/propagate signals:
//   gt_s[k+1] = gt so far OR (equal so far AND a[bit] > b[bit])
//   lt_s[k+1] = lt so far OR (equal so far AND a[bit] < b[bit])
//   eq_s[k+1] = equal so far AND a[bit] == b[bit]
//
// For SIGNED: MSB comparison polarity is inverted (negative weight in 2's-c).
// Implemented via the standard MSB-inversion trick:
//   a_cmp = {~a[MSB], a[MSB-1:0]},  b_cmp = {~b[MSB], b[MSB-1:0]}
// This maps signed ordering onto unsigned ordering with no extra logic.
// =============================================================================
module comparator #(
    parameter int WIDTH  = 8,
    parameter bit SIGNED = 1'b0
) (
    input  logic [WIDTH-1:0] a,
    input  logic [WIDTH-1:0] b,
    output logic             eq,
    output logic             lt,
    output logic             gt
);
    logic [WIDTH-1:0] a_cmp, b_cmp;

    // Map signed comparison to unsigned by inverting the sign bit
    generate
        if (SIGNED) begin : g_signed_remap
            assign a_cmp = {~a[WIDTH-1], a[WIDTH-2:0]};
            assign b_cmp = {~b[WIDTH-1], b[WIDTH-2:0]};
        end else begin : g_unsigned_direct
            assign a_cmp = a;
            assign b_cmp = b;
        end
    endgenerate

    // Cascade from MSB (index 0 here) to LSB (index WIDTH-1)
    logic [WIDTH:0] gt_s, lt_s, eq_s;

    assign gt_s[0] = 1'b0;
    assign lt_s[0] = 1'b0;
    assign eq_s[0] = 1'b1;

    genvar i;
    generate
        for (i = 0; i < WIDTH; i++) begin : gen_cmp
            // Process bits from MSB to LSB: bit index = WIDTH-1-i
            assign gt_s[i+1] = gt_s[i] | (eq_s[i] &  a_cmp[WIDTH-1-i] & ~b_cmp[WIDTH-1-i]);
            assign lt_s[i+1] = lt_s[i] | (eq_s[i] & ~a_cmp[WIDTH-1-i] &  b_cmp[WIDTH-1-i]);
            assign eq_s[i+1] = eq_s[i] & ~(a_cmp[WIDTH-1-i] ^ b_cmp[WIDTH-1-i]);
        end
    endgenerate

    assign gt = gt_s[WIDTH];
    assign lt = lt_s[WIDTH];
    assign eq = eq_s[WIDTH];
endmodule
