`timescale 1ns/1ps
// =============================================================================
// Wallace Tree Multiplier  (unsigned)
//
// Reduces N partial products to 2 using CSA (3:2 compressor) stages, then
// adds the final two rows with a carry-propagate adder.
// CSA: sum = a^b^c,  carry = ((a&b)|(a&c)|(b&c)) << 1
//
// Supported widths : 4, 8, 16
// Signed operation : use array_multiplier with SIGNED=1; or negate inputs
//                    externally and the product if signs differ.
//
// Stage counts  :  WIDTH=4  -> 2 stages -> 2 rows -> final CPA
//                 WIDTH=8  -> 4 stages -> 2 rows -> final CPA
//                 WIDTH=16 -> 6 stages -> 2 rows -> final CPA
// =============================================================================
module wallace_tree_multiplier #(
    parameter int WIDTH = 8
) (
    input  logic [WIDTH-1:0]   a,
    input  logic [WIDTH-1:0]   b,
    output logic [2*WIDTH-1:0] product
);
    // synthesis translate_off
    initial begin
        if (WIDTH != 4 && WIDTH != 8 && WIDTH != 16)
            $fatal(1, "wallace_tree_multiplier: WIDTH must be 4, 8, or 16; got %0d", WIDTH);
    end
    // synthesis translate_on

    localparam int P_WIDTH = 2 * WIDTH;

    // -------------------------------------------------------------------------
    // Partial products (one per bit of b, zero-extended to P_WIDTH)
    // -------------------------------------------------------------------------
    logic [P_WIDTH-1:0] pp [WIDTH];
    genvar gi;
    generate
        for (gi = 0; gi < WIDTH; gi++) begin : gen_pp
            assign pp[gi] = b[gi] ? ({{WIDTH{1'b0}}, a} << gi) : {P_WIDTH{1'b0}};
        end
    endgenerate

    // -------------------------------------------------------------------------
    // Wallace tree reduction
    // -------------------------------------------------------------------------
    generate

        // ==============================
        // 4-bit : 4 -> 3 -> 2
        // ==============================
        if (WIDTH == 4) begin : wt4
            logic [P_WIDTH-1:0] s1, c1;
            logic [P_WIDTH-1:0] s2, c2;

            // Stage 1 : CSA(pp[0], pp[1], pp[2])
            assign s1 = pp[0] ^ pp[1] ^ pp[2];
            assign c1 = ((pp[0] & pp[1]) | (pp[0] & pp[2]) | (pp[1] & pp[2])) << 1;

            // Stage 2 : CSA(s1, c1, pp[3])
            assign s2 = s1 ^ c1 ^ pp[3];
            assign c2 = ((s1 & c1) | (s1 & pp[3]) | (c1 & pp[3])) << 1;

            assign product = s2 + c2;

        // ==============================
        // 8-bit : 8->6->4->3->2
        // ==============================
        end else if (WIDTH == 8) begin : wt8
            logic [P_WIDTH-1:0] s1a, c1a;
            logic [P_WIDTH-1:0] s1b, c1b;
            logic [P_WIDTH-1:0] s2a, c2a;
            logic [P_WIDTH-1:0] s2b, c2b;
            logic [P_WIDTH-1:0] s3a, c3a;
            logic [P_WIDTH-1:0] s4a, c4a;

            // Stage 1 : 8 -> 6  (2 CSA groups; pp[6],pp[7] pass through)
            assign s1a = pp[0] ^ pp[1] ^ pp[2];
            assign c1a = ((pp[0] & pp[1]) | (pp[0] & pp[2]) | (pp[1] & pp[2])) << 1;

            assign s1b = pp[3] ^ pp[4] ^ pp[5];
            assign c1b = ((pp[3] & pp[4]) | (pp[3] & pp[5]) | (pp[4] & pp[5])) << 1;

            // Stage 2 : 6 -> 4  (2 CSA groups)
            assign s2a = s1a ^ c1a ^ s1b;
            assign c2a = ((s1a & c1a) | (s1a & s1b) | (c1a & s1b)) << 1;

            assign s2b = c1b ^ pp[6] ^ pp[7];
            assign c2b = ((c1b & pp[6]) | (c1b & pp[7]) | (pp[6] & pp[7])) << 1;

            // Stage 3 : 4 -> 3  (1 CSA; c2b passes through)
            assign s3a = s2a ^ c2a ^ s2b;
            assign c3a = ((s2a & c2a) | (s2a & s2b) | (c2a & s2b)) << 1;

            // Stage 4 : 3 -> 2
            assign s4a = s3a ^ c3a ^ c2b;
            assign c4a = ((s3a & c3a) | (s3a & c2b) | (c3a & c2b)) << 1;

            assign product = s4a + c4a;

        // ==============================
        // 16-bit : 16->11->8->6->4->3->2
        // ==============================
        end else begin : wt16
            // Stage 1 intermediates
            logic [P_WIDTH-1:0] s1a, c1a, s1b, c1b, s1c, c1c, s1d, c1d, s1e, c1e;
            // Stage 2 intermediates
            logic [P_WIDTH-1:0] s2a, c2a, s2b, c2b, s2c, c2c;
            // Stage 3 intermediates
            logic [P_WIDTH-1:0] s3a, c3a, s3b, c3b;
            // Stage 4 intermediates
            logic [P_WIDTH-1:0] s4a, c4a, s4b, c4b;
            // Stage 5 intermediates
            logic [P_WIDTH-1:0] s5a, c5a;
            // Stage 6 intermediates
            logic [P_WIDTH-1:0] s6a, c6a;

            // --- Stage 1 : 16 -> 11 (5 CSA groups, pp[15] passes through) ---
            assign s1a = pp[0]  ^ pp[1]  ^ pp[2];
            assign c1a = ((pp[0]  & pp[1])  | (pp[0]  & pp[2])  | (pp[1]  & pp[2]))  << 1;

            assign s1b = pp[3]  ^ pp[4]  ^ pp[5];
            assign c1b = ((pp[3]  & pp[4])  | (pp[3]  & pp[5])  | (pp[4]  & pp[5]))  << 1;

            assign s1c = pp[6]  ^ pp[7]  ^ pp[8];
            assign c1c = ((pp[6]  & pp[7])  | (pp[6]  & pp[8])  | (pp[7]  & pp[8]))  << 1;

            assign s1d = pp[9]  ^ pp[10] ^ pp[11];
            assign c1d = ((pp[9]  & pp[10]) | (pp[9]  & pp[11]) | (pp[10] & pp[11])) << 1;

            assign s1e = pp[12] ^ pp[13] ^ pp[14];
            assign c1e = ((pp[12] & pp[13]) | (pp[12] & pp[14]) | (pp[13] & pp[14])) << 1;

            // --- Stage 2 : 11 -> 8 (3 CSA groups; c1e, pp[15] pass through) ---
            assign s2a = s1a ^ c1a ^ s1b;
            assign c2a = ((s1a & c1a) | (s1a & s1b) | (c1a & s1b)) << 1;

            assign s2b = c1b ^ s1c ^ c1c;
            assign c2b = ((c1b & s1c) | (c1b & c1c) | (s1c & c1c)) << 1;

            assign s2c = s1d ^ c1d ^ s1e;
            assign c2c = ((s1d & c1d) | (s1d & s1e) | (c1d & s1e)) << 1;

            // --- Stage 3 : 8 -> 6 (2 CSA groups; c1e, pp[15] pass through) ---
            assign s3a = s2a ^ c2a ^ s2b;
            assign c3a = ((s2a & c2a) | (s2a & s2b) | (c2a & s2b)) << 1;

            assign s3b = c2b ^ s2c ^ c2c;
            assign c3b = ((c2b & s2c) | (c2b & c2c) | (s2c & c2c)) << 1;

            // --- Stage 4 : 6 -> 4 (2 CSA groups) ---
            assign s4a = s3a ^ c3a ^ s3b;
            assign c4a = ((s3a & c3a) | (s3a & s3b) | (c3a & s3b)) << 1;

            assign s4b = c3b ^ c1e ^ pp[15];
            assign c4b = ((c3b & c1e) | (c3b & pp[15]) | (c1e & pp[15])) << 1;

            // --- Stage 5 : 4 -> 3 (1 CSA; c4b passes through) ---
            assign s5a = s4a ^ c4a ^ s4b;
            assign c5a = ((s4a & c4a) | (s4a & s4b) | (c4a & s4b)) << 1;

            // --- Stage 6 : 3 -> 2 ---
            assign s6a = s5a ^ c5a ^ c4b;
            assign c6a = ((s5a & c5a) | (s5a & c4b) | (c5a & c4b)) << 1;

            assign product = s6a + c6a;
        end

    endgenerate
endmodule
