`timescale 1ns/1ps
// =============================================================================
// Array Multiplier  (unsigned or signed 2's-complement)
//
// SIGNED = 0 : unsigned – partial products are zero-extended
// SIGNED = 1 : signed  – partial products are sign-extended;
//              MSB of b carries negative weight (standard 2's-complement PP)
//              Verified correct including the most-negative operand.
//
// Accumulation uses a chain of adder stages (structural '+' maps to RCA
// or CPA at synthesis; partial-product generation is fully gate-level).
// =============================================================================
module array_multiplier #(
    parameter int WIDTH  = 8,
    parameter bit SIGNED = 1'b0
) (
    input  logic [WIDTH-1:0]   a,
    input  logic [WIDTH-1:0]   b,
    output logic [2*WIDTH-1:0] product
);
    localparam int P_WIDTH = 2 * WIDTH;

    genvar gi;

    generate
        // ----------------------------------------------------------------
        // UNSIGNED path
        // ----------------------------------------------------------------
        if (!SIGNED) begin : g_unsigned
            logic [P_WIDTH-1:0] pp  [WIDTH];
            logic [P_WIDTH-1:0] acc [WIDTH];

            for (gi = 0; gi < WIDTH; gi++) begin : gen_pp_u
                assign pp[gi] = b[gi]
                              ? ({{WIDTH{1'b0}}, a} << gi)
                              : {P_WIDTH{1'b0}};
            end

            assign acc[0] = pp[0];
            for (gi = 1; gi < WIDTH; gi++) begin : gen_acc_u
                assign acc[gi] = acc[gi-1] + pp[gi];
            end

            assign product = acc[WIDTH-1];

        // ----------------------------------------------------------------
        // SIGNED path  (sign-extended partial products)
        //
        // For i = 0 .. WIDTH-2:  pp[i] = sign_extend(a) << i  (if b[i]=1)
        // For i = WIDTH-1:       pp = -(sign_extend(a) << (WIDTH-1)) (sign bit of b)
        //   implemented as (~sext_a + 1) shifted, i.e. (-sext_a) << (WIDTH-1)
        // ----------------------------------------------------------------
        end else begin : g_signed
            logic signed [P_WIDTH-1:0] sext_a;
            logic signed [P_WIDTH-1:0] neg_sext_a;
            logic        [P_WIDTH-1:0] pp  [WIDTH];
            logic        [P_WIDTH-1:0] acc [WIDTH];

            assign sext_a     = {{WIDTH{a[WIDTH-1]}}, a};
            assign neg_sext_a = -sext_a;

            // Positive-weight partial products
            for (gi = 0; gi < WIDTH-1; gi++) begin : gen_pp_pos
                assign pp[gi] = b[gi]
                              ? P_WIDTH'(sext_a << gi)
                              : {P_WIDTH{1'b0}};
            end

            // Negative-weight partial product (sign bit of b)
            assign pp[WIDTH-1] = b[WIDTH-1]
                               ? P_WIDTH'(neg_sext_a << (WIDTH-1))
                               : {P_WIDTH{1'b0}};

            assign acc[0] = pp[0];
            for (gi = 1; gi < WIDTH; gi++) begin : gen_acc_s
                assign acc[gi] = acc[gi-1] + pp[gi];
            end

            assign product = acc[WIDTH-1];
        end
    endgenerate
endmodule
