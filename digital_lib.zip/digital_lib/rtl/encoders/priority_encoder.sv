`timescale 1ns/1ps
// =============================================================================
// Priority Encoder
//
// LSB_FIRST = 1 : bit 0 has highest priority (finds lowest set bit index)
// LSB_FIRST = 0 : MSB has highest priority  (finds highest set bit index)
// valid          : asserted when at least one request bit is set
// enc            : encoded index of the winning bit; 0 when valid=0
//
// Structural: synthesises to a priority MUX tree via always_comb unrolled
// for-loop (fully combinational, no latches).
// =============================================================================
module priority_encoder #(
    parameter int WIDTH     = 8,
    parameter bit LSB_FIRST = 1'b1
) (
    input  logic [WIDTH-1:0]         req,
    output logic [$clog2(WIDTH)-1:0] enc,
    output logic                     valid
);
    localparam int ENC_W = $clog2(WIDTH);

    assign valid = |req;

    generate
        if (LSB_FIRST) begin : g_lsb
            // Iterate MSB->LSB; last write wins -> lowest set index dominates
            always_comb begin
                enc = {ENC_W{1'b0}};
                for (int k = WIDTH-1; k >= 0; k--) begin
                    if (req[k]) enc = ENC_W'(k);
                end
            end
        end else begin : g_msb
            // Iterate LSB->MSB; last write wins -> highest set index dominates
            always_comb begin
                enc = {ENC_W{1'b0}};
                for (int k = 0; k < WIDTH; k++) begin
                    if (req[k]) enc = ENC_W'(k);
                end
            end
        end
    endgenerate
endmodule
