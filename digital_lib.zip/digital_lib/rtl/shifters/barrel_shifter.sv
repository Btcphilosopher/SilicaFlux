`timescale 1ns/1ps
// =============================================================================
// Barrel Shifter  (WIDTH must be a power of 2)
//
// Supports all four modes via runtime-selectable ports:
//   direction  = 0 : left  shift (logical, fill LSBs with 0)
//   direction  = 1 : right shift
//   arithmetic = 0 : logical  right shift (fill MSBs with 0)
//   arithmetic = 1 : arithmetic right shift (fill MSBs with sign bit)
//
// Implementation: binary-decomposition – log2(WIDTH) stages in series.
//   Stage i conditionally shifts by 2^i bits when shift_amt[i] = 1.
// Three parallel shift chains (left-logical, right-logical, right-arith)
// are computed simultaneously; direction/arithmetic select the output.
// =============================================================================
module barrel_shifter #(
    parameter int WIDTH = 8
) (
    input  logic [WIDTH-1:0]         data_in,
    input  logic [$clog2(WIDTH)-1:0] shift_amt,
    input  logic                     direction,   // 0=left,  1=right
    input  logic                     arithmetic,  // 0=logical,1=arithmetic
    output logic [WIDTH-1:0]         data_out
);
    localparam int STAGES = $clog2(WIDTH);

    logic [WIDTH-1:0] stg_l [STAGES+1];   // left-logical stages
    logic [WIDTH-1:0] stg_r [STAGES+1];   // right-logical stages
    logic [WIDTH-1:0] stg_a [STAGES+1];   // right-arithmetic stages

    assign stg_l[0] = data_in;
    assign stg_r[0] = data_in;
    assign stg_a[0] = data_in;

    genvar i;
    generate
        for (i = 0; i < STAGES; i++) begin : gen_stage
            // Shift distance for this stage = 2^i
            localparam int SH = 1 << i;

            // Left logical: shift SH positions left, fill SH LSBs with 0
            assign stg_l[i+1] = shift_amt[i]
                ? {stg_l[i][WIDTH-1-SH:0], {SH{1'b0}}}
                : stg_l[i];

            // Right logical: shift SH positions right, fill SH MSBs with 0
            assign stg_r[i+1] = shift_amt[i]
                ? {{SH{1'b0}}, stg_r[i][WIDTH-1:SH]}
                : stg_r[i];

            // Right arithmetic: fill SH MSBs with original sign bit
            assign stg_a[i+1] = shift_amt[i]
                ? {{SH{data_in[WIDTH-1]}}, stg_a[i][WIDTH-1:SH]}
                : stg_a[i];
        end
    endgenerate

    // Output mux
    always_comb begin
        if (!direction)
            data_out = stg_l[STAGES];
        else if (!arithmetic)
            data_out = stg_r[STAGES];
        else
            data_out = stg_a[STAGES];
    end
endmodule
