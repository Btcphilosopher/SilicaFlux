`timescale 1ns/1ps
// =============================================================================
// Ripple Carry Adder
// Instantiates WIDTH full-adder cells in a chain.
// overflow : signed overflow flag = carry[WIDTH] XOR carry[WIDTH-1]
// Depends  : rtl/primitives/full_adder.sv
// =============================================================================
module ripple_carry_adder #(
    parameter int WIDTH = 8
) (
    input  logic [WIDTH-1:0] a,
    input  logic [WIDTH-1:0] b,
    input  logic             cin,
    output logic [WIDTH-1:0] sum,
    output logic             cout,
    output logic             overflow
);
    logic [WIDTH:0] carry;
    assign carry[0] = cin;

    genvar i;
    generate
        for (i = 0; i < WIDTH; i++) begin : gen_fa
            full_adder u_fa (
                .a    (a[i]),
                .b    (b[i]),
                .cin  (carry[i]),
                .sum  (sum[i]),
                .cout (carry[i+1])
            );
        end
    endgenerate

    assign cout     = carry[WIDTH];
    assign overflow = carry[WIDTH] ^ carry[WIDTH-1];
endmodule
