`timescale 1ns/1ps
// =============================================================================
// Carry Lookahead Adder  (hierarchical two-level CLA)
//
// cla_block              : 4-bit CLA building block with group G/P outputs
// carry_lookahead_adder  : top-level; WIDTH must be a multiple of 4
//   NUM_BLOCKS 1-4  -> full second-level CLA  (O(1) inter-block carry)
//   NUM_BLOCKS > 4  -> ripple between blocks  (O(1) intra-block carry)
// =============================================================================

// ----------------------------------------------------------------------------
// 4-bit CLA block
// ----------------------------------------------------------------------------
module cla_block (
    input  logic [3:0] a,
    input  logic [3:0] b,
    input  logic       cin,
    output logic [3:0] sum,
    output logic       cout,
    output logic       G,
    output logic       P
);
    logic [3:0] g, p;
    logic [4:0] c;

    assign g    = a & b;
    assign p    = a ^ b;
    assign c[0] = cin;

    assign c[1] = g[0] | (p[0] & c[0]);
    assign c[2] = g[1] | (p[1] & g[0])
                       | (p[1] & p[0] & c[0]);
    assign c[3] = g[2] | (p[2] & g[1])
                       | (p[2] & p[1] & g[0])
                       | (p[2] & p[1] & p[0] & c[0]);
    assign c[4] = g[3] | (p[3] & g[2])
                       | (p[3] & p[2] & g[1])
                       | (p[3] & p[2] & p[1] & g[0])
                       | (p[3] & p[2] & p[1] & p[0] & c[0]);

    assign sum  = p ^ c[3:0];
    assign cout = c[4];

    assign G = g[3] | (p[3] & g[2])
                    | (p[3] & p[2] & g[1])
                    | (p[3] & p[2] & p[1] & g[0]);
    assign P = &p;
endmodule

// ----------------------------------------------------------------------------
// Top-level hierarchical CLA
// ----------------------------------------------------------------------------
module carry_lookahead_adder #(
    parameter int WIDTH = 16
) (
    input  logic [WIDTH-1:0] a,
    input  logic [WIDTH-1:0] b,
    input  logic             cin,
    output logic [WIDTH-1:0] sum,
    output logic             cout,
    output logic             overflow
);
    // synthesis translate_off
    initial begin
        if (WIDTH % 4 != 0)
            $fatal(1, "carry_lookahead_adder: WIDTH must be a multiple of 4, got %0d", WIDTH);
    end
    // synthesis translate_on

    localparam int NUM_BLOCKS = WIDTH / 4;

    logic [NUM_BLOCKS-1:0] G_blk, P_blk;
    logic [NUM_BLOCKS:0]   blk_c;

    assign blk_c[0] = cin;

    genvar i;
    generate
        for (i = 0; i < NUM_BLOCKS; i++) begin : gen_cla
            cla_block u_cla (
                .a   (a  [4*i+3 : 4*i]),
                .b   (b  [4*i+3 : 4*i]),
                .cin (blk_c[i]),
                .sum (sum[4*i+3 : 4*i]),
                .cout(),
                .G   (G_blk[i]),
                .P   (P_blk[i])
            );
        end
    endgenerate

    generate
        if (NUM_BLOCKS == 1) begin : L1
            assign blk_c[1] = G_blk[0] | (P_blk[0] & cin);

        end else if (NUM_BLOCKS == 2) begin : L2
            assign blk_c[1] = G_blk[0] | (P_blk[0] & cin);
            assign blk_c[2] = G_blk[1] | (P_blk[1] & G_blk[0])
                                        | (P_blk[1] & P_blk[0] & cin);

        end else if (NUM_BLOCKS == 3) begin : L3
            assign blk_c[1] = G_blk[0] | (P_blk[0] & cin);
            assign blk_c[2] = G_blk[1] | (P_blk[1] & G_blk[0])
                                        | (P_blk[1] & P_blk[0] & cin);
            assign blk_c[3] = G_blk[2] | (P_blk[2] & G_blk[1])
                                        | (P_blk[2] & P_blk[1] & G_blk[0])
                                        | (P_blk[2] & P_blk[1] & P_blk[0] & cin);

        end else if (NUM_BLOCKS == 4) begin : L4
            assign blk_c[1] = G_blk[0] | (P_blk[0] & cin);
            assign blk_c[2] = G_blk[1] | (P_blk[1] & G_blk[0])
                                        | (P_blk[1] & P_blk[0] & cin);
            assign blk_c[3] = G_blk[2] | (P_blk[2] & G_blk[1])
                                        | (P_blk[2] & P_blk[1] & G_blk[0])
                                        | (P_blk[2] & P_blk[1] & P_blk[0] & cin);
            assign blk_c[4] = G_blk[3] | (P_blk[3] & G_blk[2])
                                        | (P_blk[3] & P_blk[2] & G_blk[1])
                                        | (P_blk[3] & P_blk[2] & P_blk[1] & G_blk[0])
                                        | (P_blk[3] & P_blk[2] & P_blk[1] & P_blk[0] & cin);

        end else begin : LRIPPLE
            for (genvar j = 1; j <= NUM_BLOCKS; j++) begin : gen_rc
                assign blk_c[j] = G_blk[j-1] | (P_blk[j-1] & blk_c[j-1]);
            end
        end
    endgenerate

    assign cout     = blk_c[NUM_BLOCKS];
    assign overflow = (~a[WIDTH-1] & ~b[WIDTH-1] &  sum[WIDTH-1])
                    | ( a[WIDTH-1] &  b[WIDTH-1] & ~sum[WIDTH-1]);
endmodule
