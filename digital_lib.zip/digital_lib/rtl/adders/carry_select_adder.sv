`timescale 1ns/1ps
// =============================================================================
// Carry Select Adder
// Each BLOCK_SIZE-bit block speculatively computes sum for cin=0 and cin=1
// in parallel; actual carry selects the correct result with a 2:1 MUX.
// Depends : rtl/adders/ripple_carry_adder.sv
// =============================================================================
module carry_select_adder #(
    parameter int WIDTH      = 16,
    parameter int BLOCK_SIZE = 4
) (
    input  logic [WIDTH-1:0] a,
    input  logic [WIDTH-1:0] b,
    input  logic             cin,
    output logic [WIDTH-1:0] sum,
    output logic             cout,
    output logic             overflow
);
    // synthesis translate_off
    initial begin
        if (WIDTH % BLOCK_SIZE != 0)
            $fatal(1, "carry_select_adder: WIDTH (%0d) must be divisible by BLOCK_SIZE (%0d)",
                   WIDTH, BLOCK_SIZE);
    end
    // synthesis translate_on

    localparam int NUM_BLOCKS = WIDTH / BLOCK_SIZE;

    logic [NUM_BLOCKS:0] carry;
    assign carry[0] = cin;

    genvar i;
    generate
        for (i = 0; i < NUM_BLOCKS; i++) begin : gen_block
            logic [BLOCK_SIZE-1:0] sum0, sum1;
            logic                  c0, c1;

            ripple_carry_adder #(.WIDTH(BLOCK_SIZE)) u_rca0 (
                .a       (a[BLOCK_SIZE*(i+1)-1 : BLOCK_SIZE*i]),
                .b       (b[BLOCK_SIZE*(i+1)-1 : BLOCK_SIZE*i]),
                .cin     (1'b0), .sum(sum0), .cout(c0), .overflow()
            );
            ripple_carry_adder #(.WIDTH(BLOCK_SIZE)) u_rca1 (
                .a       (a[BLOCK_SIZE*(i+1)-1 : BLOCK_SIZE*i]),
                .b       (b[BLOCK_SIZE*(i+1)-1 : BLOCK_SIZE*i]),
                .cin     (1'b1), .sum(sum1), .cout(c1), .overflow()
            );

            assign sum  [BLOCK_SIZE*(i+1)-1 : BLOCK_SIZE*i] = carry[i] ? sum1 : sum0;
            assign carry[i+1]                               = carry[i] ? c1   : c0;
        end
    endgenerate

    assign cout     = carry[NUM_BLOCKS];
    assign overflow = (~a[WIDTH-1] & ~b[WIDTH-1] &  sum[WIDTH-1])
                    | ( a[WIDTH-1] &  b[WIDTH-1] & ~sum[WIDTH-1]);
endmodule
