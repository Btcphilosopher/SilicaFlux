`timescale 1ns/1ps
// =============================================================================
// 1:N Demultiplexer
// Routes the single input to output[sel]; all other outputs are zero.
// =============================================================================
module demux #(
    parameter int NUM_OUTPUTS = 4,
    parameter int DATA_WIDTH  = 8
) (
    input  logic [DATA_WIDTH-1:0]          in,
    input  logic [$clog2(NUM_OUTPUTS)-1:0] sel,
    output logic [DATA_WIDTH-1:0]          out [NUM_OUTPUTS]
);
    localparam int SEL_W = $clog2(NUM_OUTPUTS);

    genvar i;
    generate
        for (i = 0; i < NUM_OUTPUTS; i++) begin : gen_out
            assign out[i] = (sel == SEL_W'(i)) ? in : {DATA_WIDTH{1'b0}};
        end
    endgenerate
endmodule
