`timescale 1ns/1ps
// =============================================================================
// N:1 Multiplexer  (binary-tree structure, NUM_INPUTS must be a power of 2)
//
// Structural binary tree: log2(NUM_INPUTS) levels of 2:1 MUXes.
//   Level k selects on sel[k]:  stg[k+1][j] = sel[k] ? stg[k][2j+1] : stg[k][2j]
// No vendor primitives; synthesises to LUT-based MUX tree on any FPGA.
// =============================================================================
module mux #(
    parameter int NUM_INPUTS = 4,
    parameter int DATA_WIDTH = 8
) (
    input  logic [DATA_WIDTH-1:0]          in  [NUM_INPUTS],
    input  logic [$clog2(NUM_INPUTS)-1:0]  sel,
    output logic [DATA_WIDTH-1:0]          out
);
    localparam int NUM_LEVELS = $clog2(NUM_INPUTS);

    // synthesis translate_off
    initial begin
        if ((NUM_INPUTS & (NUM_INPUTS - 1)) != 0)
            $fatal(1, "mux: NUM_INPUTS (%0d) must be a power of 2", NUM_INPUTS);
    end
    // synthesis translate_on

    // stg[level][node] – level 0 is the inputs, level NUM_LEVELS is the output
    logic [DATA_WIDTH-1:0] stg [NUM_LEVELS+1][NUM_INPUTS];

    // Connect leaves
    genvar j;
    generate
        for (j = 0; j < NUM_INPUTS; j++) begin : gen_leaf
            assign stg[0][j] = in[j];
        end
    endgenerate

    // Build tree level by level
    genvar lv, nd;
    generate
        for (lv = 0; lv < NUM_LEVELS; lv++) begin : gen_level
            for (nd = 0; nd < (NUM_INPUTS >> (lv+1)); nd++) begin : gen_node
                assign stg[lv+1][nd] = sel[lv]
                                     ? stg[lv][2*nd+1]
                                     : stg[lv][2*nd];
            end
        end
    endgenerate

    assign out = stg[NUM_LEVELS][0];
endmodule
