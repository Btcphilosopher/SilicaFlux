`timescale 1ns/1ps
// =============================================================================
// Testbench: wallace_tree_multiplier  (WIDTH = 4, 8, 16)
// =============================================================================
module tb_wallace_tree_multiplier;
    int pass_cnt, fail_cnt;

    // ---- 4-bit DUT ----
    logic [3:0]  a4, b4;
    logic [7:0]  prod4;
    wallace_tree_multiplier #(.WIDTH(4)) dut4 (.a(a4),.b(b4),.product(prod4));

    // ---- 8-bit DUT ----
    logic [7:0]  a8, b8;
    logic [15:0] prod8;
    wallace_tree_multiplier #(.WIDTH(8)) dut8 (.a(a8),.b(b8),.product(prod8));

    // ---- 16-bit DUT ----
    logic [15:0] a16, b16;
    logic [31:0] prod16;
    wallace_tree_multiplier #(.WIDTH(16)) dut16 (.a(a16),.b(b16),.product(prod16));

    // SVA on 8-bit
    logic clk; initial clk=0; always #5 clk=~clk;
    property p_w8;
        @(posedge clk) prod8 == (16'(a8) * 16'(b8));
    endproperty
    assert property (p_w8) else $error("SVA: 8-bit Wallace tree mismatch");

    task automatic check4(input logic [3:0] ta,tb, input string tag);
        a4=ta; b4=tb; #1;
        assert (prod4 == 8'(ta)*8'(tb)) else begin
            $error("[WT4 %s] a=%0h b=%0h exp=%0h got=%0h",tag,ta,tb,8'(ta)*8'(tb),prod4);
            fail_cnt++;
        end
        pass_cnt++;
    endtask

    task automatic check8(input logic [7:0] ta,tb, input string tag);
        a8=ta; b8=tb; #1;
        assert (prod8 == 16'(ta)*16'(tb)) else begin
            $error("[WT8 %s] a=%0h b=%0h exp=%0h got=%0h",tag,ta,tb,16'(ta)*16'(tb),prod8);
            fail_cnt++;
        end
        pass_cnt++;
    endtask

    task automatic check16(input logic [15:0] ta,tb, input string tag);
        a16=ta; b16=tb; #1;
        assert (prod16 == 32'(ta)*32'(tb)) else begin
            $error("[WT16 %s] a=%0h b=%0h exp=%0h got=%0h",tag,ta,tb,32'(ta)*32'(tb),prod16);
            fail_cnt++;
        end
        pass_cnt++;
    endtask

    initial begin
        pass_cnt=0; fail_cnt=0;
        $display("=== tb_wallace_tree_multiplier ===");

        // 4-bit exhaustive
        for (int ia=0; ia<16; ia++)
            for (int ib=0; ib<16; ib++)
                check4(4'(ia),4'(ib),"exh4");

        // 8-bit directed
        check8(8'h00,8'h00,"zero");
        check8(8'hFF,8'hFF,"max_sq");
        check8(8'h01,8'hFF,"one_max");
        check8(8'h0F,8'h0F,"nibble_sq");
        check8(8'h10,8'h08,"pow2");
        check8(8'hAA,8'h55,"chkbd");

        // 16-bit directed
        check16(16'h0000,16'h0000,"zero16");
        check16(16'hFFFF,16'hFFFF,"max_sq16");
        check16(16'h1234,16'h5678,"dir16");
        check16(16'h0001,16'hFFFF,"one_max16");

        // Random
        void'($urandom(13));
        for (int n=0; n<500; n++) begin
            logic [7:0] ra,rb;
            ra=$urandom; rb=$urandom;
            check8(ra,rb,"rand8");
        end
        for (int n=0; n<200; n++) begin
            logic [15:0] ra,rb;
            ra={$urandom,$urandom}; rb={$urandom,$urandom};
            check16(ra,rb,"rand16");
        end

        $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
        if (fail_cnt==0) $display("ALL TESTS PASSED");
        else             $display("*** FAILURES DETECTED ***");
        $finish;
    end
endmodule
