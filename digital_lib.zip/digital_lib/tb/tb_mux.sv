`timescale 1ns/1ps
// =============================================================================
// Testbench: mux (4:1 and 8:1, DATA_WIDTH=8)
// =============================================================================
module tb_mux;
    localparam int DW = 8;
    int pass_cnt, fail_cnt;

    // ---- 4:1 DUT ----
    localparam int N4 = 4;
    logic [DW-1:0] in4 [N4];
    logic [1:0]    sel4;
    logic [DW-1:0] out4;
    mux #(.NUM_INPUTS(N4),.DATA_WIDTH(DW)) dut4 (.in(in4),.sel(sel4),.out(out4));

    // ---- 8:1 DUT ----
    localparam int N8 = 8;
    logic [DW-1:0] in8 [N8];
    logic [2:0]    sel8;
    logic [DW-1:0] out8;
    mux #(.NUM_INPUTS(N8),.DATA_WIDTH(DW)) dut8 (.in(in8),.sel(sel8),.out(out8));

    // SVA: output equals selected input
    logic clk; initial clk=0; always #5 clk=~clk;
    property p_mux4;
        @(posedge clk) out4 == in4[sel4];
    endproperty
    assert property (p_mux4) else $error("SVA: 4:1 mux output mismatch");

    property p_mux8;
        @(posedge clk) out8 == in8[sel8];
    endproperty
    assert property (p_mux8) else $error("SVA: 8:1 mux output mismatch");

    initial begin
        pass_cnt=0; fail_cnt=0;
        $display("=== tb_mux ===");

        // Init inputs with unique identifiable values
        for (int k=0; k<N4; k++) in4[k] = 8'(8'hA0 + k);
        for (int k=0; k<N8; k++) in8[k] = 8'(8'hB0 + k);

        // 4:1 exhaustive selection
        for (int s=0; s<N4; s++) begin
            sel4 = 2'(s); #1;
            assert (out4 == in4[s]) else begin
                $error("[MUX4] sel=%0d exp=%0h got=%0h",s,in4[s],out4); fail_cnt++;
            end
            pass_cnt++;
        end

        // 8:1 exhaustive selection
        for (int s=0; s<N8; s++) begin
            sel8 = 3'(s); #1;
            assert (out8 == in8[s]) else begin
                $error("[MUX8] sel=%0d exp=%0h got=%0h",s,in8[s],out8); fail_cnt++;
            end
            pass_cnt++;
        end

        // Random input values + selection
        void'($urandom(33));
        for (int n=0; n<500; n++) begin
            logic [1:0] rs4; logic [2:0] rs8;
            for (int k=0; k<N4; k++) in4[k] = $urandom & 8'hFF;
            for (int k=0; k<N8; k++) in8[k] = $urandom & 8'hFF;
            rs4 = $urandom & 2'h3; rs8 = $urandom & 3'h7;
            sel4=rs4; sel8=rs8; #1;
            assert (out4==in4[rs4]) else begin $error("[MUX4r] sel=%0d",rs4); fail_cnt++; end
            assert (out8==in8[rs8]) else begin $error("[MUX8r] sel=%0d",rs8); fail_cnt++; end
            pass_cnt+=2;
        end

        // Verify changing inputs doesn't corrupt unselected output
        sel4 = 2'd2; in4[2] = 8'hDE; #1;
        assert (out4==8'hDE) else begin $error("MUX4 input change"); fail_cnt++; end
        in4[0] = 8'hFF; #1;                        // change non-selected
        assert (out4==8'hDE) else begin $error("MUX4 isolation fail"); fail_cnt++; end
        pass_cnt+=2;

        $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
        if (fail_cnt==0) $display("ALL TESTS PASSED");
        else             $display("*** FAILURES DETECTED ***");
        $finish;
    end
endmodule
