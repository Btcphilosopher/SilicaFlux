`timescale 1ns/1ps
// =============================================================================
// Testbench: comparator (unsigned + signed, WIDTH=8; exhaustive 6-bit)
// =============================================================================
module tb_comparator;
    localparam int W  = 8;
    localparam int W6 = 6;

    // ---- 8-bit unsigned DUT ----
    logic [W-1:0] au, bu;
    logic          eq_u, lt_u, gt_u;
    comparator #(.WIDTH(W),.SIGNED(0)) dut_u (.a(au),.b(bu),.eq(eq_u),.lt(lt_u),.gt(gt_u));

    // ---- 8-bit signed DUT ----
    logic [W-1:0] as_, bs_;
    logic          eq_s, lt_s, gt_s;
    comparator #(.WIDTH(W),.SIGNED(1)) dut_s (.a(as_),.b(bs_),.eq(eq_s),.lt(lt_s),.gt(gt_s));

    // ---- 6-bit unsigned DUT for exhaustive sweep ----
    logic [W6-1:0] xu6, xv6;
    logic           xeq6, xlt6, xgt6;
    comparator #(.WIDTH(W6),.SIGNED(0)) dut6u (.a(xu6),.b(xv6),.eq(xeq6),.lt(xlt6),.gt(xgt6));

    // ---- 6-bit signed DUT for exhaustive sweep ----
    logic [W6-1:0] xs6, xt6;
    logic           xeqs6, xlts6, xgts6;
    comparator #(.WIDTH(W6),.SIGNED(1)) dut6s (.a(xs6),.b(xt6),.eq(xeqs6),.lt(xlts6),.gt(xgts6));

    int pass_cnt, fail_cnt;

    // ---- SVA: outputs must form a one-hot+complete set ----
    logic clk; initial clk=0; always #5 clk=~clk;

    property p_onehot_u;
        @(posedge clk) (eq_u ^ lt_u ^ gt_u) && !(eq_u && lt_u) && !(eq_u && gt_u) && !(lt_u && gt_u);
    endproperty
    assert property (p_onehot_u)
        else $error("SVA: unsigned comparator outputs not mutually exclusive");

    property p_complete_u;
        @(posedge clk) eq_u | lt_u | gt_u;
    endproperty
    assert property (p_complete_u)
        else $error("SVA: unsigned comparator no output asserted");

    property p_onehot_s;
        @(posedge clk) (eq_s ^ lt_s ^ gt_s) && !(eq_s && lt_s) && !(eq_s && gt_s) && !(lt_s && gt_s);
    endproperty
    assert property (p_onehot_s)
        else $error("SVA: signed comparator outputs not mutually exclusive");

    // ---- Check tasks ----
    task automatic check_u(input logic [W-1:0] ta, tb, input string tag);
        bit ref_eq, ref_lt, ref_gt;
        ref_eq=(ta==tb); ref_lt=(ta<tb); ref_gt=(ta>tb);
        au=ta; bu=tb; #1;
        assert (eq_u==ref_eq) else begin $error("[UCMP %s] eq  a=%0h b=%0h",tag,ta,tb);  fail_cnt++; end
        assert (lt_u==ref_lt) else begin $error("[UCMP %s] lt  a=%0h b=%0h",tag,ta,tb);  fail_cnt++; end
        assert (gt_u==ref_gt) else begin $error("[UCMP %s] gt  a=%0h b=%0h",tag,ta,tb);  fail_cnt++; end
        pass_cnt++;
    endtask

    task automatic check_s(input logic [W-1:0] ta, tb, input string tag);
        bit ref_eq, ref_lt, ref_gt;
        ref_eq=($signed(ta)==$signed(tb));
        ref_lt=($signed(ta)< $signed(tb));
        ref_gt=($signed(ta)> $signed(tb));
        as_=ta; bs_=tb; #1;
        assert (eq_s==ref_eq) else begin $error("[SCMP %s] eq  a=%0h b=%0h",tag,ta,tb);  fail_cnt++; end
        assert (lt_s==ref_lt) else begin $error("[SCMP %s] lt  a=%0h b=%0h",tag,ta,tb);  fail_cnt++; end
        assert (gt_s==ref_gt) else begin $error("[SCMP %s] gt  a=%0h b=%0h",tag,ta,tb);  fail_cnt++; end
        pass_cnt++;
    endtask

    initial begin
        pass_cnt=0; fail_cnt=0;
        $display("=== tb_comparator ===");

        // ---- 6-bit unsigned exhaustive ----
        for (int ia=0; ia<64; ia++) for (int ib=0; ib<64; ib++) begin
            xu6=6'(ia); xv6=6'(ib); #1;
            assert (xeq6==(ia==ib)) else begin $error("exh6u eq ia=%0d ib=%0d",ia,ib); fail_cnt++; end
            assert (xlt6==(ia< ib)) else begin $error("exh6u lt ia=%0d ib=%0d",ia,ib); fail_cnt++; end
            assert (xgt6==(ia> ib)) else begin $error("exh6u gt ia=%0d ib=%0d",ia,ib); fail_cnt++; end
            pass_cnt++;
        end

        // ---- 6-bit signed exhaustive ----
        for (int ia=0; ia<64; ia++) for (int ib=0; ib<64; ib++) begin
            xs6=6'(ia); xt6=6'(ib); #1;
            assert (xeqs6==($signed(6'(ia))==$signed(6'(ib)))) else begin $error("exh6s eq ia=%0d ib=%0d",ia,ib); fail_cnt++; end
            assert (xlts6==($signed(6'(ia))< $signed(6'(ib)))) else begin $error("exh6s lt ia=%0d ib=%0d",ia,ib); fail_cnt++; end
            assert (xgts6==($signed(6'(ia))> $signed(6'(ib)))) else begin $error("exh6s gt ia=%0d ib=%0d",ia,ib); fail_cnt++; end
            pass_cnt++;
        end

        // ---- 8-bit unsigned directed ----
        check_u(8'h00,8'h00,"eq_zero");
        check_u(8'hFF,8'hFF,"eq_max");
        check_u(8'h00,8'hFF,"min_lt_max");
        check_u(8'hFF,8'h00,"max_gt_min");
        check_u(8'h7F,8'h80,"lt_boundary");
        check_u(8'h80,8'h7F,"gt_boundary");
        check_u(8'h01,8'h02,"one_lt_two");

        // ---- 8-bit signed directed ----
        check_s(8'h00,8'h00,"s_eq_zero");
        check_s(8'h7F,8'h7F,"s_eq_maxpos");
        check_s(8'h80,8'h80,"s_eq_minneg");
        check_s(8'h80,8'h7F,"s_minneg_lt_maxpos");
        check_s(8'h7F,8'h80,"s_maxpos_gt_minneg");
        check_s(8'hFF,8'h01,"s_neg1_lt_1");
        check_s(8'h01,8'hFF,"s_1_gt_neg1");
        check_s(8'h80,8'hFF,"s_min_lt_neg1");
        check_s(8'h81,8'h82,"s_neg127_gt_neg126");

        // ---- 8-bit random ----
        void'($urandom(21));
        for (int n=0; n<1000; n++) begin
            logic [W-1:0] ra,rb;
            ra=$urandom; rb=$urandom;
            check_u(ra,rb,"rand_u");
            check_s(ra,rb,"rand_s");
        end

        $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
        if (fail_cnt==0) $display("ALL TESTS PASSED");
        else             $display("*** FAILURES DETECTED ***");
        $finish;
    end
endmodule
