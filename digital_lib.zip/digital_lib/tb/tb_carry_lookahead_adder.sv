`timescale 1ns/1ps
// =============================================================================
// Testbench: carry_lookahead_adder
// Tests WIDTH=4 (1 block) and WIDTH=16 (4 blocks, full 2-level CLA)
// =============================================================================
module tb_carry_lookahead_adder;

    int pass_cnt, fail_cnt;

    // ---- DUT A: 4-bit (single block) ----
    localparam int W4 = 4;
    logic [W4-1:0] a4, b4, sum4;
    logic           cin4, cout4, ovf4;
    carry_lookahead_adder #(.WIDTH(W4)) dut4 (
        .a(a4),.b(b4),.cin(cin4),.sum(sum4),.cout(cout4),.overflow(ovf4)
    );

    // ---- DUT B: 16-bit (4 blocks, full second-level CLA) ----
    localparam int W16 = 16;
    logic [W16-1:0] a16, b16, sum16;
    logic            cin16, cout16, ovf16;
    carry_lookahead_adder #(.WIDTH(W16)) dut16 (
        .a(a16),.b(b16),.cin(cin16),.sum(sum16),.cout(cout16),.overflow(ovf16)
    );

    // -------------------------------------------------------------------------
    task automatic check4(
        input logic [W4-1:0] ta, tb, input logic tc, input string tag
    );
        logic [W4:0]   rf;
        logic [W4-1:0] rs;
        logic          rc, ro;
        rf = {1'b0,ta} + {1'b0,tb} + {W4'(0), tc};
        rs = rf[W4-1:0]; rc = rf[W4];
        ro = (~ta[W4-1] & ~tb[W4-1] & rs[W4-1])
           | ( ta[W4-1] &  tb[W4-1] & ~rs[W4-1]);
        a4 = ta; b4 = tb; cin4 = tc; #1;
        assert (sum4 == rs) else begin $error("[CLA4 %s] sum  exp=%0h got=%0h",tag,rs,sum4);   fail_cnt++; end
        assert (cout4 == rc) else begin $error("[CLA4 %s] cout exp=%0b got=%0b",tag,rc,cout4); fail_cnt++; end
        assert (ovf4 == ro) else begin $error("[CLA4 %s] ovf  exp=%0b got=%0b",tag,ro,ovf4);  fail_cnt++; end
        pass_cnt++;
    endtask

    task automatic check16(
        input logic [W16-1:0] ta, tb, input logic tc, input string tag
    );
        logic [W16:0]   rf;
        logic [W16-1:0] rs;
        logic           rc, ro;
        rf = {1'b0,ta} + {1'b0,tb} + {W16'(0), tc};
        rs = rf[W16-1:0]; rc = rf[W16];
        ro = (~ta[W16-1] & ~tb[W16-1] & rs[W16-1])
           | ( ta[W16-1] &  tb[W16-1] & ~rs[W16-1]);
        a16 = ta; b16 = tb; cin16 = tc; #1;
        assert (sum16 == rs)  else begin $error("[CLA16 %s] sum  exp=%0h got=%0h",tag,rs,sum16);    fail_cnt++; end
        assert (cout16 == rc) else begin $error("[CLA16 %s] cout exp=%0b got=%0b",tag,rc,cout16);   fail_cnt++; end
        assert (ovf16 == ro)  else begin $error("[CLA16 %s] ovf  exp=%0b got=%0b",tag,ro,ovf16);   fail_cnt++; end
        pass_cnt++;
    endtask

    initial begin
        pass_cnt = 0; fail_cnt = 0;
        $display("=== tb_carry_lookahead_adder ===");

        // 4-bit exhaustive
        for (int ia=0; ia<16; ia++)
            for (int ib=0; ib<16; ib++)
                for (int ic=0; ic<2; ic++)
                    check4(4'(ia), 4'(ib), 1'(ic), "exh4");

        // 16-bit directed
        check16(16'h0000, 16'h0000, 0, "zero");
        check16(16'hFFFF, 16'h0001, 0, "wrap");
        check16(16'h7FFF, 16'h0001, 0, "signed_ovf_pos");
        check16(16'h8000, 16'hFFFF, 0, "signed_ovf_neg");
        check16(16'hAAAA, 16'h5555, 1, "alternating");
        check16(16'hFFFF, 16'hFFFF, 1, "all_ones");

        // 16-bit random
        void'($urandom(99));
        for (int n=0; n<2000; n++) begin
            logic [W16-1:0] ra, rb; logic rc;
            ra = {$urandom,$urandom}; rb = {$urandom,$urandom}; rc = $urandom & 1;
            check16(ra, rb, rc, "rand16");
        end

        $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
        if (fail_cnt == 0) $display("ALL TESTS PASSED");
        else               $display("*** FAILURES DETECTED ***");
        $finish;
    end
endmodule
