`timescale 1ns/1ps
// =============================================================================
// Testbench: array_multiplier  (unsigned + signed, WIDTH=8)
// Also exhaustive 4-bit sweep via separate module-level DUT
// =============================================================================
module tb_array_multiplier;
    localparam int W  = 8;
    localparam int W4 = 4;

    // ---- 8-bit unsigned DUT ----
    logic [W-1:0]   au, bu;
    logic [2*W-1:0] product_u;
    array_multiplier #(.WIDTH(W),.SIGNED(0)) dut_u (.a(au),.b(bu),.product(product_u));

    // ---- 8-bit signed DUT ----
    logic [W-1:0]   as_, bs_;
    logic [2*W-1:0] product_s;
    array_multiplier #(.WIDTH(W),.SIGNED(1)) dut_s (.a(as_),.b(bs_),.product(product_s));

    // ---- 4-bit unsigned DUT for exhaustive sweep ----
    logic [W4-1:0]    xa4, xb4;
    logic [2*W4-1:0]  xp4;
    array_multiplier #(.WIDTH(W4),.SIGNED(0)) dut4 (.a(xa4),.b(xb4),.product(xp4));

    int pass_cnt, fail_cnt;

    // ---- SVA: unsigned product correct ----
    logic clk; initial clk=0; always #5 clk=~clk;
    property p_umul;
        @(posedge clk) product_u == ({W'(0),au} * {W'(0),bu});
    endproperty
    assert property (p_umul) else $error("SVA: unsigned product mismatch a=%0h b=%0h",au,bu);

    // ---- SVA: signed product correct ----
    property p_smul;
        @(posedge clk) product_s == ($signed({{W{as_[W-1]}},as_}) * $signed({{W{bs_[W-1]}},bs_}));
    endproperty
    assert property (p_smul) else $error("SVA: signed product mismatch a=%0h b=%0h",as_,bs_);

    // ---- Unsigned check ----
    task automatic check_u(input logic [W-1:0] ta, tb, input string tag);
        logic [2*W-1:0] ref_p;
        ref_p = {W'(0),ta} * {W'(0),tb};
        au=ta; bu=tb; #1;
        assert (product_u == ref_p) else begin
            $error("[UMUL %s] a=%0h b=%0h exp=%0h got=%0h",tag,ta,tb,ref_p,product_u);
            fail_cnt++;
        end
        pass_cnt++;
    endtask

    // ---- Signed check ----
    task automatic check_s(input logic [W-1:0] ta, tb, input string tag);
        logic signed [2*W-1:0] ref_p;
        ref_p = $signed({{W{ta[W-1]}},ta}) * $signed({{W{tb[W-1]}},tb});
        as_=ta; bs_=tb; #1;
        assert ($signed(product_s) == ref_p) else begin
            $error("[SMUL %s] a=%0h b=%0h exp=%0h got=%0h",tag,ta,tb,ref_p,product_s);
            fail_cnt++;
        end
        pass_cnt++;
    endtask

    initial begin
        pass_cnt=0; fail_cnt=0;
        $display("=== tb_array_multiplier ===");

        // --- 4-bit unsigned exhaustive ---
        for (int ia=0; ia<16; ia++) for (int ib=0; ib<16; ib++) begin
            xa4=4'(ia); xb4=4'(ib); #1;
            assert (xp4 == 8'(ia*ib)) else begin
                $error("[UMUL4 exh] a=%0d b=%0d exp=%0d got=%0d",ia,ib,ia*ib,xp4);
                fail_cnt++;
            end
            pass_cnt++;
        end

        // --- 8-bit unsigned directed ---
        check_u(8'h00, 8'h00, "zero");
        check_u(8'h01, 8'h01, "one_x_one");
        check_u(8'hFF, 8'hFF, "max_x_max");
        check_u(8'hFF, 8'h01, "max_x_one");
        check_u(8'h0F, 8'h11, "nibble");
        check_u(8'h10, 8'h10, "pow2_x_pow2");
        check_u(8'hAA, 8'h55, "alternating");

        // --- 8-bit signed directed ---
        check_s(8'h00, 8'h00, "s_zero");
        check_s(8'h01, 8'hFF, "pos_x_neg1");    //  1 × -1  = -1
        check_s(8'hFF, 8'hFF, "neg1_x_neg1");   // -1 × -1  = +1
        check_s(8'h80, 8'h80, "minval_sq");      // -128 × -128 = +16384
        check_s(8'h80, 8'hFF, "minval_neg1");    // -128 × -1   = +128
        check_s(8'h7F, 8'h7F, "max_pos_sq");     //  127 × 127  = +16129
        check_s(8'h80, 8'h01, "minval_one");     // -128 × 1    = -128
        check_s(8'hFE, 8'h03, "neg2_x_3");       //   -2 × 3    = -6
        check_s(8'h02, 8'hFE, "2_x_neg2");       //    2 × -2   = -4
        check_s(8'h7F, 8'h80, "maxpos_x_minval");//  127 × -128 = -16256

        // --- 1000 pseudo-random ---
        void'($urandom(55));
        for (int n=0; n<1000; n++) begin
            logic [W-1:0] ra, rb;
            ra=$urandom; rb=$urandom;
            check_u(ra, rb, "rand_u");
            check_s(ra, rb, "rand_s");
        end

        $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
        if (fail_cnt==0) $display("ALL TESTS PASSED");
        else             $display("*** FAILURES DETECTED ***");
        $finish;
    end
endmodule
