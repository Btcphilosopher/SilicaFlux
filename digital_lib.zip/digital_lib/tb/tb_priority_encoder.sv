`timescale 1ns/1ps
// =============================================================================
// Testbench: priority_encoder (LSB-first and MSB-first, WIDTH=8)
// =============================================================================
module tb_priority_encoder;
    localparam int W = 8;

    // LSB-first DUT
    logic [W-1:0] req_l;
    logic [2:0]   enc_l;
    logic          valid_l;
    priority_encoder #(.WIDTH(W),.LSB_FIRST(1)) dut_l (.req(req_l),.enc(enc_l),.valid(valid_l));

    // MSB-first DUT
    logic [W-1:0] req_m;
    logic [2:0]   enc_m;
    logic          valid_m;
    priority_encoder #(.WIDTH(W),.LSB_FIRST(0)) dut_m (.req(req_m),.enc(enc_m),.valid(valid_m));

    int pass_cnt, fail_cnt;

    // SVA: if valid, encoded bit must be set in req
    logic clk; initial clk=0; always #5 clk=~clk;

    property p_lsb_valid;
        @(posedge clk) valid_l |-> req_l[enc_l];
    endproperty
    assert property (p_lsb_valid) else $error("SVA: LSB enc bit not set in req");

    property p_msb_valid;
        @(posedge clk) valid_m |-> req_m[enc_m];
    endproperty
    assert property (p_msb_valid) else $error("SVA: MSB enc bit not set in req");

    // SVA: LSB priority – no lower bit may be set
    property p_lsb_priority;
        @(posedge clk) valid_l |-> (req_l & ((8'(1) << enc_l) - 8'(1))) == 0;
    endproperty
    assert property (p_lsb_priority) else $error("SVA: LSB lower bit set – wrong priority");

    // SVA: MSB priority – no higher bit may be set
    property p_msb_priority;
        @(posedge clk) valid_m |-> (req_m >> (enc_m + 3'(1))) == 0;
    endproperty
    assert property (p_msb_priority) else $error("SVA: MSB higher bit set – wrong priority");

    task automatic check_l(input logic [W-1:0] r, input int exp_idx, exp_v, input string tag);
        req_l = r; #1;
        assert (valid_l == exp_v) else begin $error("[PE_LSB %s] valid req=%0b",tag,r); fail_cnt++; end
        if (exp_v) begin
            assert (enc_l == 3'(exp_idx)) else begin
                $error("[PE_LSB %s] enc req=%0b exp=%0d got=%0d",tag,r,exp_idx,enc_l);
                fail_cnt++;
            end
        end
        pass_cnt++;
    endtask

    task automatic check_m(input logic [W-1:0] r, input int exp_idx, exp_v, input string tag);
        req_m = r; #1;
        assert (valid_m == exp_v) else begin $error("[PE_MSB %s] valid req=%0b",tag,r); fail_cnt++; end
        if (exp_v) begin
            assert (enc_m == 3'(exp_idx)) else begin
                $error("[PE_MSB %s] enc req=%0b exp=%0d got=%0d",tag,r,exp_idx,enc_m);
                fail_cnt++;
            end
        end
        pass_cnt++;
    endtask

    initial begin
        pass_cnt=0; fail_cnt=0;
        $display("=== tb_priority_encoder ===");

        // All zeros
        check_l(8'h00,0,0,"no_req_l");
        check_m(8'h00,0,0,"no_req_m");

        // Single-bit inputs
        for (int k=0; k<W; k++) begin
            check_l(8'(1<<k), k, 1, $sformatf("single_l_%0d",k));
            check_m(8'(1<<k), k, 1, $sformatf("single_m_%0d",k));
        end

        // Multi-bit: LSB priority
        check_l(8'b11111110, 1, 1, "multi_l_bit1");
        check_l(8'b11111100, 2, 1, "multi_l_bit2");
        check_l(8'b10000001, 0, 1, "multi_l_bit0");
        check_l(8'hFF,       0, 1, "all_ones_l");

        // Multi-bit: MSB priority
        check_m(8'b11111110, 7, 1, "multi_m_bit7");
        check_m(8'b01111111, 6, 1, "multi_m_bit6");
        check_m(8'b10000001, 7, 1, "multi_m_bit7b");
        check_m(8'hFF,       7, 1, "all_ones_m");

        // Exhaustive 8-bit
        for (int r=0; r<256; r++) begin
            int lsb_exp, msb_exp;
            lsb_exp = -1; msb_exp = -1;
            for (int k=0; k<W; k++)   if (r[k]) lsb_exp = (lsb_exp<0) ? k : lsb_exp;
            for (int k=W-1; k>=0; k--) if (r[k]) msb_exp = (msb_exp<0) ? k : msb_exp;
            req_l = 8'(r); req_m = 8'(r); #1;
            if (r==0) begin
                assert (!valid_l && !valid_m) else begin fail_cnt++; end
            end else begin
                assert (valid_l && enc_l==3'(lsb_exp)) else begin
                    $error("exh lsb r=%08b exp=%0d got=%0d",r,lsb_exp,enc_l); fail_cnt++;
                end
                assert (valid_m && enc_m==3'(msb_exp)) else begin
                    $error("exh msb r=%08b exp=%0d got=%0d",r,msb_exp,enc_m); fail_cnt++;
                end
            end
            pass_cnt++;
        end

        $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
        if (fail_cnt==0) $display("ALL TESTS PASSED");
        else             $display("*** FAILURES DETECTED ***");
        $finish;
    end
endmodule
