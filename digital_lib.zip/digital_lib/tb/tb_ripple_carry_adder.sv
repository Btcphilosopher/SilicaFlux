`timescale 1ns/1ps
// =============================================================================
// Testbench: ripple_carry_adder
// Coverage : directed corner cases, exhaustive 4-bit, 1000 random 8-bit
// =============================================================================
module tb_ripple_carry_adder;
    localparam int W  = 8;
    localparam int W4 = 4;

    // ---- Primary 8-bit DUT ----
    logic [W-1:0]  a, b, sum;
    logic           cin, cout, overflow;
    ripple_carry_adder #(.WIDTH(W)) dut (.*);

    // ---- Secondary 4-bit DUT for exhaustive sweep ----
    logic [W4-1:0] a4, b4, sum4;
    logic           cin4, cout4, ovf4;
    ripple_carry_adder #(.WIDTH(W4)) dut4 (
        .a(a4),.b(b4),.cin(cin4),.sum(sum4),.cout(cout4),.overflow(ovf4)
    );

    int pass_cnt, fail_cnt;

    // ---- Free-running clock for concurrent assertions ----
    logic clk;
    initial clk = 0;
    always #5 clk = ~clk;

    // SVA: sum must equal a+b+cin (mod 2^W) on every rising edge
    property p_sum_correct;
        @(posedge clk) (sum == (a + b + cin));
    endproperty
    assert property (p_sum_correct)
        else $error("SVA: sum mismatch a=%0h b=%0h cin=%0b got=%0h", a, b, cin, sum);

    // SVA: cout must equal the carry out of (a+b+cin)
    property p_cout_correct;
        @(posedge clk) cout == ({1'b0,a} + {1'b0,b} + {W'(0),cin})[W];
    endproperty
    assert property (p_cout_correct)
        else $error("SVA: cout mismatch");

    // -------------------------------------------------------------------------
    // 8-bit check task
    // -------------------------------------------------------------------------
    task automatic check8(
        input logic [W-1:0] ta, tb,
        input logic         tc,
        input string        tag
    );
        logic [W:0]   rf;
        logic [W-1:0] rs;
        logic         rc, ro;
        rf = {1'b0,ta} + {1'b0,tb} + {W'(0),tc};
        rs = rf[W-1:0]; rc = rf[W];
        ro = (~ta[W-1] & ~tb[W-1] & rs[W-1])
           | ( ta[W-1] &  tb[W-1] & ~rs[W-1]);
        a=ta; b=tb; cin=tc; #1;
        assert (sum      == rs) else begin $error("[RCA8 %s] sum  exp=%0h got=%0h",tag,rs, sum);      fail_cnt++; end
        assert (cout     == rc) else begin $error("[RCA8 %s] cout exp=%0b got=%0b",tag,rc, cout);     fail_cnt++; end
        assert (overflow == ro) else begin $error("[RCA8 %s] ovf  exp=%0b got=%0b",tag,ro, overflow); fail_cnt++; end
        pass_cnt++;
    endtask

    // 4-bit exhaustive check task
    task automatic check4(
        input logic [W4-1:0] ta, tb,
        input logic          tc,
        input string         tag
    );
        logic [W4:0]   rf;
        logic [W4-1:0] rs;
        logic          rc, ro;
        rf = {1'b0,ta} + {1'b0,tb} + {W4'(0),tc};
        rs = rf[W4-1:0]; rc = rf[W4];
        ro = (~ta[W4-1] & ~tb[W4-1] & rs[W4-1])
           | ( ta[W4-1] &  tb[W4-1] & ~rs[W4-1]);
        a4=ta; b4=tb; cin4=tc; #1;
        assert (sum4 == rs) else begin $error("[RCA4 %s] sum  exp=%0h got=%0h",tag,rs,sum4);   fail_cnt++; end
        assert (cout4== rc) else begin $error("[RCA4 %s] cout exp=%0b got=%0b",tag,rc,cout4);  fail_cnt++; end
        assert (ovf4 == ro) else begin $error("[RCA4 %s] ovf  exp=%0b got=%0b",tag,ro,ovf4);  fail_cnt++; end
        pass_cnt++;
    endtask

    // -------------------------------------------------------------------------
    // Stimulus
    // -------------------------------------------------------------------------
    initial begin
        pass_cnt = 0; fail_cnt = 0;
        $display("=== tb_ripple_carry_adder ===");

        // --- Directed 8-bit corners ---
        check8(8'h00, 8'h00, 0, "zero_add");
        check8(8'hFF, 8'h01, 0, "overflow_u");
        check8(8'hFF, 8'hFF, 1, "all_ones_cin");
        check8(8'h7F, 8'h01, 0, "signed_pos_ovf");
        check8(8'h80, 8'hFF, 0, "signed_neg_ovf");
        check8(8'h55, 8'hAA, 0, "checkerboard");
        check8(8'h00, 8'h00, 1, "only_cin");
        check8(8'hFF, 8'h00, 1, "max_plus_cin");
        check8(8'h01, 8'h01, 0, "one_plus_one");
        check8(8'h80, 8'h80, 0, "min_plus_min");

        // --- Exhaustive 4-bit ---
        for (int ia=0; ia<16; ia++)
            for (int ib=0; ib<16; ib++)
                for (int ic=0; ic<2; ic++)
                    check4(4'(ia), 4'(ib), 1'(ic), "exh4");

        // --- 1000 pseudo-random 8-bit ---
        void'($urandom(42));
        for (int n = 0; n < 1000; n++) begin
            logic [W-1:0] ra, rb; logic rc;
            ra = $urandom; rb = $urandom; rc = $urandom & 1;
            check8(ra, rb, rc, "random");
        end

        $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
        if (fail_cnt == 0) $display("ALL TESTS PASSED");
        else               $display("*** FAILURES DETECTED ***");
        $finish;
    end
endmodule
