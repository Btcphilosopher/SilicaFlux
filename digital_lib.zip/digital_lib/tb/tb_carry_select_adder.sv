`timescale 1ns/1ps
// =============================================================================
// Testbench: carry_select_adder (WIDTH=16, BLOCK_SIZE=4)
// =============================================================================
module tb_carry_select_adder;
    localparam int W  = 16;
    localparam int BS = 4;

    logic [W-1:0] a, b, sum;
    logic          cin, cout, overflow;
    int            pass_cnt, fail_cnt;

    carry_select_adder #(.WIDTH(W),.BLOCK_SIZE(BS)) dut (.*);

    task automatic check(
        input logic [W-1:0] ta, tb, input logic tc, input string tag
    );
        logic [W:0]   rf;
        logic [W-1:0] rs; logic rc, ro;
        rf = {1'b0,ta} + {1'b0,tb} + {W'(0),tc};
        rs = rf[W-1:0]; rc = rf[W];
        ro = (~ta[W-1] & ~tb[W-1] & rs[W-1])
           | ( ta[W-1] &  tb[W-1] & ~rs[W-1]);
        a=ta; b=tb; cin=tc; #1;
        assert (sum == rs)      else begin $error("[CSA %s] sum  got=%0h exp=%0h",tag,sum,rs);      fail_cnt++; end
        assert (cout == rc)     else begin $error("[CSA %s] cout got=%0b exp=%0b",tag,cout,rc);     fail_cnt++; end
        assert (overflow == ro) else begin $error("[CSA %s] ovf  got=%0b exp=%0b",tag,overflow,ro); fail_cnt++; end
        pass_cnt++;
    endtask

    // SVA: cout must equal bit W of (a+b+cin)
    logic clk; initial clk=0; always #5 clk=~clk;
    property p_cout;
        @(posedge clk) cout == ({1'b0,a}+{1'b0,b}+{W'(0),cin})[W];
    endproperty
    assert property (p_cout) else $error("SVA: cout mismatch");

    initial begin
        pass_cnt=0; fail_cnt=0;
        $display("=== tb_carry_select_adder ===");
        check(16'h0000,16'h0000,0,"zero");
        check(16'hFFFF,16'h0001,0,"wrap");
        check(16'h7FFF,16'h0001,0,"pos_ovf");
        check(16'h8000,16'hFFFF,0,"neg_ovf");
        check(16'hFFFF,16'hFFFF,1,"max_cin");
        check(16'h1234,16'h5678,1,"random_dir");
        void'($urandom(7));
        for (int n=0; n<2000; n++) begin
            logic [W-1:0] ra,rb; logic rc;
            ra={$urandom,$urandom}; rb={$urandom,$urandom}; rc=$urandom&1;
            check(ra,rb,rc,"rand");
        end
        $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
        if (fail_cnt==0) $display("ALL TESTS PASSED");
        else             $display("*** FAILURES DETECTED ***");
        $finish;
    end
endmodule
