`timescale 1ns/1ps
// =============================================================================
// Testbench: barrel_shifter (WIDTH=8 and WIDTH=16)
// Tests all four modes: left-logical, right-logical, right-arithmetic
// =============================================================================
module tb_barrel_shifter;
    localparam int W8  = 8;
    localparam int W16 = 16;
    int pass_cnt, fail_cnt;

    // 8-bit DUT
    logic [W8-1:0]  di8, do8;
    logic [2:0]      sa8;
    logic             dir8, arith8;
    barrel_shifter #(.WIDTH(W8)) dut8 (
        .data_in(di8),.shift_amt(sa8),.direction(dir8),.arithmetic(arith8),.data_out(do8)
    );

    // 16-bit DUT
    logic [W16-1:0] di16, do16;
    logic [3:0]      sa16;
    logic             dir16, arith16;
    barrel_shifter #(.WIDTH(W16)) dut16 (
        .data_in(di16),.shift_amt(sa16),.direction(dir16),.arithmetic(arith16),.data_out(do16)
    );

    // SVA: left shift result
    logic clk; initial clk=0; always #5 clk=~clk;
    property p_left_logical8;
        @(posedge clk) (!dir8 && di8==8'hA5 && sa8==3'd3)
            |-> (do8 == 8'((8'hA5 << 3) & 8'hFF));
    endproperty
    assert property (p_left_logical8) else $error("SVA: left-logical 8-bit failed");

    // Reference functions
    function automatic logic [W8-1:0] ref_shift8(
        input logic [W8-1:0] d, input logic [2:0] sa,
        input logic dir, arith
    );
        if (!dir)        return d << sa;
        else if (!arith) return d >> sa;
        else             return $signed(d) >>> sa;
    endfunction

    function automatic logic [W16-1:0] ref_shift16(
        input logic [W16-1:0] d, input logic [3:0] sa,
        input logic dir, arith
    );
        if (!dir)        return d << sa;
        else if (!arith) return d >> sa;
        else             return $signed(d) >>> sa;
    endfunction

    task automatic check8(
        input logic [W8-1:0] d, input logic [2:0] sa,
        input logic dir, arith, input string tag
    );
        logic [W8-1:0] exp;
        exp = ref_shift8(d,sa,dir,arith);
        di8=d; sa8=sa; dir8=dir; arith8=arith; #1;
        assert (do8==exp) else begin
            $error("[BS8 %s] d=%0h sa=%0d dir=%0b arith=%0b exp=%0h got=%0h",
                   tag,d,sa,dir,arith,exp,do8);
            fail_cnt++;
        end
        pass_cnt++;
    endtask

    task automatic check16(
        input logic [W16-1:0] d, input logic [3:0] sa,
        input logic dir, arith, input string tag
    );
        logic [W16-1:0] exp;
        exp = ref_shift16(d,sa,dir,arith);
        di16=d; sa16=sa; dir16=dir; arith16=arith; #1;
        assert (do16==exp) else begin
            $error("[BS16 %s] d=%0h sa=%0d dir=%0b arith=%0b exp=%0h got=%0h",
                   tag,d,sa,dir,arith,exp,do16);
            fail_cnt++;
        end
        pass_cnt++;
    endtask

    initial begin
        pass_cnt=0; fail_cnt=0;
        $display("=== tb_barrel_shifter ===");

        // Left-logical 8-bit: all shift amounts
        for (int s=0; s<W8; s++) begin
            check8(8'hA5, 3'(s), 0, 0, $sformatf("ll8_s%0d",s));
            check8(8'hFF, 3'(s), 0, 0, $sformatf("ll8_ff_s%0d",s));
        end

        // Right-logical 8-bit
        for (int s=0; s<W8; s++) begin
            check8(8'hA5, 3'(s), 1, 0, $sformatf("rl8_s%0d",s));
            check8(8'hFF, 3'(s), 1, 0, $sformatf("rl8_ff_s%0d",s));
        end

        // Right-arithmetic 8-bit (positive and negative values)
        for (int s=0; s<W8; s++) begin
            check8(8'hA5, 3'(s), 1, 1, $sformatf("ra8_neg_s%0d",s)); // 0xA5 = negative
            check8(8'h5A, 3'(s), 1, 1, $sformatf("ra8_pos_s%0d",s)); // 0x5A = positive
        end

        // Special cases
        check8(8'h00, 3'd7, 0, 0, "zero_maxsh");
        check8(8'hFF, 3'd7, 1, 0, "ff_rl_max");
        check8(8'h80, 3'd7, 1, 1, "minval_ra_max");   // -128 >>> 7 = -1 = 0xFF
        check8(8'h80, 3'd1, 1, 1, "minval_ra_1");     // -128 >>> 1 = -64 = 0xC0
        check8(8'h00, 3'd0, 0, 0, "zero_noshift");
        check8(8'hFF, 3'd0, 1, 1, "noshift_ra");

        // 16-bit directed
        for (int s=0; s<W16; s++) begin
            check16(16'hA5A5, 4'(s), 0, 0, $sformatf("ll16_s%0d",s));
            check16(16'hA5A5, 4'(s), 1, 0, $sformatf("rl16_s%0d",s));
            check16(16'hA5A5, 4'(s), 1, 1, $sformatf("ra16_s%0d",s));
            check16(16'h5A5A, 4'(s), 1, 1, $sformatf("ra16_pos_s%0d",s));
        end

        // Random
        void'($urandom(88));
        for (int n=0; n<1000; n++) begin
            logic [W8-1:0] rd; logic [2:0] rs; logic d,ar;
            rd=$urandom; rs=$urandom & 3'h7; d=$urandom&1; ar=$urandom&1;
            check8(rd,rs,d,ar,"rand8");
        end
        for (int n=0; n<500; n++) begin
            logic [W16-1:0] rd; logic [3:0] rs; logic d,ar;
            rd={$urandom,$urandom}; rs=$urandom & 4'hF; d=$urandom&1; ar=$urandom&1;
            check16(rd,rs,d,ar,"rand16");
        end

        $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
        if (fail_cnt==0) $display("ALL TESTS PASSED");
        else             $display("*** FAILURES DETECTED ***");
        $finish;
    end
endmodule
