`timescale 1ns/1ps
// =============================================================================
// Testbench: demux (1:4 and 1:8, DATA_WIDTH=8)
// =============================================================================
module tb_demux;
    localparam int DW = 8;
    int pass_cnt, fail_cnt;

    // ---- 1:4 DUT ----
    localparam int N4 = 4;
    logic [DW-1:0] in4;
    logic [1:0]    sel4;
    logic [DW-1:0] out4 [N4];
    demux #(.NUM_OUTPUTS(N4),.DATA_WIDTH(DW)) dut4 (.in(in4),.sel(sel4),.out(out4));

    // ---- 1:8 DUT ----
    localparam int N8 = 8;
    logic [DW-1:0] in8;
    logic [2:0]    sel8;
    logic [DW-1:0] out8 [N8];
    demux #(.NUM_OUTPUTS(N8),.DATA_WIDTH(DW)) dut8 (.in(in8),.sel(sel8),.out(out8));

    // SVA: selected output equals input, all others zero
    logic clk; initial clk=0; always #5 clk=~clk;
    property p_demux4_sel;
        @(posedge clk) out4[sel4] == in4;
    endproperty
    assert property (p_demux4_sel) else $error("SVA: demux4 selected output mismatch");

    initial begin
        pass_cnt=0; fail_cnt=0;
        $display("=== tb_demux ===");

        // 1:4 exhaustive
        for (int s=0; s<N4; s++) begin
            in4 = 8'(8'hC0 + s); sel4 = 2'(s); #1;
            for (int k=0; k<N4; k++) begin
                if (k==s)
                    assert (out4[k]==in4) else begin $error("[DMUX4] sel=%0d out[%0d]=%0h",s,k,out4[k]); fail_cnt++; end
                else
                    assert (out4[k]==0)   else begin $error("[DMUX4] non-sel k=%0d not zero",k); fail_cnt++; end
                pass_cnt++;
            end
        end

        // 1:8 exhaustive
        for (int s=0; s<N8; s++) begin
            in8 = 8'(8'hD0 + s); sel8 = 3'(s); #1;
            for (int k=0; k<N8; k++) begin
                if (k==s)
                    assert (out8[k]==in8) else begin $error("[DMUX8] sel=%0d out[%0d]=%0h",s,k,out8[k]); fail_cnt++; end
                else
                    assert (out8[k]==0)   else begin $error("[DMUX8] non-sel k=%0d not zero",k); fail_cnt++; end
                pass_cnt++;
            end
        end

        // Random stimulus
        void'($urandom(77));
        for (int n=0; n<500; n++) begin
            logic [DW-1:0] ri; logic [2:0] rs;
            ri=$urandom; rs=$urandom & 3'h7;
            in8=ri; sel8=rs; #1;
            assert (out8[rs]==ri) else begin $error("[DMUX8r] sel=%0d",rs); fail_cnt++; end
            // Spot-check one other output is zero
            assert (out8[(rs+1) & 3'h7]==0) else begin $error("[DMUX8r] isolation"); fail_cnt++; end
            pass_cnt+=2;
        end

        $display("PASS: %0d   FAIL: %0d", pass_cnt, fail_cnt);
        if (fail_cnt==0) $display("ALL TESTS PASSED");
        else             $display("*** FAILURES DETECTED ***");
        $finish;
    end
endmodule
