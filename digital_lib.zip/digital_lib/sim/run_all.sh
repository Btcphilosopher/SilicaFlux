#!/usr/bin/env bash
# =============================================================================
# run_all.sh  –  compile and simulate all testbenches
# Supports: Questa/ModelSim, Icarus Verilog (iverilog), VCS
# Usage: ./run_all.sh [questa|iverilog|vcs]
# =============================================================================
set -euo pipefail

SIM=${1:-questa}
PASS=0; FAIL=0; SKIPPED=0

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

RTL_PRIM="$REPO_ROOT/rtl/primitives/full_adder.sv
          $REPO_ROOT/rtl/primitives/half_adder.sv"

RTL_ADD="$RTL_PRIM
         $REPO_ROOT/rtl/adders/ripple_carry_adder.sv
         $REPO_ROOT/rtl/adders/carry_lookahead_adder.sv
         $REPO_ROOT/rtl/adders/carry_select_adder.sv"

RTL_MUL="$RTL_PRIM
         $REPO_ROOT/rtl/adders/ripple_carry_adder.sv
         $REPO_ROOT/rtl/multipliers/array_multiplier.sv
         $REPO_ROOT/rtl/multipliers/wallace_tree_multiplier.sv"

RTL_MISC="$REPO_ROOT/rtl/comparators/comparator.sv
          $REPO_ROOT/rtl/encoders/priority_encoder.sv
          $REPO_ROOT/rtl/mux/mux.sv
          $REPO_ROOT/rtl/mux/demux.sv
          $REPO_ROOT/rtl/shifters/barrel_shifter.sv"

declare -A TB_SRCS
TB_SRCS["tb_ripple_carry_adder"]="$RTL_ADD"
TB_SRCS["tb_carry_lookahead_adder"]="$RTL_ADD"
TB_SRCS["tb_carry_select_adder"]="$RTL_ADD"
TB_SRCS["tb_array_multiplier"]="$RTL_MUL $RTL_ADD"
TB_SRCS["tb_wallace_tree_multiplier"]="$RTL_MUL"
TB_SRCS["tb_comparator"]="$RTL_MISC"
TB_SRCS["tb_priority_encoder"]="$RTL_MISC"
TB_SRCS["tb_mux"]="$RTL_MISC"
TB_SRCS["tb_demux"]="$RTL_MISC"
TB_SRCS["tb_barrel_shifter"]="$RTL_MISC"

run_questa() {
    local TB=$1; shift; local SRCS="$@"
    local LOGFILE="$TB.log"
    vlog -sv -timescale 1ns/1ps $SRCS "$REPO_ROOT/tb/${TB}.sv" > "$LOGFILE" 2>&1
    vsim -c -do "run -all; quit -f" "$TB" >> "$LOGFILE" 2>&1
    if grep -q "ALL TESTS PASSED" "$LOGFILE"; then
        echo "  PASS : $TB"; ((PASS++))
    else
        echo "  FAIL : $TB  (see $LOGFILE)"; ((FAIL++))
    fi
}

run_iverilog() {
    local TB=$1; shift; local SRCS="$@"
    local LOGFILE="$TB.log"
    iverilog -g2012 -o "${TB}.vvp" $SRCS "$REPO_ROOT/tb/${TB}.sv" > "$LOGFILE" 2>&1 \
        && vvp "${TB}.vvp" >> "$LOGFILE" 2>&1
    if grep -q "ALL TESTS PASSED" "$LOGFILE"; then
        echo "  PASS : $TB"; ((PASS++))
    else
        echo "  FAIL : $TB  (see $LOGFILE)"; ((FAIL++))
    fi
}

run_vcs() {
    local TB=$1; shift; local SRCS="$@"
    local LOGFILE="$TB.log"
    vcs -sverilog -timescale=1ns/1ps $SRCS "$REPO_ROOT/tb/${TB}.sv" -o "${TB}.simv" > "$LOGFILE" 2>&1 \
        && "./${TB}.simv" >> "$LOGFILE" 2>&1
    if grep -q "ALL TESTS PASSED" "$LOGFILE"; then
        echo "  PASS : $TB"; ((PASS++))
    else
        echo "  FAIL : $TB  (see $LOGFILE)"; ((FAIL++))
    fi
}

echo "============================================"
echo " digital_lib regression  [simulator: $SIM]"
echo "============================================"
mkdir -p "$REPO_ROOT/sim/logs"
cd "$REPO_ROOT/sim/logs"

for TB in "${!TB_SRCS[@]}"; do
    echo -n "Running $TB ... "
    case "$SIM" in
        questa)   run_questa  "$TB" ${TB_SRCS[$TB]} ;;
        iverilog) run_iverilog "$TB" ${TB_SRCS[$TB]} ;;
        vcs)      run_vcs      "$TB" ${TB_SRCS[$TB]} ;;
        *)        echo "Unknown simulator '$SIM'. Use questa|iverilog|vcs"; exit 1 ;;
    esac
done

echo "============================================"
echo " Results: PASS=$PASS  FAIL=$FAIL  SKIP=$SKIPPED"
echo "============================================"
[[ $FAIL -eq 0 ]]
