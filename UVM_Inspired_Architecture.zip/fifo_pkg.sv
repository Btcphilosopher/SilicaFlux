//==============================================================================
// fifo_pkg.sv — FIFO Verification Package
//
//  Compilation order (enforced by include sequence):
//    1. fifo_seq_item.svh    — sequence item (extends tb_transaction)
//    2. fifo_sequences.svh   — all sequence classes
//    3. fifo_driver.svh      — DUT driver
//    4. fifo_monitor.svh     — DUT monitor
//    5. fifo_scoreboard.svh  — reference model + checkers
//    6. fifo_coverage.svh    — functional coverage
//    7. fifo_agent.svh       — agent container
//    8. fifo_env.svh         — environment container
//
//  DUT configuration:
//    Modify FIFO_DATA_W and FIFO_DEPTH to match your DUT parameters.
//    All classes automatically inherit these values.
//==============================================================================
`ifndef FIFO_PKG_SV
`define FIFO_PKG_SV

`include "tb_defines.svh"

package fifo_pkg;

    import tb_pkg::*;

    // ── DUT Configuration ── modify to match your DUT ─────────────────────
    parameter int FIFO_DATA_W = 8;
    parameter int FIFO_DEPTH  = 16;
    parameter int FIFO_CNT_W  = $clog2(FIFO_DEPTH) + 1;

    // ── Component includes (dependency order) ─────────────────────────────
    `include "fifo_seq_item.svh"
    `include "fifo_sequences.svh"
    `include "fifo_driver.svh"
    `include "fifo_monitor.svh"
    `include "fifo_scoreboard.svh"
    `include "fifo_coverage.svh"
    `include "fifo_agent.svh"
    `include "fifo_env.svh"

endpackage : fifo_pkg

`endif // FIFO_PKG_SV
