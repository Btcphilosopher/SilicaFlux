//==============================================================================
// fifo_scoreboard.svh — FIFO Scoreboard / Reference Model
//   Included by fifo_pkg.sv — not a standalone compilation unit.
//
//  Reference model:
//    A logic queue (ref_q) mirrors the DUT's internal storage.
//    Every observed transaction is processed in arrival order:
//      1. Write side  → push din when wr_valid
//      2. Read  side  → pop ref_q, compare with observed dout when rd_valid
//      3. Flag checks → full, empty, count vs. expected_count
//
//  A single inbox mailbox receives all transaction types (WRITE / READ / BOTH).
//  BOTH is decomposed as: process write first, then read — matching DUT semantics.
//==============================================================================

class fifo_scoreboard extends tb_scoreboard #(fifo_seq_item);

    // ── Reference model ───────────────────────────────────────────────────
    logic [FIFO_DATA_W-1:0]  ref_q[$];
    int unsigned             expected_count = 0;

    // ── Input mailbox (connected from monitor.ap in connect_phase) ────────
    mailbox #(fifo_seq_item) inbox;

    // ── Per-category error counters ───────────────────────────────────────
    int unsigned data_errors  = 0;
    int unsigned flag_errors  = 0;
    int unsigned count_errors = 0;
    int unsigned write_ops    = 0;
    int unsigned read_ops     = 0;

    function new(string name = "fifo_scoreboard");
        super.new(name);
        inbox = new(0);
    endfunction

    // ─────────────────────────────────────────────────────────────────────
    //  process_write — push and validate status after write
    // ─────────────────────────────────────────────────────────────────────
    function automatic void process_write(fifo_seq_item item);
        write_ops++;
        if (item.wr_valid) begin
            ref_q.push_back(item.din);
            expected_count++;
        end
        // Validate full flag
        begin
            bit exp_full = (expected_count == FIFO_DEPTH);
            if (item.full !== exp_full) begin
                `TB_ERROR(name, $sformatf(
                    "full flag mismatch: obs=%b exp=%b  (ref_count=%0d)",
                    item.full, exp_full, expected_count))
                flag_errors++;
            end
        end
        // Validate count
        if (item.count !== expected_count[FIFO_CNT_W-1:0]) begin
            `TB_ERROR(name, $sformatf(
                "count mismatch: obs=%0d exp=%0d",
                item.count, expected_count))
            count_errors++;
        end
    endfunction

    // ─────────────────────────────────────────────────────────────────────
    //  process_read — pop, compare dout, validate empty / count
    // ─────────────────────────────────────────────────────────────────────
    function automatic void process_read(fifo_seq_item item);
        read_ops++;
        if (item.rd_valid) begin
            if (ref_q.size() == 0) begin
                `TB_ERROR(name, "Read from empty reference model queue!")
                data_errors++;
            end else begin
                logic [FIFO_DATA_W-1:0] exp_data = ref_q.pop_front();
                expected_count--;
                if (item.dout !== exp_data) begin
                    `TB_ERROR(name, $sformatf(
                        "DATA MISMATCH: observed=%02h  expected=%02h  [%s]",
                        item.dout, exp_data, item.sprint()))
                    data_errors++;
                end else begin
                    tb_pkg::pass_count++;
                    pass_count++;
                end
            end
        end
        // Validate empty flag
        begin
            bit exp_empty = (expected_count == 0);
            if (item.empty !== exp_empty) begin
                `TB_ERROR(name, $sformatf(
                    "empty flag mismatch: obs=%b exp=%b  (ref_count=%0d)",
                    item.empty, exp_empty, expected_count))
                flag_errors++;
            end
        end
    endfunction

    // ─────────────────────────────────────────────────────────────────────
    //  run — blocking loop, processes transactions in arrival order
    // ─────────────────────────────────────────────────────────────────────
    virtual task run();
        fifo_seq_item item;
        `TB_INFO(name, "Scoreboard started")
        forever begin
            inbox.get(item);
            total_count++;
            // Process write before read to model FIFO_BOTH correctly
            if (item.txn_type inside {FIFO_WRITE, FIFO_BOTH})
                process_write(item);
            if (item.txn_type inside {FIFO_READ, FIFO_BOTH})
                process_read(item);
        end
    endtask

    // ─────────────────────────────────────────────────────────────────────
    //  report
    // ─────────────────────────────────────────────────────────────────────
    virtual function void report();
        $display("");
        $display("  ┌──────────────────────────────────────────────┐");
        $display("  │  SCOREBOARD  %-31s│", name);
        $display("  ├──────────────────────────────────────────────┤");
        $display("  │  Write ops         : %-6d                  │", write_ops);
        $display("  │  Read  ops         : %-6d                  │", read_ops);
        $display("  │  Total transactions: %-6d                  │", total_count);
        $display("  ├──────────────────────────────────────────────┤");
        $display("  │  Data  errors      : %-6d                  │", data_errors);
        $display("  │  Flag  errors      : %-6d                  │", flag_errors);
        $display("  │  Count errors      : %-6d                  │", count_errors);
        $display("  │  Checks PASSED     : %-6d                  │", pass_count);
        $display("  └──────────────────────────────────────────────┘");
    endfunction

endclass : fifo_scoreboard
