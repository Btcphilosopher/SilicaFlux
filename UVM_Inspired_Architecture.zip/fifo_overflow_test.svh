//==============================================================================
// fifo_overflow_test.svh — Boundary / corner-case test
//   Included by fifo_test_pkg.sv — not a standalone compilation unit.
//
//  Four staged operations:
//    Stage 1  fill_seq      — write FIFO_DEPTH items (reach full)
//    Stage 2  overflow_seq  — 4 extra writes to full FIFO
//    Stage 3  drain_seq     — read FIFO_DEPTH items (reach empty)
//    Stage 4  underflow_seq — 4 extra reads from empty FIFO
//
//  SVA properties A9 / A10 catch violations in real-time.
//  The scoreboard verifies data integrity over fill → overflow → drain.
//==============================================================================

class fifo_overflow_test extends tb_test;

    fifo_env        env;
    virtual fifo_if vif;

    function new(virtual fifo_if vif_h,
                 string name = "fifo_overflow_test");
        super.new(name);
        this.vif = vif_h;
    endfunction

    virtual function void build_phase();
        env = new({name, ".env"}, vif);
        env.build_phase();
    endfunction

    virtual function void connect_phase();
        env.connect_phase();
    endfunction

    virtual task run_phase();
        fifo_fill_seq      fill_seq;
        fifo_overflow_seq  ov_seq;
        fifo_drain_seq     drain_seq;
        fifo_underflow_seq uf_seq;

        fork env.run_phase(); join_none

        // ── Stage 1: Fill to capacity ─────────────────────────────────────
        `TB_PHASE_START("overflow_test::fill")
        `TB_INFO(name, $sformatf("Filling FIFO to capacity (%0d entries)", FIFO_DEPTH))
        fill_seq = new("fill");
        fill_seq.start(env.agent.sequencer);
        #200ns;

        // ── Stage 2: Attempt overflow ─────────────────────────────────────
        `TB_PHASE_START("overflow_test::overflow")
        `TB_INFO(name, "Writing 4 extra items to full FIFO (SVA A9 monitors)")
        ov_seq = new("overflow");
        ov_seq.start(env.agent.sequencer);
        #200ns;

        // ── Stage 3: Drain completely ─────────────────────────────────────
        `TB_PHASE_START("overflow_test::drain")
        `TB_INFO(name, $sformatf("Draining FIFO (%0d reads)", FIFO_DEPTH))
        drain_seq = new("drain");
        drain_seq.start(env.agent.sequencer);
        #200ns;

        // ── Stage 4: Attempt underflow ────────────────────────────────────
        `TB_PHASE_START("overflow_test::underflow")
        `TB_INFO(name, "Reading 4 items from empty FIFO (SVA A10 monitors)")
        uf_seq = new("underflow", 4);
        uf_seq.start(env.agent.sequencer);
        #200ns;

        `TB_INFO(name, "All corner-case stages complete")
        #400ns;
    endtask

    virtual function void check_phase();
        env.check_phase();

        // Expect zero data errors: overflow/underflow ops should be silently
        // rejected by the DUT (backpressure) and the scoreboard's wr_valid /
        // rd_valid flags correctly exclude them from the reference model.
        `TB_CHECK(name,
            env.scoreboard.data_errors == 0,
            "No data errors expected in overflow/underflow test")

        // Final state: FIFO should be empty
        `TB_CHECK(name,
            env.scoreboard.expected_count == 0,
            $sformatf("Expected empty FIFO at end; ref_count=%0d",
                      env.scoreboard.expected_count))

        `TB_INFO(name, $sformatf(
            "boundary_cg coverage: %.1f%%",
            env.coverage.boundary_cg.get_inst_coverage()))
    endfunction

endclass : fifo_overflow_test
