//==============================================================================
// fifo_sequences.svh — FIFO Sequence Library
//   Included by fifo_pkg.sv — not a standalone compilation unit.
//
//  Sequences available:
//    fifo_base_seq       – common helpers (make_write / make_read / make_both)
//    fifo_write_seq      – N sequential incremental writes
//    fifo_read_seq       – N sequential reads
//    fifo_fill_seq       – fill FIFO to capacity
//    fifo_drain_seq      – drain FIFO completely
//    fifo_overflow_seq   – fill then write past capacity (corner case)
//    fifo_underflow_seq  – read past empty (corner case)
//    fifo_ping_pong_seq  – sustained simultaneous write + read stress
//    fifo_rand_seq       – fully constrained-random traffic
//==============================================================================

// ─────────────────────────────────────────────────────────────────────────────
//  Base sequence — common helper constructors
// ─────────────────────────────────────────────────────────────────────────────
class fifo_base_seq extends tb_sequence #(fifo_seq_item);

    function new(string name = "fifo_base_seq");
        super.new(name);
    endfunction

    // Construct a write-only item
    protected function fifo_seq_item make_write(logic [FIFO_DATA_W-1:0] data);
        fifo_seq_item item = new();
        item.txn_type = FIFO_WRITE;
        item.din      = data;
        return item;
    endfunction

    // Construct a read-only item
    protected function fifo_seq_item make_read();
        fifo_seq_item item = new();
        item.txn_type = FIFO_READ;
        return item;
    endfunction

    // Construct a simultaneous write+read item
    protected function fifo_seq_item make_both(logic [FIFO_DATA_W-1:0] data);
        fifo_seq_item item = new();
        item.txn_type = FIFO_BOTH;
        item.din      = data;
        return item;
    endfunction

    // Default empty body (overridden by concrete sequences)
    virtual task body(); endtask

endclass : fifo_base_seq

// ─────────────────────────────────────────────────────────────────────────────
//  Write N incrementing values starting from start_data
// ─────────────────────────────────────────────────────────────────────────────
class fifo_write_seq extends fifo_base_seq;
    int unsigned             n_writes   = 8;
    logic [FIFO_DATA_W-1:0]  start_data = 8'h10;

    function new(string name = "fifo_write_seq",
                 int unsigned n         = 8,
                 logic [FIFO_DATA_W-1:0] start = 8'h10);
        super.new(name);
        n_writes   = n;
        start_data = start;
    endfunction

    virtual task body();
        for (int i = 0; i < n_writes; i++)
            p_sequencer.send(make_write(start_data + i[FIFO_DATA_W-1:0]));
    endtask
endclass : fifo_write_seq

// ─────────────────────────────────────────────────────────────────────────────
//  Issue N read requests
// ─────────────────────────────────────────────────────────────────────────────
class fifo_read_seq extends fifo_base_seq;
    int unsigned n_reads = 8;

    function new(string name = "fifo_read_seq", int unsigned n = 8);
        super.new(name); n_reads = n;
    endfunction

    virtual task body();
        for (int i = 0; i < n_reads; i++)
            p_sequencer.send(make_read());
    endtask
endclass : fifo_read_seq

// ─────────────────────────────────────────────────────────────────────────────
//  Fill FIFO to capacity (FIFO_DEPTH writes)
// ─────────────────────────────────────────────────────────────────────────────
class fifo_fill_seq extends fifo_base_seq;
    function new(string name = "fifo_fill_seq"); super.new(name); endfunction

    virtual task body();
        for (int i = 0; i < FIFO_DEPTH; i++)
            p_sequencer.send(make_write(8'hA0 + i[7:0]));
    endtask
endclass : fifo_fill_seq

// ─────────────────────────────────────────────────────────────────────────────
//  Drain FIFO completely (FIFO_DEPTH reads)
// ─────────────────────────────────────────────────────────────────────────────
class fifo_drain_seq extends fifo_base_seq;
    function new(string name = "fifo_drain_seq"); super.new(name); endfunction

    virtual task body();
        for (int i = 0; i < FIFO_DEPTH; i++)
            p_sequencer.send(make_read());
    endtask
endclass : fifo_drain_seq

// ─────────────────────────────────────────────────────────────────────────────
//  Fill FIFO then attempt 4 extra writes (overflow corner case)
// ─────────────────────────────────────────────────────────────────────────────
class fifo_overflow_seq extends fifo_base_seq;
    function new(string name = "fifo_overflow_seq"); super.new(name); endfunction

    virtual task body();
        for (int i = 0; i < FIFO_DEPTH; i++)           // fill to capacity
            p_sequencer.send(make_write(8'hB0 + i[7:0]));
        for (int i = 0; i < 4; i++)                     // attempt overflow
            p_sequencer.send(make_write(8'hFF));
    endtask
endclass : fifo_overflow_seq

// ─────────────────────────────────────────────────────────────────────────────
//  Attempt N reads from an empty FIFO (underflow corner case)
// ─────────────────────────────────────────────────────────────────────────────
class fifo_underflow_seq extends fifo_base_seq;
    int unsigned n_bad = 4;

    function new(string name = "fifo_underflow_seq", int unsigned n = 4);
        super.new(name); n_bad = n;
    endfunction

    virtual task body();
        for (int i = 0; i < n_bad; i++)
            p_sequencer.send(make_read());
    endtask
endclass : fifo_underflow_seq

// ─────────────────────────────────────────────────────────────────────────────
//  Sustained simultaneous read+write stress (ping-pong)
//  Seeds the FIFO at half-depth first, then fires FIFO_BOTH ops.
// ─────────────────────────────────────────────────────────────────────────────
class fifo_ping_pong_seq extends fifo_base_seq;
    int unsigned n_pairs = 32;

    function new(string name = "fifo_ping_pong_seq", int unsigned n = 32);
        super.new(name); n_pairs = n;
    endfunction

    virtual task body();
        // Seed with half-capacity data
        for (int i = 0; i < FIFO_DEPTH/2; i++)
            p_sequencer.send(make_write(8'hC0 + i[7:0]));
        // Sustained simultaneous traffic
        for (int i = 0; i < n_pairs; i++)
            p_sequencer.send(make_both(8'hD0 + (i % FIFO_DEPTH)[7:0]));
    endtask
endclass : fifo_ping_pong_seq

// ─────────────────────────────────────────────────────────────────────────────
//  Fully constrained-random sequence (uses fifo_seq_item constraints)
// ─────────────────────────────────────────────────────────────────────────────
class fifo_rand_seq extends fifo_base_seq;
    int unsigned n_txn = 200;

    function new(string name = "fifo_rand_seq", int unsigned n = 200);
        super.new(name); n_txn = n;
    endfunction

    virtual task body();
        fifo_seq_item item;
        for (int i = 0; i < n_txn; i++) begin
            item = new($sformatf("rand_%04d", i));
            if (!item.randomize())
                `TB_FATAL("fifo_rand_seq", $sformatf("randomize() failed on item %0d", i))
            p_sequencer.send(item);
        end
    endtask
endclass : fifo_rand_seq

// ─────────────────────────────────────────────────────────────────────────────
//  Write-then-read sequence with inline data-integrity checking
//  (for directed, deterministic ordering without the scoreboard)
// ─────────────────────────────────────────────────────────────────────────────
class fifo_directed_seq extends fifo_base_seq;
    int unsigned n_items = 8;

    function new(string name = "fifo_directed_seq", int unsigned n = 8);
        super.new(name); n_items = n;
    endfunction

    virtual task body();
        // Write all
        for (int i = 0; i < n_items; i++)
            p_sequencer.send(make_write(8'h30 + i[7:0]));
        // Read all
        for (int i = 0; i < n_items; i++)
            p_sequencer.send(make_read());
    endtask
endclass : fifo_directed_seq
