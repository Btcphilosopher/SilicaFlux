//==============================================================================
// sync_fifo.sv — Parameterised Synchronous FIFO  (Reference DUT)
//
//  DATA_WIDTH : data bus width in bits     (default 8)
//  DEPTH      : number of entries          (default 16)
//
//  Registered read output: dout updates one cycle after rd_en asserts.
//==============================================================================
`timescale 1ns/1ps
`default_nettype none

module sync_fifo #(
    parameter int DATA_WIDTH = 8,
    parameter int DEPTH      = 16
)(
    input  logic                   clk,
    input  logic                   rst_n,
    // ── Write port ────────────────────────────────────────────────────────
    input  logic                   wr_en,
    input  logic [DATA_WIDTH-1:0]  din,
    // ── Read port ─────────────────────────────────────────────────────────
    input  logic                   rd_en,
    output logic [DATA_WIDTH-1:0]  dout,
    // ── Status ────────────────────────────────────────────────────────────
    output logic                   full,
    output logic                   empty,
    output logic [$clog2(DEPTH):0] count
);

    localparam int PTR_W = $clog2(DEPTH);

    logic [DATA_WIDTH-1:0] mem      [0:DEPTH-1];
    logic [PTR_W-1:0]      wr_ptr;
    logic [PTR_W-1:0]      rd_ptr;
    logic [PTR_W:0]        fill_cnt;

    // ── Combinational flags ───────────────────────────────────────────────
    assign full  = (fill_cnt == DEPTH[PTR_W:0]);
    assign empty = (fill_cnt == '0);
    assign count = fill_cnt;

    // ── Registered read output ────────────────────────────────────────────
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)               dout <= '0;
        else if (rd_en && !empty) dout <= mem[rd_ptr];
    end

    // ── Write / read pointer control ──────────────────────────────────────
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_ptr   <= '0;
            rd_ptr   <= '0;
            fill_cnt <= '0;
        end else begin
            if (wr_en && !full) begin
                mem[wr_ptr] <= din;
                wr_ptr      <= wr_ptr + 1'b1;
            end
            if (rd_en && !empty) begin
                rd_ptr <= rd_ptr + 1'b1;
            end
            // Fill counter update (one-hot priority cases)
            unique case ({(wr_en & ~full), (rd_en & ~empty)})
                2'b10   : fill_cnt <= fill_cnt + 1'b1;
                2'b01   : fill_cnt <= fill_cnt - 1'b1;
                default : ;   // simultaneous or no-op: count unchanged
            endcase
        end
    end

    // ── Simulation guards (non-synthesisable) ─────────────────────────────
`ifdef SIMULATION
    always @(posedge clk) begin
        if (rst_n) begin
            if (wr_en && full)
                $warning("[sync_fifo] Write-while-FULL  @%0t", $time);
            if (rd_en && empty)
                $warning("[sync_fifo] Read-while-EMPTY  @%0t", $time);
        end
    end
`endif

endmodule : sync_fifo

`default_nettype wire
