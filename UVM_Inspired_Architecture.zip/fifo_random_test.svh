//==============================================================================
// fifo_random_test.svh — Constrained-random regression test
//   Included by fifo_test_pkg.sv — not a standalone compilation unit.
//
//  Phases:
//    1. fifo_rand_seq     (500 fully-random transactions)
//    2. fifo_ping_pong_seq (64 simultaneous R/W pairs — stresses FIFO_BOTH)
//
//  Post-run: warns if any covergroup falls below its threshold.
//==============================================================================

class fifo_random_test extends tb_test;

    fifo_env        env;
    virtual fifo_if vif;

    int unsigned    n_random = 500;
    int unsigned    n_pairs  = 64;

    // Minimum acceptable per-group coverage (%)
    real  fill_thr    = 90.0;
    real  txn_thr     = 85.0;
    real  pattern_thr = 60.0;
    real  boundary_thr= 80.0;

    function new(virtual fifo_if vif_h,
                 string name = "fifo_random_test");
        super.new(name);
        this.vif = vif_h;
    endfunction

    virtual function void build_phase();
        env = new({name, ".env"}, vif);
        env.build_phase();
    endfunction

    virtual function void connect_phase();
        env.connect_phase();
    endfunction

    virtual task run_phase();
        fifo_rand_seq      rand_seq;
        fifo_ping_pong_seq pp_seq;

        fork env.run_phase(); join_none

        // ── Phase 1: Random traffic ───────────────────────────────────────
        `TB_PHASE_START("random_test::rand_traffic")
        rand_seq = new("rand_traffic", n_random);
        rand_seq.start(env.agent.sequencer);
        #300ns;

        // ── Phase 2: Simultaneous R/W stress ─────────────────────────────
        `TB_PHASE_START("random_test::ping_pong")
        pp_seq = new("ping_pong", n_pairs);
        pp_seq.start(env.agent.sequencer);
        #300ns;

        `TB_INFO(name, "All random sequences complete")
        #500ns;   // extended drain for concurrent monitor forks
    endtask

    virtual function void check_phase();
        env.check_phase();   // data / flag / count checks

        // ── Coverage threshold checks ─────────────────────────────────────
        begin
            real cov;
            cov = env.coverage.fill_level_cg.get_inst_coverage();
            if (cov < fill_thr)
                `TB_WARNING(name, $sformatf(
                    "fill_level_cg coverage %.1f%% < threshold %.1f%%",
                    cov, fill_thr))

            cov = env.coverage.txn_type_cg.get_inst_coverage();
            if (cov < txn_thr)
                `TB_WARNING(name, $sformatf(
                    "txn_type_cg coverage %.1f%% < threshold %.1f%%",
                    cov, txn_thr))

            cov = env.coverage.data_pattern_cg.get_inst_coverage();
            if (cov < pattern_thr)
                `TB_WARNING(name, $sformatf(
                    "data_pattern_cg coverage %.1f%% < threshold %.1f%%",
                    cov, pattern_thr))

            cov = env.coverage.boundary_cg.get_inst_coverage();
            if (cov < boundary_thr)
                `TB_WARNING(name, $sformatf(
                    "boundary_cg coverage %.1f%% < threshold %.1f%%",
                    cov, boundary_thr))
        end
    endfunction

endclass : fifo_random_test
