//==============================================================================
// fifo_sva.sv — Assertion-Based Verification for sync_fifo
//
//  10 safety assertions + 6 reachability cover properties.
//
//  All assertions are disabled during reset (disable iff (!rst_n)).
//
//  Instantiated in tb_top alongside the DUT, connected to the same signals.
//==============================================================================
`timescale 1ns/1ps

module fifo_sva #(
    parameter int DATA_WIDTH = 8,
    parameter int DEPTH      = 16
)(
    input logic                   clk,
    input logic                   rst_n,
    input logic                   wr_en,
    input logic [DATA_WIDTH-1:0]  din,
    input logic                   rd_en,
    input logic [DATA_WIDTH-1:0]  dout,
    input logic                   full,
    input logic                   empty,
    input logic [$clog2(DEPTH):0] count
);

    // ── Convenience nets ─────────────────────────────────────────────────
    wire eff_wr = wr_en && !full;    // write that actually takes effect
    wire eff_rd = rd_en && !empty;   // read  that actually takes effect

    // =========================================================================
    //  A1 — After deassertion of rst_n, FIFO must be empty within one cycle
    // =========================================================================
    property p_reset_empty;
        @(posedge clk)
        $fell(rst_n) |=> (empty && !full && (count == '0));
    endproperty
    A1_reset_empty: assert property (p_reset_empty)
        else $error("[SVA-A1] FIFO not empty after reset");
    C1_reset_empty: cover property (p_reset_empty);

    // =========================================================================
    //  A2 — full and empty cannot both be asserted simultaneously
    // =========================================================================
    property p_no_full_and_empty;
        @(posedge clk) disable iff (!rst_n)
        not (full && empty);
    endproperty
    A2_no_full_and_empty: assert property (p_no_full_and_empty)
        else $error("[SVA-A2] full && empty simultaneously asserted");

    // =========================================================================
    //  A3 — count must never exceed DEPTH
    // =========================================================================
    property p_count_bounded;
        @(posedge clk) disable iff (!rst_n)
        count <= DEPTH;
    endproperty
    A3_count_bounded: assert property (p_count_bounded)
        else $error("[SVA-A3] count exceeded DEPTH: %0d > %0d", count, DEPTH);

    // =========================================================================
    //  A4 — full flag iff count == DEPTH
    // =========================================================================
    property p_full_consistency;
        @(posedge clk) disable iff (!rst_n)
        full == (count == DEPTH[$clog2(DEPTH):0]);
    endproperty
    A4_full_consistency: assert property (p_full_consistency)
        else $error("[SVA-A4] full flag inconsistent with count=%0d", count);

    // =========================================================================
    //  A5 — empty flag iff count == 0
    // =========================================================================
    property p_empty_consistency;
        @(posedge clk) disable iff (!rst_n)
        empty == (count == '0);
    endproperty
    A5_empty_consistency: assert property (p_empty_consistency)
        else $error("[SVA-A5] empty flag inconsistent with count=%0d", count);

    // =========================================================================
    //  A6 — write-only: count must increment by 1
    // =========================================================================
    property p_count_inc_on_write;
        @(posedge clk) disable iff (!rst_n)
        (eff_wr && !eff_rd) |=> (count == $past(count) + 1);
    endproperty
    A6_count_inc_on_write: assert property (p_count_inc_on_write)
        else $error("[SVA-A6] count did not increment after effective write");

    // =========================================================================
    //  A7 — read-only: count must decrement by 1
    // =========================================================================
    property p_count_dec_on_read;
        @(posedge clk) disable iff (!rst_n)
        (!eff_wr && eff_rd) |=> (count == $past(count) - 1);
    endproperty
    A7_count_dec_on_read: assert property (p_count_dec_on_read)
        else $error("[SVA-A7] count did not decrement after effective read");

    // =========================================================================
    //  A8 — simultaneous eff_wr + eff_rd: count stays stable
    // =========================================================================
    property p_count_stable_both;
        @(posedge clk) disable iff (!rst_n)
        (eff_wr && eff_rd) |=> (count == $past(count));
    endproperty
    A8_count_stable_both: assert property (p_count_stable_both)
        else $error("[SVA-A8] count changed on simultaneous read+write");

    // =========================================================================
    //  A9 — overflow protection: write to full FIFO must not change count
    // =========================================================================
    property p_no_overflow;
        @(posedge clk) disable iff (!rst_n)
        (wr_en && full && !rd_en) |=> (count == $past(count));
    endproperty
    A9_no_overflow: assert property (p_no_overflow)
        else $error("[SVA-A9] FIFO overflowed (count changed on wr_en to full)");

    // =========================================================================
    //  A10 — underflow protection: read from empty FIFO must not change count
    // =========================================================================
    property p_no_underflow;
        @(posedge clk) disable iff (!rst_n)
        (rd_en && empty && !wr_en) |=> (count == $past(count));
    endproperty
    A10_no_underflow: assert property (p_no_underflow)
        else $error("[SVA-A10] FIFO underflowed (count changed on rd_en from empty)");

    // =========================================================================
    //  A11 — write-to-read data integrity (single-entry path)
    //  When the FIFO transitions from empty→1 entry (single write) and a read
    //  immediately follows, dout must equal the value that was written.
    // =========================================================================
    property p_write_read_integrity;
        logic [DATA_WIDTH-1:0] wdata;
        @(posedge clk) disable iff (!rst_n)
        // Write when FIFO is empty; capture din
        (eff_wr && empty, wdata = din)
        // Immediate read one cycle later (now count==1, not empty)
        ##1 eff_rd
        // Registered output appears one more cycle after rd_en
        |=> (dout == wdata);
    endproperty
    A11_write_read_integrity: assert property (p_write_read_integrity)
        else $error("[SVA-A11] Read data mismatch on single-entry path");

    // =========================================================================
    //  Cover properties — verify reachability of critical states
    // =========================================================================
    C2_full_reached    : cover property (@(posedge clk) disable iff (!rst_n) full);
    C3_empty_reached   : cover property (@(posedge clk) disable iff (!rst_n) empty);
    C4_wr_when_full    : cover property (@(posedge clk) disable iff (!rst_n) (wr_en && full));
    C5_rd_when_empty   : cover property (@(posedge clk) disable iff (!rst_n) (rd_en && empty));
    C6_simultaneous_rw : cover property (@(posedge clk) disable iff (!rst_n) (eff_wr && eff_rd));
    C7_count_mid       : cover property (@(posedge clk) disable iff (!rst_n)
                             (count == DEPTH/2));

endmodule : fifo_sva
