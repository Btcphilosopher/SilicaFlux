//==============================================================================
// fifo_basic_test.svh — Directed functional test
//   Included by fifo_test_pkg.sv — not a standalone compilation unit.
//
//  Sequence:
//    1. Write 8 incrementing values (0xA0 … 0xA7)
//    2. Read  8 values back
//    3. Scoreboard checks in-order data integrity + flag correctness
//    4. Verify FIFO is empty at end (count == 0)
//==============================================================================

class fifo_basic_test extends tb_test;

    fifo_env        env;
    virtual fifo_if vif;
    int unsigned    n_items = 8;

    function new(virtual fifo_if vif_h,
                 string name = "fifo_basic_test");
        super.new(name);
        this.vif = vif_h;
    endfunction

    virtual function void build_phase();
        env = new({name, ".env"}, vif);
        env.build_phase();
        `TB_INFO(name, "Build complete")
    endfunction

    virtual function void connect_phase();
        env.connect_phase();
        `TB_INFO(name, "Connect complete")
    endfunction

    virtual task run_phase();
        fifo_write_seq wr_seq;
        fifo_read_seq  rd_seq;

        // Start background scoreboard / coverage processes
        fork env.run_phase(); join_none

        // ── Phase 1: Write ────────────────────────────────────────────────
        `TB_PHASE_START("basic_test::write")
        wr_seq = new("wr_seq", n_items, 8'hA0);
        wr_seq.start(env.agent.sequencer);
        #150ns;    // let driver flush all items

        // ── Phase 2: Read ─────────────────────────────────────────────────
        `TB_PHASE_START("basic_test::read")
        rd_seq = new("rd_seq", n_items);
        rd_seq.start(env.agent.sequencer);
        #150ns;

        `TB_INFO(name, "Sequences complete — drain time")
        #300ns;    // extra drain: allow monitor forks to settle
    endtask

    virtual function void check_phase();
        env.check_phase();
        // FIFO should be empty after reading everything back
        `TB_CHECK(name,
            env.scoreboard.expected_count == 0,
            $sformatf("Expected empty FIFO after test; ref_count=%0d",
                      env.scoreboard.expected_count))
        `TB_INFO(name, "Check phase complete")
    endfunction

endclass : fifo_basic_test
