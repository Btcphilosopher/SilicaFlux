// =============================================================================
// compile.f — Ordered compilation file list for sv_verify_framework
//
//  Usage:
//    VCS      : vcs  -sverilog -f sim/compile.f -o simv
//    Questa   : vlog -sv       -f sim/compile.f
//    Xcelium  : xrun -sv       -f sim/compile.f
//    Icarus   : iverilog -g2012 -f sim/compile.f -o sim.vvp
//
//  Dependency order (must not be reordered):
//    1. Base framework package   — no dependencies
//    2. DUT RTL                  — no TB dependencies
//    3. FIFO interface           — no package dependencies
//    4. FIFO package             — imports tb_pkg, uses fifo_if
//    5. FIFO test package        — imports fifo_pkg
//    6. FIFO SVA module          — standalone, no package imports
//    7. Testbench top            — imports all packages, instantiates all modules
// =============================================================================

// ── Global defines ────────────────────────────────────────────────────────
+define+SIMULATION

// ── Include paths (for `include resolution) ───────────────────────────────
+incdir+../tb/base
+incdir+../tb/fifo
+incdir+../tb/tests

// ── 1. Base framework ─────────────────────────────────────────────────────
../tb/base/tb_pkg.sv

// ── 2. DUT ───────────────────────────────────────────────────────────────
../rtl/sync_fifo.sv

// ── 3. Verification interface ─────────────────────────────────────────────
../tb/fifo/fifo_if.sv

// ── 4. FIFO verification package ─────────────────────────────────────────
../tb/fifo/fifo_pkg.sv

// ── 5. FIFO test package ──────────────────────────────────────────────────
../tb/tests/fifo_test_pkg.sv

// ── 6. SVA module ─────────────────────────────────────────────────────────
../tb/fifo/fifo_sva.sv

// ── 7. Testbench top ──────────────────────────────────────────────────────
../tb/top/fifo_tb_top.sv
