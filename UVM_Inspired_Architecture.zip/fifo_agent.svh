//==============================================================================
// fifo_agent.svh — FIFO Agent
//   Included by fifo_pkg.sv — not a standalone compilation unit.
//
//  Bundles the driver, monitor, and sequencer into a single reusable agent.
//
//  active = 1  (default) — instantiates driver + sequencer; can drive DUT
//  active = 0            — monitor only; useful for passive observation
//
//  The agent exposes:
//    sequencer  — tests start sequences here
//    monitor.ap — broadcast analysis port (connect to scoreboard / coverage)
//==============================================================================

class fifo_agent;

    string                          name;
    bit                             active = 1;

    // ── Sub-components ────────────────────────────────────────────────────
    fifo_driver                     driver;
    fifo_monitor                    monitor;
    tb_sequencer #(fifo_seq_item)   sequencer;

    // ── Interface handle ──────────────────────────────────────────────────
    virtual fifo_if                 vif;

    function new(string name = "fifo_agent",
                 virtual fifo_if vif_h,
                 bit active = 1);
        this.name   = name;
        this.vif    = vif_h;
        this.active = active;
    endfunction

    // ── build_phase: instantiate components ──────────────────────────────
    virtual function void build_phase();
        monitor = new({name, ".monitor"}, vif);
        if (active) begin
            sequencer = new({name, ".sequencer"});
            driver    = new({name, ".driver"}, vif);
        end
        `TB_INFO(name, $sformatf("Agent built [%s]", active ? "ACTIVE" : "PASSIVE"))
    endfunction

    // ── connect_phase: wire driver port to sequencer export ───────────────
    virtual function void connect_phase();
        if (active)
            driver.connect(sequencer.seq_item_export);
    endfunction

    // ── run: start monitor and (optionally) driver in background ─────────
    virtual task run();
        fork
            monitor.run();
            if (active) driver.run();
        join_none
    endtask

endclass : fifo_agent
