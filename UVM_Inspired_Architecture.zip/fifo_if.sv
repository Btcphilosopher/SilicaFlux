//==============================================================================
// fifo_if.sv — FIFO Verification Interface
//
//  Provides two clocking blocks:
//    driver_cb  — synchronised outputs from TB → DUT  (1-step skew)
//    monitor_cb — synchronised inputs  to   TB       (1-step skew)
//
//  Both modports and helper tasks are included.
//==============================================================================
`timescale 1ns/1ps

interface fifo_if #(
    parameter int DATA_WIDTH = 8,
    parameter int DEPTH      = 16
)(
    input logic clk,
    input logic rst_n
);

    // ── DUT-facing signals ────────────────────────────────────────────────
    logic                   wr_en;
    logic [DATA_WIDTH-1:0]  din;
    logic                   rd_en;
    logic [DATA_WIDTH-1:0]  dout;
    logic                   full;
    logic                   empty;
    logic [$clog2(DEPTH):0] count;

    // ── Driver clocking block ─────────────────────────────────────────────
    clocking driver_cb @(posedge clk);
        default input #1step output #1step;
        output wr_en, din, rd_en;
        input  dout, full, empty, count;
    endclocking

    // ── Monitor clocking block ────────────────────────────────────────────
    clocking monitor_cb @(posedge clk);
        default input #1step;
        input wr_en, din, rd_en, dout, full, empty, count;
    endclocking

    // ── Modports ─────────────────────────────────────────────────────────
    modport DUT_MP (
        input  clk, rst_n, wr_en, din, rd_en,
        output dout, full, empty, count
    );

    modport DRIVER_MP  (clocking driver_cb,  input rst_n);
    modport MONITOR_MP (clocking monitor_cb, input rst_n);

    // ── Utility tasks (available in default context) ──────────────────────

    // Wait N rising edges
    task automatic wait_clocks(int unsigned n = 1);
        repeat (n) @(posedge clk);
    endtask

    // Drive all outputs to known-idle state
    task automatic drive_idle();
        driver_cb.wr_en <= 1'b0;
        driver_cb.din   <= '0;
        driver_cb.rd_en <= 1'b0;
    endtask

endinterface : fifo_if
