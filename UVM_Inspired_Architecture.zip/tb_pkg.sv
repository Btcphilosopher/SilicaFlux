//==============================================================================
// tb_pkg.sv — Lightweight UVM-inspired base framework
//
// Hierarchy (all parameterised with default type = tb_transaction):
//
//   tb_transaction   – base sequence item
//   tb_ap            – analysis port (fan-out broadcaster)
//   tb_sequencer     – holds the shared driver mailbox; sequences put into it
//   tb_sequence      – abstract; override body()
//   tb_driver        – abstract; override drive_item(); calls run() in fork
//   tb_monitor       – abstract; override collect_item(); broadcasts via ap
//   tb_scoreboard    – abstract; override run() / check_txn() / report()
//   tb_coverage      – abstract; override sample() / get_coverage()
//   tb_env           – abstract; 5-phase lifecycle
//   tb_test          – abstract; 5-phase lifecycle + result banner
//==============================================================================
`ifndef TB_PKG_SV
`define TB_PKG_SV

`include "tb_defines.svh"

package tb_pkg;

    // ── Global simulation counters ────────────────────────────────────────
    int unsigned error_count = 0;
    int unsigned pass_count  = 0;
    int unsigned verbosity   = `TB_MEDIUM;

    // =========================================================================
    //  tb_transaction  – base class for all sequence items
    // =========================================================================
    class tb_transaction;
        int unsigned        txn_id;
        time                timestamp;
        static int unsigned id_counter = 0;

        function new();
            txn_id    = id_counter++;
            timestamp = $time;
        endfunction

        virtual function tb_transaction clone();
            tb_transaction t = new();
            t.txn_id    = this.txn_id;
            t.timestamp = this.timestamp;
            return t;
        endfunction

        virtual function string sprint();
            return $sformatf("TXN[%04d] @%0t", txn_id, timestamp);
        endfunction

        virtual function void print(string pfx = "");
            $display("%s%s", pfx, sprint());
        endfunction

        // Override in derived classes; default: non-null rhs => pass
        virtual function bit compare(tb_transaction rhs);
            return (rhs != null);
        endfunction
    endclass : tb_transaction

    // =========================================================================
    //  tb_ap  – analysis port: fan-out broadcaster to many mailbox subscribers
    // =========================================================================
    class tb_ap #(type T = tb_transaction);
        mailbox #(T) subscribers[$];

        function void connect(mailbox #(T) mb);
            subscribers.push_back(mb);
        endfunction

        // Task (mailbox.put is a blocking task even on unbounded mailboxes)
        task automatic write(T item);
            foreach (subscribers[i])
                subscribers[i].put(item);
        endtask
    endclass : tb_ap

    // =========================================================================
    //  tb_sequencer  – mediates sequence → driver communication
    // =========================================================================
    class tb_sequencer #(type T = tb_transaction);
        string        name;
        mailbox #(T)  seq_item_export;   // sequences put() here; driver get()s
        int unsigned  items_sent = 0;

        function new(string name = "sequencer");
            this.name       = name;
            seq_item_export = new(0);     // unbounded
        endfunction

        task automatic send(T item);
            seq_item_export.put(item);
            items_sent++;
        endtask
    endclass : tb_sequencer

    // =========================================================================
    //  tb_sequence  – abstract; derived classes implement body()
    // =========================================================================
    virtual class tb_sequence #(type T = tb_transaction);
        string             name;
        tb_sequencer #(T)  p_sequencer;

        function new(string name = "seq");
            this.name = name;
        endfunction

        task automatic start(tb_sequencer #(T) sqr);
            p_sequencer = sqr;
            body();
        endtask

        pure virtual task body();
    endclass : tb_sequence

    // =========================================================================
    //  tb_driver  – abstract; drives DUT via clocking block
    // =========================================================================
    virtual class tb_driver #(type T = tb_transaction);
        string              name;
        mailbox #(T)        seq_item_port;   // shared with sequencer's export
        int unsigned        num_driven = 0;

        function new(string name = "driver");
            this.name      = name;
            seq_item_port  = new(0);
        endfunction

        // Wire driver port to sequencer export (share the same mailbox)
        function void connect(mailbox #(T) sqr_export);
            seq_item_port = sqr_export;
        endfunction

        virtual task pre_drive(); endtask // hook: runs once before first item

        pure virtual task drive_item(T item);

        task automatic run();
            T item;
            pre_drive();
            forever begin
                seq_item_port.get(item);
                drive_item(item);
                num_driven++;
            end
        endtask
    endclass : tb_driver

    // =========================================================================
    //  tb_monitor  – abstract; observes DUT and broadcasts via analysis port
    // =========================================================================
    virtual class tb_monitor #(type T = tb_transaction);
        string        name;
        tb_ap #(T)    ap;               // fan-out analysis port
        int unsigned  num_observed = 0;

        function new(string name = "monitor");
            this.name = name;
            ap        = new();
        endfunction

        pure virtual task collect_item(output T item);

        task automatic run();
            T item;
            forever begin
                collect_item(item);
                ap.write(item);
                num_observed++;
            end
        endtask
    endclass : tb_monitor

    // =========================================================================
    //  tb_scoreboard  – abstract; reference model base
    // =========================================================================
    virtual class tb_scoreboard #(type T = tb_transaction);
        string        name;
        int unsigned  pass_count  = 0;
        int unsigned  fail_count  = 0;
        int unsigned  total_count = 0;

        function new(string name = "scoreboard");
            this.name = name;
        endfunction

        virtual function bit check_txn(T expected, T observed);
            return expected.compare(observed);
        endfunction

        virtual function void on_pass(T exp, T obs);
            tb_pkg::pass_count++;
            pass_count++;
        endfunction

        virtual function void on_fail(T exp, T obs);
            tb_pkg::error_count++;
            fail_count++;
            $display("[%8t ns][SB FAIL][%s]", $time, name);
            $display("  Expected : %s", exp.sprint());
            $display("  Observed : %s", obs.sprint());
        endfunction

        // Override in derived classes with appropriate port/mailbox logic
        pure virtual task run();

        virtual function void report();
            $display("[%s] PASS=%0d  FAIL=%0d  TOTAL=%0d",
                     name, pass_count, fail_count, total_count);
        endfunction
    endclass : tb_scoreboard

    // =========================================================================
    //  tb_coverage  – abstract; sample-driven functional coverage base
    // =========================================================================
    virtual class tb_coverage #(type T = tb_transaction);
        string        name;
        mailbox #(T)  ap;       // receives observed transactions

        function new(string name = "coverage");
            this.name = name;
            ap        = new(0);
        endfunction

        pure virtual function void  sample(T item);
        pure virtual function real  get_coverage();

        task automatic run();
            T item;
            forever begin
                ap.get(item);
                sample(item);
            end
        endtask

        virtual function void report();
            $display("[%s] Functional coverage: %.1f%%", name, get_coverage());
        endfunction
    endclass : tb_coverage

    // =========================================================================
    //  tb_env  – abstract environment: holds agents, scoreboards, coverage
    // =========================================================================
    virtual class tb_env;
        string name;

        function new(string name = "env");
            this.name = name;
        endfunction

        virtual function void build_phase();   endfunction
        virtual function void connect_phase(); endfunction
        virtual task         run_phase();      endtask
        virtual function void check_phase();   endfunction
        virtual function void report_phase();  endfunction

        task automatic run();
            `TB_PHASE_START("build_phase")   build_phase();    `TB_PHASE_END("build_phase")
            `TB_PHASE_START("connect_phase") connect_phase();  `TB_PHASE_END("connect_phase")
            `TB_PHASE_START("run_phase")     run_phase();      `TB_PHASE_END("run_phase")
            `TB_PHASE_START("check_phase")   check_phase();    `TB_PHASE_END("check_phase")
            `TB_PHASE_START("report_phase")  report_phase();   `TB_PHASE_END("report_phase")
        endtask
    endclass : tb_env

    // =========================================================================
    //  tb_test  – abstract test base; wraps env phases + result banner
    // =========================================================================
    virtual class tb_test;
        string name;

        function new(string name = "test");
            this.name = name;
        endfunction

        virtual function void build_phase();   endfunction
        virtual function void connect_phase(); endfunction
        virtual task         run_phase();      endtask
        virtual function void check_phase();   endfunction

        virtual function void report_phase();
            string result = (tb_pkg::error_count == 0) ? "PASS ✓" : "FAIL ✗";
            $display("");
            $display("╔══════════════════════════════════════════════╗");
            $display("║  Test  : %-37s║", name);
            $display("║  Checks PASSED : %-4d                       ║", tb_pkg::pass_count);
            $display("║  Checks FAILED : %-4d                       ║", tb_pkg::error_count);
            $display("║  Result        : %-28s ║", result);
            $display("╚══════════════════════════════════════════════╝");
            $display("");
        endfunction

        task automatic run();
            `TB_PHASE_START({name, "::build_phase"})   build_phase();   `TB_PHASE_END({name, "::build_phase"})
            `TB_PHASE_START({name, "::connect_phase"}) connect_phase(); `TB_PHASE_END({name, "::connect_phase"})
            `TB_PHASE_START({name, "::run_phase"})     run_phase();     `TB_PHASE_END({name, "::run_phase"})
            `TB_PHASE_START({name, "::check_phase"})   check_phase();   `TB_PHASE_END({name, "::check_phase"})
            report_phase();
        endtask
    endclass : tb_test

endpackage : tb_pkg

`endif // TB_PKG_SV
