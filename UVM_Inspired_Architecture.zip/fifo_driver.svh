//==============================================================================
// fifo_driver.svh — FIFO Driver
//   Included by fifo_pkg.sv — not a standalone compilation unit.
//
//  Drives stimulus onto the FIFO interface via the driver clocking block.
//  Handles backpressure:
//    • write-only  : waits if FIFO is full   (up to timeout_cycles)
//    • read-only   : waits if FIFO is empty  (up to timeout_cycles)
//    • both        : proceeds even if one side is blocked (DUT ignores it)
//==============================================================================

class fifo_driver extends tb_driver #(fifo_seq_item);

    virtual fifo_if  vif;
    int unsigned     timeout_cycles = 512;

    function new(string name = "fifo_driver", virtual fifo_if vif_h);
        super.new(name);
        this.vif = vif_h;
    endfunction

    // ── pre_drive: idle the bus and wait for reset release ────────────────
    virtual task pre_drive();
        vif.drive_idle();
        // Wait for rst_n rising edge
        @(posedge vif.rst_n);
        @(vif.driver_cb);
        `TB_INFO(name, "Driver ready — reset released")
    endtask

    // ── drive_item: apply one sequence item to the DUT ────────────────────
    virtual task drive_item(fifo_seq_item item);
        logic do_wr = item.wr_en();
        logic do_rd = item.rd_en();
        int   to;

        // ── Backpressure: stall a pure write if FIFO is full ──────────────
        if (do_wr && !do_rd) begin
            to = 0;
            while (vif.driver_cb.full) begin
                @(vif.driver_cb);
                if (++to > timeout_cycles) begin
                    `TB_WARNING(name, "Write stall: FIFO full — timeout, proceeding")
                    break;
                end
            end
        end

        // ── Backpressure: stall a pure read if FIFO is empty ─────────────
        if (do_rd && !do_wr) begin
            to = 0;
            while (vif.driver_cb.empty) begin
                @(vif.driver_cb);
                if (++to > timeout_cycles) begin
                    `TB_WARNING(name, "Read stall: FIFO empty — timeout, proceeding")
                    break;
                end
            end
        end

        // ── Drive for one cycle ───────────────────────────────────────────
        vif.driver_cb.wr_en <= do_wr;
        vif.driver_cb.din   <= item.din;
        vif.driver_cb.rd_en <= do_rd;
        @(vif.driver_cb);

        // ── De-assert after one active cycle ─────────────────────────────
        vif.driver_cb.wr_en <= 1'b0;
        vif.driver_cb.rd_en <= 1'b0;

        `TB_DEBUG_MSG(name, item.sprint())
    endtask

endclass : fifo_driver
