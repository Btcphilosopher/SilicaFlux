//==============================================================================
// fifo_monitor.svh — FIFO Monitor
//   Included by fifo_pkg.sv — not a standalone compilation unit.
//
//  Sampling strategy:
//    On each clock edge where wr_en || rd_en is asserted, a transaction is
//    captured.  Because the FIFO has a REGISTERED output, dout becomes valid
//    one cycle after rd_en — so the monitor forks a lightweight task per
//    transaction to latch dout, preventing any missed cycles.
//
//  Analysis port (ap, from tb_monitor base):
//    Broadcasts complete fifo_seq_item to all connected mailboxes
//    (scoreboard inbox, coverage ap).
//==============================================================================

class fifo_monitor extends tb_monitor #(fifo_seq_item);

    virtual fifo_if vif;

    function new(string name = "fifo_monitor", virtual fifo_if vif_h);
        super.new(name);
        this.vif = vif_h;
    endfunction

    // ── collect_item is not used directly; run() is fully overridden ──────
    virtual task collect_item(output fifo_seq_item item);
        // Intentionally empty — run() below handles the full flow
    endtask

    // ── run: non-blocking per-transaction capture ─────────────────────────
    //
    //  Main loop advances every clock.  When an active edge is detected, a
    //  fork..join_none is spawned to latch dout one cycle later.  The main
    //  loop immediately continues, so back-to-back cycles are never missed.
    // ─────────────────────────────────────────────────────────────────────
    virtual task run();
        `TB_INFO(name, "Monitor started")
        // Wait for reset to deassert before sampling
        @(posedge vif.rst_n);

        forever begin
            @(vif.monitor_cb);

            if (vif.monitor_cb.wr_en || vif.monitor_cb.rd_en) begin
                // Snapshot current-cycle signals into a local item
                fifo_seq_item item = new($sformatf("mon_%04d", num_observed));
                num_observed++;

                // Transaction type
                case ({vif.monitor_cb.wr_en, vif.monitor_cb.rd_en})
                    2'b10   : item.txn_type = FIFO_WRITE;
                    2'b01   : item.txn_type = FIFO_READ;
                    default : item.txn_type = FIFO_BOTH;
                endcase

                // Capture stimulus and status flags
                item.din      = vif.monitor_cb.din;
                item.full     = vif.monitor_cb.full;
                item.empty    = vif.monitor_cb.empty;
                item.count    = vif.monitor_cb.count;
                item.wr_valid = vif.monitor_cb.wr_en && !vif.monitor_cb.full;
                item.rd_valid = vif.monitor_cb.rd_en && !vif.monitor_cb.empty;

                // Fork: latch registered dout then broadcast
                fork
                    automatic fifo_seq_item fitem  = item;
                    automatic bit           need_rd = fitem.rd_valid;
                begin
                    if (need_rd)
                        @(vif.monitor_cb);   // registered output latches here
                    fitem.dout = vif.monitor_cb.dout;
                    ap.write(fitem);
                    `TB_DEBUG_MSG(name, fitem.sprint())
                end
                join_none
            end
        end
    endtask

endclass : fifo_monitor
