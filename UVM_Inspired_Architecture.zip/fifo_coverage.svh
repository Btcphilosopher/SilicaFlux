//==============================================================================
// fifo_coverage.svh — FIFO Functional Coverage Collector
//   Included by fifo_pkg.sv — not a standalone compilation unit.
//
//  Four covergroups:
//    fill_level_cg   — sample fill level: empty / low / mid / high / full
//    txn_type_cg     — transaction type × full × empty crosses
//    data_pattern_cg — corner data values (0x00, 0xFF, walking-ones)
//    boundary_cg     — overflow / underflow / near-boundary states
//
//  All groups are explicitly sampled (no auto-trigger) via sample().
//==============================================================================

class fifo_coverage extends tb_coverage #(fifo_seq_item);

    fifo_seq_item current;    // item being sampled (set before each sample())

    // ── Covergroup: fill level ────────────────────────────────────────────
    covergroup fill_level_cg;
        option.per_instance = 1;
        cp_fill: coverpoint current.count {
            bins empty         = {0};
            bins low           = {[1           : FIFO_DEPTH/4]};
            bins mid_low       = {[FIFO_DEPTH/4+1 : FIFO_DEPTH/2]};
            bins mid_high      = {[FIFO_DEPTH/2+1 : FIFO_DEPTH*3/4]};
            bins high          = {[FIFO_DEPTH*3/4+1 : FIFO_DEPTH-1]};
            bins full          = {FIFO_DEPTH};
        }
    endgroup

    // ── Covergroup: transaction type distribution ─────────────────────────
    covergroup txn_type_cg;
        option.per_instance = 1;
        cp_type: coverpoint current.txn_type {
            bins write = {FIFO_WRITE};
            bins read  = {FIFO_READ};
            bins both  = {FIFO_BOTH};
        }
        cp_full:  coverpoint current.full;
        cp_empty: coverpoint current.empty;

        // Key crosses: write-when-full, read-when-empty, simultaneous near boundary
        cx_type_full:  cross cp_type, cp_full;
        cx_type_empty: cross cp_type, cp_empty;
    endgroup

    // ── Covergroup: data value patterns ──────────────────────────────────
    covergroup data_pattern_cg;
        option.per_instance = 1;
        cp_din: coverpoint current.din {
            bins all_zeros  = {8'h00};
            bins all_ones   = {8'hFF};
            bins low_half   = {[8'h01 : 8'h7F]};
            bins high_half  = {[8'h80 : 8'hFE]};
            // Walking-one patterns
            bins walk1[] = {8'h01, 8'h02, 8'h04, 8'h08,
                            8'h10, 8'h20, 8'h40, 8'h80};
            // Walking-zero patterns
            bins walk0[] = {8'hFE, 8'hFD, 8'hFB, 8'hF7,
                            8'hEF, 8'hDF, 8'hBF, 8'h7F};
        }
    endgroup

    // ── Covergroup: boundary / corner conditions ──────────────────────────
    covergroup boundary_cg;
        option.per_instance = 1;
        // Write attempted when full (wr_en && full)
        cp_wr_full: coverpoint (current.txn_type[0] && current.full) {
            bins wr_while_full = {1'b1};
            bins wr_not_full   = {1'b0};
        }
        // Read attempted when empty (rd_en && empty)
        cp_rd_empty: coverpoint (current.txn_type[1] && current.empty) {
            bins rd_while_empty = {1'b1};
            bins rd_not_empty   = {1'b0};
        }
        // Fill boundary states
        cp_count_boundary: coverpoint current.count {
            bins exactly_full   = {FIFO_DEPTH};
            bins exactly_empty  = {0};
            bins one_from_full  = {FIFO_DEPTH - 1};
            bins one_from_empty = {1};
        }
    endgroup

    // ── Constructor ───────────────────────────────────────────────────────
    function new(string name = "fifo_coverage");
        super.new(name);
        fill_level_cg   = new();
        txn_type_cg     = new();
        data_pattern_cg = new();
        boundary_cg     = new();
    endfunction

    // ── sample: called by base class run() on each received transaction ───
    virtual function void sample(fifo_seq_item item);
        current = item;
        fill_level_cg.sample();
        txn_type_cg.sample();
        boundary_cg.sample();
        if (item.txn_type inside {FIFO_WRITE, FIFO_BOTH})
            data_pattern_cg.sample();
    endfunction

    // ── get_coverage: average across all covergroups ──────────────────────
    virtual function real get_coverage();
        return (fill_level_cg.get_inst_coverage()   +
                txn_type_cg.get_inst_coverage()     +
                data_pattern_cg.get_inst_coverage() +
                boundary_cg.get_inst_coverage()     ) / 4.0;
    endfunction

    // ── report ────────────────────────────────────────────────────────────
    virtual function void report();
        $display("");
        $display("  ┌──────────────────────────────────────────────┐");
        $display("  │  COVERAGE  %-33s│", name);
        $display("  ├──────────────────────────────────────────────┤");
        $display("  │  fill_level_cg     : %5.1f%%                 │",
                 fill_level_cg.get_inst_coverage());
        $display("  │  txn_type_cg       : %5.1f%%                 │",
                 txn_type_cg.get_inst_coverage());
        $display("  │  data_pattern_cg   : %5.1f%%                 │",
                 data_pattern_cg.get_inst_coverage());
        $display("  │  boundary_cg       : %5.1f%%                 │",
                 boundary_cg.get_inst_coverage());
        $display("  ├──────────────────────────────────────────────┤");
        $display("  │  Overall avg       : %5.1f%%                 │",
                 get_coverage());
        $display("  └──────────────────────────────────────────────┘");
    endfunction

endclass : fifo_coverage
