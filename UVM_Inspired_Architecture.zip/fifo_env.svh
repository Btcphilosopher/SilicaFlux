//==============================================================================
// fifo_env.svh — FIFO Verification Environment
//   Included by fifo_pkg.sv — not a standalone compilation unit.
//
//  Contains:
//    fifo_agent       — driver + monitor + sequencer
//    fifo_scoreboard  — reference model + data/flag checks
//    fifo_coverage    — functional coverage collector
//
//  Connection topology (connect_phase):
//    agent.monitor.ap  ──┬──► scoreboard.inbox
//                        └──► coverage.ap
//==============================================================================

class fifo_env extends tb_env;

    fifo_agent       agent;
    fifo_scoreboard  scoreboard;
    fifo_coverage    coverage;
    virtual fifo_if  vif;

    function new(string name = "fifo_env", virtual fifo_if vif_h);
        super.new(name);
        this.vif = vif_h;
    endfunction

    // ── build_phase ───────────────────────────────────────────────────────
    virtual function void build_phase();
        agent      = new({name, ".agent"},      vif, 1 /*active*/);
        scoreboard = new({name, ".scoreboard"});
        coverage   = new({name, ".coverage"});
        agent.build_phase();
        `TB_INFO(name, "Environment built")
    endfunction

    // ── connect_phase ─────────────────────────────────────────────────────
    virtual function void connect_phase();
        agent.connect_phase();
        // Fan-out: monitor.ap → scoreboard.inbox
        agent.monitor.ap.connect(scoreboard.inbox);
        // Fan-out: monitor.ap → coverage.ap
        agent.monitor.ap.connect(coverage.ap);
        `TB_INFO(name, "Environment connected")
    endfunction

    // ── run_phase: fork all background processes ──────────────────────────
    //  Tests call env.run_phase() in a fork so they can run sequences
    //  concurrently.  Sequences are started directly on agent.sequencer.
    virtual task run_phase();
        fork
            agent.run();
            scoreboard.run();
            coverage.run();
        join_none
    endtask

    // ── check_phase: surface scoreboard errors into tb_pkg counters ───────
    virtual function void check_phase();
        if (scoreboard.data_errors > 0)
            `TB_ERROR(name, $sformatf(
                "%0d data integrity error(s) detected", scoreboard.data_errors))
        if (scoreboard.flag_errors > 0)
            `TB_ERROR(name, $sformatf(
                "%0d flag error(s) detected", scoreboard.flag_errors))
        if (scoreboard.count_errors > 0)
            `TB_ERROR(name, $sformatf(
                "%0d count error(s) detected", scoreboard.count_errors))
    endfunction

    // ── report_phase ──────────────────────────────────────────────────────
    virtual function void report_phase();
        scoreboard.report();
        coverage.report();
    endfunction

endclass : fifo_env
