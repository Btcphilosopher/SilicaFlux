//==============================================================================
// fifo_tb_top.sv — Testbench Top-Level Module
//
//  Instantiates:
//    sync_fifo          — DUT
//    fifo_if            — verification interface (clocking blocks + modports)
//    fifo_sva           — assertion-based checker (bound to DUT signals)
//
//  Test selection via plusarg:
//    +TEST=fifo_basic_test       (default)
//    +TEST=fifo_random_test
//    +TEST=fifo_overflow_test
//
//  Verbosity via plusarg:
//    +VERBOSITY=0..5             (default 2 = TB_MEDIUM)
//==============================================================================
`timescale 1ns/1ps

`include "tb_defines.svh"

module fifo_tb_top;

    import tb_pkg::*;
    import fifo_pkg::*;
    import fifo_test_pkg::*;

    // ── DUT parameters ────────────────────────────────────────────────────
    localparam int DATA_WIDTH = FIFO_DATA_W;   // from fifo_pkg
    localparam int DEPTH      = FIFO_DEPTH;

    // ── Clock & reset ─────────────────────────────────────────────────────
    logic clk   = 1'b0;
    logic rst_n = 1'b0;

    always #5ns clk = ~clk;   // 100 MHz

    initial begin
        rst_n = 1'b0;
        repeat (4) @(posedge clk);
        @(negedge clk);        // deassert on falling edge for clean sampling
        rst_n = 1'b1;
        `TB_INFO("TOP", "Reset deasserted")
    end

    // ── Interface ─────────────────────────────────────────────────────────
    fifo_if #(DATA_WIDTH, DEPTH) vif (.clk(clk), .rst_n(rst_n));

    // ── DUT ───────────────────────────────────────────────────────────────
    sync_fifo #(
        .DATA_WIDTH (DATA_WIDTH),
        .DEPTH      (DEPTH)
    ) dut (
        .clk    (clk),
        .rst_n  (rst_n),
        .wr_en  (vif.wr_en),
        .din    (vif.din),
        .rd_en  (vif.rd_en),
        .dout   (vif.dout),
        .full   (vif.full),
        .empty  (vif.empty),
        .count  (vif.count)
    );

    // ── SVA checker ───────────────────────────────────────────────────────
    fifo_sva #(DATA_WIDTH, DEPTH) sva_checker (
        .clk    (clk),
        .rst_n  (rst_n),
        .wr_en  (vif.wr_en),
        .din    (vif.din),
        .rd_en  (vif.rd_en),
        .dout   (vif.dout),
        .full   (vif.full),
        .empty  (vif.empty),
        .count  (vif.count)
    );

    // ── Waveform dump ─────────────────────────────────────────────────────
    initial begin
        $dumpfile("fifo_sim.vcd");
        $dumpvars(0, fifo_tb_top);
    end

    // ── Test dispatch ─────────────────────────────────────────────────────
    initial begin : test_runner
        string test_name;
        int    verb;

        // Parse plusargs
        if (!$value$plusargs("TEST=%s",      test_name)) test_name = "fifo_basic_test";
        if (!$value$plusargs("VERBOSITY=%d", verb))      verb      = `TB_MEDIUM;
        tb_pkg::verbosity = verb;

        $display("");
        $display("╔══════════════════════════════════════════════════╗");
        $display("║   SV VERIFY FRAMEWORK  —  FIFO testbench        ║");
        $display("║   Test      : %-36s║", test_name);
        $display("║   DUT width : %0d-bit data, depth=%0d             ║", DATA_WIDTH, DEPTH);
        $display("╚══════════════════════════════════════════════════╝");
        $display("");

        // Wait for reset release + one clean clock
        @(posedge rst_n);
        @(posedge clk);

        // ── Select and run test ───────────────────────────────────────────
        case (test_name)
            "fifo_basic_test": begin
                fifo_basic_test t = new(vif);
                t.run();
            end
            "fifo_random_test": begin
                fifo_random_test t = new(vif);
                t.run();
            end
            "fifo_overflow_test": begin
                fifo_overflow_test t = new(vif);
                t.run();
            end
            default: begin
                `TB_FATAL("TOP", $sformatf(
                    "Unknown test '%s'. Valid: fifo_basic_test, fifo_random_test, fifo_overflow_test",
                    test_name))
            end
        endcase

        // ── Simulation complete ───────────────────────────────────────────
        $display("");
        $display("Simulation complete.  Errors=%0d  Passes=%0d",
                 tb_pkg::error_count, tb_pkg::pass_count);
        $finish;
    end : test_runner

endmodule : fifo_tb_top
