//==============================================================================
// fifo_test_pkg.sv — FIFO Test Package
//
//  Imports tb_pkg and fifo_pkg, then includes all test class definitions.
//  To add a new test:
//    1. Create   tb/tests/my_new_test.svh
//    2. Add      `include "my_new_test.svh"  below
//    3. Add a    case branch in fifo_tb_top.sv
//==============================================================================
`ifndef FIFO_TEST_PKG_SV
`define FIFO_TEST_PKG_SV

`include "tb_defines.svh"

package fifo_test_pkg;

    import tb_pkg::*;
    import fifo_pkg::*;

    `include "fifo_basic_test.svh"
    `include "fifo_random_test.svh"
    `include "fifo_overflow_test.svh"

endpackage : fifo_test_pkg

`endif // FIFO_TEST_PKG_SV
