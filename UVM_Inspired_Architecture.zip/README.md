# SV Verify Framework

A lightweight, UVM-inspired SystemVerilog verification framework for testing
digital designs. Demonstrates driver/monitor architecture, constrained-random
stimulus, scoreboard reference modelling, functional coverage, and
assertion-based verification — without requiring a full UVM install.

---

## Repository Layout

```
sv_verify_framework/
├── rtl/
│   └── sync_fifo.sv             — Parameterised synchronous FIFO (DUT)
├── tb/
│   ├── base/
│   │   ├── tb_defines.svh       — Logging / check macros
│   │   └── tb_pkg.sv            — Base framework package (all abstract classes)
│   ├── fifo/
│   │   ├── fifo_if.sv           — Verification interface (clocking blocks)
│   │   ├── fifo_seq_item.svh    — Sequence item with rand fields + constraints
│   │   ├── fifo_sequences.svh   — 8 sequence classes (directed + random)
│   │   ├── fifo_driver.svh      — Clocking-block driver with backpressure
│   │   ├── fifo_monitor.svh     — Non-blocking monitor (fork per transaction)
│   │   ├── fifo_scoreboard.svh  — Queue-based reference model
│   │   ├── fifo_coverage.svh    — 4 covergroups with crosses
│   │   ├── fifo_agent.svh       — Active/passive agent container
│   │   ├── fifo_env.svh         — Environment (wires agent → SB → cov)
│   │   ├── fifo_pkg.sv          — FIFO package (includes above .svh files)
│   │   └── fifo_sva.sv          — 11 SVA assertions + 6 cover properties
│   ├── tests/
│   │   ├── fifo_basic_test.svh  — Directed write-N / read-N test
│   │   ├── fifo_random_test.svh — Constrained-random + coverage thresholds
│   │   ├── fifo_overflow_test.svh — fill / overflow / drain / underflow
│   │   └── fifo_test_pkg.sv     — Test package
│   └── top/
│       └── fifo_tb_top.sv       — TB top: DUT + IF + SVA + test dispatch
├── sim/
│   └── compile.f                — Ordered file list for all simulators
├── Makefile                     — VCS / Questa / Xcelium / Icarus targets
└── README.md
```

---

## Quick Start

```bash
# VCS (default test)
make vcs

# Questa — random test
make questa TEST=fifo_random_test

# Xcelium — overflow corner case
make xcelium TEST=fifo_overflow_test

# Icarus Verilog (open source, no SVA/coverage)
make icarus

# Full regression (all 3 tests)
make regression_vcs

# Lint RTL only
make lint
```

---

## Framework Architecture

### Base Package (`tb_pkg`)

All base classes are parameterised with `#(type T = tb_transaction)`.

| Class | Role |
|---|---|
| `tb_transaction` | Base sequence item: ID, timestamp, `clone()`, `compare()`, `sprint()` |
| `tb_ap #(T)` | Analysis port broadcaster — fans out to N mailbox subscribers |
| `tb_sequencer #(T)` | Holds the shared driver/sequence mailbox |
| `tb_sequence #(T)` | Abstract — override `body()` |
| `tb_driver #(T)` | Abstract — override `drive_item()`; calls `run()` in fork |
| `tb_monitor #(T)` | Abstract — override `collect_item()`; broadcasts via `ap` |
| `tb_scoreboard #(T)` | Abstract — override `run()`, `check_txn()`, `report()` |
| `tb_coverage #(T)` | Abstract — override `sample()`, `get_coverage()` |
| `tb_env` | 5-phase lifecycle: build → connect → run → check → report |
| `tb_test` | Wraps env phases; prints result banner |

### Signal Flow

```
Sequences ──put()──► Sequencer mailbox ──get()──► Driver ──clock_block──► DUT
                                                                           │
                                                                      Monitor
                                                                      (fork/cb)
                                                                           │
                                                                       tb_ap
                                                                      /     \
                                                              Scoreboard   Coverage
                                                              (ref model)  (covergroups)
```

### Monitor Design

The FIFO has a **registered output** (dout valid one cycle after rd_en).
The monitor uses `fork..join_none` per transaction: the main loop advances
every clock and never misses back-to-back operations. A background task per
read transaction waits the extra cycle before broadcasting the complete item.

### Scoreboard Reference Model

A `logic[$]` queue mirrors the DUT's internal storage:

- **Write** (`wr_valid`): `ref_q.push_back(din)`, increment `expected_count`
- **Read**  (`rd_valid`): `ref_q.pop_front()`, compare with observed `dout`
- **Both**:  write processed first, then read — matching DUT semantics
- Validates `full`, `empty`, and `count` flags on every transaction

### SVA Assertions

| ID | Property |
|---|---|
| A1 | FIFO empty within one cycle of reset deassertion |
| A2 | `full` and `empty` never simultaneously asserted |
| A3 | `count` never exceeds DEPTH |
| A4 | `full` iff `count == DEPTH` |
| A5 | `empty` iff `count == 0` |
| A6 | Write-only: count increments by 1 |
| A7 | Read-only: count decrements by 1 |
| A8 | Simultaneous R/W: count stays stable |
| A9 | Overflow protection: write to full FIFO leaves count unchanged |
| A10 | Underflow protection: read from empty FIFO leaves count unchanged |
| A11 | Single-entry write-to-read data integrity |

Plus six `cover` properties verifying reachability of critical states.

### Functional Coverage (`fifo_coverage`)

| Covergroup | What it measures |
|---|---|
| `fill_level_cg` | Fill level: empty / low / mid-low / mid-high / high / full |
| `txn_type_cg` | Tx type × full flag cross; tx type × empty flag cross |
| `data_pattern_cg` | All-zeros, all-ones, walking-ones, walking-zeros, low/high byte |
| `boundary_cg` | wr-while-full, rd-while-empty, one-from-full, one-from-empty |

---

## Adding a New DUT

1. Write the RTL in `rtl/`.
2. Create `tb/<dut>/<dut>_if.sv` with appropriate clocking blocks.
3. Create `tb/<dut>/<dut>_pkg.sv` — import `tb_pkg::*`, set parameters,
   include component `.svh` files extending the base classes.
4. Create `tb/tests/<dut>_test_pkg.sv` with your test classes.
5. Create `tb/top/<dut>_tb_top.sv` — instantiate DUT, IF, SVA, dispatch.
6. Add entries to `sim/compile.f` and `Makefile`.

The base classes require only three overrides to be functional:
- `drive_item()` in your driver
- `collect_item()` (or override `run()`) in your monitor
- `run()` in your scoreboard

---

## Extending Constraints

Derive from `fifo_seq_item` and add constraint blocks:

```systemverilog
class fifo_write_heavy_item extends fifo_seq_item;
    // Override distribution: 80% writes
    constraint c_txn_dist {
        txn_type dist { FIFO_WRITE := 80, FIFO_READ := 15, FIFO_BOTH := 5 };
    }
    // Restrict data to a specific range
    constraint c_din_range { din inside {[8'h00:8'h0F]}; }
endclass
```

Then use it in a sequence:

```systemverilog
virtual task body();
    fifo_write_heavy_item item;
    repeat (100) begin
        item = new();
        void'(item.randomize());
        p_sequencer.send(item);
    end
endtask
```

---

## DUT Parameters

To change FIFO dimensions, update **two** places consistently:

```systemverilog
// tb/fifo/fifo_pkg.sv
parameter int FIFO_DATA_W = 16;   // ← change here
parameter int FIFO_DEPTH  = 32;

// tb/top/fifo_tb_top.sv  (and fifo_if instantiation)
// These read FIFO_DATA_W / FIFO_DEPTH from fifo_pkg — no edit needed.

// rtl/sync_fifo.sv instantiation in tb_top uses localparam aliases — also automatic.
```

---

## Verbosity Levels

| Level | Constant | Output |
|---|---|---|
| 0 | `TB_NONE` | Silent |
| 1 | `TB_LOW` | INFO messages (default) |
| 2 | `TB_MEDIUM` | + phase tracing |
| 3 | `TB_HIGH` | (reserved) |
| 5 | `TB_DEBUG` | + every driven/observed item |

Set at runtime: `+VERBOSITY=5`
