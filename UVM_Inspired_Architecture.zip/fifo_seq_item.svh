//==============================================================================
// fifo_seq_item.svh — FIFO Sequence Item
//   Included by fifo_pkg.sv — not a standalone compilation unit.
//
//  One item represents a single clock-cycle operation:
//    FIFO_WRITE : wr_en asserted;  din is randomised
//    FIFO_READ  : rd_en asserted;  dout captured by monitor
//    FIFO_BOTH  : simultaneous write + read
//
//  Response fields (full, empty, count, dout) are populated by the monitor
//  after the item is driven; they are not randomised.
//==============================================================================

typedef enum logic [1:0] {
    FIFO_WRITE = 2'b01,
    FIFO_READ  = 2'b10,
    FIFO_BOTH  = 2'b11
} fifo_txn_t;

class fifo_seq_item extends tb_transaction;

    // ── Randomised stimulus ───────────────────────────────────────────────
    rand fifo_txn_t              txn_type;
    rand logic [FIFO_DATA_W-1:0] din;

    // ── Response (filled by monitor) ──────────────────────────────────────
    logic [FIFO_DATA_W-1:0]  dout;
    logic                    full;
    logic                    empty;
    logic [FIFO_CNT_W-1:0]   count;
    bit                      wr_valid;    // wr_en && !full  at sample time
    bit                      rd_valid;    // rd_en && !empty at sample time

    // ── Constraints ───────────────────────────────────────────────────────

    // Default weight distribution: balanced with some simultaneous ops
    constraint c_txn_dist {
        txn_type dist {
            FIFO_WRITE := 40,
            FIFO_READ  := 40,
            FIFO_BOTH  := 20
        };
    }

    // Full data-bus coverage
    constraint c_din_range {
        din inside {[0 : (2**FIFO_DATA_W)-1]};
    }

    // ── Helper accessors ──────────────────────────────────────────────────
    function automatic logic wr_en(); return txn_type[0]; endfunction
    function automatic logic rd_en(); return txn_type[1]; endfunction

    // ── Lifecycle ─────────────────────────────────────────────────────────
    function new(string name = "fifo_seq_item");
        super.new();
    endfunction

    // Return type must match base class (tb_transaction); caller $casts back
    virtual function tb_transaction clone();
        fifo_seq_item item = new();
        item.txn_type  = this.txn_type;
        item.din       = this.din;
        item.dout      = this.dout;
        item.full      = this.full;
        item.empty     = this.empty;
        item.count     = this.count;
        item.wr_valid  = this.wr_valid;
        item.rd_valid  = this.rd_valid;
        return item;
    endfunction

    virtual function string sprint();
        return $sformatf(
            "TXN[%04d] %-5s | din=%02h dout=%02h | full=%b empty=%b count=%02d",
            txn_id, txn_type.name(), din, dout, full, empty, count);
    endfunction

    // Compare read-side data only
    virtual function bit compare(tb_transaction rhs);
        fifo_seq_item r;
        if (!$cast(r, rhs)) return 0;
        return (this.dout === r.dout);
    endfunction

endclass : fifo_seq_item
