//==============================================================================
// tb_defines.svh — Global macros for the SV Verify Framework
//==============================================================================
`ifndef TB_DEFINES_SVH
`define TB_DEFINES_SVH

// ---------------------------------------------------------------------------
// Verbosity levels
// ---------------------------------------------------------------------------
`define TB_NONE    0
`define TB_LOW     1
`define TB_MEDIUM  2
`define TB_HIGH    3
`define TB_DEBUG   5

// ---------------------------------------------------------------------------
// Logging
// ---------------------------------------------------------------------------
`define TB_INFO(comp, msg) \
    if (tb_pkg::verbosity >= `TB_LOW) \
        $display("[%8t ns][INFO ][%s] %s", $time, comp, msg);

`define TB_DEBUG_MSG(comp, msg) \
    if (tb_pkg::verbosity >= `TB_DEBUG) \
        $display("[%8t ns][DEBUG][%s] %s", $time, comp, msg);

`define TB_WARNING(comp, msg) \
    $display("[%8t ns][WARN ][%s] %s", $time, comp, msg);

// ---------------------------------------------------------------------------
// Error / Fatal  (macros must be usable as statements inside begin/end)
// ---------------------------------------------------------------------------
`define TB_ERROR(comp, msg) \
    begin \
        $display("[%8t ns][ERROR][%s] %s", $time, comp, msg); \
        tb_pkg::error_count++; \
    end

`define TB_FATAL(comp, msg) \
    begin \
        $display("[%8t ns][FATAL][%s] %s", $time, comp, msg); \
        $finish(1); \
    end

// ---------------------------------------------------------------------------
// Assertion-style check: counts pass/fail into the global tb_pkg counters
// ---------------------------------------------------------------------------
`define TB_CHECK(comp, expr, msg) \
    begin \
        if (!(expr)) begin \
            $display("[%8t ns][FAIL ][%s] %s", $time, comp, msg); \
            tb_pkg::error_count++; \
        end else begin \
            tb_pkg::pass_count++; \
        end \
    end

// ---------------------------------------------------------------------------
// Phase tracing
// ---------------------------------------------------------------------------
`define TB_PHASE_START(pname) \
    if (tb_pkg::verbosity >= `TB_MEDIUM) \
        $display("[%8t ns][ >> ] %s", $time, pname);

`define TB_PHASE_END(pname) \
    if (tb_pkg::verbosity >= `TB_MEDIUM) \
        $display("[%8t ns][ << ] %s", $time, pname);

`endif // TB_DEFINES_SVH
